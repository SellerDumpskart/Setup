# VidyaMate — School Management System

A complete, production-ready School Management System built with React, Node.js, and PostgreSQL.

---

## 🏗 Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React 18, Recharts, Zustand, React Router v6 |
| Backend | Node.js, Express.js, JWT Auth |
| Database | PostgreSQL 16 |
| Cache | Redis 7 |
| File Storage | Local (dev) / AWS S3 (prod) |
| Notifications | NodeMailer (email), MSG91 (SMS) |
| Payments | Razorpay |

---

## 📁 Project Structure

```
vidyamate/
├── backend/
│   ├── src/
│   │   ├── config/         # DB connection, migrate, seed
│   │   ├── controllers/    # Business logic (auth, students, fees, etc.)
│   │   ├── middleware/     # Auth, error handler, audit log
│   │   ├── routes/         # All API endpoints
│   │   ├── services/       # Email, SMS, payments, file upload
│   │   └── utils/          # Logger
│   ├── uploads/            # Local file storage
│   └── .env.example
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   │   ├── common/     # Shared UI (Table, Modal, Button, etc.)
│   │   │   └── layout/     # Sidebar, Navbar, Layouts
│   │   ├── pages/
│   │   │   ├── auth/       # Login
│   │   │   ├── admin/      # Super admin pages
│   │   │   └── school/     # All school module pages
│   │   ├── services/       # Axios API client
│   │   └── store/          # Zustand auth store
│   └── public/
└── database/
    ├── migrations/         # SQL schema files
    └── seeds/              # Default data
```

---

## 🚀 Quick Start

### Prerequisites
- Node.js 18+
- PostgreSQL 16
- Redis 7

### 1. Clone and install

```bash
# Install backend dependencies
cd vidyamate/backend
npm install

# Install frontend dependencies
cd ../frontend
npm install
```

### 2. Configure environment

```bash
cd backend
cp .env.example .env
# Edit .env with your DB credentials and API keys
```

### 3. Set up database

```bash
# Create the database
psql -U postgres -c "CREATE DATABASE vidyamate;"
psql -U postgres -c "CREATE USER vidyamate_user WITH PASSWORD 'vidyamate_pass';"
psql -U postgres -c "GRANT ALL PRIVILEGES ON DATABASE vidyamate TO vidyamate_user;"

# Run migrations
cd backend
npm run migrate

# Seed default data (super admin + master values)
npm run seed
```

### 4. Start the servers

```bash
# Terminal 1: Start backend (port 4000)
cd backend
npm run dev

# Terminal 2: Start frontend (port 3000)
cd frontend
npm start
```

### 5. Login

Open http://localhost:3000 and login with:
- **Email:** admin@vidyamate.in
- **Password:** Admin@123

---

## 🐳 Docker (Alternative)

```bash
cd vidyamate
docker-compose up -d

# Run migrations inside container
docker exec vidyamate_api npm run migrate
docker exec vidyamate_api npm run seed
```

---

## 📋 Modules

| Module | Route | Description |
|--------|-------|-------------|
| Dashboard | /school | Live stats, charts, quick actions |
| Students | /school/students | Admission, profiles, documents |
| Attendance | /school/attendance | Daily marking, reports |
| Fees | /school/fees | Collection, receipts, discounts |
| Exams | /school/exams | Schedule, marks, results |
| Hall Tickets | /school/hall-tickets | Generate, download PDFs |
| Staff | /school/staff | Staff master, HR |
| Payroll | /school/payroll | Monthly salary processing |
| Leave | /school/leave | Applications, approvals |
| Hostel | /school/hostel | Room allocation |
| Transport | /school/transport | Routes, stops |
| Timetable | /school/timetable | Class schedules |
| LMS | /school/lms | Study materials, assignments |
| Teacher Desk | /school/teacher-desk | Homework, diary |
| Communication | /school/communication | SMS, email broadcast |
| Notices | /school/notices | Circulars, announcements |
| Expenditure | /school/expenditure | Expense tracking |
| Reports | /school/reports | Analytics & exports |
| Admin | /admin | Organizations, schools, users |

---

## 🔐 API Endpoints

All endpoints require `Authorization: Bearer <access_token>` header.

### Auth
```
POST /api/v1/auth/login
POST /api/v1/auth/refresh
POST /api/v1/auth/logout
GET  /api/v1/auth/me
POST /api/v1/auth/change-password
```

### Students
```
GET    /api/v1/students
POST   /api/v1/students
GET    /api/v1/students/:id
PUT    /api/v1/students/:id
DELETE /api/v1/students/:id
```

### Attendance
```
GET  /api/v1/attendance?classId=&date=
POST /api/v1/attendance/mark
GET  /api/v1/attendance/report?classId=&month=&year=
GET  /api/v1/attendance/summary
```

### Fees
```
GET  /api/v1/fees/heads
POST /api/v1/fees/collect
GET  /api/v1/fees/payments
POST /api/v1/fees/discount
GET  /api/v1/fees/defaulters
```

### Reports
```
GET /api/v1/reports/overview
GET /api/v1/reports/attendance-trend
GET /api/v1/reports/fee-collection
GET /api/v1/reports/class-strength
GET /api/v1/reports/top-performers
GET /api/v1/reports/expenditure
```

---

## 🔑 Environment Variables

```env
# Server
PORT=4000
NODE_ENV=development

# Database
DATABASE_URL=postgresql://vidyamate_user:vidyamate_pass@localhost:5432/vidyamate

# Auth
JWT_SECRET=your_jwt_secret_here
JWT_REFRESH_SECRET=your_refresh_secret_here
JWT_EXPIRES_IN=15m
JWT_REFRESH_EXPIRES_IN=7d

# Email (optional)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your@gmail.com
SMTP_PASS=your_app_password

# SMS - MSG91 (optional)
MSG91_AUTH_KEY=your_msg91_key

# Razorpay (optional)
RAZORPAY_KEY_ID=rzp_test_xxxxx
RAZORPAY_KEY_SECRET=your_secret
```

---

## 👥 User Roles

| Role | Access |
|------|--------|
| super_admin | Full system access |
| org_admin | All schools in their organization |
| principal | Full school access |
| teacher | Attendance, marks for their classes |
| accountant | Fees, payroll, expenditure |
| non_teaching | Limited read access |

---

## 📦 Production Deployment

1. Set `NODE_ENV=production` in backend `.env`
2. Build frontend: `npm run build`
3. Serve frontend build with nginx
4. Use PM2 for backend: `pm2 start src/index.js --name vidyamate-api`
5. Set up PostgreSQL with replication
6. Configure Redis for session caching
7. Point `UPLOAD_DIR` to S3 bucket (or use MinIO)
8. Set up SSL certificates (Let's Encrypt)
9. Configure nginx reverse proxy

---

## 🧪 Default Credentials

After seeding:
- **Super Admin:** admin@vidyamate.in / Admin@123

---

Built with ❤️ — VidyaMate School Management System
