-- =============================================================
-- VIDYAMATE - MISSING MODULES SCHEMA
-- Migration: 002_missing_modules.sql
-- =============================================================

-- =============================================================
-- 1. TIMETABLE
-- =============================================================
CREATE TABLE timetable_periods (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  school_id   UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  period_no   INT  NOT NULL,
  period_name VARCHAR(30),          -- e.g. "Period 1", "Break", "Lunch"
  start_time  TIME NOT NULL,
  end_time    TIME NOT NULL,
  is_break    BOOLEAN DEFAULT FALSE,
  created_at  TIMESTAMP DEFAULT NOW(),
  UNIQUE(school_id, period_no)
);

CREATE TABLE timetable (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  school_id   UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  class_id    UUID NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
  session_id  UUID NOT NULL REFERENCES academic_sessions(id),
  period_id   UUID NOT NULL REFERENCES timetable_periods(id) ON DELETE CASCADE,
  day_of_week INT  NOT NULL CHECK (day_of_week BETWEEN 1 AND 7),
  -- 1=Monday, 2=Tuesday ... 7=Sunday
  subject_id  UUID REFERENCES subjects(id) ON DELETE SET NULL,
  teacher_id  UUID REFERENCES staff(id)   ON DELETE SET NULL,
  room_no     VARCHAR(20),
  created_at  TIMESTAMP DEFAULT NOW(),
  updated_at  TIMESTAMP DEFAULT NOW(),
  UNIQUE(class_id, period_id, day_of_week, session_id)
);

-- =============================================================
-- 2. LMS - LEARNING MANAGEMENT SYSTEM
-- =============================================================
CREATE TABLE lms_content (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  school_id    UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  class_id     UUID REFERENCES classes(id) ON DELETE SET NULL,
  subject_id   UUID REFERENCES subjects(id) ON DELETE SET NULL,
  teacher_id   UUID REFERENCES staff(id)   ON DELETE SET NULL,
  session_id   UUID REFERENCES academic_sessions(id),
  title        VARCHAR(255) NOT NULL,
  description  TEXT,
  content_type VARCHAR(30) DEFAULT 'document'
               CHECK (content_type IN ('document','video','audio','image',
                                       'link','assignment','quiz','other')),
  file_url     VARCHAR(500),
  external_url VARCHAR(500),
  is_published BOOLEAN DEFAULT FALSE,
  published_at TIMESTAMP,
  due_date     TIMESTAMP,               -- for assignments
  max_marks    INT,                     -- for assignments/quizzes
  created_at   TIMESTAMP DEFAULT NOW(),
  updated_at   TIMESTAMP DEFAULT NOW()
);

CREATE TABLE lms_submissions (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  content_id      UUID NOT NULL REFERENCES lms_content(id) ON DELETE CASCADE,
  student_id      UUID NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  file_url        VARCHAR(500),
  text_answer     TEXT,
  submitted_at    TIMESTAMP DEFAULT NOW(),
  marks_obtained  DECIMAL(6,2),
  feedback        TEXT,
  graded_by       UUID REFERENCES staff(id) ON DELETE SET NULL,
  graded_at       TIMESTAMP,
  status          VARCHAR(20) DEFAULT 'submitted'
                  CHECK (status IN ('draft','submitted','graded','late')),
  UNIQUE(content_id, student_id)
);

CREATE TABLE lms_online_classes (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  school_id    UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  class_id     UUID REFERENCES classes(id) ON DELETE SET NULL,
  subject_id   UUID REFERENCES subjects(id) ON DELETE SET NULL,
  teacher_id   UUID REFERENCES staff(id) ON DELETE SET NULL,
  title        VARCHAR(255) NOT NULL,
  description  TEXT,
  meeting_link VARCHAR(500),           -- Zoom/Google Meet link
  platform     VARCHAR(30) DEFAULT 'zoom'
               CHECK (platform IN ('zoom','google_meet','microsoft_teams','other')),
  scheduled_at TIMESTAMP NOT NULL,
  duration_min INT DEFAULT 60,
  recording_url VARCHAR(500),
  status       VARCHAR(20) DEFAULT 'scheduled'
               CHECK (status IN ('scheduled','live','completed','cancelled')),
  created_at   TIMESTAMP DEFAULT NOW()
);

-- =============================================================
-- 3. TEACHER DESK
-- =============================================================
CREATE TABLE teacher_homework (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  school_id    UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  class_id     UUID NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
  subject_id   UUID NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
  teacher_id   UUID NOT NULL REFERENCES staff(id)   ON DELETE CASCADE,
  session_id   UUID NOT NULL REFERENCES academic_sessions(id),
  title        VARCHAR(255) NOT NULL,
  description  TEXT,
  file_url     VARCHAR(500),
  assigned_date DATE DEFAULT CURRENT_DATE,
  due_date      DATE,
  status        VARCHAR(20) DEFAULT 'active'
                CHECK (status IN ('active','completed','cancelled')),
  created_at    TIMESTAMP DEFAULT NOW()
);

CREATE TABLE teacher_marks_entry (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  student_id    UUID NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  exam_id       UUID NOT NULL REFERENCES exams(id)    ON DELETE CASCADE,
  subject_id    UUID NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
  teacher_id    UUID REFERENCES staff(id) ON DELETE SET NULL,
  marks         DECIMAL(6,2),
  max_marks     INT DEFAULT 100,
  is_absent     BOOLEAN DEFAULT FALSE,
  remarks       TEXT,
  entered_at    TIMESTAMP DEFAULT NOW(),
  updated_at    TIMESTAMP DEFAULT NOW(),
  UNIQUE(student_id, exam_id, subject_id)
);

CREATE TABLE teacher_diary (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  teacher_id  UUID NOT NULL REFERENCES staff(id) ON DELETE CASCADE,
  school_id   UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  class_id    UUID REFERENCES classes(id) ON DELETE SET NULL,
  subject_id  UUID REFERENCES subjects(id) ON DELETE SET NULL,
  diary_date  DATE DEFAULT CURRENT_DATE,
  content     TEXT NOT NULL,
  created_at  TIMESTAMP DEFAULT NOW()
);

-- =============================================================
-- 4. SCHOOL COMMUNICATION (enhanced)
-- =============================================================
CREATE TABLE communication_templates (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  school_id    UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  template_name VARCHAR(100) NOT NULL,
  template_type VARCHAR(20) DEFAULT 'sms'
                CHECK (template_type IN ('sms','email','push')),
  subject      VARCHAR(255),           -- for email
  body         TEXT NOT NULL,
  -- Placeholders: {{student_name}}, {{fee_amount}}, {{due_date}}, etc.
  variables    JSONB DEFAULT '[]',
  is_active    BOOLEAN DEFAULT TRUE,
  created_at   TIMESTAMP DEFAULT NOW(),
  UNIQUE(school_id, template_name, template_type)
);

CREATE TABLE bulk_communications (
  id             UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  school_id      UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  template_id    UUID REFERENCES communication_templates(id) ON DELETE SET NULL,
  title          VARCHAR(255) NOT NULL,
  message        TEXT NOT NULL,
  channel        VARCHAR(20) DEFAULT 'sms'
                 CHECK (channel IN ('sms','email','push','whatsapp','all')),
  target_group   VARCHAR(30) DEFAULT 'all'
                 CHECK (target_group IN ('all','class','parents','staff',
                                         'teachers','custom')),
  target_class_id UUID REFERENCES classes(id) ON DELETE SET NULL,
  total_recipients INT DEFAULT 0,
  sent_count      INT DEFAULT 0,
  failed_count    INT DEFAULT 0,
  status          VARCHAR(20) DEFAULT 'draft'
                  CHECK (status IN ('draft','queued','sending','sent','failed')),
  scheduled_at    TIMESTAMP,
  sent_at         TIMESTAMP,
  created_by      UUID REFERENCES users(id) ON DELETE SET NULL,
  created_at      TIMESTAMP DEFAULT NOW()
);

CREATE TABLE parent_messages (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  school_id    UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  parent_id    UUID REFERENCES parents(id) ON DELETE CASCADE,
  staff_id     UUID REFERENCES staff(id)  ON DELETE SET NULL,
  student_id   UUID REFERENCES students(id) ON DELETE SET NULL,
  sender_type  VARCHAR(10) NOT NULL CHECK (sender_type IN ('parent','staff')),
  message      TEXT NOT NULL,
  is_read      BOOLEAN DEFAULT FALSE,
  read_at      TIMESTAMP,
  created_at   TIMESTAMP DEFAULT NOW()
);

-- =============================================================
-- 5. TRANSPORT (full expansion)
-- =============================================================
CREATE TABLE transport_stops (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  route_id    UUID NOT NULL REFERENCES transport_routes(id) ON DELETE CASCADE,
  stop_name   VARCHAR(100) NOT NULL,
  stop_order  INT NOT NULL,
  pickup_time TIME,
  drop_time   TIME,
  latitude    DECIMAL(10,8),
  longitude   DECIMAL(11,8),
  created_at  TIMESTAMP DEFAULT NOW(),
  UNIQUE(route_id, stop_order)
);

CREATE TABLE vehicle_maintenance (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  school_id    UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  vehicle_no   VARCHAR(20) NOT NULL,
  service_type VARCHAR(100),
  service_date DATE DEFAULT CURRENT_DATE,
  next_service_date DATE,
  cost         DECIMAL(10,2) DEFAULT 0,
  remarks      TEXT,
  created_at   TIMESTAMP DEFAULT NOW()
);

-- =============================================================
-- INDEXES for new tables
-- =============================================================
CREATE INDEX idx_timetable_class    ON timetable(class_id, session_id, day_of_week);
CREATE INDEX idx_lms_content_class  ON lms_content(class_id, subject_id);

-- =============================================================
-- 6. BIOMETRIC INTEGRATION (ZKTeco)
-- =============================================================

-- Registered devices
CREATE TABLE biometric_devices (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  school_id    UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  device_name  VARCHAR(100) NOT NULL,
  device_id    VARCHAR(100) NOT NULL,         -- hardware serial / IP
  location     VARCHAR(150),
  secret_key   VARCHAR(255) NOT NULL,         -- per-device HMAC key shown once
  last_ping    TIMESTAMP,
  is_active    BOOLEAN DEFAULT TRUE,
  created_at   TIMESTAMP DEFAULT NOW(),
  UNIQUE(school_id, device_id)
);

-- Log of punches whose user_id could not be matched
CREATE TABLE biometric_unmatched_log (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  school_id    UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  device_id    VARCHAR(100) NOT NULL,
  user_id      VARCHAR(100) NOT NULL,         -- raw value from punch payload
  punch_time   TIMESTAMP NOT NULL,
  punch_type   SMALLINT NOT NULL,             -- 0=check-in, 1=check-out
  raw_payload  JSONB,
  resolved     BOOLEAN DEFAULT FALSE,
  created_at   TIMESTAMP DEFAULT NOW()
);

-- Manual mapping: biometric user_id → student or staff
CREATE TABLE biometric_user_map (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  school_id    UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  device_id    VARCHAR(100),                  -- NULL = applies to all devices
  biometric_user_id VARCHAR(100) NOT NULL,
  entity_type  VARCHAR(10) NOT NULL CHECK (entity_type IN ('student','staff')),
  entity_id    UUID NOT NULL,
  created_at   TIMESTAMP DEFAULT NOW(),
  UNIQUE(school_id, biometric_user_id)
);

-- Add source column to student_attendance (idempotent)
DO $$ BEGIN
  ALTER TABLE student_attendance ADD COLUMN source VARCHAR(20) DEFAULT 'manual';
EXCEPTION WHEN duplicate_column THEN NULL; END $$;

-- Add source column to staff_attendance (idempotent)
DO $$ BEGIN
  ALTER TABLE staff_attendance ADD COLUMN source VARCHAR(20) DEFAULT 'manual';
EXCEPTION WHEN duplicate_column THEN NULL; END $$;

CREATE INDEX idx_biometric_unmatched_school ON biometric_unmatched_log(school_id, resolved);
CREATE INDEX idx_biometric_user_map_uid     ON biometric_user_map(school_id, biometric_user_id);
CREATE INDEX idx_lms_submissions    ON lms_submissions(content_id, student_id);
CREATE INDEX idx_homework_class     ON teacher_homework(class_id, subject_id);
CREATE INDEX idx_marks_entry        ON teacher_marks_entry(exam_id, subject_id);
CREATE INDEX idx_bulk_comm_school   ON bulk_communications(school_id, status);
CREATE INDEX idx_parent_messages    ON parent_messages(school_id, parent_id);
CREATE INDEX idx_transport_stops    ON transport_stops(route_id, stop_order);
