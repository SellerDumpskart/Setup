-- =============================================================
-- VIDYAMATE - COMPLETE DATABASE SCHEMA
-- Version: 1.0.0
-- =============================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- =============================================================
-- 1. ORGANIZATIONS
-- =============================================================
CREATE TABLE organizations (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name        VARCHAR(255) NOT NULL UNIQUE,
  reg_number  VARCHAR(100) UNIQUE,
  since_date  DATE,
  logo_url    VARCHAR(500),
  address     TEXT,
  phone       VARCHAR(20),
  email       VARCHAR(100),
  website     VARCHAR(255),
  status      VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active','inactive')),
  created_at  TIMESTAMP DEFAULT NOW(),
  updated_at  TIMESTAMP DEFAULT NOW()
);

-- =============================================================
-- 2. SCHOOLS
-- =============================================================
CREATE TABLE schools (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE RESTRICT,
  name            VARCHAR(255) NOT NULL,
  logo_url        VARCHAR(500),
  contact_number  VARCHAR(20),
  email           VARCHAR(100),
  address         TEXT,
  city            VARCHAR(100),
  state           VARCHAR(100),
  pincode         VARCHAR(10),
  affiliation_no  VARCHAR(100),
  medium          VARCHAR(50),
  school_type     VARCHAR(50) DEFAULT 'English Medium',
  status          VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active','inactive')),
  created_at      TIMESTAMP DEFAULT NOW(),
  updated_at      TIMESTAMP DEFAULT NOW(),
  UNIQUE(organization_id, name)
);

-- =============================================================
-- 3. ACADEMIC SESSIONS
-- =============================================================
CREATE TABLE academic_sessions (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE RESTRICT,
  session_name    VARCHAR(100) NOT NULL,
  start_date      DATE NOT NULL,
  end_date        DATE NOT NULL,
  is_current      BOOLEAN DEFAULT FALSE,
  created_at      TIMESTAMP DEFAULT NOW(),
  updated_at      TIMESTAMP DEFAULT NOW(),
  UNIQUE(organization_id, session_name),
  CHECK(end_date > start_date)
);

-- =============================================================
-- 4. MASTER CONFIGURATION (single table for all master types)
-- =============================================================
CREATE TABLE masters (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  master_type     VARCHAR(50) NOT NULL,
  -- Types: cancel_reason, concession, designation, document_type,
  --        education, occupation, mother_tongue, nationality,
  --        religion, special_fee, scholarship, discount_reason,
  --        medium, blood_group, category, expense_category
  value           VARCHAR(255) NOT NULL,
  code            VARCHAR(50),
  sort_order      INT DEFAULT 0,
  is_default      BOOLEAN DEFAULT FALSE,
  status          VARCHAR(20) DEFAULT 'active',
  created_at      TIMESTAMP DEFAULT NOW(),
  UNIQUE(organization_id, master_type, value)
);

-- =============================================================
-- 5. USERS (admins, teachers, staff with system access)
-- =============================================================
CREATE TABLE users (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  school_id       UUID REFERENCES schools(id) ON DELETE SET NULL,
  organization_id UUID REFERENCES organizations(id) ON DELETE SET NULL,
  username        VARCHAR(100) NOT NULL UNIQUE,
  email           VARCHAR(150) NOT NULL UNIQUE,
  password_hash   VARCHAR(255) NOT NULL,
  first_name      VARCHAR(100),
  last_name       VARCHAR(100),
  phone           VARCHAR(20),
  photo_url       VARCHAR(500),
  role            VARCHAR(30) NOT NULL DEFAULT 'teacher'
                  CHECK (role IN ('super_admin','org_admin','principal','teacher',
                                  'accountant','non_teaching','parent')),
  is_active       BOOLEAN DEFAULT TRUE,
  last_login      TIMESTAMP,
  reset_token     VARCHAR(255),
  reset_token_exp TIMESTAMP,
  two_fa_secret   VARCHAR(100),
  two_fa_enabled  BOOLEAN DEFAULT FALSE,
  created_at      TIMESTAMP DEFAULT NOW(),
  updated_at      TIMESTAMP DEFAULT NOW()
);

-- =============================================================
-- 6. STAFF (all school staff including teachers)
-- =============================================================
CREATE TABLE staff (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  school_id       UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  user_id         UUID REFERENCES users(id) ON DELETE SET NULL,
  emp_no          VARCHAR(30) NOT NULL,
  first_name      VARCHAR(100) NOT NULL,
  last_name       VARCHAR(100),
  gender          VARCHAR(10) CHECK (gender IN ('male','female','other')),
  date_of_birth   DATE,
  date_of_joining DATE,
  phone           VARCHAR(20),
  email           VARCHAR(150),
  address         TEXT,
  city            VARCHAR(100),
  state           VARCHAR(100),
  qualification   VARCHAR(100),
  designation     VARCHAR(100),
  department      VARCHAR(100),
  staff_type      VARCHAR(30) DEFAULT 'teaching'
                  CHECK (staff_type IN ('teaching','non_teaching','admin','support')),
  salary          DECIMAL(10,2) DEFAULT 0,
  photo_url       VARCHAR(500),
  aadhaar_no      VARCHAR(12),
  pan_no          VARCHAR(10),
  bank_account    VARCHAR(20),
  bank_ifsc       VARCHAR(11),
  bank_name       VARCHAR(100),
  status          VARCHAR(20) DEFAULT 'active'
                  CHECK (status IN ('active','inactive','resigned','terminated')),
  created_at      TIMESTAMP DEFAULT NOW(),
  updated_at      TIMESTAMP DEFAULT NOW(),
  UNIQUE(school_id, emp_no)
);

-- =============================================================
-- 7. CLASSES
-- =============================================================
CREATE TABLE classes (
  id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  school_id        UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  session_id       UUID NOT NULL REFERENCES academic_sessions(id) ON DELETE CASCADE,
  class_name       VARCHAR(50) NOT NULL,
  section          VARCHAR(10) NOT NULL DEFAULT 'A',
  capacity         INT DEFAULT 50,
  class_teacher_id UUID REFERENCES staff(id) ON DELETE SET NULL,
  room_number      VARCHAR(20),
  created_at       TIMESTAMP DEFAULT NOW(),
  updated_at       TIMESTAMP DEFAULT NOW(),
  UNIQUE(school_id, session_id, class_name, section)
);

-- =============================================================
-- 8. SUBJECTS
-- =============================================================
CREATE TABLE subjects (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  school_id   UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  subject_name VARCHAR(100) NOT NULL,
  subject_code VARCHAR(20),
  description TEXT,
  is_language  BOOLEAN DEFAULT FALSE,
  status       VARCHAR(20) DEFAULT 'active',
  created_at   TIMESTAMP DEFAULT NOW(),
  UNIQUE(school_id, subject_name)
);

-- =============================================================
-- 9. CLASS-SUBJECT MAPPING
-- =============================================================
CREATE TABLE class_subjects (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  class_id      UUID NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
  subject_id    UUID NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
  teacher_id    UUID REFERENCES staff(id) ON DELETE SET NULL,
  is_compulsory BOOLEAN DEFAULT TRUE,
  max_marks     INT DEFAULT 100,
  pass_marks    INT DEFAULT 35,
  created_at    TIMESTAMP DEFAULT NOW(),
  UNIQUE(class_id, subject_id)
);

-- =============================================================
-- 10. PARENTS / GUARDIANS
-- =============================================================
CREATE TABLE parents (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  school_id    UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  user_id      UUID REFERENCES users(id) ON DELETE SET NULL,
  father_name  VARCHAR(100),
  father_phone VARCHAR(20),
  father_email VARCHAR(150),
  father_occ   VARCHAR(100),
  father_income DECIMAL(12,2),
  mother_name  VARCHAR(100),
  mother_phone VARCHAR(20),
  mother_email VARCHAR(150),
  mother_occ   VARCHAR(100),
  mother_income DECIMAL(12,2),
  guardian_name  VARCHAR(100),
  guardian_phone VARCHAR(20),
  guardian_rel   VARCHAR(50),
  address      TEXT,
  city         VARCHAR(100),
  state        VARCHAR(100),
  pincode      VARCHAR(10),
  created_at   TIMESTAMP DEFAULT NOW(),
  updated_at   TIMESTAMP DEFAULT NOW()
);

-- =============================================================
-- 11. STUDENTS
-- =============================================================
CREATE TABLE students (
  id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  school_id           UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  session_id          UUID NOT NULL REFERENCES academic_sessions(id),
  class_id            UUID REFERENCES classes(id) ON DELETE SET NULL,
  parent_id           UUID REFERENCES parents(id) ON DELETE SET NULL,
  student_code        VARCHAR(30) UNIQUE,
  pen_number          VARCHAR(50),
  apaar_id            VARCHAR(50),
  child_id            VARCHAR(50),
  application_no      VARCHAR(50),
  aadhaar_no          VARCHAR(12),
  admission_no        VARCHAR(50),
  -- Personal
  first_name          VARCHAR(100) NOT NULL,
  last_name           VARCHAR(100),
  date_of_birth       DATE,
  gender              VARCHAR(10) CHECK (gender IN ('male','female','other')),
  blood_group         VARCHAR(5),
  category            VARCHAR(50),
  religion            VARCHAR(50),
  caste               VARCHAR(50),
  nationality         VARCHAR(50) DEFAULT 'Indian',
  mother_tongue       VARCHAR(50),
  identification_mark TEXT,
  height              DECIMAL(5,2),
  weight              DECIMAL(5,2),
  medical_conditions  TEXT,
  -- Enrollment
  admission_date      DATE DEFAULT CURRENT_DATE,
  roll_number         INT,
  section             VARCHAR(10),
  -- Previous school
  prev_school         VARCHAR(255),
  prev_class          VARCHAR(50),
  prev_percentage     DECIMAL(5,2),
  tc_number           VARCHAR(50),
  tc_submitted        BOOLEAN DEFAULT FALSE,
  -- Photos & docs
  photo_url           VARCHAR(500),
  birth_cert_url      VARCHAR(500),
  tc_url              VARCHAR(500),
  aadhaar_url         VARCHAR(500),
  caste_cert_url      VARCHAR(500),
  income_cert_url     VARCHAR(500),
  -- Status
  status              VARCHAR(20) DEFAULT 'active'
                      CHECK (status IN ('active','alumni','dropped',
                                        'transferred','cancelled')),
  cancel_reason       VARCHAR(100),
  created_at          TIMESTAMP DEFAULT NOW(),
  updated_at          TIMESTAMP DEFAULT NOW()
);

-- =============================================================
-- 12. ROLL NUMBER ALLOTMENT
-- =============================================================
CREATE TABLE roll_numbers (
  id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  student_id UUID NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  class_id   UUID NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
  session_id UUID NOT NULL REFERENCES academic_sessions(id),
  roll_no    INT NOT NULL,
  created_at TIMESTAMP DEFAULT NOW(),
  UNIQUE(class_id, session_id, roll_no)
);

-- =============================================================
-- 13. HOLIDAYS
-- =============================================================
CREATE TABLE holidays (
  id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  school_id           UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  session_id          UUID NOT NULL REFERENCES academic_sessions(id),
  holiday_name        VARCHAR(255) NOT NULL,
  holiday_type        VARCHAR(50) DEFAULT 'government'
                      CHECK (holiday_type IN ('government','school','festival','exam','other')),
  from_date           DATE NOT NULL,
  to_date             DATE NOT NULL,
  applicable_to       VARCHAR(20) DEFAULT 'all'
                      CHECK (applicable_to IN ('all','students','staff')),
  description         TEXT,
  created_at          TIMESTAMP DEFAULT NOW(),
  updated_at          TIMESTAMP DEFAULT NOW(),
  CHECK(to_date >= from_date)
);

-- =============================================================
-- 14. STUDENT ATTENDANCE
-- =============================================================
CREATE TABLE student_attendance (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  student_id      UUID NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  class_id        UUID NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
  session_id      UUID NOT NULL REFERENCES academic_sessions(id),
  attendance_date DATE NOT NULL,
  status          VARCHAR(20) DEFAULT 'present'
                  CHECK (status IN ('present','absent','holiday','leave','late')),
  reason          TEXT,
  marked_by       UUID REFERENCES staff(id) ON DELETE SET NULL,
  created_at      TIMESTAMP DEFAULT NOW(),
  updated_at      TIMESTAMP DEFAULT NOW(),
  UNIQUE(student_id, attendance_date)
);

-- =============================================================
-- 15. STAFF ATTENDANCE
-- =============================================================
CREATE TABLE staff_attendance (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  staff_id        UUID NOT NULL REFERENCES staff(id) ON DELETE CASCADE,
  session_id      UUID NOT NULL REFERENCES academic_sessions(id),
  attendance_date DATE NOT NULL,
  status          VARCHAR(20) DEFAULT 'present'
                  CHECK (status IN ('present','absent','holiday','leave','half_day')),
  in_time         TIME,
  out_time        TIME,
  reason          TEXT,
  marked_by       UUID REFERENCES users(id) ON DELETE SET NULL,
  created_at      TIMESTAMP DEFAULT NOW(),
  UNIQUE(staff_id, attendance_date)
);

-- =============================================================
-- 16. FEE HEADS (fee categories configured per school per session)
-- =============================================================
CREATE TABLE fee_heads (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  school_id    UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  session_id   UUID NOT NULL REFERENCES academic_sessions(id),
  fee_name     VARCHAR(100) NOT NULL,
  fee_type     VARCHAR(30) DEFAULT 'tuition'
               CHECK (fee_type IN ('tuition','bus','hostel','exam',
                                   'library','sports','other')),
  amount       DECIMAL(10,2) DEFAULT 0,
  frequency    VARCHAR(20) DEFAULT 'yearly'
               CHECK (frequency IN ('monthly','quarterly',
                                    'half_yearly','yearly','one_time')),
  due_day      INT DEFAULT 10,
  is_optional  BOOLEAN DEFAULT FALSE,
  created_at   TIMESTAMP DEFAULT NOW(),
  updated_at   TIMESTAMP DEFAULT NOW(),
  UNIQUE(school_id, session_id, fee_name)
);

-- =============================================================
-- 17. STUDENT FEE ASSIGNMENT
-- =============================================================
CREATE TABLE student_fees (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  student_id      UUID NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  fee_head_id     UUID NOT NULL REFERENCES fee_heads(id) ON DELETE CASCADE,
  session_id      UUID NOT NULL REFERENCES academic_sessions(id),
  total_amount    DECIMAL(10,2) DEFAULT 0,
  concession      DECIMAL(10,2) DEFAULT 0,
  net_amount      DECIMAL(10,2) GENERATED ALWAYS AS (total_amount - concession) STORED,
  paid_amount     DECIMAL(10,2) DEFAULT 0,
  balance         DECIMAL(10,2) GENERATED ALWAYS AS
                  (total_amount - concession - paid_amount) STORED,
  due_date        DATE,
  status          VARCHAR(20) DEFAULT 'pending'
                  CHECK (status IN ('paid','partial','pending','waived','overdue')),
  created_at      TIMESTAMP DEFAULT NOW(),
  updated_at      TIMESTAMP DEFAULT NOW(),
  UNIQUE(student_id, fee_head_id, session_id)
);

-- =============================================================
-- 18. FEE PAYMENTS
-- =============================================================
CREATE TABLE fee_payments (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  student_id      UUID NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  student_fee_id  UUID NOT NULL REFERENCES student_fees(id) ON DELETE CASCADE,
  receipt_no      VARCHAR(50) NOT NULL UNIQUE,
  amount          DECIMAL(10,2) NOT NULL,
  payment_date    DATE DEFAULT CURRENT_DATE,
  payment_mode    VARCHAR(30) DEFAULT 'cash'
                  CHECK (payment_mode IN ('cash','online','cheque',
                                          'dd','upi','card','neft')),
  transaction_id  VARCHAR(100),
  razorpay_id     VARCHAR(100),
  bank_ref        VARCHAR(100),
  remarks         TEXT,
  collected_by    UUID REFERENCES users(id) ON DELETE SET NULL,
  is_refunded     BOOLEAN DEFAULT FALSE,
  refund_amount   DECIMAL(10,2) DEFAULT 0,
  refund_date     DATE,
  created_at      TIMESTAMP DEFAULT NOW()
);

-- =============================================================
-- 19. FEE DISCOUNTS
-- =============================================================
CREATE TABLE fee_discounts (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  student_fee_id  UUID NOT NULL REFERENCES student_fees(id) ON DELETE CASCADE,
  student_id      UUID NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  discount_amount DECIMAL(10,2) NOT NULL,
  discount_reason VARCHAR(100),
  authority_name  VARCHAR(100),
  given_by        UUID REFERENCES users(id) ON DELETE SET NULL,
  approved_by     UUID REFERENCES users(id) ON DELETE SET NULL,
  approval_date   DATE DEFAULT CURRENT_DATE,
  remarks         TEXT,
  created_at      TIMESTAMP DEFAULT NOW()
);

-- =============================================================
-- 20. EXPENDITURE (NEW - not in original system)
-- =============================================================
CREATE TABLE expenditure_heads (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  school_id   UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  head_name   VARCHAR(100) NOT NULL,
  category    VARCHAR(50)  -- From masters: salary, maintenance, etc.
              CHECK (category IN ('salary','maintenance','utilities','infrastructure',
                                  'stationery','events','transport','other')),
  budget      DECIMAL(12,2) DEFAULT 0,
  session_id  UUID REFERENCES academic_sessions(id),
  created_at  TIMESTAMP DEFAULT NOW(),
  UNIQUE(school_id, head_name, session_id)
);

CREATE TABLE expenditures (
  id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  school_id        UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  head_id          UUID REFERENCES expenditure_heads(id) ON DELETE SET NULL,
  session_id       UUID NOT NULL REFERENCES academic_sessions(id),
  description      VARCHAR(255) NOT NULL,
  amount           DECIMAL(10,2) NOT NULL,
  expense_date     DATE DEFAULT CURRENT_DATE,
  payment_mode     VARCHAR(30) DEFAULT 'cash'
                   CHECK (payment_mode IN ('cash','cheque','online','upi','neft')),
  vendor_name      VARCHAR(255),
  bill_no          VARCHAR(100),
  bill_url         VARCHAR(500),
  approved_by      UUID REFERENCES users(id) ON DELETE SET NULL,
  created_by       UUID REFERENCES users(id) ON DELETE SET NULL,
  created_at       TIMESTAMP DEFAULT NOW(),
  updated_at       TIMESTAMP DEFAULT NOW()
);

-- =============================================================
-- 21. EXAMINATIONS
-- =============================================================
CREATE TABLE exams (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  school_id    UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  session_id   UUID NOT NULL REFERENCES academic_sessions(id),
  exam_name    VARCHAR(100) NOT NULL,
  exam_type    VARCHAR(30) DEFAULT 'unit_test'
               CHECK (exam_type IN ('unit_test','midterm','final',
                                    'quarterly','half_yearly','annual','other')),
  start_date   DATE,
  end_date     DATE,
  total_marks  INT DEFAULT 100,
  pass_marks   INT DEFAULT 35,
  status       VARCHAR(20) DEFAULT 'scheduled'
               CHECK (status IN ('scheduled','ongoing','completed','cancelled')),
  created_at   TIMESTAMP DEFAULT NOW(),
  updated_at   TIMESTAMP DEFAULT NOW()
);

CREATE TABLE exam_schedules (
  id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  exam_id    UUID NOT NULL REFERENCES exams(id) ON DELETE CASCADE,
  class_id   UUID NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
  subject_id UUID NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
  exam_date  DATE,
  start_time TIME,
  end_time   TIME,
  room_no    VARCHAR(20),
  max_marks  INT DEFAULT 100,
  pass_marks INT DEFAULT 35,
  created_at TIMESTAMP DEFAULT NOW(),
  UNIQUE(exam_id, class_id, subject_id)
);

-- =============================================================
-- 22. EXAM RESULTS / MARKS
-- =============================================================
CREATE TABLE exam_results (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  student_id    UUID NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  exam_id       UUID NOT NULL REFERENCES exams(id) ON DELETE CASCADE,
  subject_id    UUID NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
  session_id    UUID NOT NULL REFERENCES academic_sessions(id),
  marks_obtained DECIMAL(6,2),
  max_marks     INT DEFAULT 100,
  pass_marks    INT DEFAULT 35,
  grade         VARCHAR(5),
  remarks       TEXT,
  is_absent     BOOLEAN DEFAULT FALSE,
  entered_by    UUID REFERENCES users(id) ON DELETE SET NULL,
  created_at    TIMESTAMP DEFAULT NOW(),
  updated_at    TIMESTAMP DEFAULT NOW(),
  UNIQUE(student_id, exam_id, subject_id)
);

-- =============================================================
-- 23. HALL TICKETS
-- =============================================================
CREATE TABLE hall_tickets (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  student_id      UUID NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  exam_id         UUID NOT NULL REFERENCES exams(id) ON DELETE CASCADE,
  hall_ticket_no  VARCHAR(50) UNIQUE,
  issued_date     DATE DEFAULT CURRENT_DATE,
  pdf_url         VARCHAR(500),
  is_issued       BOOLEAN DEFAULT FALSE,
  created_at      TIMESTAMP DEFAULT NOW(),
  UNIQUE(student_id, exam_id)
);

-- =============================================================
-- 24. HOSTEL
-- =============================================================
CREATE TABLE hostels (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  school_id    UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  hostel_name  VARCHAR(100) NOT NULL,
  hostel_type  VARCHAR(10) DEFAULT 'boys' CHECK (hostel_type IN ('boys','girls','mixed')),
  capacity     INT DEFAULT 0,
  warden_id    UUID REFERENCES staff(id) ON DELETE SET NULL,
  address      TEXT,
  created_at   TIMESTAMP DEFAULT NOW()
);

CREATE TABLE hostel_rooms (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  hostel_id    UUID NOT NULL REFERENCES hostels(id) ON DELETE CASCADE,
  room_number  VARCHAR(20) NOT NULL,
  room_type    VARCHAR(20) DEFAULT 'shared'
               CHECK (room_type IN ('single','double','triple','dormitory')),
  capacity     INT DEFAULT 2,
  floor_no     INT DEFAULT 0,
  ac           BOOLEAN DEFAULT FALSE,
  status       VARCHAR(20) DEFAULT 'available'
               CHECK (status IN ('available','full','maintenance')),
  created_at   TIMESTAMP DEFAULT NOW(),
  UNIQUE(hostel_id, room_number)
);

CREATE TABLE hostel_allocations (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  student_id      UUID NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  room_id         UUID NOT NULL REFERENCES hostel_rooms(id) ON DELETE CASCADE,
  session_id      UUID NOT NULL REFERENCES academic_sessions(id),
  alloc_date      DATE DEFAULT CURRENT_DATE,
  vacate_date     DATE,
  meal_plan       VARCHAR(20) DEFAULT 'full'
                  CHECK (meal_plan IN ('none','breakfast','lunch','dinner','full')),
  status          VARCHAR(20) DEFAULT 'active'
                  CHECK (status IN ('active','vacated','transferred')),
  created_at      TIMESTAMP DEFAULT NOW(),
  UNIQUE(student_id, session_id)
);

-- =============================================================
-- 25. TRANSPORT
-- =============================================================
CREATE TABLE transport_routes (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  school_id    UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  route_name   VARCHAR(100) NOT NULL,
  route_no     VARCHAR(20),
  driver_id    UUID REFERENCES staff(id) ON DELETE SET NULL,
  vehicle_no   VARCHAR(20),
  capacity     INT DEFAULT 40,
  monthly_fee  DECIMAL(8,2) DEFAULT 0,
  status       VARCHAR(20) DEFAULT 'active',
  created_at   TIMESTAMP DEFAULT NOW()
);

CREATE TABLE student_transport (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  student_id  UUID NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  route_id    UUID NOT NULL REFERENCES transport_routes(id) ON DELETE CASCADE,
  session_id  UUID NOT NULL REFERENCES academic_sessions(id),
  stop_name   VARCHAR(100),
  pickup_time TIME,
  drop_time   TIME,
  status      VARCHAR(20) DEFAULT 'active',
  created_at  TIMESTAMP DEFAULT NOW(),
  UNIQUE(student_id, session_id)
);

-- =============================================================
-- 26. NOTICES / CIRCULARS
-- =============================================================
CREATE TABLE notices (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  school_id    UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  session_id   UUID REFERENCES academic_sessions(id),
  title        VARCHAR(255) NOT NULL,
  content      TEXT NOT NULL,
  notice_type  VARCHAR(30) DEFAULT 'general'
               CHECK (notice_type IN ('general','exam','event','fee',
                                      'holiday','urgent','circular')),
  target_role  VARCHAR(30) DEFAULT 'all'
               CHECK (target_role IN ('all','students','parents','staff','teachers')),
  attachment_url VARCHAR(500),
  published_at TIMESTAMP DEFAULT NOW(),
  expires_at   TIMESTAMP,
  created_by   UUID REFERENCES users(id) ON DELETE SET NULL,
  is_published BOOLEAN DEFAULT TRUE,
  created_at   TIMESTAMP DEFAULT NOW()
);

-- =============================================================
-- 27. EVENTS / CALENDAR
-- =============================================================
CREATE TABLE events (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  school_id   UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  session_id  UUID REFERENCES academic_sessions(id),
  title       VARCHAR(255) NOT NULL,
  description TEXT,
  event_type  VARCHAR(30) DEFAULT 'general'
              CHECK (event_type IN ('general','sports','cultural',
                                    'academic','exam','holiday','other')),
  event_date  DATE NOT NULL,
  start_time  TIME,
  end_time    TIME,
  venue       VARCHAR(255),
  created_by  UUID REFERENCES users(id) ON DELETE SET NULL,
  created_at  TIMESTAMP DEFAULT NOW()
);

-- =============================================================
-- 28. LEAVE MANAGEMENT
-- =============================================================
CREATE TABLE leave_types (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  school_id   UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  leave_name  VARCHAR(100) NOT NULL,
  max_days    INT DEFAULT 0,
  paid        BOOLEAN DEFAULT TRUE,
  applies_to  VARCHAR(20) DEFAULT 'staff'
              CHECK (applies_to IN ('staff','students','all')),
  created_at  TIMESTAMP DEFAULT NOW()
);

CREATE TABLE leave_applications (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  school_id       UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  applicant_type  VARCHAR(20) NOT NULL CHECK (applicant_type IN ('staff','student')),
  staff_id        UUID REFERENCES staff(id) ON DELETE CASCADE,
  student_id      UUID REFERENCES students(id) ON DELETE CASCADE,
  leave_type_id   UUID REFERENCES leave_types(id) ON DELETE SET NULL,
  from_date       DATE NOT NULL,
  to_date         DATE NOT NULL,
  total_days      INT,
  reason          TEXT,
  status          VARCHAR(20) DEFAULT 'pending'
                  CHECK (status IN ('pending','approved','rejected','cancelled')),
  approved_by     UUID REFERENCES users(id) ON DELETE SET NULL,
  remarks         TEXT,
  created_at      TIMESTAMP DEFAULT NOW(),
  updated_at      TIMESTAMP DEFAULT NOW(),
  CHECK(to_date >= from_date)
);

-- =============================================================
-- 29. SALARY / PAYROLL
-- =============================================================
CREATE TABLE salary_heads (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  school_id   UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  head_name   VARCHAR(100) NOT NULL,
  head_type   VARCHAR(20) DEFAULT 'earning'
              CHECK (head_type IN ('earning','deduction')),
  is_fixed    BOOLEAN DEFAULT TRUE,
  created_at  TIMESTAMP DEFAULT NOW(),
  UNIQUE(school_id, head_name)
);

CREATE TABLE staff_salary (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  staff_id     UUID NOT NULL REFERENCES staff(id) ON DELETE CASCADE,
  head_id      UUID NOT NULL REFERENCES salary_heads(id) ON DELETE CASCADE,
  amount       DECIMAL(10,2) DEFAULT 0,
  effective_from DATE DEFAULT CURRENT_DATE,
  created_at   TIMESTAMP DEFAULT NOW(),
  UNIQUE(staff_id, head_id, effective_from)
);

CREATE TABLE payroll (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  staff_id     UUID NOT NULL REFERENCES staff(id) ON DELETE CASCADE,
  school_id    UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  session_id   UUID REFERENCES academic_sessions(id),
  month        INT NOT NULL CHECK (month BETWEEN 1 AND 12),
  year         INT NOT NULL,
  gross_salary DECIMAL(10,2) DEFAULT 0,
  deductions   DECIMAL(10,2) DEFAULT 0,
  net_salary   DECIMAL(10,2) GENERATED ALWAYS AS (gross_salary - deductions) STORED,
  days_worked  INT DEFAULT 0,
  days_leave   INT DEFAULT 0,
  payment_date DATE,
  payment_mode VARCHAR(30) DEFAULT 'bank_transfer',
  slip_url     VARCHAR(500),
  status       VARCHAR(20) DEFAULT 'pending'
               CHECK (status IN ('pending','processed','paid')),
  created_at   TIMESTAMP DEFAULT NOW(),
  UNIQUE(staff_id, month, year)
);

-- =============================================================
-- 30. NOTIFICATIONS
-- =============================================================
CREATE TABLE notifications (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  school_id    UUID REFERENCES schools(id) ON DELETE CASCADE,
  user_id      UUID REFERENCES users(id) ON DELETE CASCADE,
  title        VARCHAR(255) NOT NULL,
  message      TEXT NOT NULL,
  notif_type   VARCHAR(30) DEFAULT 'info'
               CHECK (notif_type IN ('info','warning','success','error',
                                     'fee','attendance','exam','leave')),
  channel      VARCHAR(20) DEFAULT 'app'
               CHECK (channel IN ('app','sms','email','push','all')),
  is_read      BOOLEAN DEFAULT FALSE,
  sent_at      TIMESTAMP,
  read_at      TIMESTAMP,
  created_at   TIMESTAMP DEFAULT NOW()
);

-- =============================================================
-- 31. SMS / EMAIL LOGS
-- =============================================================
CREATE TABLE communication_logs (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  school_id    UUID REFERENCES schools(id) ON DELETE CASCADE,
  channel      VARCHAR(10) NOT NULL CHECK (channel IN ('sms','email','push')),
  recipient    VARCHAR(255) NOT NULL,
  subject      VARCHAR(255),
  message      TEXT NOT NULL,
  status       VARCHAR(20) DEFAULT 'pending'
               CHECK (status IN ('pending','sent','failed','delivered')),
  provider_ref VARCHAR(100),
  sent_at      TIMESTAMP,
  created_at   TIMESTAMP DEFAULT NOW()
);

-- =============================================================
-- 32. AUDIT LOGS
-- =============================================================
CREATE TABLE audit_logs (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id     UUID REFERENCES users(id) ON DELETE SET NULL,
  school_id   UUID REFERENCES schools(id) ON DELETE SET NULL,
  action      VARCHAR(50) NOT NULL,
  table_name  VARCHAR(100),
  record_id   UUID,
  old_values  JSONB,
  new_values  JSONB,
  ip_address  VARCHAR(45),
  user_agent  TEXT,
  created_at  TIMESTAMP DEFAULT NOW()
);

-- =============================================================
-- INDEXES for performance
-- =============================================================
CREATE INDEX idx_schools_org ON schools(organization_id);
CREATE INDEX idx_sessions_org ON academic_sessions(organization_id);
CREATE INDEX idx_users_school ON users(school_id);
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_staff_school ON staff(school_id);
CREATE INDEX idx_students_school ON students(school_id);
CREATE INDEX idx_students_session ON students(session_id);
CREATE INDEX idx_students_class ON students(class_id);
CREATE INDEX idx_students_code ON students(student_code);
CREATE INDEX idx_student_att_student ON student_attendance(student_id);
CREATE INDEX idx_student_att_date ON student_attendance(attendance_date);
CREATE INDEX idx_student_att_class ON student_attendance(class_id);
CREATE INDEX idx_staff_att_staff ON staff_attendance(staff_id);
CREATE INDEX idx_staff_att_date ON staff_attendance(attendance_date);
CREATE INDEX idx_fee_payments_student ON fee_payments(student_id);
CREATE INDEX idx_exam_results_student ON exam_results(student_id);
CREATE INDEX idx_exam_results_exam ON exam_results(exam_id);
CREATE INDEX idx_notices_school ON notices(school_id);
CREATE INDEX idx_audit_user ON audit_logs(user_id);
CREATE INDEX idx_audit_table ON audit_logs(table_name, record_id);
CREATE INDEX idx_masters_org_type ON masters(organization_id, master_type);
CREATE INDEX idx_expenditures_school ON expenditures(school_id, session_id);

-- =============================================================
-- UPDATED_AT trigger function
-- =============================================================
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply trigger to all tables with updated_at
DO $$
DECLARE
  t TEXT;
BEGIN
  FOR t IN
    SELECT table_name FROM information_schema.columns
    WHERE column_name = 'updated_at'
    AND table_schema = 'public'
  LOOP
    EXECUTE format('CREATE TRIGGER trg_updated_at BEFORE UPDATE ON %I
                    FOR EACH ROW EXECUTE FUNCTION update_updated_at()', t);
  END LOOP;
END;
$$;
