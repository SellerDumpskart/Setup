-- =============================================================
-- VIDYAMATE - SEED DATA
-- Default super admin + all master data
-- =============================================================

-- Super Admin user
-- Password: Admin@123 (bcrypt hashed)
INSERT INTO organizations (id, name, reg_number, since_date, status)
VALUES (
  'a0000000-0000-0000-0000-000000000001',
  'VidyaMate Platform',
  'VM-PLATFORM-001',
  '2020-01-01',
  'active'
);

INSERT INTO users (id, organization_id, username, email, password_hash, first_name, last_name, role, is_active)
VALUES (
  'u0000000-0000-0000-0000-000000000001',
  'a0000000-0000-0000-0000-000000000001',
  'superadmin',
  'admin@vidyamate.in',
  '$2a$12$9MP4PW5f7Bt4tqtKx8fKr.TjvRSNjO0MjKXqUIruGjr3w3MS7eNoe', -- Admin@123
  'Super',
  'Admin',
  'super_admin',
  TRUE
);

-- =============================================================
-- DEFAULT MASTERS for every organization
-- These are the system defaults - orgs can add their own
-- =============================================================

-- For the platform org, insert all defaults
-- (Schools will copy relevant ones or use their own)

-- DESIGNATIONS
INSERT INTO masters (organization_id, master_type, value, sort_order) VALUES
('a0000000-0000-0000-0000-000000000001', 'designation', 'Principal', 1),
('a0000000-0000-0000-0000-000000000001', 'designation', 'Vice Principal', 2),
('a0000000-0000-0000-0000-000000000001', 'designation', 'Head Master', 3),
('a0000000-0000-0000-0000-000000000001', 'designation', 'PGT Teacher', 4),
('a0000000-0000-0000-0000-000000000001', 'designation', 'TGT Teacher', 5),
('a0000000-0000-0000-0000-000000000001', 'designation', 'PRT Teacher', 6),
('a0000000-0000-0000-0000-000000000001', 'designation', 'Accountant', 7),
('a0000000-0000-0000-0000-000000000001', 'designation', 'Librarian', 8),
('a0000000-0000-0000-0000-000000000001', 'designation', 'Lab Assistant', 9),
('a0000000-0000-0000-0000-000000000001', 'designation', 'Physical Education Teacher', 10),
('a0000000-0000-0000-0000-000000000001', 'designation', 'Driver', 11),
('a0000000-0000-0000-0000-000000000001', 'designation', 'Cleaner', 12),
('a0000000-0000-0000-0000-000000000001', 'designation', 'Warden', 13),
('a0000000-0000-0000-0000-000000000001', 'designation', 'Security Guard', 14),
('a0000000-0000-0000-0000-000000000001', 'designation', 'Peon', 15),
('a0000000-0000-0000-0000-000000000001', 'designation', 'Clerk', 16);

-- EDUCATION
INSERT INTO masters (organization_id, master_type, value, sort_order) VALUES
('a0000000-0000-0000-0000-000000000001', 'education', 'SSLC / 10th', 1),
('a0000000-0000-0000-0000-000000000001', 'education', 'HSC / 12th', 2),
('a0000000-0000-0000-0000-000000000001', 'education', 'D.Ed', 3),
('a0000000-0000-0000-0000-000000000001', 'education', 'D.El.Ed', 4),
('a0000000-0000-0000-0000-000000000001', 'education', 'B.Ed', 5),
('a0000000-0000-0000-0000-000000000001', 'education', 'M.Ed', 6),
('a0000000-0000-0000-0000-000000000001', 'education', 'B.A', 7),
('a0000000-0000-0000-0000-000000000001', 'education', 'M.A', 8),
('a0000000-0000-0000-0000-000000000001', 'education', 'B.Sc', 9),
('a0000000-0000-0000-0000-000000000001', 'education', 'M.Sc', 10),
('a0000000-0000-0000-0000-000000000001', 'education', 'B.Com', 11),
('a0000000-0000-0000-0000-000000000001', 'education', 'M.Com', 12),
('a0000000-0000-0000-0000-000000000001', 'education', 'BCA', 13),
('a0000000-0000-0000-0000-000000000001', 'education', 'MCA', 14),
('a0000000-0000-0000-0000-000000000001', 'education', 'B.Tech', 15),
('a0000000-0000-0000-0000-000000000001', 'education', 'M.Tech', 16),
('a0000000-0000-0000-0000-000000000001', 'education', 'MBA', 17),
('a0000000-0000-0000-0000-000000000001', 'education', 'Ph.D', 18);

-- OCCUPATION
INSERT INTO masters (organization_id, master_type, value, sort_order) VALUES
('a0000000-0000-0000-0000-000000000001', 'occupation', 'Government Employee', 1),
('a0000000-0000-0000-0000-000000000001', 'occupation', 'Private Employee', 2),
('a0000000-0000-0000-0000-000000000001', 'occupation', 'Business', 3),
('a0000000-0000-0000-0000-000000000001', 'occupation', 'Farmer', 4),
('a0000000-0000-0000-0000-000000000001', 'occupation', 'Doctor', 5),
('a0000000-0000-0000-0000-000000000001', 'occupation', 'Engineer', 6),
('a0000000-0000-0000-0000-000000000001', 'occupation', 'Teacher', 7),
('a0000000-0000-0000-0000-000000000001', 'occupation', 'Lawyer', 8),
('a0000000-0000-0000-0000-000000000001', 'occupation', 'Retired', 9),
('a0000000-0000-0000-0000-000000000001', 'occupation', 'Labour', 10),
('a0000000-0000-0000-0000-000000000001', 'occupation', 'Self Employed', 11),
('a0000000-0000-0000-0000-000000000001', 'occupation', 'Housewife', 12),
('a0000000-0000-0000-0000-000000000001', 'occupation', 'Unemployed', 13),
('a0000000-0000-0000-0000-000000000001', 'occupation', 'Other', 14);

-- RELIGION
INSERT INTO masters (organization_id, master_type, value, sort_order) VALUES
('a0000000-0000-0000-0000-000000000001', 'religion', 'Hindu', 1),
('a0000000-0000-0000-0000-000000000001', 'religion', 'Muslim', 2),
('a0000000-0000-0000-0000-000000000001', 'religion', 'Christian', 3),
('a0000000-0000-0000-0000-000000000001', 'religion', 'Sikh', 4),
('a0000000-0000-0000-0000-000000000001', 'religion', 'Buddhist', 5),
('a0000000-0000-0000-0000-000000000001', 'religion', 'Jain', 6),
('a0000000-0000-0000-0000-000000000001', 'religion', 'Other', 7);

-- CATEGORY
INSERT INTO masters (organization_id, master_type, value, sort_order) VALUES
('a0000000-0000-0000-0000-000000000001', 'category', 'General', 1),
('a0000000-0000-0000-0000-000000000001', 'category', 'OBC', 2),
('a0000000-0000-0000-0000-000000000001', 'category', 'SC', 3),
('a0000000-0000-0000-0000-000000000001', 'category', 'ST', 4),
('a0000000-0000-0000-0000-000000000001', 'category', 'EWS', 5),
('a0000000-0000-0000-0000-000000000001', 'category', 'Minority', 6);

-- MOTHER TONGUE
INSERT INTO masters (organization_id, master_type, value, sort_order) VALUES
('a0000000-0000-0000-0000-000000000001', 'mother_tongue', 'Telugu', 1),
('a0000000-0000-0000-0000-000000000001', 'mother_tongue', 'Hindi', 2),
('a0000000-0000-0000-0000-000000000001', 'mother_tongue', 'English', 3),
('a0000000-0000-0000-0000-000000000001', 'mother_tongue', 'Tamil', 4),
('a0000000-0000-0000-0000-000000000001', 'mother_tongue', 'Kannada', 5),
('a0000000-0000-0000-0000-000000000001', 'mother_tongue', 'Malayalam', 6),
('a0000000-0000-0000-0000-000000000001', 'mother_tongue', 'Marathi', 7),
('a0000000-0000-0000-0000-000000000001', 'mother_tongue', 'Bengali', 8),
('a0000000-0000-0000-0000-000000000001', 'mother_tongue', 'Gujarati', 9),
('a0000000-0000-0000-0000-000000000001', 'mother_tongue', 'Odia', 10),
('a0000000-0000-0000-0000-000000000001', 'mother_tongue', 'Punjabi', 11),
('a0000000-0000-0000-0000-000000000001', 'mother_tongue', 'Urdu', 12),
('a0000000-0000-0000-0000-000000000001', 'mother_tongue', 'Other', 13);

-- MEDIUM
INSERT INTO masters (organization_id, master_type, value, sort_order) VALUES
('a0000000-0000-0000-0000-000000000001', 'medium', 'English Medium', 1),
('a0000000-0000-0000-0000-000000000001', 'medium', 'Telugu Medium', 2),
('a0000000-0000-0000-0000-000000000001', 'medium', 'Hindi Medium', 3),
('a0000000-0000-0000-0000-000000000001', 'medium', 'Tamil Medium', 4),
('a0000000-0000-0000-0000-000000000001', 'medium', 'Kannada Medium', 5),
('a0000000-0000-0000-0000-000000000001', 'medium', 'Urdu Medium', 6);

-- BLOOD GROUP
INSERT INTO masters (organization_id, master_type, value, sort_order) VALUES
('a0000000-0000-0000-0000-000000000001', 'blood_group', 'A+', 1),
('a0000000-0000-0000-0000-000000000001', 'blood_group', 'A-', 2),
('a0000000-0000-0000-0000-000000000001', 'blood_group', 'B+', 3),
('a0000000-0000-0000-0000-000000000001', 'blood_group', 'B-', 4),
('a0000000-0000-0000-0000-000000000001', 'blood_group', 'AB+', 5),
('a0000000-0000-0000-0000-000000000001', 'blood_group', 'AB-', 6),
('a0000000-0000-0000-0000-000000000001', 'blood_group', 'O+', 7),
('a0000000-0000-0000-0000-000000000001', 'blood_group', 'O-', 8);

-- CANCEL REASON
INSERT INTO masters (organization_id, master_type, value, sort_order) VALUES
('a0000000-0000-0000-0000-000000000001', 'cancel_reason', 'Cancel', 1),
('a0000000-0000-0000-0000-000000000001', 'cancel_reason', 'Left', 2),
('a0000000-0000-0000-0000-000000000001', 'cancel_reason', 'Long Absent', 3),
('a0000000-0000-0000-0000-000000000001', 'cancel_reason', 'Parents Transfer', 4),
('a0000000-0000-0000-0000-000000000001', 'cancel_reason', 'Fee Default', 5),
('a0000000-0000-0000-0000-000000000001', 'cancel_reason', 'Discipline Issue', 6);

-- DISCOUNT REASON
INSERT INTO masters (organization_id, master_type, value, sort_order) VALUES
('a0000000-0000-0000-0000-000000000001', 'discount_reason', 'Merit Scholarship', 1),
('a0000000-0000-0000-0000-000000000001', 'discount_reason', 'Need Based', 2),
('a0000000-0000-0000-0000-000000000001', 'discount_reason', 'Staff Ward', 3),
('a0000000-0000-0000-0000-000000000001', 'discount_reason', 'Management Quota', 4),
('a0000000-0000-0000-0000-000000000001', 'discount_reason', 'Government Scholarship', 5),
('a0000000-0000-0000-0000-000000000001', 'discount_reason', 'Sibling Discount', 6),
('a0000000-0000-0000-0000-000000000001', 'discount_reason', 'Sports Quota', 7),
('a0000000-0000-0000-0000-000000000001', 'discount_reason', 'Other', 8);

-- DOCUMENT TYPES
INSERT INTO masters (organization_id, master_type, value, sort_order) VALUES
('a0000000-0000-0000-0000-000000000001', 'document_type', 'Birth Certificate', 1),
('a0000000-0000-0000-0000-000000000001', 'document_type', 'Transfer Certificate', 2),
('a0000000-0000-0000-0000-000000000001', 'document_type', 'Aadhaar Card', 3),
('a0000000-0000-0000-0000-000000000001', 'document_type', 'Caste Certificate', 4),
('a0000000-0000-0000-0000-000000000001', 'document_type', 'Income Certificate', 5),
('a0000000-0000-0000-0000-000000000001', 'document_type', 'Medical Certificate', 6),
('a0000000-0000-0000-0000-000000000001', 'document_type', 'Passport Size Photo', 7),
('a0000000-0000-0000-0000-000000000001', 'document_type', 'Migration Certificate', 8),
('a0000000-0000-0000-0000-000000000001', 'document_type', 'Conduct Certificate', 9);

-- EXPENSE CATEGORIES
INSERT INTO masters (organization_id, master_type, value, sort_order) VALUES
('a0000000-0000-0000-0000-000000000001', 'expense_category', 'Staff Salary', 1),
('a0000000-0000-0000-0000-000000000001', 'expense_category', 'Building Maintenance', 2),
('a0000000-0000-0000-0000-000000000001', 'expense_category', 'Electricity', 3),
('a0000000-0000-0000-0000-000000000001', 'expense_category', 'Water', 4),
('a0000000-0000-0000-0000-000000000001', 'expense_category', 'Stationery', 5),
('a0000000-0000-0000-0000-000000000001', 'expense_category', 'Lab Equipment', 6),
('a0000000-0000-0000-0000-000000000001', 'expense_category', 'Library Books', 7),
('a0000000-0000-0000-0000-000000000001', 'expense_category', 'Sports Equipment', 8),
('a0000000-0000-0000-0000-000000000001', 'expense_category', 'Transport', 9),
('a0000000-0000-0000-0000-000000000001', 'expense_category', 'Events & Functions', 10),
('a0000000-0000-0000-0000-000000000001', 'expense_category', 'Repairs', 11),
('a0000000-0000-0000-0000-000000000001', 'expense_category', 'Cleaning & Sanitation', 12),
('a0000000-0000-0000-0000-000000000001', 'expense_category', 'Security', 13),
('a0000000-0000-0000-0000-000000000001', 'expense_category', 'Internet & Phone', 14),
('a0000000-0000-0000-0000-000000000001', 'expense_category', 'Other', 15);
