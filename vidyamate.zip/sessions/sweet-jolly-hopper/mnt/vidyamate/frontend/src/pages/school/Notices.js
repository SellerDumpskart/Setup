import React, { useState, useEffect } from 'react';
import { PageHeader, Btn, Card, Badge, Modal, Input, Select, Textarea } from '../../components/common/Common';
import { useSessionContext } from '../../store/sessionStore';
import { noticeService } from '../../services';
import { fmtDate, NOTICE_TYPES } from '../../utils';
import toast from 'react-hot-toast';

const TYPE_COLOR = { general:'teal', exam:'purple', fee:'orange', holiday:'blue', urgent:'red', circular:'green' };
const EMPTY = { title:'', content:'', noticeType:'general', targetRole:'all' };

export default function Notices() {
  const { sessionId } = useSessionContext();
  const [notices, setNotices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShow]   = useState(false);
  const [viewing, setView]    = useState(null);
  const [form, setForm]       = useState(EMPTY);
  const [saving, setSaving]   = useState(false);

  const load = async () => {
    setLoading(true);
    try { const { data } = await noticeService.list(); setNotices(data || []); }
    catch { setNotices([]); }
    finally { setLoading(false); }
  };

  useEffect(() => { load(); }, [sessionId]);

  const handleSave = async () => {
    if (!form.title || !form.content) { toast.error('Title and content required'); return; }
    setSaving(true);
    try {
      await noticeService.create(form);
      toast.success('Notice published'); load(); setShow(false); setForm(EMPTY);
    } catch (e) { toast.error(e.response?.data?.error || 'Failed'); }
    finally { setSaving(false); }
  };

  const handleDelete = async (id) => {
    await noticeService.remove(id);
    toast.success('Notice removed'); load();
  };

  return (
    <div>
      <PageHeader title="School Notices" subtitle="Post circulars and announcements" icon="fa-bullhorn"
        actions={<Btn icon="fa-plus" variant="primary" onClick={() => setShow(true)}>Post Notice</Btn>}
      />

      {loading ? (
        <div style={{ padding:48, textAlign:'center', color:'var(--text-light)' }}>
          <i className="fa-solid fa-spinner fa-spin" style={{ fontSize:24, marginBottom:10 }}/><br/>Loading notices...
        </div>
      ) : notices.length === 0 ? (
        <Card>
          <div style={{ padding:48, textAlign:'center', color:'var(--text-light)' }}>
            <i className="fa-solid fa-bullhorn" style={{ fontSize:40, opacity:.3, marginBottom:12 }}/>
            <p>No notices posted yet</p>
          </div>
        </Card>
      ) : (
        <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:14 }}>
          {notices.map(n => {
            const colorName = TYPE_COLOR[n.notice_type] || 'teal';
            const color = { teal:'#00A99D', orange:'#F7941D', purple:'#9C27B0', blue:'#2196F3', red:'#e53e3e', green:'#38a169' }[colorName] || '#00A99D';
            return (
              <div key={n.id} onClick={() => setView(n)}
                style={{ background:'#fff', borderRadius:12, padding:16, boxShadow:'var(--card-shadow)',
                  cursor:'pointer', transition:'all .18s',
                  borderTop:`3px solid ${color}` }}
                onMouseEnter={e=>e.currentTarget.style.transform='translateY(-2px)'}
                onMouseLeave={e=>e.currentTarget.style.transform='translateY(0)'}
              >
                <div style={{ display:'flex', justifyContent:'space-between', marginBottom:8 }}>
                  <Badge label={n.notice_type} color={colorName} />
                  <span style={{ fontSize:11, color:'var(--text-light)' }}>
                    {fmtDate(n.published_at, { day:'2-digit', month:'short' })}
                  </span>
                </div>
                <h3 style={{ fontWeight:600, fontSize:14, color:'var(--text-dark)', marginBottom:6, lineHeight:1.4 }}>{n.title}</h3>
                <p style={{ fontSize:12.5, color:'var(--text-mid)', lineHeight:1.5, overflow:'hidden',
                  display:'-webkit-box', WebkitLineClamp:2, WebkitBoxOrient:'vertical' }}>{n.content}</p>
                <div style={{ marginTop:10, display:'flex', justifyContent:'space-between', alignItems:'center' }}>
                  <Badge label={n.target_role||'all'} color="teal" />
                  <button className="icon-btn danger" onClick={e=>{e.stopPropagation();handleDelete(n.id)}}><i className="fa-solid fa-trash"/></button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* View Modal */}
      <Modal open={!!viewing} onClose={() => setView(null)} title={viewing?.title||''} size="md"
        footer={<div style={{ display:'flex', gap:8, justifyContent:'flex-end' }}><Btn variant="ghost" onClick={()=>setView(null)}>Close</Btn></div>}
      >
        {viewing && (
          <div>
            <div style={{ display:'flex', gap:8, marginBottom:14 }}>
              <Badge label={viewing.notice_type} color={TYPE_COLOR[viewing.notice_type]||'teal'} />
              <Badge label={`For: ${viewing.target_role||'all'}`} color="teal" />
            </div>
            <p style={{ fontSize:14, color:'var(--text-dark)', lineHeight:1.7, whiteSpace:'pre-wrap' }}>{viewing.content}</p>
            <div style={{ marginTop:16, paddingTop:12, borderTop:'1px solid var(--border)', fontSize:12, color:'var(--text-light)' }}>
              {fmtDate(viewing.published_at, { day:'2-digit', month:'long', year:'numeric' })}
            </div>
          </div>
        )}
      </Modal>

      {/* Add Modal */}
      <Modal open={showForm} onClose={() => { setShow(false); setForm(EMPTY); }} title="Post Notice" size="md"
        footer={
          <div style={{ display:'flex', gap:8, justifyContent:'flex-end' }}>
            <Btn variant="ghost" onClick={() => setShow(false)}>Cancel</Btn>
            <Btn variant="primary" icon="fa-bullhorn" loading={saving} onClick={handleSave}>Publish</Btn>
          </div>
        }
      >
        <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
          <Input label="Title" required value={form.title} onChange={e => setForm(f=>({...f,title:e.target.value}))} />
          <div className="form-grid">
            <Select label="Notice Type" value={form.noticeType} onChange={e => setForm(f=>({...f,noticeType:e.target.value}))}
              options={NOTICE_TYPES.map(t => ({ value:t, label:t.charAt(0).toUpperCase()+t.slice(1) }))} />
            <Select label="Audience" value={form.targetRole} onChange={e => setForm(f=>({...f,targetRole:e.target.value}))}
              options={[{value:'all',label:'Everyone'},{value:'students',label:'Students'},{value:'parents',label:'Parents'},{value:'staff',label:'Staff'}]} />
          </div>
          <Textarea label="Content" required value={form.content} onChange={e => setForm(f=>({...f,content:e.target.value}))} rows={5} placeholder="Write notice content..." />
        </div>
      </Modal>
    </div>
  );
}
