import React, { useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import api from '../../services/api';
import './LoginPage.css';

export default function ResetPassword() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const token = searchParams.get('token') || '';

  const [form, setForm]       = useState({ password: '', confirm: '' });
  const [showPass, setShowPass] = useState(false);
  const [status, setStatus]   = useState('idle'); // idle | loading | done | error
  const [message, setMessage] = useState('');

  const validate = () => {
    if (!form.password) return 'Password is required.';
    if (form.password.length < 8) return 'Password must be at least 8 characters.';
    if (form.password !== form.confirm) return 'Passwords do not match.';
    return null;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const err = validate();
    if (err) { setStatus('error'); setMessage(err); return; }
    if (!token) { setStatus('error'); setMessage('Invalid or missing reset token. Please request a new link.'); return; }

    setStatus('loading');
    try {
      const { data } = await api.post('/auth/reset-password', { token, newPassword: form.password });
      setStatus('done');
      setMessage(data.message || 'Password reset successfully!');
    } catch (err2) {
      setStatus('error');
      setMessage(err2.response?.data?.error || 'Reset failed. The link may have expired.');
    }
  };

  const strength = (p) => {
    if (!p) return { label: '', color: '#e2e8f0', width: 0 };
    let score = 0;
    if (p.length >= 8)  score++;
    if (/[A-Z]/.test(p)) score++;
    if (/[0-9]/.test(p)) score++;
    if (/[^A-Za-z0-9]/.test(p)) score++;
    const map = [
      { label: 'Too short', color: '#fc8181', width: 25 },
      { label: 'Weak',      color: '#fc8181', width: 25 },
      { label: 'Fair',      color: '#F7941D', width: 50 },
      { label: 'Good',      color: '#68d391', width: 75 },
      { label: 'Strong',    color: '#38a169', width: 100 },
    ];
    return map[score];
  };

  const s = strength(form.password);

  return (
    <div className="login-page">
      <div className="login-left">
        <div className="login-brand">
          <div className="brand-logo"><i className="fa-solid fa-graduation-cap" /></div>
          <h1>VidyaMate</h1>
          <p>Complete School Management System</p>
        </div>
        <div className="login-features">
          {[
            { icon: 'fa-shield-halved', text: 'Choose a strong password' },
            { icon: 'fa-lock',          text: 'Minimum 8 characters required' },
            { icon: 'fa-key',           text: 'Mix letters, numbers & symbols' },
            { icon: 'fa-check-circle',  text: 'One-time link — use it now' },
          ].map((f, i) => (
            <div className="feature-item" key={i}>
              <i className={`fa-solid ${f.icon}`} />
              <span>{f.text}</span>
            </div>
          ))}
        </div>
        <div className="login-wave" />
      </div>

      <div className="login-right">
        <div className="login-card">
          <div className="login-header">
            <div className="login-icon">
              <i className="fa-solid fa-lock" />
            </div>
            <h2>Reset Password</h2>
            <p>Enter your new password below</p>
          </div>

          {!token && (
            <div className="login-error">
              <i className="fa-solid fa-circle-exclamation" />
              No reset token found. Please use the link from your email.
            </div>
          )}

          {status === 'done' ? (
            <div style={{ textAlign: 'center', padding: '8px 0 16px' }}>
              <div style={{ width: 64, height: 64, borderRadius: '50%', background: '#e6f9f7',
                display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 16px' }}>
                <i className="fa-solid fa-circle-check" style={{ fontSize: 28, color: '#38a169' }} />
              </div>
              <p style={{ fontWeight: 600, fontSize: 15, marginBottom: 8, color: '#2d3748' }}>Password Updated!</p>
              <p style={{ fontSize: 13, color: '#718096', lineHeight: 1.6, marginBottom: 20 }}>{message}</p>
              <button className="login-btn" onClick={() => navigate('/login')}>
                <i className="fa-solid fa-right-to-bracket" /> Go to Sign In
              </button>
            </div>
          ) : (
            <>
              {status === 'error' && (
                <div className="login-error">
                  <i className="fa-solid fa-circle-exclamation" />{message}
                </div>
              )}
              <form onSubmit={handleSubmit} className="login-form">
                <div className="form-group">
                  <label>New Password</label>
                  <div className="input-wrap">
                    <i className="fa-solid fa-lock input-icon" />
                    <input
                      type={showPass ? 'text' : 'password'}
                      placeholder="Minimum 8 characters"
                      value={form.password}
                      onChange={e => { setForm(f => ({ ...f, password: e.target.value })); setStatus('idle'); }}
                      autoFocus
                    />
                    <button type="button" className="pass-toggle" onClick={() => setShowPass(p => !p)}>
                      <i className={`fa-solid ${showPass ? 'fa-eye-slash' : 'fa-eye'}`} />
                    </button>
                  </div>
                  {form.password && (
                    <div style={{ marginTop: 6 }}>
                      <div style={{ height: 4, borderRadius: 2, background: '#e2e8f0', overflow: 'hidden' }}>
                        <div style={{ width: `${s.width}%`, height: '100%', background: s.color, transition: 'all .3s' }} />
                      </div>
                      <span style={{ fontSize: 11, color: s.color, fontWeight: 600 }}>{s.label}</span>
                    </div>
                  )}
                </div>

                <div className="form-group">
                  <label>Confirm Password</label>
                  <div className="input-wrap">
                    <i className="fa-solid fa-lock-open input-icon" />
                    <input
                      type={showPass ? 'text' : 'password'}
                      placeholder="Repeat your new password"
                      value={form.confirm}
                      onChange={e => { setForm(f => ({ ...f, confirm: e.target.value })); setStatus('idle'); }}
                    />
                  </div>
                  {form.confirm && form.password !== form.confirm && (
                    <span style={{ fontSize: 11, color: '#fc8181' }}>Passwords do not match</span>
                  )}
                </div>

                <button type="submit" className="login-btn" disabled={status === 'loading' || !token}>
                  {status === 'loading' ? (
                    <><i className="fa-solid fa-spinner fa-spin" /> Resetting...</>
                  ) : (
                    <><i className="fa-solid fa-floppy-disk" /> Set New Password</>
                  )}
                </button>
              </form>
            </>
          )}

          <p style={{ textAlign: 'center', marginTop: 20, fontSize: 13, color: '#718096' }}>
            <Link to="/login" style={{ color: '#00A99D', fontWeight: 600, textDecoration: 'none' }}>
              ← Back to Sign In
            </Link>
          </p>
          <p className="login-footer">© 2026 VidyaMate · School Management System</p>
        </div>
      </div>
    </div>
  );
}
