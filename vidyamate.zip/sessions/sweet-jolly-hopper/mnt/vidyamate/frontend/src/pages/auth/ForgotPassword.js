import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../../services/api';
import './LoginPage.css';

export default function ForgotPassword() {
  const [email, setEmail]     = useState('');
  const [status, setStatus]   = useState('idle'); // idle | loading | sent | error
  const [message, setMessage] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!email.trim()) { setStatus('error'); setMessage('Please enter your email address.'); return; }
    setStatus('loading');
    try {
      const { data } = await api.post('/auth/forgot-password', { email });
      setStatus('sent');
      setMessage(data.message || 'Check your inbox for the reset link.');
    } catch (err) {
      setStatus('error');
      setMessage(err.response?.data?.error || 'Something went wrong. Please try again.');
    }
  };

  return (
    <div className="login-page">
      {/* Left panel */}
      <div className="login-left">
        <div className="login-brand">
          <div className="brand-logo"><i className="fa-solid fa-graduation-cap" /></div>
          <h1>VidyaMate</h1>
          <p>Complete School Management System</p>
        </div>
        <div className="login-features">
          {[
            { icon: 'fa-lock-open', text: 'Secure password recovery' },
            { icon: 'fa-envelope', text: 'Reset link sent to your inbox' },
            { icon: 'fa-clock', text: 'Link expires in 1 hour' },
            { icon: 'fa-shield-halved', text: 'Your account stays protected' },
          ].map((f, i) => (
            <div className="feature-item" key={i}>
              <i className={`fa-solid ${f.icon}`} />
              <span>{f.text}</span>
            </div>
          ))}
        </div>
        <div className="login-wave" />
      </div>

      {/* Right panel */}
      <div className="login-right">
        <div className="login-card">
          <div className="login-header">
            <div className="login-icon">
              <i className="fa-solid fa-key" />
            </div>
            <h2>Forgot Password?</h2>
            <p>Enter your email and we'll send a reset link</p>
          </div>

          {status === 'sent' ? (
            <div style={{ textAlign: 'center', padding: '8px 0 16px' }}>
              <div style={{ width: 64, height: 64, borderRadius: '50%', background: '#e6f9f7',
                display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 16px' }}>
                <i className="fa-solid fa-envelope-circle-check" style={{ fontSize: 28, color: '#00A99D' }} />
              </div>
              <p style={{ fontWeight: 600, fontSize: 15, marginBottom: 8, color: '#2d3748' }}>Check your inbox</p>
              <p style={{ fontSize: 13, color: '#718096', lineHeight: 1.6 }}>{message}</p>
              <p style={{ fontSize: 13, color: '#718096', marginTop: 8 }}>
                Didn't receive it?{' '}
                <button onClick={() => setStatus('idle')}
                  style={{ color: '#00A99D', background: 'none', border: 'none', cursor: 'pointer', fontWeight: 600 }}>
                  Try again
                </button>
              </p>
            </div>
          ) : (
            <>
              {status === 'error' && (
                <div className="login-error">
                  <i className="fa-solid fa-circle-exclamation" />{message}
                </div>
              )}
              <form onSubmit={handleSubmit} className="login-form">
                <div className="form-group">
                  <label>Email Address</label>
                  <div className="input-wrap">
                    <i className="fa-solid fa-envelope input-icon" />
                    <input
                      type="email"
                      placeholder="admin@school.com"
                      value={email}
                      onChange={e => { setEmail(e.target.value); setStatus('idle'); }}
                      autoComplete="email"
                      autoFocus
                    />
                  </div>
                </div>
                <button type="submit" className="login-btn" disabled={status === 'loading'}>
                  {status === 'loading' ? (
                    <><i className="fa-solid fa-spinner fa-spin" /> Sending...</>
                  ) : (
                    <><i className="fa-solid fa-paper-plane" /> Send Reset Link</>
                  )}
                </button>
              </form>
            </>
          )}

          <p style={{ textAlign: 'center', marginTop: 20, fontSize: 13, color: '#718096' }}>
            Remembered it?{' '}
            <Link to="/login" style={{ color: '#00A99D', fontWeight: 600, textDecoration: 'none' }}>
              Back to Sign In
            </Link>
          </p>

          <p className="login-footer">© 2026 VidyaMate · School Management System</p>
        </div>
      </div>
    </div>
  );
}
