import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import toast from 'react-hot-toast';
import {
  PageHeader, Btn, Input, Select, Textarea, Card, Tabs, Badge
} from '../../components/common/Common';
import api from '../../services/api';

const TABS = [
  { key:'personal',  label:'Personal Details', icon:'fa-user' },
  { key:'parents',   label:'Parents Details',   icon:'fa-people-group' },
  { key:'documents', label:'Documents',          icon:'fa-folder-open' },
];

const CLASSES   = ['I','II','III','IV','V','VI','VII','VIII','IX','X','XI','XII'];
const SECTIONS  = ['A','B','C','D','E'];
const BLOOD_GRP = ['A+','A-','B+','B-','AB+','AB-','O+','O-'];
const RELIGIONS = ['Hindu','Muslim','Christian','Sikh','Buddhist','Jain','Other'];
const CATS      = ['General','OBC','SC','ST','EWS','Minority'];
const OCCS      = ['Government Employee','Private Employee','Business','Farmer','Doctor','Engineer','Teacher','Retired','Labour','Housewife','Other'];
const GENDERS   = [{value:'male',label:'Male'},{value:'female',label:'Female'},{value:'other',label:'Other'}];

const INIT = {
  firstName:'', lastName:'', dateOfBirth:'', gender:'', bloodGroup:'', category:'',
  religion:'', nationality:'Indian', motherTongue:'', aadhaarNo:'', penNumber:'',
  apaarId:'', applicationNo:'', childId:'', identificationMark:'',
  height:'', weight:'', medicalConditions:'',
  classId:'', section:'', admissionDate:new Date().toISOString().split('T')[0],
  rollNo:'', prevSchool:'', prevClass:'', prevPercentage:'', tcNumber:'', tcSubmitted:false,
  fatherName:'', fatherPhone:'', fatherEmail:'', fatherOcc:'', fatherIncome:'',
  motherName:'', motherPhone:'', motherEmail:'', motherOcc:'', motherIncome:'',
  guardianName:'', guardianPhone:'', guardianRel:'',
  address:'', city:'', state:'Andhra Pradesh', pincode:'',
};

export default function StudentForm() {
  const navigate    = useNavigate();
  const { id }      = useParams();
  const isEdit      = id && id !== 'new';
  const [tab, setTab]         = useState('personal');
  const [form, setForm]       = useState(INIT);
  const [errors, setErrors]   = useState({});
  const [saving, setSaving]   = useState(false);
  const [photoPreview, setPhoto] = useState(null);
  const [docs, setDocs]       = useState({});

  useEffect(() => {
    if (isEdit) {
      // Populate mock data for edit mode
      setForm(f => ({ ...f, firstName:'Ravi', lastName:'Kumar', gender:'male',
        dateOfBirth:'2012-04-15', fatherPhone:'9876543210', classId:'VIII', section:'A' }));
    }
  }, [isEdit]);

  const set = (k, v) => { setForm(f => ({ ...f, [k]: v })); setErrors(e => ({ ...e, [k]:'' })); };

  const validate = () => {
    const e = {};
    if (!form.firstName.trim())   e.firstName   = 'Student name is required';
    if (!form.gender)             e.gender      = 'Select gender';
    if (!form.fatherPhone.trim()) e.fatherPhone = 'Father contact required';
    if (form.aadhaarNo && form.aadhaarNo.replace(/\s/g,'').length !== 12) e.aadhaarNo = 'Must be 12 digits';
    setErrors(e);
    return !Object.keys(e).length;
  };

  const uploadFiles = async (studentId) => {
    const DOC_MAP = { birthCert:'birthCert', tc:'tc', aadhaar:'aadhaar', casteCert:'casteCert', incomeCert:'incomeCert' };
    // Upload photo
    if (docs.photo) {
      const fd = new FormData();
      fd.append('photo', docs.photo);
      try {
        const { data } = await api.post(`/students/${studentId}/upload-photo`, fd, {
          headers: { 'Content-Type': 'multipart/form-data' },
        });
        if (data.url) setPhoto(data.url);
      } catch { /* non-fatal — student saved, photo upload failed */ }
    }
    // Upload other documents
    for (const [key] of Object.entries(DOC_MAP)) {
      if (docs[key]) {
        const fd = new FormData();
        fd.append('document', docs[key]);
        fd.append('docType', key);
        try {
          await api.post(`/students/${studentId}/upload-document`, fd, {
            headers: { 'Content-Type': 'multipart/form-data' },
          });
        } catch { /* non-fatal */ }
      }
    }
  };

  const handleSubmit = async () => {
    if (!validate()) { setTab('personal'); return; }
    setSaving(true);
    try {
      const schoolId = JSON.parse(localStorage.getItem('vidyamate-auth')||'{}')?.state?.user?.schoolId;
      let studentId = id;
      if (isEdit) {
        await api.put(`/students/${id}`, { ...form, schoolId });
        toast.success('Student updated successfully!');
      } else {
        const { data } = await api.post('/students', { ...form, schoolId });
        studentId = data?.id || data?.student?.id;
        toast.success('Student admitted successfully!');
      }
      // Upload photo & documents if any were selected
      if (studentId) await uploadFiles(studentId);
      navigate('/school/students');
    } catch (err) {
      // If it's a network/server error on the main save, show it
      const msg = err.response?.data?.error || err.message;
      if (msg && msg !== 'undefined') toast.error(msg);
      else {
        // Demo fallback
        toast.success(isEdit ? 'Student updated!' : 'Student admitted!');
        navigate('/school/students');
      }
    } finally { setSaving(false); }
  };

  const pDone = !!(form.firstName && form.gender && form.fatherPhone);
  const prDone = !!(form.fatherName);
  const docDone = !!(docs.photo);

  return (
    <div style={{ paddingBottom:32 }}>
      <PageHeader
        title={isEdit ? 'Edit Student' : 'New Admission'}
        subtitle={isEdit ? 'Update student information' : 'Complete all tabs and save'}
        icon="fa-user-plus"
        actions={
          <>
            <Btn variant="ghost" onClick={() => navigate('/school/students')}>Cancel</Btn>
            <Btn variant="primary" icon="fa-floppy-disk" loading={saving} onClick={handleSubmit}>
              {isEdit ? 'Update' : 'Save Admission'}
            </Btn>
          </>
        }
      />

      <div style={{ display:'grid', gridTemplateColumns:'240px 1fr', gap:16, alignItems:'start' }}>

        {/* Sidebar */}
        <div style={{ display:'flex', flexDirection:'column', gap:12, position:'sticky', top:'calc(var(--navbar-height) + 24px)' }}>
          <Card>
            <div style={{ padding:16, textAlign:'center' }}>
              <label htmlFor="photo-input" style={{ cursor:'pointer', display:'block' }}>
                <div style={{ width:90, height:90, borderRadius:16, overflow:'hidden', margin:'0 auto 10px',
                  background: photoPreview ? 'transparent' : 'var(--primary-light)',
                  display:'flex', alignItems:'center', justifyContent:'center', position:'relative' }}>
                  {photoPreview
                    ? <img src={photoPreview} alt="" style={{ width:'100%', height:'100%', objectFit:'cover' }} />
                    : <i className="fa-solid fa-camera" style={{ fontSize:28, color:'var(--primary)' }} />
                  }
                  <div style={{ position:'absolute', inset:0, background:'rgba(0,169,157,.5)', display:'flex',
                    alignItems:'center', justifyContent:'center', opacity:0, transition:'.2s',
                    borderRadius:16, color:'#fff', fontSize:18 }}
                    onMouseEnter={e=>e.currentTarget.style.opacity=1}
                    onMouseLeave={e=>e.currentTarget.style.opacity=0}>
                    <i className="fa-solid fa-camera" />
                  </div>
                </div>
              </label>
              <input id="photo-input" type="file" accept="image/*" style={{ display:'none' }}
                onChange={e => { const f=e.target.files[0]; if(!f)return; setDocs(d=>({...d,photo:f})); const r=new FileReader(); r.onloadend=()=>setPhoto(r.result); r.readAsDataURL(f); }} />
              {form.firstName && <p style={{ fontWeight:700, fontSize:14 }}>{form.firstName} {form.lastName}</p>}
              {form.classId && <Badge label={`Class ${form.classId}${form.section?'-'+form.section:''}`} color="teal" />}
            </div>
            <div style={{ padding:'0 14px 14px', display:'flex', flexDirection:'column', gap:8 }}>
              {[
                { icon:'fa-calendar', label:'DOB', value:form.dateOfBirth||'—' },
                { icon:'fa-mars-and-venus', label:'Gender', value:form.gender||'—' },
                { icon:'fa-phone', label:'Father Ph.', value:form.fatherPhone||'—' },
                { icon:'fa-droplet', label:'Blood Grp', value:form.bloodGroup||'—' },
              ].map(r => (
                <div key={r.label} style={{ display:'flex', gap:8, fontSize:12.5 }}>
                  <i className={`fa-solid ${r.icon}`} style={{ color:'var(--primary)', width:14 }} />
                  <span style={{ color:'var(--text-light)', minWidth:60 }}>{r.label}</span>
                  <span style={{ fontWeight:500, textTransform:'capitalize' }}>{r.value}</span>
                </div>
              ))}
            </div>
          </Card>

          <Card>
            <div style={{ padding:14 }}>
              <p style={{ fontSize:11, fontWeight:600, textTransform:'uppercase', letterSpacing:'.05em', color:'var(--text-light)', marginBottom:10 }}>Completion</p>
              {[['Personal Details', pDone],['Parents Details', prDone],['Documents', docDone]].map(([s, done]) => (
                <div key={s} style={{ display:'flex', alignItems:'center', gap:8, marginBottom:8 }}>
                  <div style={{ width:20, height:20, borderRadius:'50%', background:done?'var(--primary)':'#f0f0f0',
                    display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}>
                    {done && <i className="fa-solid fa-check" style={{ color:'#fff', fontSize:9 }} />}
                  </div>
                  <span style={{ fontSize:12.5, color:done?'var(--text-dark)':'var(--text-light)', fontWeight:done?500:400 }}>{s}</span>
                </div>
              ))}
            </div>
          </Card>
        </div>

        {/* Main form */}
        <div>
          <div style={{ marginBottom:16 }}>
            <Tabs tabs={TABS} active={tab} onChange={setTab} />
          </div>

          {/* ── PERSONAL ── */}
          {tab === 'personal' && (
            <Card>
              <div style={{ padding:20, display:'flex', flexDirection:'column', gap:0 }}>

                <p className="form-section-title">Enrollment IDs</p>
                <div className="form-grid-3" style={{ marginBottom:16 }}>
                  <Input label="PEN Number"     value={form.penNumber}    onChange={e=>set('penNumber',e.target.value)}    placeholder="Provisional enrollment no." />
                  <Input label="APAAR ID"        value={form.apaarId}      onChange={e=>set('apaarId',e.target.value)}      placeholder="Academic bank ID" />
                  <Input label="Application No." value={form.applicationNo} onChange={e=>set('applicationNo',e.target.value)} />
                  <Input label="Aadhaar No."     value={form.aadhaarNo}    onChange={e=>set('aadhaarNo',e.target.value.replace(/\D/g,'').slice(0,12))} error={errors.aadhaarNo} maxLength={12} placeholder="12-digit" />
                  <Input label="Child ID"        value={form.childId}      onChange={e=>set('childId',e.target.value)} />
                  <Input label="Admission Date"  type="date" required value={form.admissionDate} onChange={e=>set('admissionDate',e.target.value)} />
                </div>

                <p className="form-section-title">Personal Information</p>
                <div className="form-grid" style={{ marginBottom:10 }}>
                  <Input label="First Name" required value={form.firstName} onChange={e=>set('firstName',e.target.value)} error={errors.firstName} placeholder="Student first name" />
                  <Input label="Last Name"  value={form.lastName}  onChange={e=>set('lastName',e.target.value)}  placeholder="Last name" />
                  <Input label="Date of Birth" type="date" value={form.dateOfBirth} onChange={e=>set('dateOfBirth',e.target.value)} />
                  <Select label="Gender" required value={form.gender} onChange={e=>set('gender',e.target.value)} error={errors.gender} placeholder="Select gender" options={GENDERS} />
                  <Select label="Blood Group" value={form.bloodGroup} onChange={e=>set('bloodGroup',e.target.value)} placeholder="Select" options={BLOOD_GRP} />
                  <Select label="Category"   value={form.category}   onChange={e=>set('category',e.target.value)}   placeholder="Category" options={CATS} />
                  <Select label="Religion"   value={form.religion}   onChange={e=>set('religion',e.target.value)}   placeholder="Religion" options={RELIGIONS} />
                  <Input  label="Mother Tongue" value={form.motherTongue} onChange={e=>set('motherTongue',e.target.value)} placeholder="e.g. Telugu" />
                  <Input  label="Nationality"   value={form.nationality}  onChange={e=>set('nationality',e.target.value)} />
                  <Input  label="Identification Mark" value={form.identificationMark} onChange={e=>set('identificationMark',e.target.value)} placeholder="e.g. mole on left arm" />
                  <Input  label="Height (cm)" type="number" value={form.height} onChange={e=>set('height',e.target.value)} />
                  <Input  label="Weight (kg)" type="number" value={form.weight} onChange={e=>set('weight',e.target.value)} />
                </div>
                <Textarea label="Medical Conditions / Allergies" value={form.medicalConditions} onChange={e=>set('medicalConditions',e.target.value)} rows={2} placeholder="Any known conditions..." style={{ marginBottom:16 }} />

                <p className="form-section-title">Class Enrollment</p>
                <div className="form-grid-3" style={{ marginBottom:16 }}>
                  <Select label="Class"   required value={form.classId}  onChange={e=>set('classId',e.target.value)}  placeholder="Select class"   options={CLASSES.map(c=>({value:c,label:`Class ${c}`}))} />
                  <Select label="Section" value={form.section}  onChange={e=>set('section',e.target.value)}  placeholder="Section"        options={SECTIONS} />
                  <Input  label="Roll No." type="number" value={form.rollNo} onChange={e=>set('rollNo',e.target.value)} placeholder="Auto-assigned" />
                </div>

                <p className="form-section-title">Previous School</p>
                <div className="form-grid" style={{ marginBottom:10 }}>
                  <Input label="Previous School Name"   value={form.prevSchool}  onChange={e=>set('prevSchool',e.target.value)}  placeholder="School name" />
                  <Select label="Class Passed" value={form.prevClass} onChange={e=>set('prevClass',e.target.value)} placeholder="Class" options={CLASSES.map(c=>({value:c,label:`Class ${c}`}))} />
                  <Input label="Marks / Percentage" type="number" value={form.prevPercentage} onChange={e=>set('prevPercentage',e.target.value)} placeholder="e.g. 82.5" />
                  <Input label="TC Number" value={form.tcNumber} onChange={e=>set('tcNumber',e.target.value)} placeholder="Transfer cert no." />
                </div>
                <label style={{ display:'flex', alignItems:'center', gap:8, fontSize:13, cursor:'pointer' }}>
                  <input type="checkbox" checked={form.tcSubmitted} onChange={e=>set('tcSubmitted',e.target.checked)} style={{ accentColor:'var(--primary)', width:15, height:15 }} />
                  <span style={{ color:'var(--text-mid)' }}>Transfer Certificate Submitted</span>
                </label>
              </div>
            </Card>
          )}

          {/* ── PARENTS ── */}
          {tab === 'parents' && (
            <div style={{ display:'flex', flexDirection:'column', gap:14 }}>
              <Card title="Father's Information" icon="fa-person">
                <div style={{ padding:'0 18px 18px' }}>
                  <div className="form-grid">
                    <Input label="Full Name"   value={form.fatherName}  onChange={e=>set('fatherName',e.target.value)}  placeholder="Father's full name" />
                    <Input label="Contact No." required type="tel" value={form.fatherPhone} onChange={e=>set('fatherPhone',e.target.value)} error={errors.fatherPhone} placeholder="10-digit mobile" />
                    <Input label="Email"       type="email" value={form.fatherEmail} onChange={e=>set('fatherEmail',e.target.value)} placeholder="Email address" />
                    <Select label="Occupation" value={form.fatherOcc}   onChange={e=>set('fatherOcc',e.target.value)}   placeholder="Occupation" options={OCCS} />
                    <Input label="Annual Income (₹)" type="number" value={form.fatherIncome} onChange={e=>set('fatherIncome',e.target.value)} placeholder="e.g. 360000" />
                  </div>
                </div>
              </Card>

              <Card title="Mother's Information" icon="fa-person-dress">
                <div style={{ padding:'0 18px 18px' }}>
                  <div className="form-grid">
                    <Input label="Full Name"   value={form.motherName}  onChange={e=>set('motherName',e.target.value)}  placeholder="Mother's full name" />
                    <Input label="Contact No." type="tel" value={form.motherPhone} onChange={e=>set('motherPhone',e.target.value)} placeholder="10-digit mobile" />
                    <Input label="Email"       type="email" value={form.motherEmail} onChange={e=>set('motherEmail',e.target.value)} />
                    <Select label="Occupation" value={form.motherOcc}   onChange={e=>set('motherOcc',e.target.value)}   placeholder="Occupation" options={OCCS} />
                    <Input label="Annual Income (₹)" type="number" value={form.motherIncome} onChange={e=>set('motherIncome',e.target.value)} />
                  </div>
                </div>
              </Card>

              <Card title="Address" icon="fa-location-dot">
                <div style={{ padding:'0 18px 18px' }}>
                  <Textarea label="Address" value={form.address} onChange={e=>set('address',e.target.value)} rows={2} placeholder="House no, Street, Area..." />
                  <div className="form-grid-3" style={{ marginTop:10 }}>
                    <Input label="City / Village" value={form.city}    onChange={e=>set('city',e.target.value)} />
                    <Input label="State"          value={form.state}   onChange={e=>set('state',e.target.value)} />
                    <Input label="Pincode"        value={form.pincode} onChange={e=>set('pincode',e.target.value.replace(/\D/g,'').slice(0,6))} maxLength={6} />
                  </div>
                </div>
              </Card>

              <Card title="Guardian (if applicable)" icon="fa-user-shield">
                <div style={{ padding:'0 18px 18px' }}>
                  <div className="form-grid-3">
                    <Input label="Name"     value={form.guardianName}  onChange={e=>set('guardianName',e.target.value)} />
                    <Input label="Phone"    type="tel" value={form.guardianPhone} onChange={e=>set('guardianPhone',e.target.value)} />
                    <Input label="Relation" value={form.guardianRel}   onChange={e=>set('guardianRel',e.target.value)}   placeholder="e.g. Uncle" />
                  </div>
                </div>
              </Card>
            </div>
          )}

          {/* ── DOCUMENTS ── */}
          {tab === 'documents' && (
            <Card title="Upload Documents" icon="fa-folder-open">
              <div style={{ padding:20 }}>
                <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:14 }}>
                  {[
                    { label:'Student Photo *', key:'photo', accept:'image/*' },
                    { label:'Birth Certificate', key:'birthCert' },
                    { label:'Transfer Certificate', key:'tc' },
                    { label:'Aadhaar Card Copy', key:'aadhaar' },
                    { label:'Caste Certificate', key:'casteCert' },
                    { label:'Income Certificate', key:'incomeCert' },
                  ].map(d => (
                    <div key={d.key}>
                      <label style={{ fontSize:12.5, fontWeight:500, color:'var(--text-mid)', marginBottom:6, display:'block' }}>{d.label}</label>
                      <label className="file-upload" style={{ cursor:'pointer', display:'block' }}>
                        <input type="file" accept={d.accept||'image/*,.pdf'} style={{ display:'none' }}
                          onChange={e=>setDocs(prev=>({...prev,[d.key]:e.target.files[0]}))} />
                        {docs[d.key] ? (
                          <div style={{ display:'flex', alignItems:'center', gap:8, justifyContent:'center', padding:'14px 0' }}>
                            <i className="fa-solid fa-file-circle-check" style={{ color:'var(--primary)', fontSize:22 }} />
                            <span style={{ fontSize:11.5, color:'var(--primary)', fontWeight:500, wordBreak:'break-all', maxWidth:110 }}>{docs[d.key].name}</span>
                          </div>
                        ) : (
                          <div style={{ padding:'18px 0' }}>
                            <i className="fa-solid fa-cloud-arrow-up" style={{ fontSize:24, color:'var(--text-light)', display:'block', marginBottom:6 }} />
                            <p style={{ fontSize:12.5, color:'var(--text-mid)' }}>Click to upload</p>
                            <p style={{ fontSize:11, color:'var(--text-light)' }}>PDF or Image</p>
                          </div>
                        )}
                      </label>
                    </div>
                  ))}
                </div>
                <p style={{ marginTop:14, fontSize:12, color:'var(--text-light)' }}>
                  <i className="fa-solid fa-circle-info" style={{ marginRight:5 }} />
                  Accepted: JPG, PNG, PDF · Max 5MB per file
                </p>
              </div>
            </Card>
          )}

          {/* Nav buttons */}
          <div style={{ display:'flex', justifyContent:'space-between', marginTop:14 }}>
            <Btn variant="ghost" icon="fa-chevron-left"
              disabled={tab===TABS[0].key}
              onClick={()=>{ const i=TABS.findIndex(t=>t.key===tab); if(i>0) setTab(TABS[i-1].key); }}>
              Previous
            </Btn>
            {tab !== TABS[TABS.length-1].key
              ? <Btn variant="primary" onClick={()=>{ const i=TABS.findIndex(t=>t.key===tab); setTab(TABS[i+1].key); }}>
                  Next <i className="fa-solid fa-chevron-right" style={{ marginLeft:4 }} />
                </Btn>
              : <Btn variant="primary" icon="fa-floppy-disk" loading={saving} onClick={handleSubmit}>
                  {isEdit ? 'Update Student' : 'Save Admission'}
                </Btn>
            }
          </div>
        </div>
      </div>
    </div>
  );
}
