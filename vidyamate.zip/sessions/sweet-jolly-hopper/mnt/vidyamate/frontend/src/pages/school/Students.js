import React, { useState, useCallback, useRef } from 'react';
import * as XLSX from 'xlsx';
import { useNavigate } from 'react-router-dom';
import { PageHeader, Btn, SearchBar, DataTable, Badge, Avatar, StatMini, Card, Select, Modal } from '../../components/common/Common';
import { useStudents } from '../../hooks';
import { useSessionContext } from '../../store/sessionStore';
import { fmtDate, exportToCSV, STATUS_COLORS } from '../../utils';
import api from '../../services/api';
import toast from 'react-hot-toast';

// ─── Template column definitions ──────────────────────────────────────────────
const TEMPLATE_COLS = [
  'First Name', 'Last Name', 'Gender', 'Date of Birth',
  'Father Name', 'Father Phone', 'Mother Name', 'Mother Phone',
  'Category', 'Religion', 'Blood Group', 'Aadhaar No', 'Address', 'Class', 'Section',
];

const HEADER_MAP = {
  'First Name':   'firstName',
  'Last Name':    'lastName',
  'Gender':       'gender',
  'Date of Birth':'dateOfBirth',
  'Father Name':  'fatherName',
  'Father Phone': 'fatherPhone',
  'Mother Name':  'motherName',
  'Mother Phone': 'motherPhone',
  'Category':     'category',
  'Religion':     'religion',
  'Blood Group':  'bloodGroup',
  'Aadhaar No':   'aadhaarNo',
  'Address':      'address',
  'Class':        'className',
  'Section':      'section',
};

const REQUIRED_COLS = ['firstName', 'gender', 'fatherPhone', 'className'];

// Client-side row validation — mirrors backend rules
function validateRow(row, idx) {
  const errs = [];
  if (!String(row.firstName || '').trim())        errs.push('First Name required');
  if (!['male','female','other'].includes(String(row.gender || '').toLowerCase()))
    errs.push('Gender must be male / female / other');
  const phone = String(row.fatherPhone || '').replace(/\D/g, '');
  if (!phone || phone.length !== 10)              errs.push('Father Phone must be 10 digits');
  if (!String(row.className || '').trim())        errs.push('Class required');
  if (row.aadhaarNo && !/^\d{12}$/.test(String(row.aadhaarNo).replace(/\s/g, '')))
    errs.push('Aadhaar must be 12 digits');
  return errs;
}

// ─── Download template ─────────────────────────────────────────────────────────
function downloadTemplate() {
  const wb  = XLSX.utils.book_new();
  const ws  = XLSX.utils.aoa_to_sheet([
    TEMPLATE_COLS,
    // Example row
    ['Ravi', 'Kumar', 'male', '2012-05-15', 'Suresh Kumar', '9876543210',
     'Sunita Kumar', '9876543211', 'OBC', 'Hindu', 'O+', '', 'Main Road, Kurnool', 'VI', 'A'],
  ]);
  // Column widths
  ws['!cols'] = TEMPLATE_COLS.map((h, i) => ({ wch: i < 2 ? 14 : i === 12 ? 28 : 16 }));
  XLSX.utils.book_append_sheet(wb, ws, 'Students');
  XLSX.writeFile(wb, 'VidyaMate_Student_Import_Template.xlsx');
}

// ─── Download error report ─────────────────────────────────────────────────────
function downloadErrorReport(parsedRows, errors) {
  const errorRowNums = new Set(errors.map(e => e.row));
  const errorReasonMap = {};
  errors.forEach(e => { errorReasonMap[e.row] = e.reason; });

  const data = [
    [...TEMPLATE_COLS, 'Error Reason'],
    ...parsedRows
      .map((r, i) => ({ r, rowNum: i + 2 }))
      .filter(({ rowNum }) => errorRowNums.has(rowNum))
      .map(({ r, rowNum }) => [
        r.firstName || '', r.lastName || '', r.gender || '', r.dateOfBirth || '',
        r.fatherName || '', r.fatherPhone || '', r.motherName || '', r.motherPhone || '',
        r.category || '', r.religion || '', r.bloodGroup || '', r.aadhaarNo || '',
        r.address || '', r.className || '', r.section || '',
        errorReasonMap[rowNum] || '',
      ]),
  ];

  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.aoa_to_sheet(data);
  ws['!cols'] = [...TEMPLATE_COLS.map(() => ({ wch: 16 })), { wch: 40 }];
  XLSX.utils.book_append_sheet(wb, ws, 'Errors');
  XLSX.writeFile(wb, 'VidyaMate_Import_Errors.xlsx');
}

// ─── Main component ────────────────────────────────────────────────────────────
export default function Students() {
  const navigate = useNavigate();
  const { sessionId } = useSessionContext();
  const [search,      setSearch]      = useState('');
  const [classFilter, setClass]       = useState('');
  const [status,      setStatus]      = useState('active');
  const [page,        setPage]        = useState(1);

  const { students, pagination, loading, refetch } = useStudents({
    search, classId: classFilter, status, page, limit: 50, sessionId
  });

  // ── Import state ─────────────────────────────────────────────────────────────
  const [showImport,   setShowImport]  = useState(false);
  // step: 'upload' | 'preview' | 'importing' | 'results'
  const [step,         setStep]        = useState('upload');
  const [parsedRows,   setParsedRows]  = useState([]);   // all rows
  const [rowErrors,    setRowErrors]   = useState([]);   // { rowIdx (0-based), errs[] }
  const [importing,    setImporting]   = useState(false);
  const [results,      setResults]     = useState(null); // { imported, failed, errors }
  const [fileName,     setFileName]    = useState('');
  const fileRef = useRef(null);

  const resetImport = () => {
    setStep('upload'); setParsedRows([]); setRowErrors([]);
    setImporting(false); setResults(null); setFileName('');
    if (fileRef.current) fileRef.current.value = '';
  };

  // Parse file with SheetJS
  const handleFileSelect = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setFileName(file.name);

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const wb   = XLSX.read(evt.target.result, { type: 'array', cellDates: true });
        const ws   = wb.Sheets[wb.SheetNames[0]];
        const raw  = XLSX.utils.sheet_to_json(ws, { header: 1, defval: '' });

        if (raw.length < 2) { toast.error('File is empty or has only headers'); return; }

        // Map header row → field names
        const headers = (raw[0] || []).map(h => String(h).trim());
        const fieldNames = headers.map(h => HEADER_MAP[h] || h);

        const rows = raw.slice(1)
          .filter(r => r.some(cell => cell !== '' && cell !== null && cell !== undefined))
          .map(r => {
            const obj = {};
            fieldNames.forEach((f, i) => {
              let val = r[i];
              // Normalise dates: Excel may give a JS Date, a serial, or a string
              if (f === 'dateOfBirth') {
                if (val instanceof Date) {
                  val = val.toISOString().split('T')[0];
                } else if (typeof val === 'number') {
                  const d = XLSX.SSF.parse_date_code(val);
                  val = `${d.y}-${String(d.m).padStart(2,'0')}-${String(d.d).padStart(2,'0')}`;
                } else {
                  val = String(val || '').trim();
                }
              } else {
                val = val !== null && val !== undefined ? String(val).trim() : '';
              }
              obj[f] = val;
            });
            return obj;
          });

        // Client-side validation
        const errs = [];
        rows.forEach((row, i) => {
          const e = validateRow(row, i);
          if (e.length) errs.push({ rowIdx: i, errs: e });
        });

        setParsedRows(rows);
        setRowErrors(errs);
        setStep('preview');
      } catch (err) {
        toast.error('Failed to parse file: ' + err.message);
      }
    };
    reader.readAsArrayBuffer(file);
  };

  // Send to backend
  const handleImport = async () => {
    const schoolId = JSON.parse(localStorage.getItem('vidyamate-auth') || '{}')?.state?.user?.schoolId;
    setImporting(true);
    setStep('importing');
    try {
      const { data } = await api.post('/students/bulk-import', {
        students: parsedRows,
        schoolId,
        sessionId,
      });
      setResults(data);
      setStep('results');
      if (data.imported > 0) refetch();
    } catch (err) {
      toast.error(err.response?.data?.error || 'Import failed');
      setStep('preview');
    } finally {
      setImporting(false);
    }
  };

  // ── Student list handlers ─────────────────────────────────────────────────────
  const boys  = students.filter(s => s.gender === 'male').length;
  const girls = students.filter(s => s.gender === 'female').length;

  const handleExport = () => {
    exportToCSV(students, 'students', [
      { key:'student_code', label:'Code' },
      { key:'first_name',   label:'First Name' },
      { key:'last_name',    label:'Last Name' },
      { key:'gender',       label:'Gender' },
      { key:'class_name',   label:'Class' },
      { key:'roll_number',  label:'Roll No.' },
      { key:'father_name',  label:"Father's Name" },
      { key:'father_phone', label:'Father Phone' },
      { key:'status',       label:'Status' },
    ]);
    toast.success('Student list exported');
  };

  const cols = [
    { key:'student_code', label:'Code', width:120,
      render:(v,row) => (
        <div style={{ display:'flex', alignItems:'center', gap:8 }}>
          <Avatar name={`${row.first_name} ${row.last_name||''}`} photo={row.photo_url} size={30} />
          <span style={{ fontSize:11, color:'var(--text-light)', fontFamily:'monospace' }}>{v}</span>
        </div>
      )
    },
    { key:'first_name', label:'Student',
      render:(v,row) => (
        <div>
          <p style={{ fontWeight:600 }}>{v} {row.last_name}</p>
          <p style={{ fontSize:11, color:'var(--text-light)' }}>{row.father_name} · {row.father_phone}</p>
        </div>
      )
    },
    { key:'class_name', label:'Class', width:90,
      render:(v,row) => v
        ? <span style={{ background:'#e0f7fa',color:'#006064',padding:'2px 8px',borderRadius:5,fontSize:12,fontWeight:600 }}>{v}-{row.section}</span>
        : '—'
    },
    { key:'roll_number', label:'Roll', width:70,
      render:v => <span style={{ fontWeight:700, color:'var(--primary)' }}>{v||'—'}</span>
    },
    { key:'gender',  label:'Gender', width:80, render:v => <Badge label={v||'—'} color={v==='female'?'purple':'blue'} /> },
    { key:'admission_date', label:'Admitted',
      render:v => fmtDate(v, { day:'2-digit', month:'short', year:'2-digit' })
    },
    { key:'status', label:'Status', width:90,
      render:v => <Badge label={v} color={STATUS_COLORS[v]||'gray'} />
    },
    { key:'id', label:'', width:60,
      render:(v) => (
        <button className="icon-btn" onClick={e => { e.stopPropagation(); navigate(`/school/students/${v}`); }}>
          <i className="fa-solid fa-pen"/>
        </button>
      )
    },
  ];

  // ── Preview helpers ────────────────────────────────────────────────────────────
  const errorRowIdxSet  = new Set(rowErrors.map(e => e.rowIdx));
  const errorReasonMap  = {};
  rowErrors.forEach(e => { errorReasonMap[e.rowIdx] = e.errs.join(' · '); });
  const validCount      = parsedRows.length - rowErrors.length;
  const PREVIEW_COLS    = ['firstName','lastName','gender','fatherPhone','className','section'];
  const PREVIEW_LABELS  = ['First Name','Last Name','Gender','Father Phone','Class','Section'];

  // ── Results helpers ────────────────────────────────────────────────────────────
  const resultErrorSet = new Set((results?.errors || []).map(e => e.row));
  const resultReasonMap = {};
  (results?.errors || []).forEach(e => { resultReasonMap[e.row] = e.reason; });

  return (
    <div>
      <PageHeader title="Students" subtitle={`${pagination.total} students enrolled`} icon="fa-user-graduate"
        actions={
          <>
            <Btn icon="fa-file-arrow-down" variant="ghost" size="sm" onClick={downloadTemplate}>Template</Btn>
            <Btn icon="fa-file-import"     variant="ghost" size="sm" onClick={() => { resetImport(); setShowImport(true); }}>Import</Btn>
            <Btn icon="fa-file-csv"        variant="ghost" size="sm" onClick={handleExport}>Export</Btn>
            <Btn icon="fa-plus" variant="primary" onClick={() => navigate('/school/students/new')}>New Admission</Btn>
          </>
        }
      />

      <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:12, marginBottom:16 }}>
        <StatMini label="Total"  value={pagination.total || students.length} icon="fa-users"        color="#00A99D" />
        <StatMini label="Active" value={students.filter(s=>s.status==='active').length}              icon="fa-user-check"  color="#38a169" />
        <StatMini label="Boys"   value={boys}                                                        icon="fa-person"      color="#2196F3" />
        <StatMini label="Girls"  value={girls}                                                       icon="fa-person-dress" color="#E91E8C" />
      </div>

      <Card>
        <div style={{ display:'flex', gap:10, padding:'14px 16px', borderBottom:'1px solid var(--border)', flexWrap:'wrap' }}>
          <SearchBar value={search} onChange={v => { setSearch(v); setPage(1); }} placeholder="Search name, code, phone..." />
          <Select value={classFilter} onChange={e => { setClass(e.target.value); setPage(1); }}
            placeholder="All Classes"
            options={['I','II','III','IV','V','VI','VII','VIII','IX','X'].map(c=>({ value:c, label:`Class ${c}` }))}
            style={{ width:150 }}
          />
          <Select value={status} onChange={e => { setStatus(e.target.value); setPage(1); }}
            options={[{value:'',label:'All Status'},{value:'active',label:'Active'},{value:'dropped',label:'Dropped'},{value:'alumni',label:'Alumni'}]}
            style={{ width:140 }}
          />
        </div>
        <DataTable columns={cols} data={students} loading={loading}
          onRowClick={row => navigate(`/school/students/${row.id}`)}
          emptyText="No students found. Click 'New Admission' to add."
        />
        {pagination.pages > 1 && (
          <div style={{ display:'flex', justifyContent:'space-between', padding:'12px 16px', borderTop:'1px solid var(--border)', fontSize:13, color:'var(--text-light)' }}>
            <span>Showing {students.length} of {pagination.total}</span>
            <div style={{ display:'flex', gap:4 }}>
              <Btn size="sm" variant="ghost" disabled={page <= 1}                  onClick={() => setPage(p => p-1)}>‹ Prev</Btn>
              <Btn size="sm" variant="ghost" disabled={page >= pagination.pages}   onClick={() => setPage(p => p+1)}>Next ›</Btn>
            </div>
          </div>
        )}
      </Card>

      {/* ── IMPORT MODAL ─────────────────────────────────────────────────────── */}
      <Modal open={showImport} onClose={() => { setShowImport(false); resetImport(); }}
        title="Import Students from Excel"
        size="lg"
        footer={
          <div style={{ display:'flex', gap:8, justifyContent:'space-between', width:'100%' }}>
            <div>
              {step === 'results' && results?.failed > 0 && (
                <Btn variant="ghost" icon="fa-file-arrow-down"
                  onClick={() => downloadErrorReport(parsedRows, results.errors)}>
                  Download Error Report
                </Btn>
              )}
            </div>
            <div style={{ display:'flex', gap:8 }}>
              <Btn variant="ghost" onClick={() => { setShowImport(false); resetImport(); }}>
                {step === 'results' ? 'Close' : 'Cancel'}
              </Btn>
              {step === 'preview' && (
                <>
                  <Btn variant="secondary" onClick={() => { setStep('upload'); setParsedRows([]); setRowErrors([]); setFileName(''); if(fileRef.current) fileRef.current.value=''; }}>
                    ← Back
                  </Btn>
                  <Btn variant="primary" icon="fa-file-import" loading={importing}
                    disabled={validCount === 0}
                    onClick={handleImport}>
                    Import {validCount} Student{validCount !== 1 ? 's' : ''}
                  </Btn>
                </>
              )}
            </div>
          </div>
        }
      >

        {/* ── STEP 1: Upload ── */}
        {step === 'upload' && (
          <div style={{ display:'flex', flexDirection:'column', gap:20 }}>
            {/* How-to */}
            <div style={{ background:'#f0f7ff', borderRadius:10, padding:'14px 16px', border:'1px solid #bee3f8' }}>
              <p style={{ fontWeight:600, fontSize:13.5, marginBottom:8, color:'#2b6cb0' }}>
                <i className="fa-solid fa-circle-info" style={{ marginRight:6 }}/>How to import
              </p>
              <ol style={{ margin:0, paddingLeft:18, fontSize:13, color:'#2d3748', lineHeight:1.8 }}>
                <li>Click <strong>Download Template</strong> below to get the Excel file with correct headers.</li>
                <li>Fill in student data — one student per row. Required: First Name, Gender, Father Phone, Class.</li>
                <li>Save the file and upload it here. Both <code>.xlsx</code> and <code>.csv</code> are accepted.</li>
              </ol>
            </div>

            <div style={{ display:'flex', gap:10 }}>
              <Btn variant="secondary" icon="fa-file-arrow-down" onClick={downloadTemplate}>Download Template</Btn>
            </div>

            {/* File picker */}
            <div>
              <label style={{ fontSize:12.5, fontWeight:600, color:'var(--text-mid)', marginBottom:8, display:'block' }}>
                Upload File (.xlsx or .csv)
              </label>
              <label style={{
                display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center',
                gap:10, padding:'32px 20px', borderRadius:12,
                border:'2px dashed var(--border)', cursor:'pointer',
                background:'#fafafa', transition:'all .15s',
              }}
                onDragOver={e => { e.preventDefault(); e.currentTarget.style.borderColor='var(--primary)'; e.currentTarget.style.background='var(--primary-light)'; }}
                onDragLeave={e => { e.currentTarget.style.borderColor='var(--border)'; e.currentTarget.style.background='#fafafa'; }}
                onDrop={e => {
                  e.preventDefault(); e.currentTarget.style.borderColor='var(--border)'; e.currentTarget.style.background='#fafafa';
                  if (e.dataTransfer.files[0]) { handleFileSelect({ target: { files: e.dataTransfer.files } }); }
                }}
              >
                <i className="fa-solid fa-file-excel" style={{ fontSize:36, color:'#38a169', opacity:.7 }}/>
                <p style={{ fontSize:13.5, color:'var(--text-mid)', margin:0 }}>
                  {fileName ? <><strong style={{ color:'var(--primary)' }}>{fileName}</strong></> : 'Drag & drop your file here, or click to browse'}
                </p>
                <p style={{ fontSize:11.5, color:'var(--text-light)', margin:0 }}>Supports .xlsx and .csv files</p>
                <input ref={fileRef} type="file" accept=".xlsx,.xls,.csv" style={{ display:'none' }}
                  onChange={handleFileSelect} />
              </label>
            </div>
          </div>
        )}

        {/* ── STEP 2: Preview ── */}
        {step === 'preview' && (
          <div style={{ display:'flex', flexDirection:'column', gap:14 }}>
            {/* Summary bar */}
            <div style={{ display:'flex', gap:10, flexWrap:'wrap' }}>
              <div style={{ padding:'8px 14px', borderRadius:8, background:'#f0fff4', border:'1px solid #c6f6d5', fontSize:13 }}>
                <i className="fa-solid fa-circle-check" style={{ color:'#38a169', marginRight:6 }}/>
                <strong style={{ color:'#38a169' }}>{validCount}</strong> valid
              </div>
              {rowErrors.length > 0 && (
                <div style={{ padding:'8px 14px', borderRadius:8, background:'#fff5f5', border:'1px solid #fed7d7', fontSize:13 }}>
                  <i className="fa-solid fa-triangle-exclamation" style={{ color:'#e53e3e', marginRight:6 }}/>
                  <strong style={{ color:'#e53e3e' }}>{rowErrors.length}</strong> with errors — will be skipped
                </div>
              )}
              <div style={{ padding:'8px 14px', borderRadius:8, background:'#f8fafb', border:'1px solid var(--border)', fontSize:13 }}>
                <strong>{parsedRows.length}</strong> total rows in file
              </div>
            </div>

            {/* Preview table */}
            <div>
              <p style={{ fontSize:12.5, fontWeight:600, color:'var(--text-mid)', marginBottom:8 }}>
                Preview {Math.min(parsedRows.length, 10)} of {parsedRows.length} rows
                {rowErrors.length > 0 && ' · Rows with errors highlighted in red'}
              </p>
              <div style={{ overflowX:'auto', borderRadius:8, border:'1px solid var(--border)' }}>
                <table style={{ width:'100%', borderCollapse:'collapse', fontSize:12.5 }}>
                  <thead>
                    <tr style={{ background:'#f4f6f9' }}>
                      <th style={TH}>#</th>
                      {PREVIEW_LABELS.map(l => <th key={l} style={TH}>{l}</th>)}
                      <th style={TH}>Validation</th>
                    </tr>
                  </thead>
                  <tbody>
                    {parsedRows.slice(0, 10).map((row, i) => {
                      const hasErr = errorRowIdxSet.has(i);
                      return (
                        <tr key={i} style={{ background: hasErr ? '#fff5f5' : i % 2 === 0 ? '#fff' : '#fafafa' }}>
                          <td style={{ ...TD, color:'var(--text-light)', textAlign:'center' }}>{i + 2}</td>
                          {PREVIEW_COLS.map(f => (
                            <td key={f} style={{ ...TD, color: hasErr && REQUIRED_COLS.includes(f) && !String(row[f]||'').trim() ? '#e53e3e' : 'inherit',
                              fontWeight: hasErr && REQUIRED_COLS.includes(f) && !String(row[f]||'').trim() ? 600 : 400 }}>
                              {String(row[f] || '—')}
                            </td>
                          ))}
                          <td style={TD}>
                            {hasErr
                              ? <span style={{ color:'#e53e3e', fontSize:11.5 }}>
                                  <i className="fa-solid fa-circle-xmark" style={{ marginRight:4 }}/>
                                  {errorReasonMap[i]}
                                </span>
                              : <span style={{ color:'#38a169', fontSize:11.5 }}>
                                  <i className="fa-solid fa-circle-check" style={{ marginRight:4 }}/>OK
                                </span>
                            }
                          </td>
                        </tr>
                      );
                    })}
                    {parsedRows.length > 10 && (
                      <tr>
                        <td colSpan={PREVIEW_COLS.length + 2} style={{ ...TD, textAlign:'center', color:'var(--text-light)', fontStyle:'italic' }}>
                          … and {parsedRows.length - 10} more rows
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            {validCount === 0 && (
              <div style={{ padding:'12px 16px', borderRadius:8, background:'#fff5f5', border:'1px solid #fed7d7', fontSize:13, color:'#e53e3e' }}>
                <i className="fa-solid fa-triangle-exclamation" style={{ marginRight:6 }}/>
                No valid rows to import. Fix the errors in the file and re-upload.
              </div>
            )}
          </div>
        )}

        {/* ── STEP 3: Importing ── */}
        {step === 'importing' && (
          <div style={{ padding:'48px 0', textAlign:'center' }}>
            <i className="fa-solid fa-spinner fa-spin" style={{ fontSize:36, color:'var(--primary)', marginBottom:16 }}/>
            <p style={{ fontSize:15, fontWeight:600, color:'var(--text-dark)' }}>Importing students…</p>
            <p style={{ fontSize:13, color:'var(--text-light)', marginTop:6 }}>
              Processing {parsedRows.length} rows. This may take a moment.
            </p>
          </div>
        )}

        {/* ── STEP 4: Results ── */}
        {step === 'results' && results && (
          <div style={{ display:'flex', flexDirection:'column', gap:16 }}>
            {/* Big summary */}
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:10 }}>
              <div style={{ textAlign:'center', padding:'16px 0', borderRadius:10, background:'#f0fff4', border:'1px solid #c6f6d5' }}>
                <p style={{ fontSize:28, fontWeight:800, color:'#38a169', margin:0 }}>{results.imported}</p>
                <p style={{ fontSize:12.5, color:'#38a169', margin:0 }}>Imported successfully</p>
              </div>
              <div style={{ textAlign:'center', padding:'16px 0', borderRadius:10, background: results.failed ? '#fff5f5' : '#f0fff4', border:`1px solid ${results.failed ? '#fed7d7' : '#c6f6d5'}` }}>
                <p style={{ fontSize:28, fontWeight:800, color: results.failed ? '#e53e3e' : '#38a169', margin:0 }}>{results.failed}</p>
                <p style={{ fontSize:12.5, color: results.failed ? '#e53e3e' : '#38a169', margin:0 }}>Failed</p>
              </div>
              <div style={{ textAlign:'center', padding:'16px 0', borderRadius:10, background:'#f8fafb', border:'1px solid var(--border)' }}>
                <p style={{ fontSize:28, fontWeight:800, color:'var(--text-dark)', margin:0 }}>{results.total || parsedRows.length}</p>
                <p style={{ fontSize:12.5, color:'var(--text-light)', margin:0 }}>Total rows</p>
              </div>
            </div>

            {/* Per-row result list */}
            {parsedRows.length > 0 && (
              <div style={{ overflowX:'auto', borderRadius:8, border:'1px solid var(--border)', maxHeight:320, overflowY:'auto' }}>
                <table style={{ width:'100%', borderCollapse:'collapse', fontSize:12.5 }}>
                  <thead style={{ position:'sticky', top:0, zIndex:1 }}>
                    <tr style={{ background:'#f4f6f9' }}>
                      <th style={TH}>Row</th>
                      <th style={TH}>Name</th>
                      <th style={TH}>Class</th>
                      <th style={TH}>Father Phone</th>
                      <th style={TH}>Result</th>
                    </tr>
                  </thead>
                  <tbody>
                    {parsedRows.map((row, i) => {
                      const rowNum = i + 2;
                      const failed = resultErrorSet.has(rowNum);
                      return (
                        <tr key={i} style={{ background: failed ? '#fff5f5' : i % 2 === 0 ? '#fff' : '#f9f9f9' }}>
                          <td style={{ ...TD, textAlign:'center', color:'var(--text-light)' }}>{rowNum}</td>
                          <td style={TD}>{String(row.firstName || '')} {String(row.lastName || '')}</td>
                          <td style={TD}>{String(row.className || '')} {row.section ? '-' + row.section : ''}</td>
                          <td style={TD}>{String(row.fatherPhone || '')}</td>
                          <td style={TD}>
                            {failed
                              ? <span style={{ color:'#e53e3e', fontSize:11.5 }}>
                                  <i className="fa-solid fa-circle-xmark" style={{ marginRight:4 }}/>
                                  {resultReasonMap[rowNum]}
                                </span>
                              : <span style={{ color:'#38a169', fontSize:11.5 }}>
                                  <i className="fa-solid fa-circle-check" style={{ marginRight:4 }}/>
                                  Imported
                                </span>
                            }
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}
      </Modal>
    </div>
  );
}

// ─── Table cell styles ─────────────────────────────────────────────────────────
const TH = {
  padding:'8px 12px', textAlign:'left', fontSize:11.5, fontWeight:600,
  color:'var(--text-light)', textTransform:'uppercase', letterSpacing:'.03em',
  borderBottom:'1px solid var(--border)', whiteSpace:'nowrap',
};
const TD = {
  padding:'7px 12px', borderBottom:'1px solid #f7f7f7', verticalAlign:'top',
};
