import React, { useState, useEffect } from 'react';
import { PageHeader, Btn, Card, DataTable, Badge, StatMini, Select } from '../../components/common/Common';
import { useExams, useClasses } from '../../hooks';
import { useSessionContext } from '../../store/sessionStore';
import { examService } from '../../services';
import { fmtCurrency } from '../../utils';
import api from '../../services/api';
import toast from 'react-hot-toast';

export default function Results() {
  const { sessionId } = useSessionContext();
  const { exams } = useExams(sessionId);
  const { data: classesData } = useClasses(sessionId);
  const classes = classesData || [];
  const [selExam, setSelExam]   = useState('');
  const [selClass, setSelClass] = useState('');
  const [results, setResults]   = useState([]);
  const [loading, setLoading]   = useState(false);

  const load = async () => {
    if (!selExam) return;
    setLoading(true);
    try {
      const { data } = await examService.results({ examId: selExam, classId: selClass || undefined });
      // Group by student to compute totals
      const byStudent = {};
      for (const r of (data||[])) {
        if (!byStudent[r.student_id]) {
          byStudent[r.student_id] = { ...r, subjects: {}, total: 0, maxTotal: 0 };
        }
        byStudent[r.student_id].subjects[r.subject_name] = r.marks_obtained;
        byStudent[r.student_id].total    += parseFloat(r.marks_obtained || 0);
        byStudent[r.student_id].maxTotal += parseInt(r.max_marks || 100);
      }
      const rows = Object.values(byStudent).map((s, i) => ({
        ...s,
        pct: s.maxTotal > 0 ? ((s.total / s.maxTotal) * 100).toFixed(1) : '0',
        rank: i + 1,
        passed: s.total >= s.maxTotal * 0.35,
      })).sort((a, b) => b.total - a.total).map((s, i) => ({ ...s, rank: i + 1 }));
      setResults(rows);
    } catch { setResults([]); }
    finally { setLoading(false); }
  };

  useEffect(() => { if (selExam) load(); }, [selExam, selClass]);

  const handleExportPdf = async () => {
    try {
      const { data } = await api.get('/export/results', { params: { examId: selExam, classId: selClass || undefined } });
      toast.success('Results exported'); if (data.url) window.open(data.url, '_blank');
    } catch { toast.error('Export failed'); }
  };

  const passed  = results.filter(r => r.passed).length;
  const avg     = results.length ? (results.reduce((s,r) => s + parseFloat(r.pct||0), 0) / results.length).toFixed(1) : 0;
  const toppers = [...results].slice(0, 3);

  const cols = [
    { key:'rank', label:'Rank', width:65,
      render:v => <span style={{ width:28, height:28, borderRadius:'50%', display:'inline-flex', alignItems:'center', justifyContent:'center', fontSize:12, fontWeight:700,
        background:v===1?'#FFD700':v===2?'#C0C0C0':v===3?'#CD7F32':'#f0f0f0', color:v<=3?'#fff':'var(--text-mid)' }}>{v}</span>
    },
    { key:'roll_number', label:'Roll', width:65 },
    { key:'first_name',  label:'Student', render:(v,row) => <span style={{ fontWeight:600 }}>{v} {row.last_name||''}</span> },
    { key:'total',    label:'Total',  width:90, render:(v,row) => <span style={{ fontWeight:700, color:'var(--primary)' }}>{Math.round(v)}/{row.maxTotal}</span> },
    { key:'pct',      label:'%',      width:70, render:v => <span style={{ fontWeight:600, color:parseFloat(v)>=75?'var(--accent-green)':parseFloat(v)>=50?'var(--accent-orange)':'var(--danger)' }}>{v}%</span> },
    { key:'grade',    label:'Grade',  width:70, render:v => v ? <Badge label={v} color={v?.startsWith('A')?'green':v?.startsWith('B')?'blue':'orange'} /> : '—' },
    { key:'passed',   label:'Result', width:80, render:v => <Badge label={v?'Pass':'Fail'} color={v?'green':'red'} /> },
  ];

  return (
    <div>
      <PageHeader title="Exam Results" subtitle="View and publish student results" icon="fa-chart-line"
        actions={<Btn icon="fa-file-pdf" variant="ghost" size="sm" onClick={handleExportPdf}>Export PDF</Btn>}
      />
      <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:12, marginBottom:16 }}>
        <StatMini label="Total Students" value={results.length} icon="fa-users" color="#00A99D" />
        <StatMini label="Passed" value={passed} icon="fa-circle-check" color="#38a169" />
        <StatMini label="Failed" value={results.length - passed} icon="fa-circle-xmark" color="#e53e3e" />
        <StatMini label="Class Average" value={`${avg}%`} icon="fa-percent" color="#9C27B0" />
      </div>
      <Card>
        <div style={{ padding:'12px 16px', borderBottom:'1px solid var(--border)', display:'flex', gap:10, flexWrap:'wrap', alignItems:'center' }}>
          <Select value={selExam} onChange={e => setSelExam(e.target.value)} style={{ width:240 }}
            placeholder="Select Exam" options={exams.map(e => ({ value:e.id, label:e.exam_name }))} />
          <Select value={selClass} onChange={e => setSelClass(e.target.value)} style={{ width:180 }}
            placeholder="All Classes" options={classes.map(c => ({ value:c.id, label:`Class ${c.class_name}-${c.section}` }))} />
        </div>
        {toppers.length > 0 && (
          <div style={{ padding:'10px 16px', borderBottom:'1px solid var(--border)', display:'flex', gap:10, alignItems:'center' }}>
            <span style={{ fontSize:12, fontWeight:600, color:'var(--text-light)', marginRight:4 }}>🏆 TOPPERS:</span>
            {toppers.map((t,i) => (
              <div key={t.student_id} style={{ display:'flex', alignItems:'center', gap:6, background:i===0?'#FFF9C4':i===1?'#F5F5F5':'#FFF3E0', padding:'4px 10px', borderRadius:20, fontSize:12 }}>
                <span style={{ fontWeight:700 }}>{i+1}.</span>
                <span style={{ fontWeight:600 }}>{t.first_name} {t.last_name||''}</span>
                <span style={{ color:'var(--text-light)' }}>{t.pct}%</span>
              </div>
            ))}
          </div>
        )}
        <DataTable columns={cols} data={results} loading={loading} emptyText="Select exam to view results" />
      </Card>
    </div>
  );
}
