import React, { useState, useEffect } from 'react';
import { PageHeader, Btn, DataTable, Badge, Card, Modal, Input, Select, StatMini } from '../../components/common/Common';
import { classService, subjectService, staffService } from '../../services';
import { useSessionContext } from '../../store/sessionStore';
import toast from 'react-hot-toast';

const SECTIONS = ['A','B','C','D','E'];

export default function Classes() {
  const { sessionId } = useSessionContext();
  const [classes,   setClasses]  = useState([]);
  const [subjects,  setSubjects] = useState([]);
  const [staff,     setStaff]    = useState([]);
  const [loading, setLoading]    = useState(true);
  const [showForm, setShow]      = useState(false);
  const [showSubject, setShowSub] = useState(false);
  const [selClass, setSelClass]  = useState(null);
  const [clsSubjects, setClsSub] = useState([]);
  const [form, setForm]          = useState({ className:'', section:'A', capacity:50, classTeacherId:'', roomNumber:'' });
  const [subForm, setSubForm]    = useState({ subjectId:'', teacherId:'', maxMarks:100, passMarks:35 });
  const [saving, setSaving]      = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      const [cl, su, st] = await Promise.all([classService.list(), subjectService.list(), staffService.list({ staffType:'teaching' })]);
      setClasses(cl.data||[]);
      setSubjects(su.data||[]);
      setStaff(st.data?.staff||[]);
    } catch { setClasses([]); }
    finally { setLoading(false); }
  };

  useEffect(() => { load(); }, [sessionId]);

  const openClassSubjects = async (row) => {
    setSelClass(row);
    try { const { data } = await classService.getSubjects(row.id); setClsSub(data||[]); setShowSub(true); }
    catch { setClsSub([]); setShowSub(true); }
  };

  const handleCreateClass = async () => {
    if (!form.className) { toast.error('Class name required'); return; }
    setSaving(true);
    try { await classService.create(form); toast.success('Class created'); load(); setShow(false); setForm({ className:'', section:'A', capacity:50, classTeacherId:'', roomNumber:'' }); }
    catch (e) { toast.error(e.response?.data?.error||'Failed'); }
    finally { setSaving(false); }
  };

  const handleAddSubject = async () => {
    if (!subForm.subjectId) { toast.error('Select a subject'); return; }
    setSaving(true);
    try { await classService.addSubject(selClass.id, subForm); toast.success('Subject assigned'); const { data } = await classService.getSubjects(selClass.id); setClsSub(data||[]); }
    catch (e) { toast.error(e.response?.data?.error||'Failed'); }
    finally { setSaving(false); setSubForm({ subjectId:'', teacherId:'', maxMarks:100, passMarks:35 }); }
  };

  const CLASSES_ORDER = ['I','II','III','IV','V','VI','VII','VIII','IX','X','XI','XII'];

  const cols = [
    { key:'class_name', label:'Class',
      render:(v,row) => (
        <div style={{ display:'flex', alignItems:'center', gap:10 }}>
          <div style={{ width:40, height:40, borderRadius:10, background:'var(--primary-light)', display:'flex', alignItems:'center', justifyContent:'center', fontWeight:700, fontSize:14, color:'var(--primary)', flexShrink:0 }}>
            {v}-{row.section}
          </div>
          <div>
            <p style={{ fontWeight:600 }}>Class {v} - Section {row.section}</p>
            <p style={{ fontSize:11, color:'var(--text-light)' }}>{row.class_teacher_name || 'No class teacher'}</p>
          </div>
        </div>
      )
    },
    { key:'student_count', label:'Students', width:90,  render:v => <span style={{ fontWeight:700, color:'var(--primary)' }}>{v||0}</span> },
    { key:'capacity',      label:'Capacity', width:90 },
    { key:'room_number',   label:'Room',     width:80,  render:v => v||'—' },
    { key:'id', label:'', width:120,
      render:(v,row) => (
        <Btn size="sm" variant="secondary" onClick={e=>{e.stopPropagation();openClassSubjects(row)}}>
          <i className="fa-solid fa-book" style={{ marginRight:5 }}/>Subjects
        </Btn>
      )
    },
  ];

  const assignedIds = new Set(clsSubjects.map(cs => cs.subject_id));

  return (
    <div>
      <PageHeader title="Class Subject Assignment" subtitle="Configure classes and assign subjects + teachers" icon="fa-chalkboard"
        actions={<Btn icon="fa-plus" variant="primary" onClick={()=>setShow(true)}>Add Class</Btn>}
      />
      <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:12, marginBottom:16 }}>
        <StatMini label="Total Classes"  value={classes.length}                                    icon="fa-chalkboard"     color="#00A99D" />
        <StatMini label="Total Students" value={classes.reduce((s,c)=>s+(c.student_count||0),0)} icon="fa-user-graduate"  color="#2196F3" />
        <StatMini label="Total Capacity" value={classes.reduce((s,c)=>s+(c.capacity||0),0)}      icon="fa-users"          color="#9C27B0" />
      </div>
      <Card>
        <DataTable columns={cols} data={classes} loading={loading} onRowClick={openClassSubjects} emptyText="No classes created yet" />
      </Card>

      {/* Add Class Modal */}
      <Modal open={showForm} onClose={()=>setShow(false)} title="Add New Class" size="md"
        footer={<div style={{ display:'flex', gap:8, justifyContent:'flex-end' }}><Btn variant="ghost" onClick={()=>setShow(false)}>Cancel</Btn><Btn variant="primary" icon="fa-floppy-disk" loading={saving} onClick={handleCreateClass}>Create</Btn></div>}
      >
        <div className="form-grid">
          <Select label="Class" required value={form.className} onChange={e=>setForm(f=>({...f,className:e.target.value}))} placeholder="Select class"
            options={CLASSES_ORDER.map(c=>({value:c,label:`Class ${c}`}))} />
          <Select label="Section" value={form.section} onChange={e=>setForm(f=>({...f,section:e.target.value}))} options={SECTIONS} />
          <Input label="Capacity" type="number" value={form.capacity} onChange={e=>setForm(f=>({...f,capacity:e.target.value}))} />
          <Input label="Room Number" value={form.roomNumber} onChange={e=>setForm(f=>({...f,roomNumber:e.target.value}))} placeholder="e.g. R-101" />
          <div className="col-span-2">
            <Select label="Class Teacher" value={form.classTeacherId} onChange={e=>setForm(f=>({...f,classTeacherId:e.target.value}))} placeholder="Select teacher"
              options={staff.map(s=>({value:s.id,label:`${s.first_name} ${s.last_name||''} — ${s.designation||''}`}))} />
          </div>
        </div>
      </Modal>

      {/* Subject Assignment Modal */}
      <Modal open={showSubject} onClose={()=>setShowSub(false)} title={`Class ${selClass?.class_name}-${selClass?.section} — Subjects`} size="md"
        footer={<div style={{ display:'flex', gap:8, justifyContent:'flex-end' }}><Btn variant="ghost" onClick={()=>setShowSub(false)}>Close</Btn></div>}
      >
        {/* Existing subject assignments */}
        {clsSubjects.length > 0 && (
          <div style={{ marginBottom:16 }}>
            <p style={{ fontSize:12, fontWeight:600, textTransform:'uppercase', letterSpacing:'.05em', color:'var(--text-light)', marginBottom:8 }}>Assigned Subjects</p>
            {clsSubjects.map(cs => (
              <div key={cs.id} style={{ display:'flex', alignItems:'center', gap:10, padding:'8px 10px', borderRadius:8, border:'1px solid var(--border)', marginBottom:4 }}>
                <div style={{ flex:1 }}>
                  <p style={{ fontWeight:600, fontSize:13 }}>{cs.subject_name}</p>
                  <p style={{ fontSize:11, color:'var(--text-light)' }}>{cs.teacher_name||'No teacher assigned'} · Max: {cs.max_marks} · Pass: {cs.pass_marks}</p>
                </div>
                <Badge label="Assigned" color="green" />
              </div>
            ))}
          </div>
        )}
        {/* Add new subject */}
        <p style={{ fontSize:12, fontWeight:600, textTransform:'uppercase', letterSpacing:'.05em', color:'var(--text-light)', marginBottom:8 }}>Add Subject</p>
        <div className="form-grid">
          <Select label="Subject" required value={subForm.subjectId} onChange={e=>setSubForm(f=>({...f,subjectId:e.target.value}))} placeholder="Select subject"
            options={subjects.filter(s=>!assignedIds.has(s.id)).map(s=>({value:s.id,label:s.subject_name}))} />
          <Select label="Teacher" value={subForm.teacherId} onChange={e=>setSubForm(f=>({...f,teacherId:e.target.value}))} placeholder="Select teacher"
            options={staff.map(s=>({value:s.id,label:`${s.first_name} ${s.last_name||''}`}))} />
          <Input label="Max Marks" type="number" value={subForm.maxMarks} onChange={e=>setSubForm(f=>({...f,maxMarks:e.target.value}))} />
          <Input label="Pass Marks" type="number" value={subForm.passMarks} onChange={e=>setSubForm(f=>({...f,passMarks:e.target.value}))} />
        </div>
        <div style={{ marginTop:12 }}>
          <Btn variant="primary" icon="fa-plus" loading={saving} onClick={handleAddSubject}>Assign Subject</Btn>
        </div>
      </Modal>
    </div>
  );
}
