import React, { useState } from 'react';
import { PageHeader, Btn, DataTable, Badge, Card, Modal, Input, Select, StatMini } from '../../components/common/Common';
import { useExams, useClasses } from '../../hooks';
import { useSessionContext } from '../../store/sessionStore';
import { examService } from '../../services';
import { fmtDate, STATUS_COLORS, EXAM_TYPES } from '../../utils';
import toast from 'react-hot-toast';

const TYPE_COLOR = { unit_test:'blue', midterm:'orange', final:'red', annual:'red', quarterly:'purple', half_yearly:'teal', other:'gray' };

export default function Exams() {
  const { sessionId } = useSessionContext();
  const { exams, loading, create, generateHallTickets } = useExams(sessionId);
  const { data: classesData } = useClasses(sessionId);
  const classes = classesData || [];

  const [tab, setTab]     = useState('exams');
  const [showForm, setShow] = useState(false);
  const [saving, setSaving] = useState(false);
  const [selExam, setSelExam] = useState('');
  const [selClass, setSelClass] = useState('');
  const [results, setResults] = useState([]);
  const [loadingResults, setLoadingResults] = useState(false);
  const [form, setForm] = useState({ examName:'', examType:'unit_test', startDate:'', endDate:'', totalMarks:100, passMarks:35, status:'scheduled' });

  const handleCreate = async () => {
    if (!form.examName || !form.startDate) { toast.error('Name and start date required'); return; }
    setSaving(true);
    try { await create(form); setShow(false); setForm({ examName:'', examType:'unit_test', startDate:'', endDate:'', totalMarks:100, passMarks:35, status:'scheduled' }); }
    catch (e) { toast.error(e.response?.data?.error || 'Failed'); }
    finally { setSaving(false); }
  };

  const loadResults = async () => {
    if (!selExam) return;
    setLoadingResults(true);
    try {
      const { data } = await examService.results({ examId: selExam, classId: selClass || undefined });
      setResults(data || []);
    } catch { setResults([]); }
    finally { setLoadingResults(false); }
  };

  const examCols = [
    { key:'exam_name', label:'Exam Name',
      render:(v,row) => <div><p style={{ fontWeight:600 }}>{v}</p><p style={{ fontSize:11, color:'var(--text-light)' }}>{fmtDate(row.start_date,{day:'2-digit',month:'short'})} – {fmtDate(row.end_date,{day:'2-digit',month:'short',year:'2-digit'})}</p></div>
    },
    { key:'exam_type',    label:'Type',      width:120, render:v => <Badge label={v?.replace('_',' ')} color={TYPE_COLOR[v]||'gray'} /> },
    { key:'total_marks',  label:'Max Marks', width:100 },
    { key:'status',       label:'Status',    width:110, render:v => <Badge label={v} color={STATUS_COLORS[v]||'gray'} /> },
    { key:'id', label:'', width:130,
      render:(v,row) => (
        <div style={{ display:'flex', gap:4 }}>
          <Btn size="sm" variant="secondary" onClick={e => { e.stopPropagation(); setSelExam(v); setTab('results'); setTimeout(loadResults, 100); }}>Results</Btn>
          <button className="icon-btn"><i className="fa-solid fa-pen"/></button>
        </div>
      )
    },
  ];

  const resultCols = [
    { key:'roll_number', label:'Roll', width:65 },
    { key:'first_name',  label:'Student', render:(v,row) => <span style={{ fontWeight:600 }}>{v} {row.last_name||''}</span> },
    { key:'marks_obtained', label:'Marks', render:(v,row) => <span style={{ fontWeight:700, color:'var(--primary)' }}>{v||'—'}/{row.max_marks}</span> },
    { key:'grade', label:'Grade', width:70, render:v => v ? <Badge label={v} color={v?.startsWith('A')?'green':v?.startsWith('B')?'blue':'orange'} /> : '—' },
    { key:'is_absent', label:'Status', width:80, render:v => <Badge label={v?'Absent':'Present'} color={v?'red':'green'} /> },
  ];

  return (
    <div>
      <PageHeader title="Examination" subtitle="Schedule exams, enter marks & results" icon="fa-file-pen"
        actions={<Btn icon="fa-plus" variant="primary" onClick={() => setShow(true)}>Schedule Exam</Btn>}
      />

      <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:12, marginBottom:16 }}>
        <StatMini label="Total Exams"  value={exams.length}                                       icon="fa-file-pen"     color="#00A99D" />
        <StatMini label="Completed"    value={exams.filter(e=>e.status==='completed').length}      icon="fa-circle-check" color="#38a169" />
        <StatMini label="Scheduled"    value={exams.filter(e=>e.status==='scheduled').length}      icon="fa-calendar"     color="#F7941D" />
        <StatMini label="Ongoing"      value={exams.filter(e=>e.status==='ongoing').length}        icon="fa-pen"          color="#2196F3" />
      </div>

      <div style={{ display:'flex', gap:4, marginBottom:14 }}>
        {[{k:'exams',l:'Exam Schedule',i:'fa-calendar'},{k:'results',l:'Results',i:'fa-chart-line'},{k:'hallticket',l:'Hall Tickets',i:'fa-id-card'}].map(t => (
          <button key={t.k} onClick={() => setTab(t.k)}
            style={{ padding:'8px 16px', borderRadius:8, fontSize:13, fontWeight:500, border:'1.5px solid', transition:'all .15s', cursor:'pointer',
              borderColor:tab===t.k?'var(--primary)':'var(--border)', background:tab===t.k?'var(--primary)':'#fff', color:tab===t.k?'#fff':'var(--text-mid)', display:'flex', alignItems:'center', gap:6 }}>
            <i className={`fa-solid ${t.i}`}/>{t.l}
          </button>
        ))}
      </div>

      {tab === 'exams' && <Card><DataTable columns={examCols} data={exams} loading={loading} emptyText="No exams scheduled" /></Card>}

      {tab === 'results' && (
        <Card>
          <div style={{ padding:'12px 16px', borderBottom:'1px solid var(--border)', display:'flex', gap:10 }}>
            <Select value={selExam} onChange={e => setSelExam(e.target.value)} style={{ width:240 }}
              placeholder="Select Exam" options={exams.map(e => ({ value:e.id, label:e.exam_name }))} />
            <Select value={selClass} onChange={e => setSelClass(e.target.value)} style={{ width:180 }}
              placeholder="All Classes" options={classes.map(c => ({ value:c.id, label:`Class ${c.class_name}-${c.section}` }))} />
            <Btn variant="primary" size="sm" onClick={loadResults} loading={loadingResults}>Load Results</Btn>
          </div>
          <DataTable columns={resultCols} data={results} loading={loadingResults} emptyText="Select exam and click Load Results" />
        </Card>
      )}

      {tab === 'hallticket' && (
        <Card>
          <div style={{ padding:32, textAlign:'center' }}>
            <i className="fa-solid fa-id-card" style={{ fontSize:48, color:'var(--primary)', marginBottom:12 }}/>
            <h3 style={{ fontSize:16, fontWeight:600, marginBottom:8 }}>Generate Hall Tickets</h3>
            <p style={{ fontSize:13, color:'var(--text-light)', marginBottom:20 }}>Select exam and class to generate hall tickets</p>
            <div style={{ display:'flex', gap:10, justifyContent:'center', marginBottom:20 }}>
              <Select placeholder="Select Exam" value={selExam} onChange={e => setSelExam(e.target.value)} style={{ width:240 }}
                options={exams.map(e => ({ value:e.id, label:e.exam_name }))} />
              <Select placeholder="All Classes" value={selClass} onChange={e => setSelClass(e.target.value)} style={{ width:180 }}
                options={classes.map(c => ({ value:c.id, label:`Class ${c.class_name}-${c.section}` }))} />
            </div>
            <Btn icon="fa-id-card" variant="primary" onClick={() => { if(!selExam){toast.error('Select exam first');return;} generateHallTickets(selExam, selClass||undefined); }}>
              Generate Hall Tickets
            </Btn>
          </div>
        </Card>
      )}

      <Modal open={showForm} onClose={() => setShow(false)} title="Schedule New Exam" size="md"
        footer={<div style={{ display:'flex', gap:8, justifyContent:'flex-end' }}><Btn variant="ghost" onClick={()=>setShow(false)}>Cancel</Btn><Btn variant="primary" icon="fa-calendar-plus" loading={saving} onClick={handleCreate}>Schedule</Btn></div>}
      >
        <div className="form-grid">
          <div className="col-span-2"><Input label="Exam Name" required value={form.examName} onChange={e=>setForm(f=>({...f,examName:e.target.value}))} placeholder="e.g. Mid Term Exam 2025" /></div>
          <Select label="Exam Type" value={form.examType} onChange={e=>setForm(f=>({...f,examType:e.target.value}))}
            options={EXAM_TYPES.map(t=>({value:t,label:t.replace(/_/g,' ')}))} />
          <Select label="Status" value={form.status} onChange={e=>setForm(f=>({...f,status:e.target.value}))}
            options={[{value:'scheduled',label:'Scheduled'},{value:'ongoing',label:'Ongoing'},{value:'completed',label:'Completed'}]} />
          <Input label="Start Date" required type="date" value={form.startDate} onChange={e=>setForm(f=>({...f,startDate:e.target.value}))} />
          <Input label="End Date" type="date" value={form.endDate} min={form.startDate} onChange={e=>setForm(f=>({...f,endDate:e.target.value}))} />
          <Input label="Total Marks" type="number" value={form.totalMarks} onChange={e=>setForm(f=>({...f,totalMarks:e.target.value}))} />
          <Input label="Pass Marks"  type="number" value={form.passMarks}  onChange={e=>setForm(f=>({...f,passMarks:e.target.value}))} />
        </div>
      </Modal>
    </div>
  );
}
