import React, { useState, useEffect, useCallback } from 'react';
import { PageHeader, Btn, Card, Badge, StatMini, Modal, Input, Select, Textarea } from '../../components/common/Common';
import { useSessionContext } from '../../store/sessionStore';
import { useClasses } from '../../hooks';
import { teacherDeskService } from '../../services';
import { fmtDate } from '../../utils';
import api from '../../services/api';
import toast from 'react-hot-toast';

const getSchoolId = () =>
  JSON.parse(localStorage.getItem('vidyamate-auth') || '{}')?.state?.user?.schoolId;

export default function TeacherDesk() {
  const { sessionId } = useSessionContext();
  const { data: classesData } = useClasses(sessionId);
  const classes = classesData || [];

  const [tab, setTab]             = useState('homework');
  const [homework, setHomework]   = useState([]);
  const [diary, setDiary]         = useState([]);
  const [loading, setLoading]     = useState(true);
  const [showHW, setShowHW]       = useState(false);
  const [showDiary, setDiaryModal]= useState(false);
  const [saving, setSaving]       = useState(false);
  const [hwForm, setHwForm]       = useState({ classId:'', subject:'', title:'', description:'', dueDate:'' });
  const [diaryForm, setDiaryForm] = useState({ classId:'', subject:'', diaryDate:new Date().toISOString().split('T')[0], content:'' });

  // ── Marks entry state ─────────────────────────────────────
  const [marksClass,   setMarksClass]   = useState('');
  const [marksExam,    setMarksExam]    = useState('');
  const [marksSubject, setMarksSubject] = useState('');
  const [maxMarks,     setMaxMarks]     = useState('100');
  const [exams,        setExams]        = useState([]);
  const [subjects,     setSubjects]     = useState([]);
  const [students,     setStudents]     = useState([]);
  const [marksMap,     setMarksMap]     = useState({}); // studentId → { marks, isAbsent, remarks }
  const [loadingStudents, setLoadingStudents] = useState(false);
  const [savingMarks,  setSavingMarks]  = useState(false);

  // Load exams & subjects once
  useEffect(() => {
    const schoolId = getSchoolId();
    Promise.all([
      api.get('/exams',    { params: { schoolId, sessionId } }),
      api.get('/subjects', { params: { schoolId } }),
    ]).then(([eRes, sRes]) => {
      setExams(eRes.data   || []);
      setSubjects(sRes.data || []);
    }).catch(() => {});
  }, [sessionId]);

  // Load students when class changes
  useEffect(() => {
    if (!marksClass) { setStudents([]); return; }
    setLoadingStudents(true);
    api.get('/students', { params: { schoolId: getSchoolId(), classId: marksClass, limit: 200 } })
      .then(r => {
        const list = r.data?.students || [];
        setStudents(list);
        const m = {};
        list.forEach(s => { m[s.id] = { marks:'', isAbsent:false, remarks:'' }; });
        setMarksMap(m);
      })
      .catch(() => setStudents([]))
      .finally(() => setLoadingStudents(false));
  }, [marksClass]);

  // Load & apply saved marks when exam+subject change
  useEffect(() => {
    if (!marksExam || !marksSubject || students.length === 0) return;
    // We don't have a GET endpoint for teacher_marks_entry, so just reset
    const m = {};
    students.forEach(s => { m[s.id] = { marks:'', isAbsent:false, remarks:'' }; });
    setMarksMap(m);
  }, [marksExam, marksSubject]);

  const setMark = (id, field, value) =>
    setMarksMap(prev => ({ ...prev, [id]: { ...prev[id], [field]: value } }));

  const handleSaveMarks = async () => {
    if (!marksExam)    { toast.error('Select an exam');    return; }
    if (!marksSubject) { toast.error('Select a subject');  return; }
    if (students.length === 0) { toast.error('No students loaded'); return; }

    const records = students.map(s => ({
      studentId: s.id,
      marks:     parseFloat(marksMap[s.id]?.marks) || 0,
      maxMarks:  parseFloat(maxMarks) || 100,
      isAbsent:  marksMap[s.id]?.isAbsent || false,
      remarks:   marksMap[s.id]?.remarks  || '',
    }));

    setSavingMarks(true);
    try {
      const { data } = await teacherDeskService.enterMarks({
        examId:    marksExam,
        subjectId: marksSubject,
        records,
      });
      toast.success(data.message || `Marks saved for ${records.length} students`);
    } catch (err) {
      toast.error(err.response?.data?.error || 'Failed to save marks');
    } finally { setSavingMarks(false); }
  };

  const load = async () => {
    setLoading(true);
    try {
      const [hw, di] = await Promise.all([teacherDeskService.homework(), teacherDeskService.diary()]);
      setHomework(hw.data||[]);
      setDiary(di.data||[]);
    } catch { setHomework([]); setDiary([]); }
    finally { setLoading(false); }
  };

  useEffect(() => { load(); }, []);

  const saveHW = async () => {
    if (!hwForm.title || !hwForm.subject) { toast.error('Fill required fields'); return; }
    setSaving(true);
    try {
      await teacherDeskService.addHomework(hwForm);
      toast.success('Homework assigned'); load(); setShowHW(false);
      setHwForm({ classId:'', subject:'', title:'', description:'', dueDate:'' });
    } catch (e) { toast.error(e.response?.data?.error||'Failed'); }
    finally { setSaving(false); }
  };

  const saveDiary = async () => {
    if (!diaryForm.content || !diaryForm.subject) { toast.error('Fill required fields'); return; }
    setSaving(true);
    try {
      await teacherDeskService.writeDiary(diaryForm);
      toast.success('Diary saved'); load(); setDiaryModal(false);
      setDiaryForm({ classId:'', subject:'', diaryDate:new Date().toISOString().split('T')[0], content:'' });
    } catch (e) { toast.error(e.response?.data?.error||'Failed'); }
    finally { setSaving(false); }
  };

  // Quick stats
  const filled   = students.length > 0 ? students.filter(s => marksMap[s.id]?.marks !== '' || marksMap[s.id]?.isAbsent).length : 0;
  const absentCt = students.filter(s => marksMap[s.id]?.isAbsent).length;

  return (
    <div>
      <PageHeader title="Teacher Desk" subtitle="Homework, class diary and marks entry" icon="fa-chalkboard"
        actions={
          <>
            <Btn icon="fa-book"  variant="ghost"   onClick={() => setDiaryModal(true)}>Write Diary</Btn>
            <Btn icon="fa-plus"  variant="primary"  onClick={() => setShowHW(true)}>Assign Homework</Btn>
          </>
        }
      />

      <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:12, marginBottom:16 }}>
        <StatMini label="Active Homework" value={homework.filter(h=>h.status==='active').length} icon="fa-file-pen"        color="#F7941D" />
        <StatMini label="Diary Entries"   value={diary.length}                                   icon="fa-book"            color="#9C27B0" />
        <StatMini label="Classes"         value={classes.length}                                  icon="fa-chalkboard-user" color="#00A99D" />
      </div>

      {/* Tabs */}
      <div style={{ display:'flex', gap:4, marginBottom:14 }}>
        {[
          { k:'homework', l:'Homework',    i:'fa-file-pen' },
          { k:'diary',    l:'Class Diary', i:'fa-book' },
          { k:'marks',    l:'Marks Entry', i:'fa-pen-to-square' },
        ].map(t => (
          <button key={t.k} onClick={() => setTab(t.k)}
            style={{ padding:'8px 16px', borderRadius:8, fontSize:13, fontWeight:500, border:'1.5px solid', transition:'all .15s', cursor:'pointer',
              borderColor:tab===t.k?'var(--primary)':'var(--border)', background:tab===t.k?'var(--primary)':'#fff',
              color:tab===t.k?'#fff':'var(--text-mid)', display:'flex', alignItems:'center', gap:6 }}>
            <i className={`fa-solid ${t.i}`}/>{t.l}
          </button>
        ))}
      </div>

      {/* ── HOMEWORK ── */}
      {tab === 'homework' && (
        <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
          {loading
            ? <Card><div style={{ padding:32, textAlign:'center', color:'var(--text-light)' }}><i className="fa-solid fa-spinner fa-spin" style={{ fontSize:24 }}/></div></Card>
            : homework.length === 0
              ? <Card><div style={{ padding:32, textAlign:'center', color:'var(--text-light)' }}>No homework assigned yet</div></Card>
              : homework.map(hw => (
                <Card key={hw.id}>
                  <div style={{ padding:14, display:'flex', gap:14, alignItems:'center' }}>
                    <div style={{ width:42, height:42, borderRadius:10, background:'#fff3e0', display:'flex', alignItems:'center', justifyContent:'center', fontSize:18, color:'#F7941D', flexShrink:0 }}>
                      <i className="fa-solid fa-file-pen"/>
                    </div>
                    <div style={{ flex:1 }}>
                      <p style={{ fontWeight:600, fontSize:14 }}>{hw.title}</p>
                      <p style={{ fontSize:12.5, color:'var(--text-mid)' }}>{hw.subject_name} · Class {hw.class_name}-{hw.section}</p>
                      {hw.due_date && <p style={{ fontSize:11.5, color:'var(--accent-orange)' }}>Due: {fmtDate(hw.due_date,{day:'2-digit',month:'short'})}</p>}
                    </div>
                    <Badge label={hw.status||'active'} color={hw.status==='active'?'green':'gray'} />
                  </div>
                </Card>
              ))
          }
        </div>
      )}

      {/* ── DIARY ── */}
      {tab === 'diary' && (
        <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
          {loading
            ? <Card><div style={{ padding:32, textAlign:'center', color:'var(--text-light)' }}><i className="fa-solid fa-spinner fa-spin" style={{ fontSize:24 }}/></div></Card>
            : diary.length === 0
              ? <Card><div style={{ padding:32, textAlign:'center', color:'var(--text-light)' }}>No diary entries yet</div></Card>
              : diary.map(d => (
                <Card key={d.id}>
                  <div style={{ padding:16, display:'flex', gap:12 }}>
                    <div style={{ width:44, height:44, borderRadius:10, background:'var(--primary-light)', display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', flexShrink:0 }}>
                      <span style={{ fontSize:15, fontWeight:700, color:'var(--primary)', lineHeight:1 }}>{new Date(d.diary_date).getDate()}</span>
                      <span style={{ fontSize:9, color:'var(--primary)', textTransform:'uppercase' }}>{new Date(d.diary_date).toLocaleString('default',{month:'short'})}</span>
                    </div>
                    <div>
                      <p style={{ fontWeight:600, fontSize:13.5 }}>Class {d.class_name}-{d.section} — {d.subject_name}</p>
                      <p style={{ fontSize:13.5, color:'var(--text-dark)', lineHeight:1.6, marginTop:4 }}>{d.content}</p>
                    </div>
                  </div>
                </Card>
              ))
          }
        </div>
      )}

      {/* ── MARKS ENTRY ── */}
      {tab === 'marks' && (
        <div>
          {/* Selector bar */}
          <Card>
            <div style={{ padding:'14px 18px', display:'flex', gap:12, flexWrap:'wrap', alignItems:'flex-end' }}>
              <Select label="Class" value={marksClass} onChange={e => setMarksClass(e.target.value)}
                placeholder="Select class" options={classes.map(c=>({value:c.id,label:`${c.class_name}-${c.section}`}))}
                style={{ width:170 }} />
              <Select label="Exam" value={marksExam} onChange={e => setMarksExam(e.target.value)}
                placeholder="Select exam" options={exams.map(e=>({value:e.id,label:e.exam_name||e.name}))}
                style={{ width:200 }} />
              <Select label="Subject" value={marksSubject} onChange={e => setMarksSubject(e.target.value)}
                placeholder="Select subject" options={subjects.map(s=>({value:s.id,label:s.subject_name}))}
                style={{ width:180 }} />
              <div>
                <p style={{ fontSize:12, fontWeight:500, color:'var(--text-mid)', marginBottom:4 }}>Max Marks</p>
                <input type="number" value={maxMarks} onChange={e=>setMaxMarks(e.target.value)}
                  style={{ width:80, padding:'8px 10px', borderRadius:8, border:'1.5px solid var(--border)', fontSize:13, fontFamily:'inherit' }} />
              </div>
              <div style={{ flex:1 }} />
              {students.length > 0 && (
                <div style={{ fontSize:12.5, color:'var(--text-light)', alignSelf:'center', textAlign:'right' }}>
                  {filled}/{students.length} filled · {absentCt} absent
                </div>
              )}
            </div>
          </Card>

          {/* Student grid */}
          {!marksClass ? (
            <Card>
              <div style={{ padding:40, textAlign:'center', color:'var(--text-light)' }}>
                <i className="fa-solid fa-chalkboard" style={{ fontSize:32, opacity:.3, marginBottom:8 }}/>
                <p>Select a class to start entering marks</p>
              </div>
            </Card>
          ) : loadingStudents ? (
            <Card>
              <div style={{ padding:40, textAlign:'center', color:'var(--text-light)' }}>
                <i className="fa-solid fa-spinner fa-spin" style={{ fontSize:24 }}/>
              </div>
            </Card>
          ) : students.length === 0 ? (
            <Card>
              <div style={{ padding:40, textAlign:'center', color:'var(--text-light)' }}>
                <i className="fa-solid fa-users" style={{ fontSize:32, opacity:.3, marginBottom:8 }}/>
                <p>No students in this class</p>
              </div>
            </Card>
          ) : (
            <Card>
              {/* Table header */}
              <div style={{ display:'grid', gridTemplateColumns:'40px 1fr 80px 100px 100px 1fr', gap:0,
                padding:'8px 16px', borderBottom:'2px solid var(--border)', background:'#f8fafb',
                fontSize:12, fontWeight:600, color:'var(--text-light)', textTransform:'uppercase', letterSpacing:'.04em' }}>
                <span>#</span>
                <span>Student</span>
                <span>Roll</span>
                <span style={{ textAlign:'center' }}>Absent</span>
                <span>Marks / {maxMarks}</span>
                <span>Remarks</span>
              </div>

              <div style={{ maxHeight:480, overflowY:'auto' }}>
                {students.map((s, idx) => {
                  const entry   = marksMap[s.id] || { marks:'', isAbsent:false, remarks:'' };
                  const isAbsent = entry.isAbsent;
                  const marks    = parseFloat(entry.marks);
                  const max      = parseFloat(maxMarks) || 100;
                  const pct      = !isNaN(marks) && entry.marks !== '' ? Math.round((marks/max)*100) : null;
                  return (
                    <div key={s.id} style={{
                      display:'grid', gridTemplateColumns:'40px 1fr 80px 100px 100px 1fr', gap:0,
                      padding:'8px 16px', borderBottom:'1px solid #f7f7f7', alignItems:'center',
                      background: isAbsent ? '#fff5f5' : idx%2===0 ? '#fff' : '#fafafa',
                    }}>
                      <span style={{ fontSize:12, color:'var(--text-light)' }}>{idx+1}</span>

                      <div>
                        <p style={{ fontWeight:600, fontSize:13 }}>{s.first_name} {s.last_name||''}</p>
                        <p style={{ fontSize:11, color:'var(--text-light)' }}>{s.student_code}</p>
                      </div>

                      <span style={{ fontSize:13, color:'var(--text-mid)' }}>{s.roll_number||'—'}</span>

                      <div style={{ display:'flex', justifyContent:'center' }}>
                        <label style={{ cursor:'pointer', display:'flex', alignItems:'center', gap:4 }}>
                          <input type="checkbox" checked={isAbsent}
                            onChange={e => setMark(s.id, 'isAbsent', e.target.checked)}
                            style={{ accentColor:'#e53e3e', width:16, height:16 }} />
                          {isAbsent && <span style={{ fontSize:11, color:'#e53e3e', fontWeight:600 }}>AB</span>}
                        </label>
                      </div>

                      <div style={{ display:'flex', alignItems:'center', gap:4 }}>
                        <input
                          type="number" disabled={isAbsent}
                          value={entry.marks} onChange={e => setMark(s.id, 'marks', e.target.value)}
                          min={0} max={maxMarks} placeholder="—"
                          style={{
                            width:60, padding:'5px 8px', borderRadius:6, fontSize:13, fontFamily:'inherit',
                            border:`1.5px solid ${pct !== null ? (pct>=35?'#38a16980':'#e53e3e80') : 'var(--border)'}`,
                            background: isAbsent ? '#f7f7f7' : '#fff',
                            textAlign:'center',
                          }}
                        />
                        {pct !== null && !isAbsent && (
                          <span style={{ fontSize:10.5, color: pct>=35?'#38a169':'#e53e3e', fontWeight:600 }}>{pct}%</span>
                        )}
                      </div>

                      <input
                        type="text" disabled={isAbsent}
                        value={entry.remarks} onChange={e => setMark(s.id, 'remarks', e.target.value)}
                        placeholder="Optional remarks"
                        style={{ padding:'5px 8px', borderRadius:6, fontSize:12, fontFamily:'inherit',
                          border:'1.5px solid var(--border)', background: isAbsent ? '#f7f7f7' : '#fff' }}
                      />
                    </div>
                  );
                })}
              </div>

              {/* Footer */}
              <div style={{ padding:'12px 18px', borderTop:'1px solid var(--border)', display:'flex',
                justifyContent:'space-between', alignItems:'center', background:'#fafafa', borderRadius:'0 0 12px 12px' }}>
                <div style={{ fontSize:12.5, color:'var(--text-light)' }}>
                  {marksExam && marksSubject
                    ? `${exams.find(e=>e.id===marksExam)?.exam_name||'Exam'} · ${subjects.find(s=>s.id===marksSubject)?.subject_name||'Subject'}`
                    : <span style={{ color:'#F7941D' }}>⚠ Select exam and subject before saving</span>}
                </div>
                <Btn variant="primary" icon="fa-floppy-disk" loading={savingMarks} onClick={handleSaveMarks}
                  disabled={!marksExam || !marksSubject || students.length === 0}>
                  Save All Marks
                </Btn>
              </div>
            </Card>
          )}
        </div>
      )}

      {/* ── HOMEWORK MODAL ── */}
      <Modal open={showHW} onClose={() => setShowHW(false)} title="Assign Homework" size="md"
        footer={<div style={{ display:'flex', gap:8, justifyContent:'flex-end' }}>
          <Btn variant="ghost" onClick={()=>setShowHW(false)}>Cancel</Btn>
          <Btn variant="primary" icon="fa-paper-plane" loading={saving} onClick={saveHW}>Assign</Btn>
        </div>}
      >
        <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
          <Input label="Title" required value={hwForm.title} onChange={e=>setHwForm(f=>({...f,title:e.target.value}))} />
          <div className="form-grid">
            <Input label="Subject" required value={hwForm.subject} onChange={e=>setHwForm(f=>({...f,subject:e.target.value}))} />
            <Select label="Class" value={hwForm.classId} onChange={e=>setHwForm(f=>({...f,classId:e.target.value}))}
              placeholder="Select class" options={classes.map(c=>({value:c.id,label:`${c.class_name}-${c.section}`}))} />
            <Input label="Due Date" type="date" value={hwForm.dueDate} onChange={e=>setHwForm(f=>({...f,dueDate:e.target.value}))} />
          </div>
          <Textarea label="Instructions" value={hwForm.description} onChange={e=>setHwForm(f=>({...f,description:e.target.value}))} rows={3} />
        </div>
      </Modal>

      {/* ── DIARY MODAL ── */}
      <Modal open={showDiary} onClose={() => setDiaryModal(false)} title="Write Class Diary" size="md"
        footer={<div style={{ display:'flex', gap:8, justifyContent:'flex-end' }}>
          <Btn variant="ghost" onClick={()=>setDiaryModal(false)}>Cancel</Btn>
          <Btn variant="primary" icon="fa-floppy-disk" loading={saving} onClick={saveDiary}>Save</Btn>
        </div>}
      >
        <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
          <div className="form-grid">
            <Input label="Date" type="date" value={diaryForm.diaryDate} onChange={e=>setDiaryForm(f=>({...f,diaryDate:e.target.value}))} />
            <Select label="Class" value={diaryForm.classId} onChange={e=>setDiaryForm(f=>({...f,classId:e.target.value}))}
              placeholder="Select class" options={classes.map(c=>({value:c.id,label:`${c.class_name}-${c.section}`}))} />
            <Input label="Subject" required value={diaryForm.subject} onChange={e=>setDiaryForm(f=>({...f,subject:e.target.value}))} />
          </div>
          <Textarea label="What was taught today? *" required value={diaryForm.content}
            onChange={e=>setDiaryForm(f=>({...f,content:e.target.value}))} rows={5}
            placeholder="Describe lesson, student engagement, homework given..." />
        </div>
      </Modal>
    </div>
  );
}
