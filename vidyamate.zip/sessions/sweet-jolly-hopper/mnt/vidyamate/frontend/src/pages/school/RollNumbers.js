import React, { useState, useEffect } from 'react';
import { PageHeader, Btn, Card, StatMini } from '../../components/common/Common';
import { useClasses } from '../../hooks';
import { useSessionContext } from '../../store/sessionStore';
import api from '../../services/api';
import toast from 'react-hot-toast';

export default function RollNumbers() {
  const { sessionId }           = useSessionContext();
  const { data: classesData }   = useClasses(sessionId);
  const classes = classesData || [];
  const [selClass, setSelClass] = useState(null);
  const [students, setStudents] = useState([]);
  const [loading, setLoading]   = useState(false);
  const [saving, setSaving]     = useState(false);
  const [editId, setEditId]     = useState(null);
  const [editVal, setEditVal]   = useState('');

  // Set first class on load
  useEffect(() => { if (classes.length && !selClass) setSelClass(classes[0]); }, [classes]);

  // Load students when class changes
  useEffect(() => {
    if (!selClass?.id) return;
    setLoading(true);
    api.get(`/students/${selClass.id}/roll-numbers`, { params: { sessionId } })
      .then(r => setStudents((r.data || []).map(s => ({ ...s, roll: s.roll_number || 0 }))))
      .catch(() => setStudents([]))
      .finally(() => setLoading(false));
  }, [selClass?.id, sessionId]);

  const autoGenerate = () => {
    const sorted = [...students].sort((a, b) =>
      `${a.first_name} ${a.last_name}`.localeCompare(`${b.first_name} ${b.last_name}`)
    );
    setStudents(sorted.map((s, i) => ({ ...s, roll: i + 1 })));
    toast.success('Roll numbers generated alphabetically');
  };

  const saveAll = async () => {
    if (!selClass?.id) return;
    setSaving(true);
    try {
      await api.post(`/students/${selClass.id}/roll-numbers`, {
        assignments: students.map(s => ({ studentId: s.id, rollNo: s.roll })),
        sessionId,
      });
      toast.success(`Roll numbers saved for Class ${selClass.class_name}-${selClass.section}`);
    } catch (e) { toast.error(e.response?.data?.error || 'Save failed'); }
    finally { setSaving(false); }
  };

  const startEdit  = (s)   => { setEditId(s.id); setEditVal(s.roll); };
  const saveEdit   = (id)  => {
    const n = parseInt(editVal);
    if (isNaN(n) || n < 1) { toast.error('Invalid roll number'); return; }
    if (students.some(s => s.id !== id && s.roll === n)) { toast.error('Roll number already assigned'); return; }
    setStudents(s => s.map(x => x.id === id ? { ...x, roll: n } : x));
    setEditId(null);
  };

  const moveUp   = (i) => {
    if (i === 0) return;
    const a = [...students];
    [a[i-1], a[i]] = [a[i], a[i-1]];
    setStudents(a.map((s, idx) => ({ ...s, roll: idx + 1 })));
  };
  const moveDown = (i) => {
    if (i === students.length - 1) return;
    const a = [...students];
    [a[i], a[i+1]] = [a[i+1], a[i]];
    setStudents(a.map((s, idx) => ({ ...s, roll: idx + 1 })));
  };

  return (
    <div>
      <PageHeader
        title="Roll Number Allotment"
        subtitle="Assign roll numbers per class and session"
        icon="fa-list-ol"
        actions={
          <>
            <Btn icon="fa-sort-alpha-down" variant="ghost" onClick={autoGenerate}>Auto Generate</Btn>
            <Btn icon="fa-floppy-disk" variant="primary" loading={saving} onClick={saveAll}
              disabled={!selClass || !students.length}>
              Save Roll Numbers
            </Btn>
          </>
        }
      />

      <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:12, marginBottom:16 }}>
        <StatMini label="Total Students" value={students.length} icon="fa-users"      color="#00A99D" />
        <StatMini label="Class"          value={selClass ? `${selClass.class_name}-${selClass.section}` : '—'} icon="fa-chalkboard" color="#2196F3" />
        <StatMini label="Last Roll No."  value={students.length ? Math.max(...students.map(s=>s.roll)) : '—'} icon="fa-hashtag" color="#9C27B0" />
      </div>

      <div style={{ display:'grid', gridTemplateColumns:'200px 1fr', gap:14 }}>
        {/* Class picker */}
        <Card>
          <div style={{ padding:14 }}>
            <p style={{ fontSize:11, fontWeight:600, textTransform:'uppercase', letterSpacing:'.05em', color:'var(--text-light)', marginBottom:10 }}>Select Class</p>
            {classes.length === 0
              ? <p style={{ fontSize:13, color:'var(--text-light)' }}>Loading classes...</p>
              : classes.map(c => (
                <button key={c.id} onClick={() => setSelClass(c)}
                  style={{ display:'block', width:'100%', textAlign:'left', padding:'8px 12px', borderRadius:8,
                    marginBottom:3, fontSize:13, fontWeight:500, transition:'all .15s', border:'none', cursor:'pointer',
                    background: selClass?.id===c.id ? 'var(--primary-light)' : 'transparent',
                    color:       selClass?.id===c.id ? 'var(--primary-dark)' : 'var(--text-mid)',
                    borderLeft:  selClass?.id===c.id ? '3px solid var(--primary)' : '3px solid transparent',
                  }}>
                  Class {c.class_name}-{c.section}
                  <span style={{ float:'right', fontSize:11, color:'var(--text-light)' }}>{c.student_count||0}</span>
                </button>
              ))
            }
          </div>
        </Card>

        {/* Roll number editor */}
        <Card title={selClass ? `Class ${selClass.class_name}-${selClass.section}` : 'Select a Class'} icon="fa-list-ol">
          <div style={{ padding:'0 16px 16px' }}>
            {loading ? (
              <div style={{ padding:32, textAlign:'center', color:'var(--text-light)' }}>
                <i className="fa-solid fa-spinner fa-spin" style={{ fontSize:24 }}/>
              </div>
            ) : students.length === 0 ? (
              <div style={{ padding:32, textAlign:'center', color:'var(--text-light)' }}>
                {selClass ? 'No students in this class' : 'Select a class to view students'}
              </div>
            ) : (
              <>
                <p style={{ fontSize:12, color:'var(--text-light)', marginBottom:10 }}>
                  Click roll number to edit · Use arrows to reorder
                </p>
                <div style={{ display:'flex', flexDirection:'column', gap:4 }}>
                  {[...students].sort((a,b) => a.roll - b.roll).map((s, i) => (
                    <div key={s.id} style={{ display:'flex', alignItems:'center', gap:10,
                      padding:'8px 10px', borderRadius:9, border:'1.5px solid var(--border)',
                      background:'#fff', transition:'all .15s' }}
                      onMouseEnter={e=>e.currentTarget.style.borderColor='var(--primary)'}
                      onMouseLeave={e=>e.currentTarget.style.borderColor='var(--border)'}
                    >
                      {/* Editable roll number */}
                      {editId === s.id ? (
                        <input autoFocus type="number" value={editVal}
                          onChange={e => setEditVal(e.target.value)}
                          onBlur={() => saveEdit(s.id)}
                          onKeyDown={e => { if(e.key==='Enter') saveEdit(s.id); if(e.key==='Escape') setEditId(null); }}
                          style={{ width:52, padding:'4px 8px', borderRadius:6, border:'2px solid var(--primary)',
                            fontWeight:700, fontSize:14, textAlign:'center', outline:'none', color:'var(--primary)' }}
                        />
                      ) : (
                        <div onClick={() => startEdit(s)}
                          style={{ width:40, height:40, borderRadius:8, background:'var(--primary-light)',
                            display:'flex', alignItems:'center', justifyContent:'center',
                            fontWeight:700, fontSize:16, color:'var(--primary)', cursor:'text', flexShrink:0 }}>
                          {s.roll}
                        </div>
                      )}

                      <div style={{ flex:1 }}>
                        <p style={{ fontWeight:600, fontSize:13.5, color:'var(--text-dark)' }}>
                          {s.first_name} {s.last_name||''}
                        </p>
                        <p style={{ fontSize:11, color:'var(--text-light)', fontFamily:'monospace' }}>{s.student_code}</p>
                      </div>

                      <div style={{ display:'flex', flexDirection:'column', gap:2 }}>
                        {[{fn:moveUp,i:'fa-chevron-up',dis:i===0},{fn:moveDown,i:'fa-chevron-down',dis:i===students.length-1}].map(btn => (
                          <button key={btn.i} onClick={() => btn.fn(i)} disabled={btn.dis}
                            style={{ width:22, height:22, borderRadius:5, border:'1px solid var(--border)',
                              display:'flex', alignItems:'center', justifyContent:'center',
                              color:'var(--text-light)', fontSize:10, cursor: btn.dis ? 'not-allowed' : 'pointer',
                              opacity: btn.dis ? 0.4 : 1 }}>
                            <i className={`fa-solid ${btn.i}`}/>
                          </button>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </>
            )}
          </div>
        </Card>
      </div>
    </div>
  );
}
