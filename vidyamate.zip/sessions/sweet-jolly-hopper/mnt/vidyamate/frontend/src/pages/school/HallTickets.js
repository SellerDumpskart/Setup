import React, { useState, useEffect } from 'react';
import { PageHeader, Btn, Card, DataTable, Badge, StatMini, Select } from '../../components/common/Common';
import { useExams, useClasses } from '../../hooks';
import { useSessionContext } from '../../store/sessionStore';
import { examService } from '../../services';
import { fmtDate, printElement } from '../../utils';
import toast from 'react-hot-toast';

export default function HallTickets() {
  const { sessionId } = useSessionContext();
  const { exams } = useExams(sessionId);
  const { data: classesData } = useClasses(sessionId);
  const classes = classesData || [];
  const [selExam, setSelExam]   = useState('');
  const [selClass, setSelClass] = useState('');
  const [tickets, setTickets]   = useState([]);
  const [loading, setLoading]   = useState(false);
  const [generating, setGen]    = useState(false);

  const loadTickets = async () => {
    if (!selExam) return;
    setLoading(true);
    try { const { data } = await examService.hallTickets(selExam, selClass||undefined); setTickets(data||[]); }
    catch { setTickets([]); }
    finally { setLoading(false); }
  };

  useEffect(() => { if (selExam) loadTickets(); }, [selExam, selClass]);

  const generate = async () => {
    if (!selExam) { toast.error('Select exam first'); return; }
    setGen(true);
    try {
      const { data } = await examService.generateTickets(selExam, selClass||undefined);
      toast.success(`${data.tickets?.length||0} hall tickets generated!`);
      loadTickets();
    } catch (e) { toast.error(e.response?.data?.error||'Generation failed'); }
    finally { setGen(false); }
  };

  const issued = tickets.filter(t => t.is_issued).length;

  const cols = [
    { key:'hall_ticket_no', label:'Ticket No.', render:v => <span style={{ fontFamily:'monospace', fontSize:12, color:'var(--primary)', fontWeight:600 }}>{v}</span> },
    { key:'first_name', label:'Student', render:(v,row) => <div><p style={{ fontWeight:600 }}>{v} {row.last_name||''}</p><p style={{ fontSize:11, color:'var(--text-light)' }}>{row.class_name}-{row.section}</p></div> },
    { key:'roll_number', label:'Roll', width:70 },
    { key:'date_of_birth', label:'DOB', render:v => fmtDate(v, { day:'2-digit', month:'short', year:'numeric' }) },
    { key:'is_issued', label:'Status', width:100, render:v => <Badge label={v?'Issued':'Pending'} color={v?'green':'orange'} /> },
    { key:'hall_ticket_no', label:'', width:80,
      render:(v,row) => row.is_issued ? (
        <button className="icon-btn" title="Download" onClick={e => { e.stopPropagation(); window.open(`/export/receipt/${row.id}`, '_blank'); }}><i className="fa-solid fa-download"/></button>
      ) : null
    },
  ];

  return (
    <div>
      <PageHeader title="Hall Tickets" subtitle="Generate and download exam admit cards" icon="fa-id-card"
        actions={
          <>
            <Btn icon="fa-print" variant="ghost" size="sm"
              disabled={!tickets.length}
              onClick={() => printElement('hall-ticket-print-area', 'Hall Tickets')}>
              Print
            </Btn>
            <Btn icon="fa-id-card" variant="primary" loading={generating} onClick={generate}>Generate Hall Tickets</Btn>
          </>
        }
      />
      <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:12, marginBottom:16 }}>
        <StatMini label="Total" value={tickets.length} icon="fa-users" color="#00A99D" />
        <StatMini label="Issued" value={issued} icon="fa-circle-check" color="#38a169" />
        <StatMini label="Pending" value={tickets.length - issued} icon="fa-clock" color="#F7941D" />
      </div>
      <Card>
        <div style={{ padding:'12px 16px', borderBottom:'1px solid var(--border)', display:'flex', gap:10 }}>
          <Select value={selExam} onChange={e => setSelExam(e.target.value)} style={{ width:260 }}
            placeholder="Select Exam" options={exams.map(e => ({ value:e.id, label:e.exam_name }))} />
          <Select value={selClass} onChange={e => setSelClass(e.target.value)} style={{ width:180 }}
            placeholder="All Classes" options={classes.map(c => ({ value:c.id, label:`Class ${c.class_name}-${c.section}` }))} />
        </div>
        <div id="hall-ticket-print-area">
          <DataTable columns={cols} data={tickets} loading={loading} emptyText="Select exam and generate hall tickets" />
        </div>
      </Card>
    </div>
  );
}
