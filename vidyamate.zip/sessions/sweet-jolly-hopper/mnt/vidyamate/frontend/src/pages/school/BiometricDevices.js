import React, { useState, useEffect, useRef, useCallback } from 'react';
import { PageHeader, Btn, Card, Badge, Modal } from '../../components/common/Common';
import { useSessionContext } from '../../store/sessionStore';
import api from '../../services/api';
import toast from 'react-hot-toast';

// ── helpers ──────────────────────────────────────────────────
const formatDt = (ts) => {
  if (!ts) return '—';
  const d = new Date(ts);
  return d.toLocaleDateString('en-IN') + ' ' + d.toLocaleTimeString('en-IN', { hour:'2-digit', minute:'2-digit' });
};
const punchLabel = (t) => t === 0 ? 'Check-In' : 'Check-Out';
const punchColor = (t) => t === 0 ? 'green' : 'orange';

// ── Inline input component ───────────────────────────────────
function Field({ label, required, children }) {
  return (
    <div style={{ marginBottom: 14 }}>
      <label style={{ fontSize: 12.5, fontWeight: 600, color: 'var(--text-mid)', marginBottom: 5, display: 'block' }}>
        {label} {required && <span style={{ color: '#e53e3e' }}>*</span>}
      </label>
      {children}
    </div>
  );
}
const inp = { width: '100%', padding: '9px 12px', borderRadius: 8, fontSize: 13,
  border: '1.5px solid var(--border)', fontFamily: 'inherit', boxSizing: 'border-box' };

// ═══════════════════════════════════════════════════════════
export default function BiometricDevices() {
  const { sessionId } = useSessionContext();
  const [tab, setTab]           = useState('devices');   // 'devices' | 'unmatched'
  const [devices, setDevices]   = useState([]);
  const [unmatched, setUnmatched] = useState([]);
  const [loading, setLoading]   = useState(true);

  // Device modal
  const [showDevModal, setShowDevModal] = useState(false);
  const [devForm, setDevForm]   = useState({ device_name: '', device_id: '', location: '' });
  const [devSaving, setDevSaving] = useState(false);
  const [newSecret, setNewSecret] = useState(null); // shown once after creation

  // Map-manually modal
  const [mapLog, setMapLog]     = useState(null);   // unmatched row being mapped
  const [mapType, setMapType]   = useState('student');
  const [mapQuery, setMapQuery] = useState('');
  const [mapResults, setMapResults] = useState([]);
  const [mapTarget, setMapTarget]   = useState(null);
  const [mapSaving, setMapSaving]   = useState(false);
  const searchTimer = useRef(null);

  const schoolId = JSON.parse(localStorage.getItem('vidyamate-auth') || '{}')?.state?.user?.schoolId;

  // ── loaders ────────────────────────────────────────────────
  const loadDevices = useCallback(async () => {
    try {
      const { data } = await api.get('/attendance/devices', { params: { schoolId } });
      setDevices(data || []);
    } catch { setDevices([]); }
  }, [schoolId]);

  const loadUnmatched = useCallback(async () => {
    try {
      const { data } = await api.get('/attendance/unmatched', { params: { schoolId } });
      setUnmatched(data || []);
    } catch { setUnmatched([]); }
  }, [schoolId]);

  useEffect(() => {
    (async () => {
      setLoading(true);
      await Promise.all([loadDevices(), loadUnmatched()]);
      setLoading(false);
    })();
  }, [loadDevices, loadUnmatched]);

  // ── device CRUD ────────────────────────────────────────────
  const openAddDevice = () => {
    setDevForm({ device_name: '', device_id: '', location: '' });
    setNewSecret(null);
    setShowDevModal(true);
  };

  const handleSaveDevice = async () => {
    if (!devForm.device_name.trim() || !devForm.device_id.trim()) {
      toast.error('Device Name and Device ID are required');
      return;
    }
    setDevSaving(true);
    try {
      const { data } = await api.post('/attendance/devices', { ...devForm, schoolId });
      setNewSecret(data.secret_key);
      toast.success('Device registered!');
      loadDevices();
    } catch (e) {
      toast.error(e.response?.data?.error || 'Failed to register device');
    } finally { setDevSaving(false); }
  };

  const toggleDevice = async (dev) => {
    try {
      await api.put(`/attendance/devices/${dev.id}`, { is_active: !dev.is_active });
      toast.success(dev.is_active ? 'Device deactivated' : 'Device activated');
      loadDevices();
    } catch { toast.error('Update failed'); }
  };

  const deleteDevice = async (dev) => {
    if (!window.confirm(`Delete device "${dev.device_name}"?`)) return;
    try {
      await api.delete(`/attendance/devices/${dev.id}`);
      toast.success('Device deleted');
      loadDevices();
    } catch { toast.error('Delete failed'); }
  };

  // ── map manually ──────────────────────────────────────────
  const openMap = (log) => {
    setMapLog(log);
    setMapType('student');
    setMapQuery('');
    setMapResults([]);
    setMapTarget(null);
  };

  const searchEntity = (q) => {
    clearTimeout(searchTimer.current);
    setMapQuery(q);
    setMapTarget(null);
    if (!q.trim()) { setMapResults([]); return; }
    searchTimer.current = setTimeout(async () => {
      try {
        const endpoint = mapType === 'student' ? '/students' : '/staff';
        const { data } = await api.get(endpoint, { params: { search: q, limit: 10 } });
        const rows = data?.students || data?.staff || data || [];
        setMapResults(rows);
      } catch { setMapResults([]); }
    }, 300);
  };

  const pickEntity = (row) => {
    const name = mapType === 'student'
      ? `${row.first_name} ${row.last_name || ''}`.trim()
      : `${row.first_name} ${row.last_name || ''}`.trim();
    const code = mapType === 'student' ? row.student_code : row.emp_no;
    setMapTarget({ id: row.id, name, code });
    setMapQuery(`${name} (${code})`);
    setMapResults([]);
  };

  const handleSaveMap = async () => {
    if (!mapTarget) { toast.error('Select a student or staff member'); return; }
    setMapSaving(true);
    try {
      await api.post(`/attendance/unmatched/${mapLog.id}/map`, {
        entity_type: mapType,
        entity_id:   mapTarget.id,
      });
      toast.success('Mapping saved — future punches will match automatically');
      setMapLog(null);
      loadUnmatched();
    } catch (e) {
      toast.error(e.response?.data?.error || 'Mapping failed');
    } finally { setMapSaving(false); }
  };

  // ── render ─────────────────────────────────────────────────
  const online  = devices.filter(d => d.is_online).length;
  const offline = devices.filter(d => !d.is_online).length;

  return (
    <div>
      <PageHeader
        title="Biometric Devices"
        subtitle="ZKTeco integration — device management and punch logs"
        icon="fa-fingerprint"
        actions={
          tab === 'devices' && (
            <Btn variant="primary" icon="fa-plus" onClick={openAddDevice}>Add Device</Btn>
          )
        }
      />

      {/* Stats row */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 12, marginBottom: 16 }}>
        {[
          { label: 'Registered',    val: devices.length,   icon: 'fa-microchip',   color: '#00A99D' },
          { label: 'Online',        val: online,            icon: 'fa-circle-check',color: '#38a169' },
          { label: 'Offline',       val: offline,           icon: 'fa-circle-xmark',color: '#e53e3e' },
          { label: 'Unmatched',     val: unmatched.length,  icon: 'fa-circle-question', color: '#F7941D' },
        ].map(s => (
          <div key={s.label} style={{ background: '#fff', borderRadius: 12, padding: '14px 18px',
            boxShadow: 'var(--card-shadow)', display: 'flex', alignItems: 'center', gap: 14 }}>
            <div style={{ width: 40, height: 40, borderRadius: 10, background: `${s.color}15`,
              display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <i className={`fa-solid ${s.icon}`} style={{ color: s.color, fontSize: 16 }} />
            </div>
            <div>
              <p style={{ fontSize: 22, fontWeight: 700, color: 'var(--text-dark)' }}>{s.val}</p>
              <p style={{ fontSize: 11.5, color: 'var(--text-light)' }}>{s.label}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div style={{ display: 'flex', borderBottom: '2px solid var(--border)', marginBottom: 20, gap: 0 }}>
        {[
          { key: 'devices',   label: 'Registered Devices', icon: 'fa-microchip' },
          { key: 'unmatched', label: `Unmatched Punches${unmatched.length ? ` (${unmatched.length})` : ''}`, icon: 'fa-circle-question' },
        ].map(t => (
          <button key={t.key} onClick={() => setTab(t.key)}
            style={{ padding: '10px 22px', border: 'none', background: 'none', cursor: 'pointer',
              fontWeight: tab === t.key ? 700 : 400, fontSize: 13.5,
              color: tab === t.key ? 'var(--primary)' : 'var(--text-mid)',
              borderBottom: tab === t.key ? '2.5px solid var(--primary)' : '2px solid transparent',
              marginBottom: -2, display: 'flex', alignItems: 'center', gap: 7 }}>
            <i className={`fa-solid ${t.icon}`} />
            {t.label}
          </button>
        ))}
      </div>

      {loading ? (
        <Card>
          <div style={{ padding: 48, textAlign: 'center', color: 'var(--text-light)' }}>
            <i className="fa-solid fa-spinner fa-spin" style={{ fontSize: 24 }} />
          </div>
        </Card>
      ) : tab === 'devices' ? (
        /* ── Devices tab ─────────────────────────── */
        devices.length === 0 ? (
          <Card>
            <div style={{ padding: 48, textAlign: 'center', color: 'var(--text-light)' }}>
              <i className="fa-solid fa-fingerprint" style={{ fontSize: 40, opacity: .3, marginBottom: 12 }} />
              <p>No devices registered yet. Click <strong>Add Device</strong> to get started.</p>
            </div>
          </Card>
        ) : (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(290px,1fr))', gap: 14 }}>
            {devices.map(dev => (
              <div key={dev.id} style={{ background: '#fff', borderRadius: 12, padding: 16,
                boxShadow: 'var(--card-shadow)',
                border: `1.5px solid ${dev.is_online ? '#38a16930' : '#e53e3e20'}` }}>
                {/* Header */}
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 10 }}>
                  <div>
                    <p style={{ fontWeight: 700, fontSize: 15, color: 'var(--text-dark)' }}>{dev.device_name}</p>
                    <p style={{ fontSize: 11.5, color: 'var(--text-light)', marginTop: 2 }}>
                      <i className="fa-solid fa-id-badge" style={{ marginRight: 4 }} />
                      {dev.device_id}
                    </p>
                  </div>
                  <Badge
                    label={dev.is_online ? 'Online' : 'Offline'}
                    color={dev.is_online ? 'green' : 'red'}
                  />
                </div>
                {/* Details */}
                <div style={{ display: 'flex', flexDirection: 'column', gap: 5, marginBottom: 12 }}>
                  {dev.location && (
                    <p style={{ fontSize: 12.5, color: 'var(--text-mid)' }}>
                      <i className="fa-solid fa-location-dot" style={{ width: 16, color: 'var(--primary)' }} />
                      {dev.location}
                    </p>
                  )}
                  <p style={{ fontSize: 12.5, color: 'var(--text-mid)' }}>
                    <i className="fa-regular fa-clock" style={{ width: 16, color: 'var(--text-light)' }} />
                    Last ping: {formatDt(dev.last_ping)}
                  </p>
                  <p style={{ fontSize: 12.5, color: 'var(--text-mid)' }}>
                    <i className="fa-solid fa-circle" style={{ width: 16, fontSize: 8,
                      color: dev.is_active ? '#38a169' : '#aaa' }} />
                    {dev.is_active ? 'Active' : 'Disabled'}
                  </p>
                </div>
                {/* Actions */}
                <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
                  <Btn variant="ghost" size="sm" icon={dev.is_active ? 'fa-toggle-on' : 'fa-toggle-off'}
                    onClick={() => toggleDevice(dev)}>
                    {dev.is_active ? 'Disable' : 'Enable'}
                  </Btn>
                  <Btn variant="danger-ghost" size="sm" icon="fa-trash" onClick={() => deleteDevice(dev)} />
                </div>
              </div>
            ))}
          </div>
        )
      ) : (
        /* ── Unmatched Punches tab ───────────────── */
        unmatched.length === 0 ? (
          <Card>
            <div style={{ padding: 48, textAlign: 'center', color: 'var(--text-light)' }}>
              <i className="fa-solid fa-circle-check" style={{ fontSize: 40, opacity: .4, marginBottom: 12, color: '#38a169' }} />
              <p>No unmatched punches — all device punches are mapped!</p>
            </div>
          </Card>
        ) : (
          <Card>
            <div style={{ overflowX: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
                <thead>
                  <tr style={{ background: '#f8fafb' }}>
                    {['Device ID', 'Biometric User ID', 'Punch Time', 'Type', 'Action'].map(h => (
                      <th key={h} style={{ padding: '10px 14px', textAlign: 'left', fontWeight: 600,
                        color: 'var(--text-mid)', borderBottom: '1.5px solid var(--border)', whiteSpace: 'nowrap' }}>
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {unmatched.map((row, i) => (
                    <tr key={row.id} style={{ background: i % 2 === 0 ? '#fff' : '#fafafa' }}>
                      <td style={{ padding: '9px 14px', borderBottom: '1px solid #f0f0f0' }}>
                        <code style={{ fontSize: 12, background: '#f0f4f8', padding: '2px 6px', borderRadius: 4 }}>
                          {row.device_id}
                        </code>
                      </td>
                      <td style={{ padding: '9px 14px', borderBottom: '1px solid #f0f0f0', fontWeight: 600 }}>
                        {row.user_id}
                      </td>
                      <td style={{ padding: '9px 14px', borderBottom: '1px solid #f0f0f0', whiteSpace: 'nowrap' }}>
                        {formatDt(row.punch_time)}
                      </td>
                      <td style={{ padding: '9px 14px', borderBottom: '1px solid #f0f0f0' }}>
                        <Badge label={punchLabel(row.punch_type)} color={punchColor(row.punch_type)} />
                      </td>
                      <td style={{ padding: '9px 14px', borderBottom: '1px solid #f0f0f0' }}>
                        <Btn variant="ghost" size="sm" icon="fa-link" onClick={() => openMap(row)}>
                          Map Manually
                        </Btn>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        )
      )}

      {/* ── Add Device Modal ──────────────────────────────────── */}
      <Modal open={showDevModal} onClose={() => { setShowDevModal(false); setNewSecret(null); }}
        title="Register Biometric Device" size="sm"
        footer={
          !newSecret && (
            <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
              <Btn variant="ghost" onClick={() => setShowDevModal(false)}>Cancel</Btn>
              <Btn variant="primary" icon="fa-save" loading={devSaving} onClick={handleSaveDevice}>
                Register Device
              </Btn>
            </div>
          )
        }
      >
        {newSecret ? (
          /* Secret key reveal — shown ONCE */
          <div>
            <div style={{ background: '#f0fdf4', border: '1.5px solid #86efac', borderRadius: 10, padding: 16, marginBottom: 16 }}>
              <p style={{ fontWeight: 700, color: '#15803d', marginBottom: 6 }}>
                <i className="fa-solid fa-shield-check" style={{ marginRight: 6 }} />
                Device Registered Successfully
              </p>
              <p style={{ fontSize: 12.5, color: '#166534', marginBottom: 12 }}>
                Copy this secret key now — it will <strong>not be shown again</strong>. Configure it as the
                <code style={{ background: '#dcfce7', padding: '1px 5px', borderRadius: 4 }}>X-Device-Key</code> header on your ZKTeco device.
              </p>
              <div style={{ background: '#fff', border: '1.5px solid #86efac', borderRadius: 8, padding: '10px 14px',
                fontFamily: 'monospace', fontSize: 12.5, wordBreak: 'break-all', color: '#111' }}>
                {newSecret}
              </div>
            </div>
            <Btn variant="primary" icon="fa-copy" style={{ width: '100%' }}
              onClick={() => { navigator.clipboard.writeText(newSecret); toast.success('Copied!'); }}>
              Copy to Clipboard
            </Btn>
            <Btn variant="ghost" style={{ width: '100%', marginTop: 8 }}
              onClick={() => { setShowDevModal(false); setNewSecret(null); }}>
              Done
            </Btn>
          </div>
        ) : (
          <div>
            <Field label="Device Name" required>
              <input style={inp} value={devForm.device_name}
                onChange={e => setDevForm(f => ({ ...f, device_name: e.target.value }))}
                placeholder="e.g. Main Gate Biometric" />
            </Field>
            <Field label="Device ID / Serial No." required>
              <input style={inp} value={devForm.device_id}
                onChange={e => setDevForm(f => ({ ...f, device_id: e.target.value }))}
                placeholder="e.g. ZKT-001 or 192.168.1.100" />
            </Field>
            <Field label="Location">
              <input style={inp} value={devForm.location}
                onChange={e => setDevForm(f => ({ ...f, location: e.target.value }))}
                placeholder="e.g. Ground Floor Entrance" />
            </Field>
            <div style={{ background: '#fef9ec', border: '1px solid #fbbf24', borderRadius: 8,
              padding: '10px 12px', fontSize: 12.5, color: '#92400e' }}>
              <i className="fa-solid fa-triangle-exclamation" style={{ marginRight: 6 }} />
              A secret key will be auto-generated and shown <strong>only once</strong> after registration.
            </div>
          </div>
        )}
      </Modal>

      {/* ── Map Manually Modal ───────────────────────────────── */}
      <Modal open={!!mapLog} onClose={() => { setMapLog(null); setMapTarget(null); setMapQuery(''); }}
        title="Map Biometric User ID" size="sm"
        footer={
          <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
            <Btn variant="ghost" onClick={() => setMapLog(null)}>Cancel</Btn>
            <Btn variant="primary" icon="fa-link" loading={mapSaving} onClick={handleSaveMap}>
              Save Mapping
            </Btn>
          </div>
        }
      >
        {mapLog && (
          <div>
            {/* Log summary */}
            <div style={{ background: '#f8fafb', border: '1px solid var(--border)', borderRadius: 8,
              padding: '10px 14px', marginBottom: 16, fontSize: 12.5, color: 'var(--text-mid)' }}>
              <p><strong>Device:</strong> {mapLog.device_id}</p>
              <p><strong>Biometric ID:</strong> <code style={{ background: '#f0f4f8', padding: '1px 5px', borderRadius: 4 }}>{mapLog.user_id}</code></p>
              <p><strong>Punch:</strong> {formatDt(mapLog.punch_time)} · {punchLabel(mapLog.punch_type)}</p>
            </div>

            {/* Entity type selector */}
            <div style={{ display: 'flex', gap: 8, marginBottom: 14 }}>
              {['student', 'staff'].map(t => (
                <button key={t} onClick={() => { setMapType(t); setMapQuery(''); setMapResults([]); setMapTarget(null); }}
                  style={{ flex: 1, padding: '8px 0', border: '1.5px solid',
                    borderColor: mapType === t ? 'var(--primary)' : 'var(--border)',
                    background: mapType === t ? 'var(--primary)' : '#fff',
                    color: mapType === t ? '#fff' : 'var(--text-mid)',
                    borderRadius: 8, cursor: 'pointer', fontWeight: 600, textTransform: 'capitalize', fontSize: 13 }}>
                  {t === 'student' ? '🎓 Student' : '👤 Staff'}
                </button>
              ))}
            </div>

            {/* Search */}
            <Field label={`Search ${mapType === 'student' ? 'Student' : 'Staff Member'}`} required>
              <div style={{ position: 'relative' }}>
                <input style={{ ...inp, borderColor: mapTarget ? '#38a169' : 'var(--border)' }}
                  value={mapQuery}
                  onChange={e => searchEntity(e.target.value)}
                  placeholder={`Type name or ${mapType === 'student' ? 'admission no.' : 'employee no.'}…`} />
                {mapTarget && (
                  <i className="fa-solid fa-circle-check"
                    style={{ position: 'absolute', right: 10, top: '50%', transform: 'translateY(-50%)', color: '#38a169' }} />
                )}
                {mapResults.length > 0 && (
                  <div style={{ position: 'absolute', top: '100%', left: 0, right: 0, zIndex: 99,
                    background: '#fff', border: '1.5px solid var(--border)', borderRadius: 8,
                    boxShadow: '0 4px 16px rgba(0,0,0,.1)', marginTop: 2 }}>
                    {mapResults.map(r => {
                      const name = `${r.first_name} ${r.last_name || ''}`.trim();
                      const code = mapType === 'student' ? r.student_code : r.emp_no;
                      return (
                        <div key={r.id} onClick={() => pickEntity(r)}
                          style={{ padding: '9px 12px', cursor: 'pointer', fontSize: 13,
                            borderBottom: '1px solid #f7f7f7' }}
                          onMouseEnter={e => e.currentTarget.style.background = '#f8fafb'}
                          onMouseLeave={e => e.currentTarget.style.background = '#fff'}>
                          <span style={{ fontWeight: 600 }}>{name}</span>
                          <span style={{ color: 'var(--text-light)', marginLeft: 8, fontSize: 11.5 }}>{code}</span>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </Field>

            <p style={{ fontSize: 12, color: 'var(--text-light)' }}>
              This mapping will be remembered — future punches with biometric ID
              <code style={{ margin: '0 4px', background: '#f0f4f8', padding: '1px 5px', borderRadius: 4 }}>{mapLog.user_id}</code>
              will automatically match this {mapType}.
            </p>
          </div>
        )}
      </Modal>
    </div>
  );
}
