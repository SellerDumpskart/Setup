import React, { useState, useEffect } from 'react';
import { PageHeader, Btn, Card, DataTable, Badge, StatMini, Modal, Input, Select, Textarea } from '../../components/common/Common';
import { useSessionContext } from '../../store/sessionStore';
import { commService } from '../../services';
import { fmtDate } from '../../utils';
import toast from 'react-hot-toast';

const CHANNELS = ['sms','email','push','whatsapp'];
const CH_COLOR = { sms:'#38a169', email:'#2196F3', push:'#F7941D', whatsapp:'#25D366' };
const CH_ICON  = { sms:'fa-message', email:'fa-envelope', push:'fa-bell', whatsapp:'fa-comment' };

export default function SchoolCommunication() {
  const { sessionId } = useSessionContext();
  const [broadcasts, setBroadcasts] = useState([]);
  const [messages,   setMessages]   = useState([]);
  const [loading,    setLoading]    = useState(true);
  const [tab, setTab]               = useState('broadcast');
  const [showCompose, setComp]      = useState(false);
  const [saving, setSaving]         = useState(false);
  const [form, setForm] = useState({ title:'', message:'', channel:'sms', target:'all' });

  const load = async () => {
    setLoading(true);
    try {
      const [bc, msgs] = await Promise.all([commService.broadcasts(), commService.messages()]);
      setBroadcasts(bc.data||[]);
      setMessages(msgs.data||[]);
    } catch { setBroadcasts([]); setMessages([]); }
    finally { setLoading(false); }
  };

  useEffect(() => { load(); }, []);

  const handleSend = async () => {
    if (!form.title || !form.message) { toast.error('Fill title and message'); return; }
    setSaving(true);
    try {
      await commService.send(form);
      toast.success(`Message sent via ${form.channel.toUpperCase()}`);
      load(); setComp(false); setForm({ title:'', message:'', channel:'sms', target:'all' });
    } catch (e) { toast.error(e.response?.data?.error||'Failed'); }
    finally { setSaving(false); }
  };

  const markRead = async (parentId) => {
    await commService.markRead(parentId);
    load();
  };

  const sent      = broadcasts.filter(b => b.status === 'sent').length;
  const totalRcpt = broadcasts.filter(b => b.status === 'sent').reduce((s,b) => s + (b.sent_count||0), 0);
  const unread    = messages.filter(m => !m.is_read).length;

  const bcCols = [
    { key:'title', label:'Message',
      render:(v,row) => <div><p style={{ fontWeight:600 }}>{v}</p><p style={{ fontSize:11, color:'var(--text-light)' }}>To: {row.target_group}</p></div>
    },
    { key:'channel', label:'Channel', width:120,
      render:v => <div style={{ display:'flex', alignItems:'center', gap:6 }}><i className={`fa-solid ${CH_ICON[v]||'fa-message'}`} style={{ color:CH_COLOR[v] }}/><span style={{ textTransform:'uppercase', fontSize:12, fontWeight:600, color:CH_COLOR[v] }}>{v}</span></div>
    },
    { key:'total_recipients', label:'Recipients', width:100, render:v => <span style={{ fontWeight:600 }}>{v||0}</span> },
    { key:'sent_count',       label:'Sent',       width:80,  render:v => <span style={{ color:'var(--accent-green)', fontWeight:600 }}>{v||0}</span> },
    { key:'status', label:'Status', width:90, render:v => <Badge label={v} color={v==='sent'?'green':v==='failed'?'red':'orange'} /> },
    { key:'created_at', label:'Date', width:110, render:v => fmtDate(v, { day:'2-digit', month:'short' }) },
  ];

  return (
    <div>
      <PageHeader title="School Communication" subtitle="Broadcast messages to parents and staff" icon="fa-envelope-open-text"
        actions={<Btn icon="fa-paper-plane" variant="primary" onClick={() => setComp(true)}>Send Message</Btn>}
      />
      <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:12, marginBottom:16 }}>
        <StatMini label="Broadcasts" value={sent}      icon="fa-paper-plane" color="#00A99D" />
        <StatMini label="Reached"    value={totalRcpt} icon="fa-users"       color="#38a169" />
        <StatMini label="Unread"     value={unread}    icon="fa-inbox"       color="#F7941D" />
        <StatMini label="Templates"  value={5}         icon="fa-file-lines"  color="#9C27B0" />
      </div>
      <div style={{ display:'flex', gap:4, marginBottom:14 }}>
        {[{k:'broadcast',l:'Broadcasts',i:'fa-list'},{k:'messages',l:`Messages${unread>0?` (${unread})`:''}`,i:'fa-comments'}].map(t => (
          <button key={t.k} onClick={() => setTab(t.k)}
            style={{ padding:'8px 16px', borderRadius:8, fontSize:13, fontWeight:500, border:'1.5px solid', transition:'all .15s', cursor:'pointer',
              borderColor:tab===t.k?'var(--primary)':'var(--border)', background:tab===t.k?'var(--primary)':'#fff', color:tab===t.k?'#fff':'var(--text-mid)', display:'flex', alignItems:'center', gap:6 }}>
            <i className={`fa-solid ${t.i}`}/>{t.l}
          </button>
        ))}
      </div>
      {tab === 'broadcast' && <Card><DataTable columns={bcCols} data={broadcasts} loading={loading} emptyText="No broadcasts sent" /></Card>}
      {tab === 'messages' && (
        <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
          {messages.length === 0 && !loading && <Card><div style={{ padding:32, textAlign:'center', color:'var(--text-light)' }}><i className="fa-solid fa-inbox" style={{ fontSize:36, opacity:.3, marginBottom:10 }}/><p>No parent messages</p></div></Card>}
          {messages.map(m => (
            <div key={m.id} onClick={() => !m.is_read && markRead(m.parent_id)}
              style={{ background:'#fff', borderRadius:12, padding:14, boxShadow:'var(--card-shadow)', cursor:'pointer', borderLeft:`4px solid ${m.is_read?'#e2e8f0':'var(--primary)'}` }}>
              <div style={{ display:'flex', justifyContent:'space-between', marginBottom:4 }}>
                <p style={{ fontWeight:600, fontSize:13.5 }}>{m.father_name||`Parent`}</p>
                <span style={{ fontSize:11.5, color:'var(--text-light)' }}>{fmtDate(m.created_at,{day:'2-digit',month:'short'})}</span>
              </div>
              <p style={{ fontSize:13, color:'var(--text-mid)' }}>{m.message}</p>
              {!m.is_read && <div style={{ marginTop:8 }}><Badge label="New" color="teal" /></div>}
            </div>
          ))}
        </div>
      )}
      <Modal open={showCompose} onClose={() => setComp(false)} title="Send Message / Broadcast" size="md"
        footer={<div style={{ display:'flex', gap:8, justifyContent:'flex-end' }}><Btn variant="ghost" onClick={() => setComp(false)}>Cancel</Btn><Btn variant="primary" icon="fa-paper-plane" loading={saving} onClick={handleSend}>{saving?'Sending...':'Send Now'}</Btn></div>}
      >
        <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
          <Input label="Subject / Title" required value={form.title} onChange={e => setForm(f=>({...f,title:e.target.value}))} />
          <div className="form-grid">
            <Select label="Channel" value={form.channel} onChange={e => setForm(f=>({...f,channel:e.target.value}))}
              options={CHANNELS.map(c => ({ value:c, label:c.toUpperCase() }))} />
            <Select label="Send To" value={form.target} onChange={e => setForm(f=>({...f,target:e.target.value}))}
              options={[{value:'all',label:'Everyone'},{value:'parents',label:'All Parents'},{value:'staff',label:'All Staff'},{value:'students',label:'Students'}]} />
          </div>
          <Textarea label="Message *" required value={form.message} onChange={e => setForm(f=>({...f,message:e.target.value}))} rows={5} placeholder="Type your message..." />
        </div>
      </Modal>
    </div>
  );
}
