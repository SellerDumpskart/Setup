import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import useAuthStore from '../../store/authStore';
import './LoginPage.css';

export default function LoginPage() {
  const navigate = useNavigate();
  const { login, isLoading } = useAuthStore();
  const [form, setForm] = useState({ email: '', password: '' });
  const [error, setError] = useState('');
  const [showPass, setShowPass] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    if (!form.email || !form.password) {
      setError('Please enter email and password.');
      return;
    }
    const result = await login(form.email, form.password);
    if (result.success) {
      const role = useAuthStore.getState().user?.role;
      navigate(role === 'super_admin' || role === 'org_admin' ? '/admin' : '/school');
    } else {
      setError(result.error);
    }
  };

  return (
    <div className="login-page">
      {/* Left panel - branding */}
      <div className="login-left">
        <div className="login-brand">
          <div className="brand-logo">
            <i className="fa-solid fa-graduation-cap" />
          </div>
          <h1>VidyaMate</h1>
          <p>Complete School Management System</p>
        </div>
        <div className="login-features">
          {[
            { icon: 'fa-users', text: 'Manage 1000+ students effortlessly' },
            { icon: 'fa-chart-bar', text: 'Real-time analytics & reports' },
            { icon: 'fa-bell', text: 'Instant SMS & email notifications' },
            { icon: 'fa-file-pdf', text: 'Auto-generate hall tickets & results' },
          ].map((f, i) => (
            <div className="feature-item" key={i}>
              <i className={`fa-solid ${f.icon}`} />
              <span>{f.text}</span>
            </div>
          ))}
        </div>
        <div className="login-wave" />
      </div>

      {/* Right panel - form */}
      <div className="login-right">
        <div className="login-card">
          <div className="login-header">
            <div className="login-icon">
              <i className="fa-solid fa-school" />
            </div>
            <h2>Welcome Back</h2>
            <p>Sign in to your school portal</p>
          </div>

          {error && (
            <div className="login-error">
              <i className="fa-solid fa-circle-exclamation" />
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="login-form">
            <div className="form-group">
              <label>Email Address</label>
              <div className="input-wrap">
                <i className="fa-solid fa-envelope input-icon" />
                <input
                  type="email"
                  placeholder="admin@school.com"
                  value={form.email}
                  onChange={e => setForm({ ...form, email: e.target.value })}
                  autoComplete="email"
                />
              </div>
            </div>

            <div className="form-group">
              <label>Password</label>
              <div className="input-wrap">
                <i className="fa-solid fa-lock input-icon" />
                <input
                  type={showPass ? 'text' : 'password'}
                  placeholder="Enter your password"
                  value={form.password}
                  onChange={e => setForm({ ...form, password: e.target.value })}
                  autoComplete="current-password"
                />
                <button
                  type="button"
                  className="pass-toggle"
                  onClick={() => setShowPass(!showPass)}
                >
                  <i className={`fa-solid ${showPass ? 'fa-eye-slash' : 'fa-eye'}`} />
                </button>
              </div>
            </div>

            <div className="form-meta">
              <label className="remember">
                <input type="checkbox" />
                <span>Remember me</span>
              </label>
              <Link to="/forgot-password" className="forgot-link">Forgot password?</Link>
            </div>

            <button type="submit" className="login-btn" disabled={isLoading}>
              {isLoading ? (
                <><i className="fa-solid fa-spinner fa-spin" /> Signing in...</>
              ) : (
                <><i className="fa-solid fa-right-to-bracket" /> Sign In</>
              )}
            </button>
          </form>

          {/* Demo credentials hint */}
          <div className="demo-hint">
            <p className="demo-title"><i className="fa-solid fa-circle-info" /> Demo credentials</p>
            <div className="demo-rows">
              <div className="demo-row" onClick={() => setForm({ email: 'admin@vidyamate.in', password: 'Admin@123' })}>
                <span className="demo-role">Super Admin</span>
                <span className="demo-cred">admin@vidyamate.in</span>
              </div>
            </div>
          </div>

          <p className="login-footer">
            © 2026 VidyaMate · School Management System
          </p>
        </div>
      </div>
    </div>
  );
}
