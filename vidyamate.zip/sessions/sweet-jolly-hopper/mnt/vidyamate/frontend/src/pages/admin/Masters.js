import React, { useState, useEffect } from 'react';
import { PageHeader, Btn, Card, Modal, Input } from '../../components/common/Common';
import { masterService, orgService } from '../../services';
import useAuthStore from '../../store/authStore';
import toast from 'react-hot-toast';

const TYPES = [
  { key:'designation',    label:'Designation',      icon:'fa-id-badge',        color:'#2196F3' },
  { key:'education',      label:'Education',         icon:'fa-graduation-cap',  color:'#9C27B0' },
  { key:'occupation',     label:'Occupation',        icon:'fa-briefcase',       color:'#F7941D' },
  { key:'religion',       label:'Religion',          icon:'fa-place-of-worship',color:'#38a169' },
  { key:'category',       label:'Category',          icon:'fa-layer-group',     color:'#00A99D' },
  { key:'mother_tongue',  label:'Mother Tongue',     icon:'fa-language',        color:'#e53e3e' },
  { key:'medium',         label:'Medium',            icon:'fa-book',            color:'#2196F3' },
  { key:'blood_group',    label:'Blood Group',       icon:'fa-droplet',         color:'#e53e3e' },
  { key:'cancel_reason',  label:'Cancel Reason',     icon:'fa-ban',             color:'#718096' },
  { key:'discount_reason',label:'Discount Reason',   icon:'fa-tag',             color:'#38a169' },
  { key:'document_type',  label:'Document Types',    icon:'fa-file',            color:'#F7941D' },
  { key:'expense_category',label:'Expense Category', icon:'fa-wallet',          color:'#9C27B0' },
];

export default function Masters() {
  const { user } = useAuthStore();
  const [masters, setMasters]   = useState({});
  const [loading, setLoading]   = useState(true);
  const [active, setActive]     = useState('designation');
  const [showAdd, setAdd]       = useState(false);
  const [newVal, setNewVal]     = useState('');
  const [saving, setSaving]     = useState(false);

  const load = async () => {
    setLoading(true);
    try { const { data } = await masterService.list(user?.orgId); setMasters(data||{}); }
    catch { setMasters({}); }
    finally { setLoading(false); }
  };

  useEffect(() => { if (user?.orgId) load(); }, [user?.orgId]);

  const handleAdd = async () => {
    if (!newVal.trim()) { toast.error('Enter a value'); return; }
    setSaving(true);
    try {
      await masterService.create({ orgId: user?.orgId, masterType: active, value: newVal.trim() });
      toast.success('Value added'); load(); setAdd(false); setNewVal('');
    } catch (e) { toast.error(e.response?.data?.error||'Failed'); }
    finally { setSaving(false); }
  };

  const handleDelete = async (id) => {
    await masterService.remove(id);
    toast.success('Removed'); load();
  };

  const current = masters[active] || [];
  const meta    = TYPES.find(t => t.key === active);

  return (
    <div>
      <PageHeader title="Masters Configuration" subtitle="System-wide dropdown values" icon="fa-list"
        actions={<Btn icon="fa-plus" variant="primary" onClick={() => setAdd(true)}>Add Value</Btn>}
      />
      <div style={{ display:'grid', gridTemplateColumns:'220px 1fr', gap:14 }}>
        <Card>
          <div style={{ padding:12 }}>
            <p style={{ fontSize:11, fontWeight:600, textTransform:'uppercase', letterSpacing:'.05em', color:'var(--text-light)', marginBottom:8 }}>Master Types</p>
            {TYPES.map(t => (
              <button key={t.key} onClick={() => setActive(t.key)}
                style={{ display:'flex', alignItems:'center', gap:8, width:'100%', padding:'8px 10px', borderRadius:8, marginBottom:2, fontSize:12.5, fontWeight:500, transition:'all .15s', border:'none', cursor:'pointer',
                  background: active===t.key ? `${t.color}18` : 'transparent', color: active===t.key ? t.color : 'var(--text-mid)', borderLeft: active===t.key ? `3px solid ${t.color}` : '3px solid transparent' }}>
                <i className={`fa-solid ${t.icon}`} style={{ width:14, fontSize:12 }}/>
                {t.label}
                <span style={{ marginLeft:'auto', background:'#f0f0f0', borderRadius:10, padding:'1px 6px', fontSize:10, fontWeight:700, color:'var(--text-light)' }}>
                  {(masters[t.key]||[]).length}
                </span>
              </button>
            ))}
          </div>
        </Card>
        <Card title={meta?.label||''} icon={meta?.icon}>
          <div style={{ padding:'0 16px 16px' }}>
            {loading ? <div style={{ padding:24, textAlign:'center', color:'var(--text-light)' }}>Loading...</div>
            : current.length === 0 ? <div style={{ padding:32, textAlign:'center', color:'var(--text-light)' }}>No values yet</div>
            : (
              <div style={{ display:'flex', flexDirection:'column', gap:4 }}>
                {current.map((v, i) => (
                  <div key={v.id||i} style={{ display:'flex', alignItems:'center', gap:10, padding:'9px 10px', borderRadius:8, border:'1.5px solid var(--border)', background:'#fff', transition:'all .15s' }}
                    onMouseEnter={e=>e.currentTarget.style.borderColor=meta?.color} onMouseLeave={e=>e.currentTarget.style.borderColor='var(--border)'}>
                    <span style={{ width:24, height:24, borderRadius:6, background:`${meta?.color}18`, display:'flex', alignItems:'center', justifyContent:'center', fontSize:10, fontWeight:700, color:meta?.color }}>{i+1}</span>
                    <span style={{ flex:1, fontSize:13.5, fontWeight:500 }}>{v.value}</span>
                    <button className="icon-btn danger" onClick={() => handleDelete(v.id)}><i className="fa-solid fa-trash"/></button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </Card>
      </div>
      <Modal open={showAdd} onClose={()=>{setAdd(false);setNewVal('');}} title={`Add ${meta?.label} Value`} size="sm"
        footer={<div style={{ display:'flex', gap:8, justifyContent:'flex-end' }}><Btn variant="ghost" onClick={()=>setAdd(false)}>Cancel</Btn><Btn variant="primary" icon="fa-plus" loading={saving} onClick={handleAdd}>Add</Btn></div>}
      >
        <Input label="Value" required value={newVal} onChange={e=>setNewVal(e.target.value)} placeholder={`Enter ${meta?.label?.toLowerCase()}...`} onKeyDown={e=>e.key==='Enter'&&handleAdd()} />
      </Modal>
    </div>
  );
}
