import React, { useState, useEffect } from 'react';
import { PageHeader, Btn, DataTable, Badge, Card, Modal, Input, Select, StatMini, SearchBar } from '../../components/common/Common';
import { schoolService, orgService } from '../../services';
import { fmtDate } from '../../utils';
import toast from 'react-hot-toast';

const STATES = ['Andhra Pradesh','Telangana','Karnataka','Tamil Nadu','Maharashtra','Gujarat','Rajasthan','Delhi','Kerala'];

export default function SchoolRegistration() {
  const [schools, setSchools] = useState([]);
  const [orgs, setOrgs]       = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch]   = useState('');
  const [showForm, setShow]   = useState(false);
  const [editItem, setEdit]   = useState(null);
  const [form, setForm]       = useState({ name:'', organizationId:'', contactNumber:'', email:'', city:'', state:'Andhra Pradesh', status:'active' });
  const [saving, setSaving]   = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      const [sc, og] = await Promise.all([schoolService.list(), orgService.list()]);
      setSchools(sc.data||[]); setOrgs(og.data||[]);
    } catch { setSchools([]); }
    finally { setLoading(false); }
  };

  useEffect(() => { load(); }, []);

  const openEdit = (row) => { setEdit(row); setForm({ name:row.name, organizationId:row.organization_id, contactNumber:row.contact_number||'', email:row.email||'', city:row.city||'', state:row.state||'Andhra Pradesh', status:row.status }); setShow(true); };

  const handleSave = async () => {
    if (!form.name) { toast.error('School name required'); return; }
    setSaving(true);
    try {
      if (editItem) { await schoolService.update(editItem.id, form); toast.success('School updated'); }
      else          { await schoolService.create(form); toast.success('School registered'); }
      load(); setShow(false);
    } catch (e) { toast.error(e.response?.data?.error||'Failed'); }
    finally { setSaving(false); }
  };

  const filtered = schools.filter(s => !search || s.name?.toLowerCase().includes(search.toLowerCase()) || s.city?.toLowerCase().includes(search.toLowerCase()));

  const cols = [
    { key:'name', label:'School Name',
      render:(v,row) => (
        <div style={{ display:'flex', gap:10, alignItems:'center' }}>
          <div style={{ width:36, height:36, borderRadius:8, background:'var(--primary-light)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:13, fontWeight:700, color:'var(--primary)', flexShrink:0 }}>{v?.charAt(0)}</div>
          <div><p style={{ fontWeight:600, fontSize:13 }}>{v}</p><p style={{ fontSize:11, color:'var(--text-light)' }}>{row.city}, {row.state}</p></div>
        </div>
      )
    },
    { key:'contact_number', label:'Contact', render:v => <a href={`tel:${v}`} style={{ color:'var(--primary)' }}>{v||'—'}</a> },
    { key:'medium', label:'Medium', render:v => v||'—' },
    { key:'status', label:'Status', width:90, render:v => <Badge label={v} color={v==='active'?'green':'red'} /> },
    { key:'id', label:'', width:60, render:(v,row) => <button className="icon-btn" onClick={e=>{e.stopPropagation();openEdit(row)}}><i className="fa-solid fa-pen"/></button> },
  ];

  return (
    <div>
      <PageHeader title="School Registration" subtitle={`${schools.length} schools registered`} icon="fa-school"
        actions={<Btn icon="fa-plus" variant="primary" onClick={() => { setEdit(null); setForm({ name:'', organizationId:'', contactNumber:'', email:'', city:'', state:'Andhra Pradesh', status:'active' }); setShow(true); }}>Register School</Btn>}
      />
      <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:12, marginBottom:16 }}>
        <StatMini label="Total Schools" value={schools.length} icon="fa-school" color="#00A99D" />
        <StatMini label="Active" value={schools.filter(s=>s.status==='active').length} icon="fa-circle-check" color="#38a169" />
        <StatMini label="Organizations" value={orgs.length} icon="fa-building" color="#2196F3" />
      </div>
      <Card>
        <div style={{ padding:'12px 16px', borderBottom:'1px solid var(--border)' }}>
          <SearchBar value={search} onChange={setSearch} placeholder="Search schools..." />
        </div>
        <DataTable columns={cols} data={filtered} loading={loading} onRowClick={openEdit} emptyText="No schools registered" />
      </Card>
      <Modal open={showForm} onClose={()=>setShow(false)} title={editItem?'Edit School':'Register School'} size="md"
        footer={<div style={{ display:'flex', gap:8, justifyContent:'flex-end' }}><Btn variant="ghost" onClick={()=>setShow(false)}>Cancel</Btn><Btn variant="primary" icon="fa-floppy-disk" loading={saving} onClick={handleSave}>Save</Btn></div>}
      >
        <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
          <Input label="School Name" required value={form.name} onChange={e=>setForm(f=>({...f,name:e.target.value}))} />
          <Select label="Organization" required value={form.organizationId} onChange={e=>setForm(f=>({...f,organizationId:e.target.value}))} placeholder="Select"
            options={orgs.map(o=>({value:o.id,label:o.name}))} />
          <div className="form-grid">
            <Input label="Phone" type="tel" value={form.contactNumber} onChange={e=>setForm(f=>({...f,contactNumber:e.target.value}))} />
            <Input label="Email" type="email" value={form.email} onChange={e=>setForm(f=>({...f,email:e.target.value}))} />
            <Input label="City" value={form.city} onChange={e=>setForm(f=>({...f,city:e.target.value}))} />
            <Select label="State" value={form.state} onChange={e=>setForm(f=>({...f,state:e.target.value}))} options={STATES} />
          </div>
        </div>
      </Modal>
    </div>
  );
}
