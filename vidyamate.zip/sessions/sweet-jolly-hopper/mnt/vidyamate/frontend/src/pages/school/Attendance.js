import React, { useState, useEffect, useCallback } from 'react';
import { PageHeader, Btn, Select, Card, StatMini } from '../../components/common/Common';
import { useAttendance, useClasses } from '../../hooks';
import { useSessionContext } from '../../store/sessionStore';
import { exportToCSV } from '../../utils';
import api from '../../services/api';
import toast from 'react-hot-toast';

const STATUS_CYCLE = { present:'absent', absent:'leave', leave:'present' };
const STATUS_LABEL = { present:'P', absent:'A', leave:'L' };
const STATUS_COLORS_MAP = {
  present: { bg:'#e6f4ea', border:'#4CAF5040', text:'#1e7e34', dot:'#4CAF50' },
  absent:  { bg:'#fde8e8', border:'#e53e3e40', text:'#c53030', dot:'#e53e3e' },
  leave:   { bg:'#e8f1fd', border:'#2196F340', text:'#1a56db', dot:'#2196F3' },
};

const getSchoolId = () =>
  JSON.parse(localStorage.getItem('vidyamate-auth') || '{}')?.state?.user?.schoolId;

// ── Staff Attendance Hook ─────────────────────────────────
function useStaffAttendance(date) {
  const [staff,   setStaff]   = useState([]);
  const [stats,   setStats]   = useState({ total:0, present:0, absent:0, leave:0 });
  const [loading, setLoading] = useState(false);
  const [saving,  setSaving]  = useState(false);

  const load = useCallback(async () => {
    if (!date) return;
    setLoading(true);
    try {
      const { data } = await api.get('/attendance/staff', {
        params: { date, schoolId: getSchoolId() }
      });
      setStaff(data.staff || []);
      setStats(data.stats || { total:0, present:0, absent:0, leave:0 });
    } catch { setStaff([]); }
    finally { setLoading(false); }
  }, [date]);

  useEffect(() => { load(); }, [load]);

  const markAll = async (records) => {
    setSaving(true);
    try {
      await api.post('/attendance/staff/mark', { records, date });
      toast.success(`Staff attendance saved for ${records.length} members`);
      load();
    } catch (err) {
      toast.error(err.response?.data?.error || 'Failed to save staff attendance');
    } finally { setSaving(false); }
  };

  return { staff, stats, loading, saving, refetch: load, markAll };
}

export default function Attendance() {
  const { sessionId } = useSessionContext();
  const { data: classesData } = useClasses(sessionId);
  const classes = classesData || [];

  const [selectedClass, setClass] = useState('');
  const [date, setDate]           = useState(new Date().toISOString().split('T')[0]);
  const [attType, setAttType]     = useState('students');
  const [search, setSearch]       = useState('');

  // Student attendance state
  const [localRecords, setLocal]  = useState({});
  const { records, stats: sStats, loading, saving, markAll, refetch } = useAttendance(selectedClass, date);

  // Staff attendance state
  const [staffLocal, setStaffLocal] = useState({});
  const { staff, stats: stStats, loading: staffLoading, saving: staffSaving, markAll: markStaff } = useStaffAttendance(date);

  // Set first class once loaded
  useEffect(() => {
    if (classes.length && !selectedClass) setClass(classes[0].id);
  }, [classes]);

  // Sync student records
  useEffect(() => {
    const map = {};
    records.forEach(s => { map[s.id] = s.attendance_status || 'present'; });
    setLocal(map);
  }, [records]);

  // Sync staff records
  useEffect(() => {
    const map = {};
    staff.forEach(s => { map[s.id] = s.attendance_status || 'present'; });
    setStaffLocal(map);
  }, [staff]);

  const toggle = (id) => setLocal(prev => ({ ...prev, [id]: STATUS_CYCLE[prev[id]] || 'present' }));
  const toggleStaff = (id) => setStaffLocal(prev => ({ ...prev, [id]: STATUS_CYCLE[prev[id]] || 'present' }));

  const handleSaveStudents = async () => {
    const recordList = records.map(s => ({ studentId: s.id, status: localRecords[s.id] || 'present' }));
    await markAll(recordList);
  };

  const handleSaveStaff = async () => {
    const recordList = staff.map(s => ({ staffId: s.id, status: staffLocal[s.id] || 'present' }));
    await markStaff(recordList);
  };

  const handleExportStudents = () => {
    exportToCSV(
      records.map(s => ({ ...s, status: localRecords[s.id] || s.attendance_status })),
      `student_attendance_${date}`,
      [{ key:'roll_number',label:'Roll' },{ key:'first_name',label:'Name' },{ key:'student_code',label:'Code' },{ key:'status',label:'Status' }]
    );
    toast.success('Exported');
  };

  const handleExportStaff = () => {
    exportToCSV(
      staff.map(s => ({ ...s, status: staffLocal[s.id] || s.attendance_status })),
      `staff_attendance_${date}`,
      [{ key:'staff_code',label:'Code' },{ key:'first_name',label:'Name' },{ key:'designation',label:'Designation' },{ key:'status',label:'Status' }]
    );
    toast.success('Exported');
  };

  // Stats
  const sPresent = Object.values(localRecords).filter(v => v === 'present').length;
  const sAbsent  = Object.values(localRecords).filter(v => v === 'absent').length;
  const sPct     = records.length > 0 ? Math.round((sPresent / records.length) * 100) : 0;

  const stPresent = Object.values(staffLocal).filter(v => v === 'present').length;
  const stAbsent  = Object.values(staffLocal).filter(v => v === 'absent').length;
  const stPct     = staff.length > 0 ? Math.round((stPresent / staff.length) * 100) : 0;

  const selClass = classes.find(c => c.id === selectedClass);

  // Filter
  const filteredStudents = records.filter(s =>
    !search || `${s.first_name} ${s.last_name||''} ${s.student_code}`.toLowerCase().includes(search.toLowerCase())
  );
  const filteredStaff = staff.filter(s =>
    !search || `${s.first_name} ${s.last_name||''} ${s.staff_code||''} ${s.designation||''}`.toLowerCase().includes(search.toLowerCase())
  );

  // ── Shared card components ──────────────────────────────
  const Legend = () => (
    <div style={{ display:'flex', gap:8, fontSize:11.5, color:'var(--text-light)' }}>
      <span><span style={{ width:9,height:9,background:'#4CAF50',borderRadius:'50%',display:'inline-block',marginRight:4 }}/>Present</span>
      <span><span style={{ width:9,height:9,background:'#e53e3e',borderRadius:'50%',display:'inline-block',marginRight:4 }}/>Absent</span>
      <span><span style={{ width:9,height:9,background:'#2196F3',borderRadius:'50%',display:'inline-block',marginRight:4 }}/>Leave</span>
      <span style={{ marginLeft:4, fontSize:11 }}>Click to toggle</span>
    </div>
  );

  const AttendanceGrid = ({ items, localMap, onToggle, nameKey='first_name', subKey=null }) => (
    <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(220px,1fr))', gap:8 }}>
      {items.map(item => {
        const status = localMap[item.id] || 'present';
        const c = STATUS_COLORS_MAP[status];
        return (
          <div key={item.id} onClick={() => onToggle(item.id)}
            style={{ display:'flex', alignItems:'center', gap:10, padding:'10px 12px',
              borderRadius:10, cursor:'pointer', border:`1.5px solid ${c.border}`,
              background:c.bg, transition:'all .15s' }}>
            <div style={{ width:34, height:34, borderRadius:8, background:`${c.dot}22`,
              display:'flex', alignItems:'center', justifyContent:'center',
              fontWeight:800, fontSize:13, color:c.dot, flexShrink:0 }}>
              {(item.first_name||'?').charAt(0)}
            </div>
            <div style={{ flex:1, overflow:'hidden' }}>
              <p style={{ fontWeight:600, fontSize:13, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>
                {item.first_name} {item.last_name||''}
              </p>
              <p style={{ fontSize:11, color:'var(--text-light)' }}>
                {subKey ? (item[subKey]||'—') : `Roll: ${item.roll_number||'—'}`}
              </p>
            </div>
            <span style={{ width:22, height:22, borderRadius:6, background:c.dot, color:'#fff',
              fontWeight:800, fontSize:11, display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}>
              {STATUS_LABEL[status]}
            </span>
          </div>
        );
      })}
    </div>
  );

  return (
    <div>
      <PageHeader title="Attendance" subtitle="Mark and manage student & staff attendance" icon="fa-calendar-check"
        actions={
          <>
            <Btn icon="fa-print" variant="ghost" size="sm"
              onClick={() => {
                const isStudents = attType === 'students';
                const items  = isStudents ? records  : staff;
                const local  = isStudents ? localRecords : staffLocal;
                const title  = isStudents
                  ? `Attendance Register · ${selClass ? `Class ${selClass.class_name}-${selClass.section}` : ''} · ${date}`
                  : `Staff Attendance · ${date}`;
                const rows   = items.map(item => {
                  const status = local[item.id] || 'present';
                  return isStudents
                    ? `<tr><td>${item.roll_number||'—'}</td><td>${item.first_name} ${item.last_name||''}</td><td>${item.student_code||''}</td><td style="font-weight:700;color:${status==='present'?'green':status==='absent'?'red':'blue'}">${status.toUpperCase()}</td></tr>`
                    : `<tr><td>${item.staff_code||'—'}</td><td>${item.first_name} ${item.last_name||''}</td><td>${item.designation||''}</td><td style="font-weight:700;color:${status==='present'?'green':status==='absent'?'red':'blue'}">${status.toUpperCase()}</td></tr>`;
                }).join('');
                const headers = isStudents
                  ? '<tr><th>Roll</th><th>Name</th><th>Code</th><th>Status</th></tr>'
                  : '<tr><th>Code</th><th>Name</th><th>Designation</th><th>Status</th></tr>';
                const win = window.open('', '_blank');
                win.document.write(`<html><head><title>${title}</title><style>body{font-family:Arial,sans-serif;font-size:12px;padding:20px}h2{margin-bottom:12px}table{width:100%;border-collapse:collapse}th,td{border:1px solid #ccc;padding:6px 10px;text-align:left}th{background:#00A99D;color:#fff}</style></head><body><h2>${title}</h2><p>Total: ${items.length}</p><table>${headers}${rows}</table></body></html>`);
                win.document.close(); win.print(); win.close();
              }}
              disabled={attType === 'students' ? !records.length : !staff.length}>
              Print
            </Btn>
            <Btn icon="fa-file-csv" variant="ghost" size="sm"
              onClick={attType === 'students' ? handleExportStudents : handleExportStaff}
              disabled={attType === 'students' ? !records.length : !staff.length}>
              Export
            </Btn>
          </>
        }
      />

      {/* Controls */}
      <Card>
        <div style={{ padding:'14px 18px', display:'flex', gap:12, flexWrap:'wrap', alignItems:'flex-end' }}>
          {/* Type toggle */}
          <div>
            <p style={{ fontSize:12, fontWeight:500, color:'var(--text-mid)', marginBottom:5 }}>Type</p>
            <div style={{ display:'flex', background:'#f4f6f9', borderRadius:8, padding:3, border:'1px solid var(--border)' }}>
              {['students','staff'].map(t => (
                <button key={t} onClick={() => { setAttType(t); setSearch(''); }}
                  style={{ padding:'6px 16px', borderRadius:6, fontSize:13, fontWeight:500, transition:'all .15s', border:'none', cursor:'pointer',
                    background: attType===t?'#fff':'transparent', color:attType===t?'var(--primary)':'var(--text-light)',
                    boxShadow: attType===t?'0 1px 4px rgba(0,0,0,.08)':'none' }}>
                  {t.charAt(0).toUpperCase()+t.slice(1)}
                </button>
              ))}
            </div>
          </div>

          {/* Class — only for students */}
          {attType === 'students' && (
            <Select label="Class" value={selectedClass} onChange={e => setClass(e.target.value)} style={{ width:200 }}
              options={classes.map(c => ({ value:c.id, label:`Class ${c.class_name}-${c.section} (${c.student_count||0})` }))}
            />
          )}

          <div className="field">
            <label className="field-label">Date</label>
            <input type="date" className="field-input" value={date}
              max={new Date().toISOString().split('T')[0]}
              onChange={e => setDate(e.target.value)} style={{ width:170 }} />
          </div>

          <div style={{ flex:1, display:'flex', justifyContent:'flex-end', gap:8, alignSelf:'flex-end' }}>
            {attType === 'students' ? (
              <>
                <Btn variant="secondary" size="sm" onClick={() => { const m={}; records.forEach(s=>{m[s.id]='present';}); setLocal(m); }}>
                  <i className="fa-solid fa-check-double" style={{ marginRight:5 }}/>All Present
                </Btn>
                <Btn variant="ghost" size="sm" onClick={() => { const m={}; records.forEach(s=>{m[s.id]='absent';}); setLocal(m); }}>
                  <i className="fa-solid fa-xmark" style={{ marginRight:5 }}/>All Absent
                </Btn>
              </>
            ) : (
              <>
                <Btn variant="secondary" size="sm" onClick={() => { const m={}; staff.forEach(s=>{m[s.id]='present';}); setStaffLocal(m); }}>
                  <i className="fa-solid fa-check-double" style={{ marginRight:5 }}/>All Present
                </Btn>
                <Btn variant="ghost" size="sm" onClick={() => { const m={}; staff.forEach(s=>{m[s.id]='absent';}); setStaffLocal(m); }}>
                  <i className="fa-solid fa-xmark" style={{ marginRight:5 }}/>All Absent
                </Btn>
              </>
            )}
          </div>
        </div>
      </Card>

      {/* Stats */}
      <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:12, margin:'16px 0' }}>
        {attType === 'students' ? (
          <>
            <StatMini label="Total"         value={records.length} icon="fa-users"      color="#00A99D" />
            <StatMini label="Present"        value={sPresent}       icon="fa-user-check" color="#38a169" />
            <StatMini label="Absent"         value={sAbsent}        icon="fa-user-xmark" color="#e53e3e" />
            <StatMini label="Attendance %"   value={`${sPct}%`}    icon="fa-percent"    color={sPct>=75?'#38a169':sPct>=50?'#F7941D':'#e53e3e'} />
          </>
        ) : (
          <>
            <StatMini label="Total Staff"    value={staff.length}   icon="fa-user-tie"   color="#00A99D" />
            <StatMini label="Present"        value={stPresent}      icon="fa-user-check" color="#38a169" />
            <StatMini label="Absent"         value={stAbsent}       icon="fa-user-xmark" color="#e53e3e" />
            <StatMini label="Attendance %"   value={`${stPct}%`}   icon="fa-percent"    color={stPct>=75?'#38a169':stPct>=50?'#F7941D':'#e53e3e'} />
          </>
        )}
      </div>

      {/* Grid card */}
      <Card>
        <div style={{ padding:'12px 16px', borderBottom:'1px solid var(--border)', display:'flex', gap:10, alignItems:'center' }}>
          <i className="fa-solid fa-magnifying-glass" style={{ color:'var(--text-light)' }}/>
          <input
            placeholder={attType === 'students' ? 'Search student...' : 'Search staff...'}
            value={search} onChange={e => setSearch(e.target.value)}
            style={{ flex:1, border:'none', outline:'none', fontSize:13, background:'transparent' }}
          />
          <Legend />
        </div>

        {/* ── STUDENT GRID ── */}
        {attType === 'students' && (
          loading ? (
            <div style={{ padding:40, textAlign:'center', color:'var(--text-light)' }}>
              <i className="fa-solid fa-spinner fa-spin" style={{ fontSize:24, marginBottom:10 }}/><br/>Loading students...
            </div>
          ) : filteredStudents.length === 0 ? (
            <div style={{ padding:40, textAlign:'center', color:'var(--text-light)' }}>
              <i className="fa-solid fa-users" style={{ fontSize:32, opacity:.3, marginBottom:8 }}/>
              <p>{selectedClass ? 'No students in this class' : 'Select a class to mark attendance'}</p>
            </div>
          ) : (
            <div style={{ padding:'12px 16px' }}>
              <AttendanceGrid items={filteredStudents} localMap={localRecords} onToggle={toggle} />
            </div>
          )
        )}

        {/* ── STAFF GRID ── */}
        {attType === 'staff' && (
          staffLoading ? (
            <div style={{ padding:40, textAlign:'center', color:'var(--text-light)' }}>
              <i className="fa-solid fa-spinner fa-spin" style={{ fontSize:24, marginBottom:10 }}/><br/>Loading staff...
            </div>
          ) : filteredStaff.length === 0 ? (
            <div style={{ padding:40, textAlign:'center', color:'var(--text-light)' }}>
              <i className="fa-solid fa-user-tie" style={{ fontSize:32, opacity:.3, marginBottom:8 }}/>
              <p>No staff records found</p>
            </div>
          ) : (
            <div style={{ padding:'12px 16px' }}>
              <AttendanceGrid items={filteredStaff} localMap={staffLocal} onToggle={toggleStaff} subKey="designation" />
            </div>
          )
        )}

        {/* Footer */}
        <div style={{ padding:'12px 18px', borderTop:'1px solid var(--border)', display:'flex',
          justifyContent:'space-between', alignItems:'center', background:'#fafafa', borderRadius:'0 0 12px 12px' }}>
          <p style={{ fontSize:12, color:'var(--text-light)' }}>
            {attType === 'students'
              ? (selClass ? `Class ${selClass.class_name}-${selClass.section} · ${date}` : 'Select a class')
              : `All Staff · ${date}`
            }
          </p>
          <Btn variant="primary" icon="fa-floppy-disk"
            loading={attType === 'students' ? saving : staffSaving}
            onClick={attType === 'students' ? handleSaveStudents : handleSaveStaff}
            disabled={attType === 'students' ? !records.length : !staff.length}>
            Save Attendance
          </Btn>
        </div>
      </Card>
    </div>
  );
}
