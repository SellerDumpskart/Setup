import React, { useState, useEffect } from 'react';
import { StatMini, Card } from '../../components/common/Common';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { orgService, schoolService } from '../../services';

export default function AdminDashboard() {
  const [orgs, setOrgs] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    orgService.list()
      .then(r => setOrgs(r.data || []))
      .catch(() => setOrgs([]))
      .finally(() => setLoading(false));
  }, []);

  const totalSchools   = orgs.reduce((s,o) => s + (o.school_count || 0), 0);
  const chartData = orgs.slice(0,6).map(o => ({ name: o.name?.split(' ')[0], schools: o.school_count||0 }));

  return (
    <div>
      <div style={{ marginBottom:20 }}>
        <h2 style={{ fontSize:20, fontWeight:700, color:'var(--text-dark)' }}>Admin Dashboard</h2>
        <p style={{ fontSize:13, color:'var(--text-light)', marginTop:2 }}>System-wide overview across all organizations</p>
      </div>
      <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:12, marginBottom:20 }}>
        <StatMini label="Organizations" value={orgs.length}   icon="fa-building"  color="#00A99D" />
        <StatMini label="Total Schools" value={totalSchools}  icon="fa-school"    color="#2196F3" />
        <StatMini label="Active"        value={orgs.filter(o=>o.status==='active').length} icon="fa-circle-check" color="#38a169" />
      </div>
      <div style={{ display:'grid', gridTemplateColumns:'3fr 2fr', gap:14 }}>
        <Card title="Organizations Overview" icon="fa-chart-bar">
          <div style={{ padding:'0 16px 16px' }}>
            {loading ? <div style={{ padding:20, textAlign:'center', color:'var(--text-light)' }}>Loading...</div> : (
              <ResponsiveContainer width="100%" height={220}>
                <BarChart data={chartData} barSize={22}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0"/>
                  <XAxis dataKey="name" tick={{ fontSize:10 }} axisLine={false} tickLine={false}/>
                  <YAxis tick={{ fontSize:10 }} axisLine={false} tickLine={false}/>
                  <Tooltip/>
                  <Bar dataKey="schools" fill="#00A99D" radius={[4,4,0,0]} name="Schools"/>
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
        </Card>
        <Card title="Organizations" icon="fa-building">
          <div style={{ padding:'0 14px 14px' }}>
            {orgs.slice(0,8).map((o,i) => (
              <div key={o.id||i} style={{ padding:'8px 0', borderBottom:'1px solid #f7f7f7', display:'flex', justifyContent:'space-between', alignItems:'center' }}>
                <div>
                  <p style={{ fontWeight:600, fontSize:13 }}>{o.name}</p>
                  <p style={{ fontSize:11, color:'var(--text-light)' }}>Since {o.since_date ? new Date(o.since_date).getFullYear() : '—'}</p>
                </div>
                <span style={{ background:'var(--primary-light)', color:'var(--primary-dark)', borderRadius:6, padding:'2px 8px', fontSize:11, fontWeight:600 }}>{o.school_count||0} schools</span>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}
