import React, { useState, useEffect } from 'react';
import { PageHeader, Btn, DataTable, Badge, Card, Modal, Input, StatMini } from '../../components/common/Common';
import { subjectService } from '../../services';
import { useSessionContext } from '../../store/sessionStore';
import toast from 'react-hot-toast';

export default function Subjects() {
  const { sessionId } = useSessionContext();
  const [subjects, setSubjects] = useState([]);
  const [loading, setLoading]   = useState(true);
  const [showForm, setShow]     = useState(false);
  const [editItem, setEdit]     = useState(null);
  const [form, setForm]         = useState({ subjectName:'', subjectCode:'', description:'', isLanguage:false });
  const [saving, setSaving]     = useState(false);

  const load = async () => {
    setLoading(true);
    try { const { data } = await subjectService.list(); setSubjects(data||[]); }
    catch { setSubjects([]); }
    finally { setLoading(false); }
  };

  useEffect(() => { load(); }, []);

  const openAdd  = ()    => { setEdit(null); setForm({ subjectName:'', subjectCode:'', description:'', isLanguage:false }); setShow(true); };
  const openEdit = (row) => { setEdit(row); setForm({ subjectName:row.subject_name, subjectCode:row.subject_code||'', description:row.description||'', isLanguage:row.is_language||false }); setShow(true); };

  const handleSave = async () => {
    if (!form.subjectName.trim()) { toast.error('Subject name required'); return; }
    setSaving(true);
    try {
      if (editItem) { await subjectService.update(editItem.id, form); toast.success('Subject updated'); }
      else          { await subjectService.create(form); toast.success('Subject added'); }
      load(); setShow(false);
    } catch (e) { toast.error(e.response?.data?.error||'Failed'); }
    finally { setSaving(false); }
  };

  const cols = [
    { key:'subject_name', label:'Subject Name', render:(v,row) => (
        <div><p style={{ fontWeight:600 }}>{v}</p>{row.subject_code && <p style={{ fontSize:11, color:'var(--text-light)', fontFamily:'monospace' }}>{row.subject_code}</p>}</div>
    )},
    { key:'description', label:'Description', render:v => <span style={{ fontSize:12.5, color:'var(--text-mid)' }}>{v||'—'}</span> },
    { key:'is_language', label:'Language', width:90, render:v => v ? <Badge label="Yes" color="blue" /> : <Badge label="No" color="gray" /> },
    { key:'status', label:'Status', width:90, render:v => <Badge label={v||'active'} color={v==='inactive'?'red':'green'} /> },
    { key:'id', label:'', width:70, render:(v,row) => (
        <button className="icon-btn" onClick={e=>{e.stopPropagation();openEdit(row)}}><i className="fa-solid fa-pen"/></button>
    )},
  ];

  return (
    <div>
      <PageHeader title="Add Subject" subtitle={`${subjects.length} subjects configured`} icon="fa-book-open"
        actions={<Btn icon="fa-plus" variant="primary" onClick={openAdd}>Add Subject</Btn>}
      />
      <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:12, marginBottom:16 }}>
        <StatMini label="Total Subjects" value={subjects.length} icon="fa-book" color="#00A99D" />
        <StatMini label="Languages" value={subjects.filter(s=>s.is_language).length} icon="fa-language" color="#2196F3" />
        <StatMini label="Active" value={subjects.filter(s=>s.status!=='inactive').length} icon="fa-circle-check" color="#38a169" />
      </div>
      <Card>
        <DataTable columns={cols} data={subjects} loading={loading} onRowClick={openEdit} emptyText="No subjects added. Click 'Add Subject' to start." />
      </Card>
      <Modal open={showForm} onClose={()=>setShow(false)} title={editItem?'Edit Subject':'Add Subject'} size="sm"
        footer={<div style={{ display:'flex', gap:8, justifyContent:'flex-end' }}><Btn variant="ghost" onClick={()=>setShow(false)}>Cancel</Btn><Btn variant="primary" icon="fa-floppy-disk" loading={saving} onClick={handleSave}>Save</Btn></div>}
      >
        <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
          <Input label="Subject Name" required value={form.subjectName} onChange={e=>setForm(f=>({...f,subjectName:e.target.value}))} placeholder="e.g. Mathematics" />
          <Input label="Subject Code" value={form.subjectCode} onChange={e=>setForm(f=>({...f,subjectCode:e.target.value}))} placeholder="e.g. MATH01" />
          <Input label="Description" value={form.description} onChange={e=>setForm(f=>({...f,description:e.target.value}))} placeholder="Optional description" />
          <label style={{ display:'flex', alignItems:'center', gap:8, fontSize:13, cursor:'pointer' }}>
            <input type="checkbox" checked={form.isLanguage} onChange={e=>setForm(f=>({...f,isLanguage:e.target.checked}))} style={{ accentColor:'var(--primary)', width:15, height:15 }}/>
            <span style={{ color:'var(--text-mid)' }}>This is a language subject</span>
          </label>
        </div>
      </Modal>
    </div>
  );
}
