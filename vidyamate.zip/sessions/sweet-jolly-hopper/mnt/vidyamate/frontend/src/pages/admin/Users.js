import React, { useState, useEffect } from 'react';
import { PageHeader, Btn, DataTable, Badge, Card, Modal, Input, Select, SearchBar, StatMini, Avatar } from '../../components/common/Common';
import { userService, orgService, schoolService } from '../../services';
import { STATUS_COLORS, ROLES } from '../../utils';
import toast from 'react-hot-toast';

const ROLE_COLOR = { super_admin:'red', org_admin:'purple', principal:'blue', teacher:'teal', accountant:'green', non_teaching:'gray' };

export default function Users() {
  const [users, setUsers]   = useState([]);
  const [orgs, setOrgs]     = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [showForm, setShow] = useState(false);
  const [editItem, setEdit] = useState(null);
  const [form, setForm]     = useState({ username:'', email:'', role:'teacher', schoolId:'', password:'', isActive:true });
  const [saving, setSaving] = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      const [us, og] = await Promise.all([userService.list(), orgService.list()]);
      setUsers(us.data||[]); setOrgs(og.data||[]);
    } catch { setUsers([]); }
    finally { setLoading(false); }
  };

  useEffect(() => { load(); }, []);

  const openEdit = (row) => { setEdit(row); setForm({ username:row.username, email:row.email, role:row.role, schoolId:row.school_id||'', password:'', isActive:row.is_active }); setShow(true); };

  const handleSave = async () => {
    if (!form.username || !form.email) { toast.error('Fill required fields'); return; }
    setSaving(true);
    try {
      if (editItem) { await userService.update(editItem.id, form); toast.success('User updated'); }
      else          { await userService.create(form); toast.success('User created'); }
      load(); setShow(false);
    } catch (e) { toast.error(e.response?.data?.error||'Failed'); }
    finally { setSaving(false); }
  };

  const resetPwd = async (id, email) => {
    await userService.resetPassword(id);
    toast.success(`Password reset for ${email}`);
  };

  const filtered = users.filter(u => !search || `${u.username} ${u.email} ${u.role}`.toLowerCase().includes(search.toLowerCase()));

  const cols = [
    { key:'username', label:'User',
      render:(v,row) => (
        <div style={{ display:'flex', alignItems:'center', gap:10 }}>
          <Avatar name={v} size={30}/>
          <div><p style={{ fontWeight:600 }}>{v}</p><p style={{ fontSize:11, color:'var(--text-light)' }}>{row.email}</p></div>
        </div>
      )
    },
    { key:'role', label:'Role', width:130, render:v => <Badge label={v?.replace(/_/g,' ')} color={ROLE_COLOR[v]||'gray'} /> },
    { key:'is_active', label:'Status', width:90, render:v => <Badge label={v?'Active':'Inactive'} color={v?'green':'red'} /> },
    { key:'last_login', label:'Last Login', render:v => v ? new Date(v).toLocaleDateString('en-IN') : 'Never' },
    { key:'id', label:'', width:100,
      render:(v,row) => (
        <div style={{ display:'flex', gap:4 }}>
          <button className="icon-btn" onClick={e=>{e.stopPropagation();openEdit(row)}}><i className="fa-solid fa-pen"/></button>
          <button className="icon-btn" title="Reset Password" onClick={e=>{e.stopPropagation();resetPwd(v,row.email)}}><i className="fa-solid fa-key"/></button>
        </div>
      )
    },
  ];

  return (
    <div>
      <PageHeader title="User Management" subtitle={`${users.length} system users`} icon="fa-users"
        actions={<Btn icon="fa-plus" variant="primary" onClick={() => { setEdit(null); setForm({ username:'', email:'', role:'teacher', schoolId:'', password:'', isActive:true }); setShow(true); }}>Add User</Btn>}
      />
      <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:12, marginBottom:16 }}>
        <StatMini label="Total" value={users.length} icon="fa-users" color="#00A99D" />
        <StatMini label="Active" value={users.filter(u=>u.is_active).length} icon="fa-circle-check" color="#38a169" />
        <StatMini label="Admins" value={users.filter(u=>['super_admin','org_admin','principal'].includes(u.role)).length} icon="fa-shield-halved" color="#9C27B0" />
        <StatMini label="Teachers" value={users.filter(u=>u.role==='teacher').length} icon="fa-chalkboard-user" color="#2196F3" />
      </div>
      <Card>
        <div style={{ padding:'12px 16px', borderBottom:'1px solid var(--border)' }}>
          <SearchBar value={search} onChange={setSearch} placeholder="Search username, email, role..." />
        </div>
        <DataTable columns={cols} data={filtered} loading={loading} onRowClick={openEdit} emptyText="No users" />
      </Card>
      <Modal open={showForm} onClose={()=>setShow(false)} title={editItem?'Edit User':'Add User'} size="md"
        footer={<div style={{ display:'flex', gap:8, justifyContent:'flex-end' }}><Btn variant="ghost" onClick={()=>setShow(false)}>Cancel</Btn><Btn variant="primary" icon="fa-floppy-disk" loading={saving} onClick={handleSave}>Save</Btn></div>}
      >
        <div className="form-grid">
          <Input label="Username" required value={form.username} onChange={e=>setForm(f=>({...f,username:e.target.value}))} />
          <Input label="Email" required type="email" value={form.email} onChange={e=>setForm(f=>({...f,email:e.target.value}))} />
          <Select label="Role" required value={form.role} onChange={e=>setForm(f=>({...f,role:e.target.value}))} options={ROLES} />
          {!editItem && <Input label="Password" required type="password" value={form.password} onChange={e=>setForm(f=>({...f,password:e.target.value}))} placeholder="Min 8 characters" />}
          <Select label="Status" value={form.isActive?'true':'false'} onChange={e=>setForm(f=>({...f,isActive:e.target.value==='true'}))}
            options={[{value:'true',label:'Active'},{value:'false',label:'Inactive'}]} />
        </div>
      </Modal>
    </div>
  );
}
