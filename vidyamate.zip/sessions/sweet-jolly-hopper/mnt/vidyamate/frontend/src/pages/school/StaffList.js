import React, { useState } from 'react';
import { PageHeader, Btn, SearchBar, DataTable, Badge, Avatar, Card, Modal, Input, Select, StatMini } from '../../components/common/Common';
import { useStaff } from '../../hooks';
import { useSessionContext } from '../../store/sessionStore';
import { fmtDate, exportToCSV, STAFF_TYPES } from '../../utils';
import { staffService } from '../../services';
import toast from 'react-hot-toast';

const TYPE_COLOR = { teaching:'green', non_teaching:'blue', support:'orange', admin:'purple' };
const QUALIFICATIONS = ['SSLC','D.Ed','D.El.Ed','B.Ed','M.Ed','B.A','M.A','B.Sc','M.Sc','B.Com','M.Com','B.Tech','MBA'];
const EMPTY = { firstName:'', lastName:'', designation:'', staffType:'teaching', qualification:'', phone:'', email:'', salary:'', status:'active' };

export default function StaffList() {
  const [search, setSearch] = useState('');
  const [typeFilter, setType] = useState('');
  const [showForm, setShow] = useState(false);
  const [editItem, setEdit] = useState(null);
  const [form, setForm]     = useState(EMPTY);
  const [saving, setSaving] = useState(false);

  const { staff, loading, refetch, create, update, resetPassword } = useStaff({ search, staffType: typeFilter });

  const openAdd  = () => { setEdit(null); setForm(EMPTY); setShow(true); };
  const openEdit = (row) => { setEdit(row); setForm({ firstName:row.first_name, lastName:row.last_name||'', designation:row.designation||'', staffType:row.staff_type, qualification:row.qualification||'', phone:row.phone||'', email:row.email||'', salary:row.salary||'', status:row.status }); setShow(true); };

  const handleSave = async () => {
    if (!form.firstName || !form.phone) { toast.error('Name and phone required'); return; }
    setSaving(true);
    try {
      if (editItem) { await update(editItem.id, form); toast.success('Staff updated'); }
      else          { await create(form); toast.success('Staff added'); }
      setShow(false);
    } catch (err) { toast.error(err.response?.data?.error || 'Failed to save'); }
    finally { setSaving(false); }
  };

  const handleExport = () => {
    exportToCSV(staff, 'staff_list', [
      { key:'emp_no',        label:'Emp No.' },
      { key:'first_name',    label:'First Name' },
      { key:'last_name',     label:'Last Name' },
      { key:'designation',   label:'Designation' },
      { key:'staff_type',    label:'Type' },
      { key:'qualification', label:'Qualification' },
      { key:'phone',         label:'Phone' },
      { key:'email',         label:'Email' },
      { key:'status',        label:'Status' },
    ]);
    toast.success('Staff list exported');
  };

  const cols = [
    { key:'emp_no', label:'Emp No.', width:120,
      render:(v,row) => (
        <div style={{ display:'flex', alignItems:'center', gap:8 }}>
          <Avatar name={`${row.first_name} ${row.last_name||''}`} photo={row.photo_url} size={30} />
          <span style={{ fontSize:11.5, color:'var(--text-light)', fontFamily:'monospace' }}>{v}</span>
        </div>
      )
    },
    { key:'first_name', label:'Name',
      render:(v,row) => (
        <div>
          <p style={{ fontWeight:600 }}>{v} {row.last_name}</p>
          <p style={{ fontSize:11, color:'var(--text-light)' }}>{row.designation}</p>
        </div>
      )
    },
    { key:'staff_type', label:'Type', width:140,
      render:v => <Badge label={v?.replace('_',' ')} color={TYPE_COLOR[v]||'gray'} />
    },
    { key:'qualification', label:'Qualification', width:130 },
    { key:'phone', label:'Contact',
      render:v => <a href={`tel:${v}`} style={{ color:'var(--primary)' }}>{v}</a>
    },
    { key:'status', label:'Status', width:90,
      render:v => <Badge label={v} color={v==='active'?'green':'red'} />
    },
    { key:'id', label:'', width:110,
      render:(v,row) => (
        <div style={{ display:'flex', gap:4 }}>
          <button className="icon-btn" title="Edit" onClick={e => { e.stopPropagation(); openEdit(row); }}><i className="fa-solid fa-pen"/></button>
          <button className="icon-btn" title="Reset Password" onClick={e => { e.stopPropagation(); resetPassword(v); }}><i className="fa-solid fa-key"/></button>
        </div>
      )
    },
  ];

  return (
    <div>
      <PageHeader title="Staff Master" subtitle={`${staff.length} staff members`} icon="fa-users-gear"
        actions={
          <>
            <Btn icon="fa-file-csv" variant="ghost" size="sm" onClick={handleExport}>Export</Btn>
            <Btn icon="fa-plus" variant="primary" onClick={openAdd}>Add Staff</Btn>
          </>
        }
      />
      <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:12, marginBottom:16 }}>
        <StatMini label="Total Staff"    value={staff.length}                                         icon="fa-users"          color="#00A99D" />
        <StatMini label="Teaching"       value={staff.filter(s=>s.staff_type==='teaching').length}    icon="fa-chalkboard-user" color="#2196F3" />
        <StatMini label="Non-Teaching"   value={staff.filter(s=>s.staff_type==='non_teaching').length} icon="fa-briefcase"     color="#9C27B0" />
        <StatMini label="Support"        value={staff.filter(s=>s.staff_type==='support').length}     icon="fa-screwdriver-wrench" color="#F7941D" />
      </div>
      <Card>
        <div style={{ display:'flex', gap:10, padding:'14px 16px', borderBottom:'1px solid var(--border)', flexWrap:'wrap' }}>
          <SearchBar value={search} onChange={setSearch} placeholder="Search name, emp no, designation..." />
          <Select value={typeFilter} onChange={e => setType(e.target.value)} style={{ width:180 }}
            options={[{value:'',label:'All Types'}, ...STAFF_TYPES]} />
        </div>
        <DataTable columns={cols} data={staff} loading={loading} onRowClick={openEdit}
          emptyText="No staff found" />
      </Card>

      <Modal open={showForm} onClose={() => setShow(false)} title={editItem ? 'Edit Staff' : 'Add New Staff'} size="md"
        footer={
          <div style={{ display:'flex', gap:8, justifyContent:'flex-end' }}>
            <Btn variant="ghost" onClick={() => setShow(false)}>Cancel</Btn>
            <Btn variant="primary" icon="fa-floppy-disk" loading={saving} onClick={handleSave}>Save</Btn>
          </div>
        }
      >
        <div className="form-grid">
          <Input label="First Name" required value={form.firstName} onChange={e => setForm(f=>({...f,firstName:e.target.value}))} />
          <Input label="Last Name"  value={form.lastName}  onChange={e => setForm(f=>({...f,lastName:e.target.value}))} />
          <Input label="Phone" required type="tel" value={form.phone} onChange={e => setForm(f=>({...f,phone:e.target.value}))} />
          <Input label="Email" type="email" value={form.email} onChange={e => setForm(f=>({...f,email:e.target.value}))} />
          <Input label="Designation" value={form.designation} onChange={e => setForm(f=>({...f,designation:e.target.value}))} />
          <Select label="Staff Type" value={form.staffType} onChange={e => setForm(f=>({...f,staffType:e.target.value}))} options={STAFF_TYPES} />
          <Select label="Qualification" value={form.qualification} onChange={e => setForm(f=>({...f,qualification:e.target.value}))} placeholder="Select" options={QUALIFICATIONS} />
          <Input label="Salary (₹)" type="number" value={form.salary} onChange={e => setForm(f=>({...f,salary:e.target.value}))} />
          <Select label="Status" value={form.status} onChange={e => setForm(f=>({...f,status:e.target.value}))}
            options={[{value:'active',label:'Active'},{value:'inactive',label:'Inactive'}]} />
          {!editItem && <Input label="Password" type="password" value={form.password||''} onChange={e => setForm(f=>({...f,password:e.target.value}))} placeholder="School@123 default" />}
        </div>
      </Modal>
    </div>
  );
}
