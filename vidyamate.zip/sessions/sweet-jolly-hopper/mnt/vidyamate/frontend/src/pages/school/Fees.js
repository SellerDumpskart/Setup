import React, { useState, useEffect, useCallback } from 'react';
import { PageHeader, Btn, SearchBar, Card, Badge, StatMini, Input, Select, Modal, DataTable } from '../../components/common/Common';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { useFees, useClasses } from '../../hooks';
import { useSessionContext } from '../../store/sessionStore';
import { fmtCurrency, fmtDate, PAYMENT_MODES, exportToCSV } from '../../utils';
import api from '../../services/api';
import toast from 'react-hot-toast';

const getSchoolId = () =>
  JSON.parse(localStorage.getItem('vidyamate-auth') || '{}')?.state?.user?.schoolId;

export default function Fees() {
  const { sessionId } = useSessionContext();
  const { feeHeads, payments, loading, refetch, collectPayment, applyDiscount } = useFees(sessionId);
  const classesResult = useClasses(sessionId);
  const classes = classesResult?.data || [];

  const [tab, setTab]               = useState('summary');
  const [search, setSearch]         = useState('');
  const [showCollect, setCollect]   = useState(false);
  const [showDiscount, setDiscount] = useState(false);
  const [showAssign, setAssign]     = useState(false);
  const [saving, setSaving]         = useState(false);

  // Collect form
  const [collectForm, setCollect2] = useState({ studentCode:'', studentFeeId:'', amount:'', mode:'cash', feeType:'', remarks:'' });

  // Discount form
  const [discountForm, setDiscount2] = useState({ studentFeeId:'', studentId:'', reason:'', authority:'', amount:'' });

  // Assign form
  const ASSIGN_INIT = { feeHeadId:'', classId:'', assignTo:'class', studentIds:[], amount:'', concession:'0', dueDate:'', notes:'' };
  const [assignForm, setAssign2] = useState(ASSIGN_INIT);
  const [classStudents, setClassStudents] = useState([]);
  const [loadingStudents, setLoadingStudents] = useState(false);
  const [defaulters, setDefaulters] = useState([]);
  const [loadingDefaulters, setLoadingDefaulters] = useState(false);

  // Fetch students when class is selected in assign modal
  useEffect(() => {
    if (!assignForm.classId || assignForm.assignTo !== 'student') { setClassStudents([]); return; }
    setLoadingStudents(true);
    api.get('/students', { params: { schoolId: getSchoolId(), classId: assignForm.classId, limit: 200 } })
      .then(r => setClassStudents(r.data?.students || []))
      .catch(() => setClassStudents([]))
      .finally(() => setLoadingStudents(false));
  }, [assignForm.classId, assignForm.assignTo]);

  const totalBalance = feeHeads.reduce((s,f) => s + parseFloat(f.total_balance||0), 0);
  const totalPaid    = feeHeads.reduce((s,f) => s + parseFloat(f.total_paid||0), 0);
  const totalFee     = feeHeads.reduce((s,f) => s + parseFloat(f.total_assigned||0), 0);
  const pct          = totalFee > 0 ? Math.round((totalPaid / totalFee) * 100) : 0;

  const chartData = feeHeads.map(f => ({
    name: (f.fee_name||'').replace(' Fee','').replace(' FEE','').slice(0,8),
    Balance: parseFloat(f.total_balance||0),
    Paid:    parseFloat(f.total_paid||0),
  }));

  const filteredPayments = payments.filter(p =>
    !search || `${p.first_name||''} ${p.last_name||''} ${p.receipt_no||''}`.toLowerCase().includes(search.toLowerCase())
  );

  const handleCollect = async () => {
    if (!collectForm.amount || !collectForm.mode) { toast.error('Fill required fields'); return; }
    setSaving(true);
    try {
      await collectPayment({ ...collectForm, amount: parseFloat(collectForm.amount) });
      setCollect(false);
      setCollect2({ studentCode:'', studentFeeId:'', amount:'', mode:'cash', feeType:'', remarks:'' });
    } catch (err) { toast.error(err.response?.data?.error || 'Payment failed'); }
    finally { setSaving(false); }
  };

  const handleDiscount = async () => {
    if (!discountForm.amount || !discountForm.reason) { toast.error('Fill required fields'); return; }
    setSaving(true);
    try {
      await applyDiscount({ ...discountForm, discountAmount: parseFloat(discountForm.amount) });
      setDiscount(false);
    } catch (err) { toast.error(err.response?.data?.error || 'Discount failed'); }
    finally { setSaving(false); }
  };

  const handleAssign = async () => {
    if (!assignForm.feeHeadId) { toast.error('Select a fee head'); return; }
    if (!assignForm.amount || parseFloat(assignForm.amount) <= 0) { toast.error('Enter a valid amount'); return; }
    if (assignForm.assignTo === 'class' && !assignForm.classId) { toast.error('Select a class'); return; }
    if (assignForm.assignTo === 'student' && assignForm.studentIds.length === 0) { toast.error('Select at least one student'); return; }

    setSaving(true);
    try {
      let studentIds = assignForm.studentIds;

      if (assignForm.assignTo === 'class') {
        // Fetch all students in this class then assign
        const r = await api.get('/students', { params: { schoolId: getSchoolId(), classId: assignForm.classId, limit: 500 } });
        studentIds = (r.data?.students || []).map(s => s.id);
        if (studentIds.length === 0) { toast.error('No active students found in this class'); setSaving(false); return; }
      }

      const { data } = await api.post('/fees/assign', {
        studentIds,
        feeHeadId:   assignForm.feeHeadId,
        sessionId,
        totalAmount: parseFloat(assignForm.amount),
        concession:  parseFloat(assignForm.concession || 0),
        dueDate:     assignForm.dueDate || null,
      });

      toast.success(data.message || `Fees assigned to ${studentIds.length} student(s)`);
      setAssign(false);
      setAssign2(ASSIGN_INIT);
      refetch();
    } catch (err) {
      toast.error(err.response?.data?.error || 'Assignment failed');
    } finally { setSaving(false); }
  };

  const loadDefaulters = async () => {
    setLoadingDefaulters(true);
    try {
      const { data } = await api.get('/fees/defaulters', { params: { schoolId: getSchoolId(), sessionId } });
      setDefaulters(data || []);
    } catch { toast.error('Failed to load defaulters'); }
    finally { setLoadingDefaulters(false); }
  };

  const paymentCols = [
    { key:'receipt_no', label:'Receipt',
      render:v => <span style={{ fontFamily:'monospace', fontSize:12, color:'var(--primary)', fontWeight:600 }}>{v}</span>
    },
    { key:'first_name', label:'Student',
      render:(v,row) => <div><p style={{ fontWeight:600 }}>{v} {row.last_name}</p><p style={{ fontSize:11, color:'var(--text-light)' }}>{row.class_name}-{row.section}</p></div>
    },
    { key:'fee_name',      label:'Fee Type',  render:v => <Badge label={v||'—'} color="teal" /> },
    { key:'amount',        label:'Amount',    render:v => <span style={{ fontWeight:700 }}>{fmtCurrency(v)}</span> },
    { key:'payment_mode',  label:'Mode',      render:v => <Badge label={v} color={{ cash:'green',online:'blue',upi:'teal',cheque:'orange',neft:'purple' }[v]||'gray'} /> },
    { key:'payment_date',  label:'Date',      render:v => fmtDate(v, { day:'2-digit', month:'short', year:'2-digit' }) },
  ];

  const [reminderSending, setReminderSending] = useState({});

  const sendReminder = async (row) => {
    setReminderSending(p => ({ ...p, [row.student_id || row.id]: true }));
    try {
      const schoolId = getSchoolId();
      await api.post('/school-communication/broadcasts', {
        schoolId,
        sessionId,
        title:       'Fee Payment Reminder',
        message:     `Dear Parent, this is a reminder that ₹${row.balance} is due for ${row.fee_name}. Kindly clear the dues at the earliest. – School Admin`,
        channel:     'sms',
        targetGroup: 'parents',
        studentId:   row.student_id || row.id,
      });
      toast.success(`Reminder sent for ${row.first_name} ${row.last_name||''}`);
    } catch {
      toast.error('Failed to send reminder');
    } finally {
      setReminderSending(p => ({ ...p, [row.student_id || row.id]: false }));
    }
  };

  const defaulterCols = [
    { key:'first_name', label:'Student',
      render:(v,row) => <div><p style={{ fontWeight:600 }}>{v} {row.last_name}</p><p style={{ fontSize:11, color:'var(--text-light)' }}>{row.student_code}</p></div>
    },
    { key:'class_name', label:'Class', render:(v,row) => <Badge label={`${v||'—'}-${row.section||''}`} color="teal" /> },
    { key:'fee_name',   label:'Fee Head', render:v => <span style={{ fontSize:13 }}>{v||'—'}</span> },
    { key:'balance',    label:'Balance Due', render:v => <span style={{ fontWeight:700, color:'var(--danger)' }}>{fmtCurrency(v)}</span> },
    { key:'due_date',   label:'Due Date',    render:v => v ? <span style={{ fontSize:12, color:'var(--text-mid)' }}>{fmtDate(v, { day:'2-digit', month:'short', year:'numeric' })}</span> : '—' },
    { key:'days_overdue', label:'Overdue', width:90,
      render:v => v > 0
        ? <span style={{ fontWeight:600, color:'#e53e3e', fontSize:12 }}>{v}d</span>
        : <span style={{ color:'var(--text-light)', fontSize:12 }}>—</span>
    },
    { key:'id', label:'', width:110,
      render:(v,row) => {
        const sid = row.student_id || v;
        const busy = reminderSending[sid];
        return (
          <button
            disabled={busy}
            onClick={e => { e.stopPropagation(); sendReminder(row); }}
            style={{ display:'flex', alignItems:'center', gap:5, padding:'5px 10px', borderRadius:6, fontSize:12,
              border:'1.5px solid #F7941D', background: busy ? '#fef3e2' : '#fff', color:'#F7941D',
              cursor: busy ? 'default' : 'pointer', fontWeight:500 }}
          >
            {busy
              ? <i className="fa-solid fa-spinner fa-spin"/>
              : <i className="fa-solid fa-bell"/>}
            {busy ? 'Sending…' : 'Remind'}
          </button>
        );
      }
    },
  ];

  return (
    <div>
      <PageHeader title="Fees Management" subtitle="Assign, collect, and track school fees" icon="fa-credit-card"
        actions={
          <>
            <Btn icon="fa-file-csv" variant="ghost" size="sm" onClick={() => { exportToCSV(payments,'fee_payments',paymentCols); toast.success('Exported'); }}>Export</Btn>
            <Btn icon="fa-tag"         variant="secondary" onClick={() => setDiscount(true)}>Discount</Btn>
            <Btn icon="fa-arrow-right" variant="secondary" onClick={() => setAssign(true)}>Assign Fees</Btn>
            <Btn icon="fa-plus"        variant="primary"   onClick={() => setCollect(true)}>Collect Fee</Btn>
          </>
        }
      />

      <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:12, marginBottom:16 }}>
        <StatMini label="Total Fees"    value={fmtCurrency(totalFee, true)}     icon="fa-file-invoice-dollar" color="#00A99D" />
        <StatMini label="Collected"     value={fmtCurrency(totalPaid, true)}    icon="fa-circle-check"        color="#38a169" />
        <StatMini label="Balance"       value={fmtCurrency(totalBalance, true)} icon="fa-clock"               color="#e53e3e" />
        <StatMini label="Collection %"  value={`${pct}%`}                       icon="fa-percent"             color="#F7941D" />
      </div>

      <div style={{ display:'flex', gap:4, marginBottom:14 }}>
        {[
          { k:'summary',  l:'Summary',   i:'fa-chart-bar' },
          { k:'assign',   l:'Assign',    i:'fa-arrow-right' },
          { k:'payments', l:'Payments',  i:'fa-list' },
          { k:'defaulters',l:'Defaulters',i:'fa-triangle-exclamation' },
        ].map(t => (
          <button key={t.k} onClick={() => { setTab(t.k); if(t.k==='defaulters' && defaulters.length===0) loadDefaulters(); }}
            style={{ padding:'8px 16px', borderRadius:8, fontSize:13, fontWeight:500, border:'1.5px solid', transition:'all .15s', cursor:'pointer',
              borderColor:tab===t.k?'var(--primary)':'var(--border)',
              background:tab===t.k?'var(--primary)':'#fff', color:tab===t.k?'#fff':'var(--text-mid)',
              display:'flex', alignItems:'center', gap:6 }}>
            <i className={`fa-solid ${t.i}`}/>{t.l}
          </button>
        ))}
      </div>

      {/* ── SUMMARY ── */}
      {tab === 'summary' && (
        <div style={{ display:'grid', gridTemplateColumns:'2fr 1fr', gap:14 }}>
          <Card title="Fee Summary Chart" icon="fa-chart-bar">
            <div style={{ padding:'0 16px 16px' }}>
              <ResponsiveContainer width="100%" height={220}>
                <BarChart data={chartData} barSize={28}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0"/>
                  <XAxis dataKey="name" tick={{ fontSize:11 }} axisLine={false} tickLine={false}/>
                  <YAxis tickFormatter={v => v>=1e5?`${(v/1e5).toFixed(0)}L`:`${(v/1e3).toFixed(0)}K`} tick={{ fontSize:10 }} axisLine={false} tickLine={false}/>
                  <Tooltip formatter={(v,n) => [fmtCurrency(v), n]} cursor={{ fill:'rgba(0,0,0,.04)' }}/>
                  <Bar dataKey="Balance" fill="#e0f7fa" radius={[4,4,0,0]}/>
                  <Bar dataKey="Paid"    fill="#F7941D" radius={[4,4,0,0]}/>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </Card>
          <Card title="Fee Heads" icon="fa-list">
            <div style={{ padding:'0 16px 16px' }}>
              {feeHeads.map(f => {
                const total = parseFloat(f.total_assigned||0);
                const paid  = parseFloat(f.total_paid||0);
                const p     = total > 0 ? Math.round((paid/total)*100) : 0;
                return (
                  <div key={f.id} style={{ marginBottom:14 }}>
                    <div style={{ display:'flex', justifyContent:'space-between', marginBottom:3 }}>
                      <span style={{ fontSize:13, fontWeight:500 }}>{f.fee_name}</span>
                      <span style={{ fontSize:12, color:'var(--text-light)' }}>{p}%</span>
                    </div>
                    <div style={{ height:6, background:'#f0f0f0', borderRadius:3, overflow:'hidden' }}>
                      <div style={{ width:`${p}%`, height:'100%', background:'var(--primary)', borderRadius:3 }}/>
                    </div>
                    <div style={{ display:'flex', justifyContent:'space-between', marginTop:2 }}>
                      <span style={{ fontSize:10, color:'var(--accent-green)' }}>Paid: {fmtCurrency(paid,true)}</span>
                      <span style={{ fontSize:10, color:'var(--danger)' }}>Due: {fmtCurrency(total-paid,true)}</span>
                    </div>
                  </div>
                );
              })}
              {feeHeads.length === 0 && (
                <div style={{ textAlign:'center', padding:'24px 0' }}>
                  <p style={{ fontSize:13, color:'var(--text-light)', marginBottom:10 }}>No fee heads configured yet.</p>
                  <Btn variant="primary" size="sm" icon="fa-arrow-right" onClick={() => { setTab('assign'); setAssign(true); }}>
                    Assign Fees
                  </Btn>
                </div>
              )}
            </div>
          </Card>
        </div>
      )}

      {/* ── ASSIGN (inline tab) ── */}
      {tab === 'assign' && (
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:14 }}>
          {/* Assign form card */}
          <Card title="Assign Fee to Students" icon="fa-arrow-right">
            <div style={{ padding:'0 18px 18px', display:'flex', flexDirection:'column', gap:14 }}>
              <Select
                label="Fee Head" required
                value={assignForm.feeHeadId}
                onChange={e => setAssign2(f => ({ ...f, feeHeadId:e.target.value }))}
                placeholder="Select fee head"
                options={feeHeads.map(h => ({ value:h.id, label:`${h.fee_name} (${h.fee_type})` }))}
              />

              <div>
                <label style={{ fontSize:12.5, fontWeight:500, color:'var(--text-mid)', marginBottom:6, display:'block' }}>Assign To</label>
                <div style={{ display:'flex', gap:8 }}>
                  {[{ v:'class', l:'Entire Class' }, { v:'student', l:'Individual Students' }].map(opt => (
                    <label key={opt.v} style={{ display:'flex', alignItems:'center', gap:6, fontSize:13, cursor:'pointer',
                      padding:'8px 14px', borderRadius:8, border:'1.5px solid',
                      borderColor:assignForm.assignTo===opt.v?'var(--primary)':'var(--border)',
                      background:assignForm.assignTo===opt.v?'var(--primary-light)':'#fff',
                      color:assignForm.assignTo===opt.v?'var(--primary)':'var(--text-mid)' }}>
                      <input type="radio" name="assignTo" value={opt.v} checked={assignForm.assignTo===opt.v}
                        onChange={e => setAssign2(f => ({ ...f, assignTo:e.target.value, studentIds:[] }))}
                        style={{ display:'none' }} />
                      <i className={`fa-solid ${opt.v==='class'?'fa-users':'fa-user'}`} style={{ fontSize:12 }} />
                      {opt.l}
                    </label>
                  ))}
                </div>
              </div>

              <Select
                label="Class" required
                value={assignForm.classId}
                onChange={e => setAssign2(f => ({ ...f, classId:e.target.value, studentIds:[] }))}
                placeholder="Select class"
                options={(classes || []).map(c => ({ value:c.id, label:`${c.class_name}${c.section?' - '+c.section:''}` }))}
              />

              {assignForm.assignTo === 'student' && (
                <div>
                  <label style={{ fontSize:12.5, fontWeight:500, color:'var(--text-mid)', marginBottom:6, display:'block' }}>
                    Select Students {loadingStudents && <i className="fa-solid fa-spinner fa-spin" style={{ marginLeft:4 }} />}
                  </label>
                  {classStudents.length > 0 ? (
                    <div style={{ maxHeight:160, overflowY:'auto', border:'1px solid var(--border)', borderRadius:8, padding:8 }}>
                      <label style={{ display:'flex', alignItems:'center', gap:8, padding:'4px 0', fontSize:12.5, cursor:'pointer',
                        fontWeight:600, borderBottom:'1px solid var(--border)', marginBottom:4 }}>
                        <input type="checkbox"
                          checked={assignForm.studentIds.length === classStudents.length}
                          onChange={e => setAssign2(f => ({ ...f, studentIds: e.target.checked ? classStudents.map(s=>s.id) : [] }))}
                          style={{ accentColor:'var(--primary)' }} />
                        Select All ({classStudents.length})
                      </label>
                      {classStudents.map(s => (
                        <label key={s.id} style={{ display:'flex', alignItems:'center', gap:8, padding:'3px 0', fontSize:12.5, cursor:'pointer' }}>
                          <input type="checkbox"
                            checked={assignForm.studentIds.includes(s.id)}
                            onChange={e => setAssign2(f => ({
                              ...f, studentIds: e.target.checked
                                ? [...f.studentIds, s.id]
                                : f.studentIds.filter(x=>x!==s.id)
                            }))}
                            style={{ accentColor:'var(--primary)' }} />
                          {s.first_name} {s.last_name}
                          <span style={{ fontSize:11, color:'var(--text-light)' }}>({s.student_code})</span>
                        </label>
                      ))}
                    </div>
                  ) : assignForm.classId && !loadingStudents ? (
                    <p style={{ fontSize:12.5, color:'var(--text-light)' }}>No students in this class</p>
                  ) : null}
                </div>
              )}

              <div className="form-grid" style={{ gap:12 }}>
                <Input label="Fee Amount (₹)" required type="number" value={assignForm.amount}
                  onChange={e => setAssign2(f=>({...f,amount:e.target.value}))} placeholder="e.g. 12000" />
                <Input label="Concession (₹)" type="number" value={assignForm.concession}
                  onChange={e => setAssign2(f=>({...f,concession:e.target.value}))} placeholder="0" />
                <Input label="Due Date" type="date" value={assignForm.dueDate}
                  onChange={e => setAssign2(f=>({...f,dueDate:e.target.value}))} />
              </div>

              {assignForm.amount && (
                <div style={{ background:'var(--primary-light)', borderRadius:8, padding:'10px 14px', fontSize:13 }}>
                  <span style={{ color:'var(--text-mid)' }}>Net payable: </span>
                  <strong style={{ color:'var(--primary)' }}>
                    {fmtCurrency(parseFloat(assignForm.amount||0) - parseFloat(assignForm.concession||0))}
                  </strong>
                  {assignForm.assignTo === 'class' && assignForm.classId &&
                    <span style={{ color:'var(--text-light)', fontSize:11 }}> per student</span>}
                </div>
              )}

              <Btn variant="primary" icon="fa-floppy-disk" loading={saving} onClick={handleAssign}
                style={{ alignSelf:'flex-start' }}>
                {assignForm.assignTo === 'class' ? 'Assign to Entire Class' :
                  `Assign to ${assignForm.studentIds.length} Student(s)`}
              </Btn>
            </div>
          </Card>

          {/* Existing fee heads card */}
          <Card title="Configured Fee Heads" icon="fa-list">
            <div style={{ padding:'0 16px 16px' }}>
              {feeHeads.length === 0 ? (
                <p style={{ fontSize:13, color:'var(--text-light)', padding:'16px 0' }}>
                  No fee heads yet. Go to <strong>Settings → Fee Heads</strong> to create one first.
                </p>
              ) : feeHeads.map(f => (
                <div key={f.id} style={{ display:'flex', alignItems:'center', gap:10, padding:'10px 0',
                  borderBottom:'1px solid var(--border)' }}>
                  <div style={{ flex:1 }}>
                    <p style={{ fontSize:13, fontWeight:600 }}>{f.fee_name}</p>
                    <p style={{ fontSize:11, color:'var(--text-light)', textTransform:'capitalize' }}>
                      {f.fee_type} · {f.frequency}
                    </p>
                  </div>
                  <div style={{ textAlign:'right' }}>
                    <p style={{ fontSize:13, fontWeight:700, color:'var(--primary)' }}>{fmtCurrency(f.amount)}</p>
                    <p style={{ fontSize:11, color:'var(--text-light)' }}>base amount</p>
                  </div>
                  <Btn variant="ghost" size="sm" onClick={() => setAssign2(f2=>({ ...f2, feeHeadId:f.id, amount:String(f.amount||'') }))}>
                    Use
                  </Btn>
                </div>
              ))}
            </div>
          </Card>
        </div>
      )}

      {/* ── PAYMENTS ── */}
      {tab === 'payments' && (
        <Card>
          <div style={{ padding:'12px 16px', borderBottom:'1px solid var(--border)' }}>
            <SearchBar value={search} onChange={setSearch} placeholder="Search by student, receipt..." />
          </div>
          <DataTable columns={paymentCols} data={filteredPayments} loading={loading} emptyText="No payments recorded" />
        </Card>
      )}

      {/* ── DEFAULTERS ── */}
      {tab === 'defaulters' && (
        <Card>
          {loadingDefaulters ? (
            <div style={{ padding:40, textAlign:'center', color:'var(--text-light)' }}>
              <i className="fa-solid fa-spinner fa-spin" style={{ fontSize:24, marginBottom:8 }}/>
              <p>Loading defaulters...</p>
            </div>
          ) : defaulters.length === 0 ? (
            <div style={{ padding:32, textAlign:'center', color:'var(--text-light)' }}>
              <i className="fa-solid fa-triangle-exclamation" style={{ fontSize:40, opacity:.3, marginBottom:10 }}/>
              <p style={{ marginBottom:16 }}>Students with outstanding fee balances</p>
              <Btn variant="primary" icon="fa-search" onClick={loadDefaulters}>Load Defaulters</Btn>
            </div>
          ) : (
            <>
              <div style={{ padding:'10px 16px', borderBottom:'1px solid var(--border)', display:'flex', alignItems:'center', justifyContent:'space-between' }}>
                <span style={{ fontSize:13, color:'var(--text-mid)' }}>{defaulters.length} student(s) with dues</span>
                <Btn variant="ghost" size="sm" icon="fa-refresh" onClick={loadDefaulters}>Refresh</Btn>
              </div>
              <DataTable columns={defaulterCols} data={defaulters} emptyText="No defaulters" />
            </>
          )}
        </Card>
      )}

      {/* ── COLLECT MODAL ── */}
      <Modal open={showCollect} onClose={() => setCollect(false)} title="Collect Fee" size="md"
        footer={<div style={{ display:'flex', gap:8, justifyContent:'flex-end' }}>
          <Btn variant="ghost" onClick={() => setCollect(false)}>Cancel</Btn>
          <Btn variant="primary" icon="fa-money-bill" loading={saving} onClick={handleCollect}>Collect</Btn>
        </div>}
      >
        <div className="form-grid">
          <Input label="Student Code/Name" required value={collectForm.studentCode} onChange={e => setCollect2(f=>({...f,studentCode:e.target.value}))} placeholder="Search student..." />
          <Select label="Fee Type" required value={collectForm.feeType} onChange={e => setCollect2(f=>({...f,feeType:e.target.value}))} placeholder="Select fee"
            options={feeHeads.map(h => ({ value:h.id, label:h.fee_name }))} />
          <Input label="Amount (₹)" required type="number" value={collectForm.amount} onChange={e => setCollect2(f=>({...f,amount:e.target.value}))} />
          <Select label="Payment Mode" value={collectForm.mode} onChange={e => setCollect2(f=>({...f,mode:e.target.value}))} options={PAYMENT_MODES} />
          <Input label="Transaction ID" value={collectForm.txnId||''} onChange={e => setCollect2(f=>({...f,txnId:e.target.value}))} placeholder="For online payments" />
          <Input label="Remarks" value={collectForm.remarks} onChange={e => setCollect2(f=>({...f,remarks:e.target.value}))} />
        </div>
      </Modal>

      {/* ── DISCOUNT MODAL ── */}
      <Modal open={showDiscount} onClose={() => setDiscount(false)} title="Apply Discount" size="md"
        footer={<div style={{ display:'flex', gap:8, justifyContent:'flex-end' }}>
          <Btn variant="ghost" onClick={() => setDiscount(false)}>Cancel</Btn>
          <Btn variant="warning" icon="fa-tag" loading={saving} onClick={handleDiscount}>Apply</Btn>
        </div>}
      >
        <div className="form-grid">
          <Input label="Student Code" required value={discountForm.studentCode||''} onChange={e => setDiscount2(f=>({...f,studentCode:e.target.value}))} />
          <Select label="Discount Reason" required value={discountForm.reason} onChange={e => setDiscount2(f=>({...f,reason:e.target.value}))} placeholder="Select"
            options={['Merit Scholarship','Need Based','Staff Ward','Management Quota','Government Scholarship','Sibling Discount','Other'].map(r=>({value:r,label:r}))} />
          <Input label="Discount Amount (₹)" required type="number" value={discountForm.amount} onChange={e => setDiscount2(f=>({...f,amount:e.target.value}))} />
          <Input label="Authority" value={discountForm.authority} onChange={e => setDiscount2(f=>({...f,authority:e.target.value}))} placeholder="e.g. Principal" />
        </div>
      </Modal>

      {/* ── ASSIGN MODAL (quick shortcut from header button) ── */}
      <Modal open={showAssign} onClose={() => { setAssign(false); setAssign2(ASSIGN_INIT); }} title="Assign Fees" size="md"
        footer={<div style={{ display:'flex', gap:8, justifyContent:'flex-end' }}>
          <Btn variant="ghost" onClick={() => { setAssign(false); setAssign2(ASSIGN_INIT); }}>Cancel</Btn>
          <Btn variant="primary" icon="fa-floppy-disk" loading={saving} onClick={handleAssign}>
            {assignForm.assignTo === 'class' ? 'Assign to Class' : `Assign to ${assignForm.studentIds.length} Student(s)`}
          </Btn>
        </div>}
      >
        <div style={{ display:'flex', flexDirection:'column', gap:14 }}>
          <Select label="Fee Head" required value={assignForm.feeHeadId}
            onChange={e => setAssign2(f=>({...f,feeHeadId:e.target.value}))} placeholder="Select fee head"
            options={feeHeads.map(h => ({ value:h.id, label:`${h.fee_name} (${h.fee_type})` }))} />

          <div>
            <label style={{ fontSize:12.5, fontWeight:500, color:'var(--text-mid)', marginBottom:6, display:'block' }}>Assign To</label>
            <div style={{ display:'flex', gap:8 }}>
              {[{ v:'class', l:'Entire Class' }, { v:'student', l:'Individual Students' }].map(opt => (
                <label key={opt.v} style={{ display:'flex', alignItems:'center', gap:6, fontSize:13, cursor:'pointer',
                  padding:'8px 14px', borderRadius:8, border:'1.5px solid',
                  borderColor:assignForm.assignTo===opt.v?'var(--primary)':'var(--border)',
                  background:assignForm.assignTo===opt.v?'var(--primary-light)':'#fff',
                  color:assignForm.assignTo===opt.v?'var(--primary)':'var(--text-mid)' }}>
                  <input type="radio" name="assignTo2" value={opt.v} checked={assignForm.assignTo===opt.v}
                    onChange={e => setAssign2(f=>({...f,assignTo:e.target.value,studentIds:[]}))}
                    style={{ display:'none' }} />
                  <i className={`fa-solid ${opt.v==='class'?'fa-users':'fa-user'}`} style={{ fontSize:12 }} />
                  {opt.l}
                </label>
              ))}
            </div>
          </div>

          <Select label="Class" required value={assignForm.classId}
            onChange={e => setAssign2(f=>({...f,classId:e.target.value,studentIds:[]}))} placeholder="Select class"
            options={(classes||[]).map(c=>({ value:c.id, label:`${c.class_name}${c.section?' - '+c.section:''}` }))} />

          {assignForm.assignTo === 'student' && assignForm.classId && (
            <div>
              <label style={{ fontSize:12.5, fontWeight:500, color:'var(--text-mid)', marginBottom:6, display:'block' }}>
                Students {loadingStudents && <i className="fa-solid fa-spinner fa-spin" style={{ marginLeft:4 }}/>}
              </label>
              <div style={{ maxHeight:140, overflowY:'auto', border:'1px solid var(--border)', borderRadius:8, padding:8 }}>
                {classStudents.map(s => (
                  <label key={s.id} style={{ display:'flex', alignItems:'center', gap:8, padding:'3px 0', fontSize:12.5, cursor:'pointer' }}>
                    <input type="checkbox" checked={assignForm.studentIds.includes(s.id)}
                      onChange={e => setAssign2(f=>({ ...f, studentIds: e.target.checked ? [...f.studentIds,s.id] : f.studentIds.filter(x=>x!==s.id) }))}
                      style={{ accentColor:'var(--primary)' }} />
                    {s.first_name} {s.last_name}
                    <span style={{ fontSize:11, color:'var(--text-light)' }}>({s.student_code})</span>
                  </label>
                ))}
              </div>
            </div>
          )}

          <div className="form-grid" style={{ gap:12 }}>
            <Input label="Fee Amount (₹)" required type="number" value={assignForm.amount}
              onChange={e => setAssign2(f=>({...f,amount:e.target.value}))} />
            <Input label="Concession (₹)" type="number" value={assignForm.concession}
              onChange={e => setAssign2(f=>({...f,concession:e.target.value}))} placeholder="0" />
            <Input label="Due Date" type="date" value={assignForm.dueDate}
              onChange={e => setAssign2(f=>({...f,dueDate:e.target.value}))} />
          </div>
        </div>
      </Modal>
    </div>
  );
}
