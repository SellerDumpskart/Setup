import React, { useState, useEffect } from 'react';
import { PageHeader, Btn, DataTable, Badge, Card, Modal, Input, StatMini, SearchBar } from '../../components/common/Common';
import { orgService } from '../../services';
import { fmtDate } from '../../utils';
import toast from 'react-hot-toast';

const EMPTY = { name:'', regNumber:'', sinceDate:'', status:'active' };

export default function Organizations() {
  const [orgs, setOrgs]     = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [showForm, setShow] = useState(false);
  const [editItem, setEdit] = useState(null);
  const [form, setForm]     = useState(EMPTY);
  const [saving, setSaving] = useState(false);

  const load = async () => {
    setLoading(true);
    try { const { data } = await orgService.list(); setOrgs(data||[]); }
    catch { setOrgs([]); }
    finally { setLoading(false); }
  };

  useEffect(() => { load(); }, []);

  const openAdd  = () => { setEdit(null); setForm(EMPTY); setShow(true); };
  const openEdit = (row) => { setEdit(row); setForm({ name:row.name, regNumber:row.reg_number||'', sinceDate:row.since_date?.split('T')[0]||'', status:row.status }); setShow(true); };

  const handleSave = async () => {
    if (!form.name || !form.regNumber) { toast.error('Name and registration number required'); return; }
    setSaving(true);
    try {
      if (editItem) { await orgService.update(editItem.id, form); toast.success('Organization updated'); }
      else          { await orgService.create(form); toast.success('Organization added'); }
      load(); setShow(false);
    } catch (e) { toast.error(e.response?.data?.error||'Failed'); }
    finally { setSaving(false); }
  };

  const filtered = orgs.filter(o => !search || o.name?.toLowerCase().includes(search.toLowerCase()) || o.reg_number?.includes(search));

  const cols = [
    { key:'name', label:'Organization',
      render:(v,row) => (
        <div style={{ display:'flex', gap:10, alignItems:'center' }}>
          <div style={{ width:36, height:36, borderRadius:8, background:'var(--primary-light)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:14, fontWeight:700, color:'var(--primary)', flexShrink:0 }}>{v?.charAt(0)}</div>
          <div><p style={{ fontWeight:600, fontSize:13 }}>{v}</p><p style={{ fontSize:11, color:'var(--text-light)', fontFamily:'monospace' }}>{row.reg_number}</p></div>
        </div>
      )
    },
    { key:'since_date', label:'Since', width:110, render:v => fmtDate(v, { day:'2-digit', month:'short', year:'numeric' }) },
    { key:'status', label:'Status', width:90, render:v => <Badge label={v} color={v==='active'?'green':'red'} /> },
    { key:'id', label:'', width:80,
      render:(v,row) => <button className="icon-btn" onClick={e=>{e.stopPropagation();openEdit(row)}}><i className="fa-solid fa-pen"/></button>
    },
  ];

  return (
    <div>
      <PageHeader title="Organizations" subtitle={`${orgs.length} organizations`} icon="fa-building"
        actions={<Btn icon="fa-plus" variant="primary" onClick={openAdd}>Add Organization</Btn>}
      />
      <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:12, marginBottom:16 }}>
        <StatMini label="Total" value={orgs.length} icon="fa-building" color="#00A99D" />
        <StatMini label="Active" value={orgs.filter(o=>o.status==='active').length} icon="fa-circle-check" color="#38a169" />
        <StatMini label="Inactive" value={orgs.filter(o=>o.status==='inactive').length} icon="fa-circle-xmark" color="#e53e3e" />
      </div>
      <Card>
        <div style={{ padding:'12px 16px', borderBottom:'1px solid var(--border)' }}>
          <SearchBar value={search} onChange={setSearch} placeholder="Search organizations..." />
        </div>
        <DataTable columns={cols} data={filtered} loading={loading} onRowClick={openEdit} emptyText="No organizations" />
      </Card>
      <Modal open={showForm} onClose={()=>setShow(false)} title={editItem?'Edit Organization':'Add Organization'} size="md"
        footer={<div style={{ display:'flex', gap:8, justifyContent:'flex-end' }}><Btn variant="ghost" onClick={()=>setShow(false)}>Cancel</Btn><Btn variant="primary" icon="fa-floppy-disk" loading={saving} onClick={handleSave}>Save</Btn></div>}
      >
        <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
          <Input label="Organization Name" required value={form.name} onChange={e=>setForm(f=>({...f,name:e.target.value}))} />
          <div className="form-grid">
            <Input label="Registration Number" required value={form.regNumber} onChange={e=>setForm(f=>({...f,regNumber:e.target.value}))} />
            <Input label="Established Since" type="date" value={form.sinceDate} onChange={e=>setForm(f=>({...f,sinceDate:e.target.value}))} />
          </div>
        </div>
      </Modal>
    </div>
  );
}
