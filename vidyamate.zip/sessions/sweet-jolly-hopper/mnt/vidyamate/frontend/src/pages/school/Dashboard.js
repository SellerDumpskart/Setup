import React, { useState, useEffect } from 'react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer
} from 'recharts';
import { useDashboard } from '../../hooks';
import { useSessionContext } from '../../store/sessionStore';
import { fmtCurrency } from '../../utils';
import './Dashboard.css';

// ── Stat Card ──────────────────────────────────────────────
function StatCard({ icon, label, value, color, sub }) {
  return (
    <div className="stat-card" style={{ '--card-color': color }}>
      <div className="stat-icon"><i className={`fa-solid ${icon}`} /></div>
      <div className="stat-body">
        <p className="stat-value">{value ?? '—'}</p>
        <p className="stat-label">{label}</p>
        {sub && <p className="stat-sub">{sub}</p>}
      </div>
    </div>
  );
}

// ── Section wrapper ────────────────────────────────────────
function Section({ title, icon, children, action }) {
  return (
    <div className="dash-section">
      <div className="section-header">
        <div className="section-title">
          <i className={`fa-solid ${icon}`} />
          <span>{title}</span>
        </div>
        {action && <button className="section-action">{action}</button>}
      </div>
      {children}
    </div>
  );
}

// ── Custom tooltip for chart ───────────────────────────────
function FeeTooltip({ active, payload, label }) {
  if (!active || !payload?.length) return null;
  return (
    <div className="fee-tooltip">
      <p className="ft-title">{label}</p>
      {payload.map((p, i) => (
        <p key={i} style={{ color: p.color }}>
          {p.name}: ₹{Number(p.value).toLocaleString('en-IN')}
        </p>
      ))}
    </div>
  );
}

export default function Dashboard() {
  const { sessionId } = useSessionContext();
  const { data, loading } = useDashboard(sessionId);
  const [attType, setAttType] = useState('students');

  const d = data || MOCK;

  // Build chart data
  const chartData = d.feeSummary?.map(f => ({
    name: f.fee_name?.replace(' FEE', '').replace(' Fee', ''),
    Balance: parseFloat(f.balance) || 0,
    Paid: parseFloat(f.paid) || 0,
  })) || [];

  if (loading) return (
    <div className="dash-loading">
      <div className="spinner" /><p>Loading dashboard...</p>
    </div>
  );

  return (
    <div className="dashboard">
      {/* ── Stats row ── */}
      <div className="stats-row">
        <StatCard icon="fa-user-graduate" label="Total Students"
          value={d.stats?.totalStudents?.toLocaleString()} color="#00A99D" sub="Active enrollments" />
        <StatCard icon="fa-chalkboard-user" label="Total Teachers"
          value={d.stats?.totalTeachers} color="#2196F3" sub="Teaching staff" />
        <StatCard icon="fa-users" label="Total Staff"
          value={d.stats?.totalStaff} color="#9C27B0" sub="All employees" />
        <StatCard icon="fa-indian-rupee-sign" label="Fee Collected"
          value={`₹${(d.feeSummary?.reduce((s, f) => s + parseFloat(f.paid || 0), 0) / 100000).toFixed(1)}L`}
          color="#F7941D" sub="This session" />
      </div>

      {/* ── Main grid ── */}
      <div className="dash-grid">

        {/* Fee Summary Chart */}
        <div className="dash-card fee-chart-card">
          <div className="card-header">
            <div className="card-title">
              <i className="fa-solid fa-chart-bar" />
              <span>Fee Summary</span>
            </div>
            <div className="chart-legend">
              <span className="legend-dot" style={{ background: '#E8F5E9' }} />
              <span>Balance</span>
              <span className="legend-dot" style={{ background: '#F7941D' }} />
              <span>Paid</span>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={chartData} barSize={28} barGap={4}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" vertical={false} />
              <XAxis dataKey="name" tick={{ fontSize: 11, fill: '#718096' }} axisLine={false} tickLine={false} />
              <YAxis
                tickFormatter={v => v >= 1e5 ? `₹${(v/1e5).toFixed(0)}L` : `₹${(v/1e3).toFixed(0)}K`}
                tick={{ fontSize: 10, fill: '#718096' }} axisLine={false} tickLine={false}
              />
              <Tooltip content={<FeeTooltip />} cursor={{ fill: 'rgba(0,0,0,0.04)' }} />
              <Bar dataKey="Balance" fill="#e0f7fa" radius={[4,4,0,0]} />
              <Bar dataKey="Paid" fill="#F7941D" radius={[4,4,0,0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Attendance Widget */}
        <div className="dash-card attendance-card">
          <div className="card-header">
            <div className="card-title">
              <i className="fa-solid fa-calendar-check" />
              <span>Today's Attendance</span>
            </div>
            <div className="att-toggle">
              <button
                className={attType === 'students' ? 'active' : ''}
                onClick={() => setAttType('students')}
              >Students</button>
              <button
                className={attType === 'staff' ? 'active' : ''}
                onClick={() => setAttType('staff')}
              >Staff</button>
            </div>
          </div>

          <div className="att-ring-wrap">
            <AttRing
              present={parseInt(d.attendance?.present) || 0}
              total={parseInt(d.stats?.totalStudents) || 100}
            />
          </div>
          <div className="att-legend">
            <div className="att-leg-item">
              <span className="att-dot present" />
              <span>Present</span>
              <strong>{d.attendance?.present || 0}</strong>
            </div>
            <div className="att-leg-item">
              <span className="att-dot absent" />
              <span>Absent</span>
              <strong>{d.attendance?.absent || 0}</strong>
            </div>
            <div className="att-leg-item">
              <span className="att-dot holiday" />
              <span>Holiday</span>
              <strong>0</strong>
            </div>
          </div>
        </div>

        {/* Upcoming Holidays */}
        <div className="dash-card">
          <div className="card-header">
            <div className="card-title">
              <i className="fa-solid fa-umbrella-beach" />
              <span>Upcoming Holidays</span>
            </div>
          </div>
          {d.holidays?.length ? d.holidays.map((h, i) => (
            <div className="holiday-item" key={i}>
              <div className="holiday-date">
                <span className="hd-day">{new Date(h.from_date).getDate()}</span>
                <span className="hd-mon">{new Date(h.from_date).toLocaleString('default', { month: 'short' })}</span>
              </div>
              <div className="holiday-info">
                <p className="holiday-name">{h.holiday_name}</p>
                <p className="holiday-type">{h.holiday_type}</p>
              </div>
            </div>
          )) : (
            <div className="empty-state">
              <i className="fa-regular fa-calendar" />
              <p>No upcoming holidays</p>
            </div>
          )}
        </div>

        {/* Today's Birthdays */}
        <div className="dash-card">
          <div className="card-header">
            <div className="card-title">
              <i className="fa-solid fa-cake-candles" />
              <span>Today's Birthdays</span>
            </div>
          </div>
          {d.birthdays?.length ? d.birthdays.map((b, i) => (
            <div className="birthday-item" key={i}>
              <div className="bday-avatar">
                {b.photo_url
                  ? <img src={b.photo_url} alt={b.first_name} />
                  : <span>{b.first_name?.[0]}{b.last_name?.[0]}</span>
                }
              </div>
              <div>
                <p className="bday-name">{b.first_name} {b.last_name}</p>
                <p className="bday-role">{b.designation}</p>
              </div>
              <span className="bday-emoji">🎂</span>
            </div>
          )) : (
            <div className="empty-state">
              <i className="fa-regular fa-face-smile" />
              <p>No birthdays today</p>
            </div>
          )}
        </div>

        {/* Notices */}
        <div className="dash-card notices-card">
          <div className="card-header">
            <div className="card-title">
              <i className="fa-solid fa-bullhorn" />
              <span>Notices</span>
            </div>
            <button className="section-action">+ Add</button>
          </div>
          {d.notices?.length ? d.notices.map((n, i) => (
            <div className="notice-item" key={i}>
              <div className={`notice-tag ${n.notice_type}`}>
                {n.notice_type}
              </div>
              <div className="notice-body">
                <p className="notice-title">{n.title}</p>
                <p className="notice-time">
                  {new Date(n.published_at).toLocaleDateString('en-IN', { day:'2-digit', month:'short' })}
                </p>
              </div>
            </div>
          )) : (
            <div className="empty-state">
              <i className="fa-regular fa-file" />
              <p>No notices yet</p>
            </div>
          )}
        </div>

        {/* Quick Actions */}
        <div className="dash-card quick-actions-card">
          <div className="card-header">
            <div className="card-title">
              <i className="fa-solid fa-bolt" />
              <span>Quick Actions</span>
            </div>
          </div>
          <div className="quick-grid">
            {[
              { icon: 'fa-user-plus',       label: 'New Admission',   color: '#00A99D', path: '/school/students/new' },
              { icon: 'fa-calendar-check',  label: 'Mark Attendance', color: '#2196F3', path: '/school/attendance' },
              { icon: 'fa-money-bill',      label: 'Collect Fee',     color: '#F7941D', path: '/school/fees' },
              { icon: 'fa-file-circle-plus',label: 'Add Notice',      color: '#9C27B0', path: '/school/notices' },
              { icon: 'fa-file-pdf',        label: 'Hall Ticket',     color: '#e53e3e', path: '/school/hall-tickets' },
              { icon: 'fa-chart-line',      label: 'View Reports',    color: '#38a169', path: '/school/reports' },
            ].map((q, i) => (
              <a href={q.path} className="quick-item" key={i}>
                <div className="quick-icon" style={{ background: q.color + '18', color: q.color }}>
                  <i className={`fa-solid ${q.icon}`} />
                </div>
                <span>{q.label}</span>
              </a>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
}

// ── Attendance Ring SVG ────────────────────────────────────
function AttRing({ present, total }) {
  const pct = total > 0 ? (present / total) * 100 : 0;
  const r = 54;
  const circ = 2 * Math.PI * r;
  const stroke = circ - (pct / 100) * circ;
  const color = pct >= 75 ? '#4CAF50' : pct >= 50 ? '#F7941D' : '#e53e3e';

  return (
    <div className="att-ring">
      <svg viewBox="0 0 130 130" width="130" height="130">
        <circle cx="65" cy="65" r={r} fill="none" stroke="#f0f0f0" strokeWidth="10" />
        <circle
          cx="65" cy="65" r={r} fill="none"
          stroke={color} strokeWidth="10"
          strokeDasharray={circ}
          strokeDashoffset={stroke}
          strokeLinecap="round"
          transform="rotate(-90 65 65)"
          style={{ transition: 'stroke-dashoffset 0.8s ease' }}
        />
      </svg>
      <div className="att-ring-text">
        <span className="att-pct">{pct.toFixed(0)}%</span>
        <span className="att-sub">{present}/{total}</span>
      </div>
    </div>
  );
}

// ── Mock data for when API is not connected ────────────────
const MOCK = {
  stats: { totalStudents: 1128, totalTeachers: 41, totalStaff: 72 },
  feeSummary: [
    { fee_name: 'TUITION FEE', balance: 20353500, paid: 240100 },
    { fee_name: 'OLD FEE',     balance: 240100,   paid: 0 },
    { fee_name: 'Bus Fee',     balance: 4661000,  paid: 4592000 },
    { fee_name: 'Hostel Fee',  balance: 1002000,  paid: 897000 },
  ],
  attendance: { present: 984, absent: 144, total: 1128 },
  holidays: [
    { holiday_name: 'Janmashtami',      from_date: '2025-08-16', holiday_type: 'government' },
    { holiday_name: 'Vinayaka Chavithi',from_date: '2025-08-27', holiday_type: 'festival' },
    { holiday_name: 'Dussehra',         from_date: '2025-09-22', holiday_type: 'government' },
  ],
  birthdays: [],
  notices: [
    { title: 'Annual Day celebration on 15th Aug', notice_type: 'general', published_at: new Date() },
    { title: 'Fee payment last date: 30 June',     notice_type: 'fee',     published_at: new Date() },
  ],
};
