import React, { useState, useEffect } from 'react';
import { PageHeader, Btn, DataTable, Badge, Card, Modal, Input, Select } from '../../components/common/Common';
import { useSessionContext } from '../../store/sessionStore';
import api from '../../services/api';
import { fmtDate } from '../../utils';
import toast from 'react-hot-toast';

const TYPES    = ['government','school','festival','exam','other'];
const TYPE_CLR = { government:'blue', school:'green', festival:'orange', exam:'red', other:'gray' };
const EMPTY    = { holidayName:'', holidayType:'government', fromDate:'', toDate:'', applicableTo:'all', description:'' };

export default function HolidayMaster() {
  const { sessionId } = useSessionContext();
  const schoolId = JSON.parse(localStorage.getItem('vidyamate-auth')||'{}')?.state?.user?.schoolId;

  const [holidays, setHolidays] = useState([]);
  const [loading, setLoading]   = useState(true);
  const [showForm, setShow]     = useState(false);
  const [editItem, setEdit]     = useState(null);
  const [form, setForm]         = useState(EMPTY);
  const [saving, setSaving]     = useState(false);

  const load = async () => {
    if (!sessionId) return;
    setLoading(true);
    try {
      const { data } = await api.get('/holidays', { params: { schoolId, sessionId } });
      setHolidays(data || []);
    } catch { setHolidays([]); }
    finally { setLoading(false); }
  };

  useEffect(() => { load(); }, [sessionId]);

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const openAdd  = ()    => { setEdit(null); setForm(EMPTY); setShow(true); };
  const openEdit = (row) => {
    setEdit(row);
    setForm({
      holidayName: row.holiday_name,
      holidayType: row.holiday_type || 'government',
      fromDate:    row.from_date?.split('T')[0] || '',
      toDate:      row.to_date?.split('T')[0]   || '',
      applicableTo:row.applicable_to || 'all',
      description: row.description  || '',
    });
    setShow(true);
  };

  const handleSave = async () => {
    if (!form.holidayName || !form.fromDate) { toast.error('Name and start date required'); return; }
    setSaving(true);
    try {
      const payload = { schoolId, sessionId, ...form };
      if (editItem) {
        await api.put(`/holidays/${editItem.id}`, payload);
        toast.success('Holiday updated');
      } else {
        await api.post('/holidays', payload);
        toast.success('Holiday added');
      }
      load(); setShow(false);
    } catch (e) { toast.error(e.response?.data?.error || 'Failed to save'); }
    finally { setSaving(false); }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Remove this holiday?')) return;
    try {
      await api.delete(`/holidays/${id}`);
      toast.success('Holiday removed'); load();
    } catch (e) { toast.error(e.response?.data?.error || 'Failed'); }
  };

  const upcoming = holidays.filter(h => h.from_date && new Date(h.from_date) >= new Date()).length;

  const cols = [
    { key:'holiday_name', label:'Holiday',
      render:(v, row) => (
        <div style={{ display:'flex', alignItems:'center', gap:10 }}>
          <div style={{ width:40, height:40, borderRadius:10, background:'var(--primary-light)',
            display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', flexShrink:0 }}>
            <span style={{ fontSize:15, fontWeight:700, color:'var(--primary)', lineHeight:1 }}>
              {row.from_date ? new Date(row.from_date).getDate() : '—'}
            </span>
            <span style={{ fontSize:9, color:'var(--primary)', textTransform:'uppercase' }}>
              {row.from_date ? new Date(row.from_date).toLocaleString('default',{month:'short'}) : ''}
            </span>
          </div>
          <div>
            <p style={{ fontWeight:600 }}>{v}</p>
            {row.description && <p style={{ fontSize:11, color:'var(--text-light)' }}>{row.description}</p>}
          </div>
        </div>
      )
    },
    { key:'holiday_type',  label:'Type',       width:120, render:v => <Badge label={v} color={TYPE_CLR[v]||'gray'} /> },
    { key:'from_date',     label:'From',        render:v => fmtDate(v, { day:'2-digit', month:'short', year:'numeric' }) },
    { key:'to_date',       label:'To',          render:(v,row) => row.from_date===v ? '—' : fmtDate(v, { day:'2-digit', month:'short', year:'numeric' }) },
    { key:'applicable_to', label:'Applicable',  width:110, render:v => <Badge label={v} color="teal" /> },
    { key:'id', label:'', width:90,
      render:(v,row) => (
        <div style={{ display:'flex', gap:4 }}>
          <button className="icon-btn" onClick={e=>{e.stopPropagation();openEdit(row)}}><i className="fa-solid fa-pen"/></button>
          <button className="icon-btn danger" onClick={e=>{e.stopPropagation();handleDelete(v)}}><i className="fa-solid fa-trash"/></button>
        </div>
      )
    },
  ];

  return (
    <div>
      <PageHeader
        title="Holiday Master"
        subtitle={`${holidays.length} holidays · ${upcoming} upcoming`}
        icon="fa-umbrella-beach"
        actions={<Btn icon="fa-plus" variant="primary" onClick={openAdd}>Add Holiday</Btn>}
      />

      <Card>
        <DataTable columns={cols} data={holidays} loading={loading}
          onRowClick={openEdit} emptyText="No holidays configured for this session" />
      </Card>

      <Modal open={showForm} onClose={() => setShow(false)}
        title={editItem ? 'Edit Holiday' : 'Add Holiday'} size="md"
        footer={
          <div style={{ display:'flex', gap:8, justifyContent:'flex-end' }}>
            <Btn variant="ghost" onClick={() => setShow(false)}>Cancel</Btn>
            <Btn variant="primary" icon="fa-floppy-disk" loading={saving} onClick={handleSave}>Save</Btn>
          </div>
        }
      >
        <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
          <Input label="Holiday Name" required value={form.holidayName}
            onChange={e => set('holidayName', e.target.value)} placeholder="e.g. Independence Day" />
          <div className="form-grid">
            <Select label="Type" value={form.holidayType} onChange={e => set('holidayType', e.target.value)}
              options={TYPES.map(t => ({ value:t, label:t.charAt(0).toUpperCase()+t.slice(1) }))} />
            <Select label="Applicable To" value={form.applicableTo} onChange={e => set('applicableTo', e.target.value)}
              options={[{value:'all',label:'All'},{value:'students',label:'Students Only'},{value:'staff',label:'Staff Only'}]} />
            <Input label="From Date" required type="date" value={form.fromDate} onChange={e => set('fromDate', e.target.value)} />
            <Input label="To Date" type="date" value={form.toDate || form.fromDate} min={form.fromDate}
              onChange={e => set('toDate', e.target.value)} />
          </div>
          <Input label="Description (optional)" value={form.description}
            onChange={e => set('description', e.target.value)} placeholder="Additional notes..." />
        </div>
      </Modal>
    </div>
  );
}
