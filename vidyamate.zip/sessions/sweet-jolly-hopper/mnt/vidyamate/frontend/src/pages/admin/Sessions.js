import React, { useState, useEffect } from 'react';
import { PageHeader, Btn, DataTable, Badge, Card, Modal, Input, Select } from '../../components/common/Common';
import { sessionService, orgService } from '../../services';
import { fmtDate } from '../../utils';
import toast from 'react-hot-toast';

export default function Sessions() {
  const [sessions, setSessions] = useState([]);
  const [orgs, setOrgs]         = useState([]);
  const [loading, setLoading]   = useState(true);
  const [showForm, setShow]     = useState(false);
  const [form, setForm]         = useState({ organizationId:'', sessionName:'', startDate:'', endDate:'', isCurrent:false });
  const [saving, setSaving]     = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      const [se, og] = await Promise.all([sessionService.list(), orgService.list()]);
      setSessions(se.data||[]); setOrgs(og.data||[]);
    } catch { setSessions([]); }
    finally { setLoading(false); }
  };

  useEffect(() => { load(); }, []);

  const handleSave = async () => {
    if (!form.organizationId || !form.sessionName || !form.startDate) { toast.error('Fill required fields'); return; }
    setSaving(true);
    try { await sessionService.create(form); toast.success('Session created'); load(); setShow(false); setForm({ organizationId:'', sessionName:'', startDate:'', endDate:'', isCurrent:false }); }
    catch (e) { toast.error(e.response?.data?.error||'Failed'); }
    finally { setSaving(false); }
  };

  const setCurrent = async (id) => {
    await sessionService.setCurrent(id);
    toast.success('Set as current session'); load();
  };

  const cols = [
    { key:'session_name', label:'Session', render:v => <span style={{ fontFamily:'monospace', fontWeight:700, color:'var(--primary)', fontSize:13 }}>{v}</span> },
    { key:'organization_id', label:'Organization', render:(v,row) => <span>{orgs.find(o=>o.id===v)?.name||'—'}</span> },
    { key:'start_date', label:'Start', render:v => fmtDate(v, { day:'2-digit', month:'short', year:'numeric' }) },
    { key:'end_date',   label:'End',   render:v => fmtDate(v, { day:'2-digit', month:'short', year:'numeric' }) },
    { key:'is_current', label:'Current', width:90, render:v => <Badge label={v?'Yes':'No'} color={v?'green':'gray'} /> },
    { key:'id', label:'', width:110,
      render:(v,row) => !row.is_current && (
        <Btn size="sm" variant="secondary" onClick={e=>{e.stopPropagation();setCurrent(v)}}>Set Current</Btn>
      )
    },
  ];

  return (
    <div>
      <PageHeader title="Academic Sessions" subtitle="Manage academic years per organization" icon="fa-calendar"
        actions={<Btn icon="fa-plus" variant="primary" onClick={()=>setShow(true)}>Add Session</Btn>}
      />
      <Card>
        <DataTable columns={cols} data={sessions} loading={loading} emptyText="No sessions configured" />
      </Card>
      <Modal open={showForm} onClose={()=>setShow(false)} title="Create Academic Session" size="md"
        footer={<div style={{ display:'flex', gap:8, justifyContent:'flex-end' }}><Btn variant="ghost" onClick={()=>setShow(false)}>Cancel</Btn><Btn variant="primary" icon="fa-calendar-plus" loading={saving} onClick={handleSave}>Create</Btn></div>}
      >
        <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
          <Select label="Organization" required value={form.organizationId} onChange={e=>setForm(f=>({...f,organizationId:e.target.value}))} placeholder="Select" options={orgs.map(o=>({value:o.id,label:o.name}))} />
          <Input label="Session Name" required value={form.sessionName} onChange={e=>setForm(f=>({...f,sessionName:e.target.value}))} placeholder="e.g. AY2025-26" />
          <div className="form-grid">
            <Input label="Start Date" required type="date" value={form.startDate} onChange={e=>setForm(f=>({...f,startDate:e.target.value}))} />
            <Input label="End Date"   required type="date" value={form.endDate}   onChange={e=>setForm(f=>({...f,endDate:e.target.value}))} />
          </div>
          <label style={{ display:'flex', alignItems:'center', gap:8, fontSize:13, cursor:'pointer' }}>
            <input type="checkbox" checked={form.isCurrent} onChange={e=>setForm(f=>({...f,isCurrent:e.target.checked}))} style={{ accentColor:'var(--primary)', width:15, height:15 }}/>
            <span style={{ color:'var(--text-mid)' }}>Mark as current active session</span>
          </label>
        </div>
      </Modal>
    </div>
  );
}
