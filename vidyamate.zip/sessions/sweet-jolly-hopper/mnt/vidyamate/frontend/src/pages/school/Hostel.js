import React, { useState, useEffect, useRef } from 'react';
import { PageHeader, Btn, Card, Badge, StatMini, Modal, Select } from '../../components/common/Common';
import { useSessionContext } from '../../store/sessionStore';
import { hostelService } from '../../services';
import api from '../../services/api';
import toast from 'react-hot-toast';

const STATUS_COLOR = { full:'red', available:'green', maintenance:'orange' };
const TYPE_COLOR   = { single:'teal', double:'blue', triple:'purple' };

export default function Hostel() {
  const { sessionId } = useSessionContext();
  const [hostels, setHostels]   = useState([]);
  const [rooms, setRooms]       = useState([]);
  const [loading, setLoading]   = useState(true);
  const [selHostel, setSelHostel] = useState(null);
  const [showAlloc, setAlloc]   = useState(false);
  const [selRoom, setSelRoom]   = useState(null);
  const [mealPlan, setMealPlan] = useState('full');
  const [saving, setSaving]     = useState(false);

  // Student live search
  const [stuQuery, setStuQuery]       = useState('');
  const [stuResults, setStuResults]   = useState([]);
  const [selStudent, setSelStudent]   = useState(null); // { id, name, code }
  const searchTimer                   = useRef(null);

  const searchStudents = (q) => {
    clearTimeout(searchTimer.current);
    setStuQuery(q);
    setSelStudent(null);
    if (!q.trim()) { setStuResults([]); return; }
    searchTimer.current = setTimeout(async () => {
      try {
        const { data } = await api.get('/students', { params: { search: q, limit: 10 } });
        setStuResults(data?.students || data || []);
      } catch { setStuResults([]); }
    }, 300);
  };

  const pickStudent = (s) => {
    setSelStudent({ id: s.id, name: `${s.first_name} ${s.last_name||''}`.trim(), code: s.student_code });
    setStuQuery(`${s.first_name} ${s.last_name||''}`.trim());
    setStuResults([]);
  };

  const resetAlloc = () => {
    setStuQuery(''); setSelStudent(null); setStuResults([]); setMealPlan('full');
  };

  const load = async () => {
    setLoading(true);
    try {
      const { data } = await hostelService.list();
      setHostels(data || []);
      if (data?.length) {
        const roomData = await hostelService.rooms(data[0].id);
        setRooms(roomData.data || []);
        setSelHostel(data[0]);
      }
    } catch { setHostels([]); setRooms([]); }
    finally { setLoading(false); }
  };

  const selectHostel = async (hostel) => {
    setSelHostel(hostel);
    try { const { data } = await hostelService.rooms(hostel.id); setRooms(data || []); }
    catch { setRooms([]); }
  };

  useEffect(() => { load(); }, []);

  const handleAllocate = async () => {
    if (!selStudent) { toast.error('Search and select a student'); return; }
    setSaving(true);
    try {
      await hostelService.allocate({ studentId: selStudent.id, roomId: selRoom?.id, sessionId, mealPlan });
      toast.success(`Room ${selRoom?.room_number} allocated to ${selStudent.name}`);
      setAlloc(false); resetAlloc(); load();
    } catch (e) { toast.error(e.response?.data?.error || 'Allocation failed'); }
    finally { setSaving(false); }
  };

  const totalBeds  = rooms.reduce((s,r) => s + (r.capacity||0), 0);
  const occupied   = rooms.reduce((s,r) => s + parseInt(r.current_occupants||0), 0);
  const available  = totalBeds - occupied;

  return (
    <div>
      <PageHeader title="Hostel Management" subtitle="Room allocation and student housing" icon="fa-bed" />

      <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:12, marginBottom:16 }}>
        <StatMini label="Total Beds"  value={totalBeds}  icon="fa-bed"         color="#00A99D" />
        <StatMini label="Occupied"    value={occupied}   icon="fa-user-check"  color="#e53e3e" />
        <StatMini label="Available"   value={available}  icon="fa-door-open"   color="#38a169" />
        <StatMini label="Occupancy %" value={totalBeds > 0 ? `${Math.round(occupied/totalBeds*100)}%` : '0%'} icon="fa-percent" color="#F7941D" />
      </div>

      {loading ? (
        <Card><div style={{ padding:48, textAlign:'center', color:'var(--text-light)' }}><i className="fa-solid fa-spinner fa-spin" style={{ fontSize:24 }}/></div></Card>
      ) : hostels.length === 0 ? (
        <Card><div style={{ padding:48, textAlign:'center', color:'var(--text-light)' }}>
          <i className="fa-solid fa-bed" style={{ fontSize:40, opacity:.3, marginBottom:12 }}/>
          <p>No hostels configured yet</p>
        </div></Card>
      ) : (
        <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(200px,1fr))', gap:12 }}>
          {rooms.map(room => {
            const fillPct = room.capacity > 0 ? Math.round((room.current_occupants/room.capacity)*100) : 0;
            const status  = fillPct >= 100 ? 'full' : room.status === 'maintenance' ? 'maintenance' : 'available';
            const color   = { full:'#e53e3e', available:'#38a169', maintenance:'#F7941D' }[status];
            return (
              <div key={room.id} style={{ background:'#fff', borderRadius:12, padding:14,
                border:`1.5px solid ${color}30`, boxShadow:'var(--card-shadow)',
                cursor: status !== 'maintenance' && fillPct < 100 ? 'pointer' : 'default', transition:'all .18s' }}
                onClick={() => { if(status !== 'maintenance' && fillPct < 100){ setSelRoom(room); setAlloc(true); } }}
                onMouseEnter={e=>e.currentTarget.style.borderColor=color}
                onMouseLeave={e=>e.currentTarget.style.borderColor=`${color}30`}
              >
                <div style={{ display:'flex', justifyContent:'space-between', marginBottom:10 }}>
                  <div>
                    <p style={{ fontWeight:700, fontSize:18 }}>Room {room.room_number}</p>
                    <p style={{ fontSize:11, color:'var(--text-light)' }}>Floor {room.floor_no}</p>
                  </div>
                  <Badge label={status} color={STATUS_COLOR[status]||'gray'} />
                </div>
                <div style={{ height:6, background:'#f0f0f0', borderRadius:3, marginBottom:8, overflow:'hidden' }}>
                  <div style={{ width:`${fillPct}%`, height:'100%', background:color, borderRadius:3 }}/>
                </div>
                <div style={{ display:'flex', justifyContent:'space-between' }}>
                  <Badge label={room.room_type||'standard'} color={TYPE_COLOR[room.room_type]||'gray'} />
                  <span style={{ fontSize:12, color:'var(--text-mid)' }}>{room.current_occupants||0}/{room.capacity}</span>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <Modal open={showAlloc} onClose={() => { setAlloc(false); resetAlloc(); }}
        title={`Allocate Room ${selRoom?.room_number}`} size="sm"
        footer={
          <div style={{ display:'flex', gap:8, justifyContent:'flex-end' }}>
            <Btn variant="ghost" onClick={() => { setAlloc(false); resetAlloc(); }}>Cancel</Btn>
            <Btn variant="primary" icon="fa-bed" loading={saving} onClick={handleAllocate}>Allocate</Btn>
          </div>
        }
      >
        <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
          <div style={{ background:'var(--primary-light)', borderRadius:8, padding:'10px 12px' }}>
            <p style={{ fontSize:13, fontWeight:600, color:'var(--primary-dark)' }}>
              Room {selRoom?.room_number} · Floor {selRoom?.floor_no}
            </p>
            <p style={{ fontSize:12, color:'var(--text-mid)' }}>
              {selRoom?.capacity - (selRoom?.current_occupants||0)} bed(s) available
            </p>
          </div>

          {/* Live student search */}
          <div style={{ position:'relative' }}>
            <label style={{ fontSize:12.5, fontWeight:600, color:'var(--text-mid)', marginBottom:5, display:'block' }}>
              Student <span style={{ color:'#e53e3e' }}>*</span>
            </label>
            <div style={{ position:'relative' }}>
              <input
                value={stuQuery}
                onChange={e => searchStudents(e.target.value)}
                placeholder="Type name or admission no…"
                style={{ width:'100%', padding:'9px 12px', borderRadius:8, fontSize:13, boxSizing:'border-box',
                  border:`1.5px solid ${selStudent ? '#38a169' : 'var(--border)'}`, fontFamily:'inherit' }}
              />
              {selStudent && (
                <i className="fa-solid fa-circle-check"
                  style={{ position:'absolute', right:10, top:'50%', transform:'translateY(-50%)', color:'#38a169' }} />
              )}
            </div>
            {stuResults.length > 0 && (
              <div style={{ position:'absolute', top:'100%', left:0, right:0, zIndex:99, background:'#fff',
                border:'1.5px solid var(--border)', borderRadius:8, boxShadow:'0 4px 16px rgba(0,0,0,.1)', marginTop:2 }}>
                {stuResults.map(s => (
                  <div key={s.id} onClick={() => pickStudent(s)}
                    style={{ padding:'9px 12px', cursor:'pointer', fontSize:13, borderBottom:'1px solid #f7f7f7' }}
                    onMouseEnter={e => e.currentTarget.style.background='#f8fafb'}
                    onMouseLeave={e => e.currentTarget.style.background='#fff'}>
                    <span style={{ fontWeight:600 }}>{s.first_name} {s.last_name||''}</span>
                    <span style={{ color:'var(--text-light)', marginLeft:8, fontSize:11.5 }}>{s.student_code}</span>
                    {s.class_name && <span style={{ color:'var(--text-light)', marginLeft:6, fontSize:11.5 }}>· Class {s.class_name}</span>}
                  </div>
                ))}
              </div>
            )}
          </div>

          <Select label="Meal Plan" value={mealPlan} onChange={e => setMealPlan(e.target.value)}
            options={[{value:'none',label:'No Meals'},{value:'breakfast',label:'Breakfast Only'},{value:'full',label:'Full Board'}]} />
        </div>
      </Modal>
    </div>
  );
}
