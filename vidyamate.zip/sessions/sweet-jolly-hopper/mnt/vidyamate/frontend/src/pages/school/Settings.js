import React, { useState, useCallback } from 'react';
import { PageHeader, Btn, Card, Input, Select, Textarea, Tabs } from '../../components/common/Common';
import api from '../../services/api';
import toast from 'react-hot-toast';

const TABS = [
  { key:'profile',  label:'School Profile',   icon:'fa-school' },
  { key:'fees',     label:'Fee Configuration', icon:'fa-credit-card' },
  { key:'notif',    label:'Notifications',     icon:'fa-bell' },
  { key:'academic', label:'Academic',          icon:'fa-graduation-cap' },
  { key:'salary',   label:'Salary Heads',      icon:'fa-money-bill-wave' },
  { key:'security', label:'Security',          icon:'fa-lock' },
];

export default function Settings() {
  const [tab, setTab] = useState('profile');
  const [saving, setSaving] = useState(false);
  const [pwdForm, setPwdForm] = useState({ current:'', newPwd:'', confirm:'' });
  const [pwdSaving, setPwdSaving] = useState(false);

  // Salary Heads state
  const [salaryHeads, setSalaryHeads]   = useState([]);
  const [salaryLoading, setSalaryLoading] = useState(false);
  const [newHead, setNewHead]           = useState({ headName:'', headType:'earning', isFixed:true });
  const [headSaving, setHeadSaving]     = useState(false);
  const [staffList, setStaffList]       = useState([]);
  const [selStaff, setSelStaff]         = useState('');
  const [staffSalary, setStaffSalary]   = useState([]);
  const [salaryEdit, setSalaryEdit]     = useState({}); // headId → amount

  const loadSalaryHeads = useCallback(async () => {
    if (salaryHeads.length) return; // already loaded
    setSalaryLoading(true);
    try {
      const [hRes, sRes] = await Promise.all([
        api.get('/payroll/salary-heads'),
        api.get('/staff', { params: { limit: 200 } }),
      ]);
      setSalaryHeads(hRes.data || []);
      setStaffList(sRes.data?.staff || sRes.data || []);
    } catch { /* ignore */ }
    finally { setSalaryLoading(false); }
  }, [salaryHeads.length]);

  const addHead = async () => {
    if (!newHead.headName.trim()) { toast.error('Enter head name'); return; }
    setHeadSaving(true);
    try {
      const { data } = await api.post('/payroll/salary-heads', newHead);
      setSalaryHeads(h => [...h.filter(x => x.id !== data.id), data].sort((a,b) => a.head_name.localeCompare(b.head_name)));
      setNewHead({ headName:'', headType:'earning', isFixed:true });
      toast.success('Salary head saved');
    } catch (e) { toast.error(e.response?.data?.error || 'Failed'); }
    finally { setHeadSaving(false); }
  };

  const deleteHead = async (id) => {
    try {
      await api.delete(`/payroll/salary-heads/${id}`);
      setSalaryHeads(h => h.filter(x => x.id !== id));
      toast.success('Deleted');
    } catch { toast.error('Failed to delete'); }
  };

  const loadStaffSalary = async (staffId) => {
    setSelStaff(staffId);
    if (!staffId) { setStaffSalary([]); setSalaryEdit({}); return; }
    try {
      const { data } = await api.get(`/payroll/staff/${staffId}/salary`);
      setStaffSalary(data || []);
      const map = {};
      (data || []).forEach(r => { map[r.head_id] = String(r.amount); });
      setSalaryEdit(map);
    } catch { setStaffSalary([]); setSalaryEdit({}); }
  };

  const saveStaffSalary = async () => {
    if (!selStaff) return;
    try {
      await Promise.all(
        Object.entries(salaryEdit)
          .filter(([, v]) => v !== '' && !isNaN(parseFloat(v)))
          .map(([headId, amount]) =>
            api.post(`/payroll/staff/${selStaff}/salary`, { headId, amount: parseFloat(amount) })
          )
      );
      toast.success('Staff salary components saved');
      loadStaffSalary(selStaff);
    } catch { toast.error('Failed to save'); }
  };

  const [profile, setProfile] = useState({
    name:'SRI VIVEKANANDA E/M HIGH SCHOOL KLD', email:'sv@school.com',
    phone:'9876543210', address:'Main Road, Kurnool', city:'Kurnool',
    state:'Andhra Pradesh', pincode:'518001', affiliation:'123456',
    principal:'A. Vasantha', medium:'English Medium', schoolType:'High School',
    website:'', estd:'2001',
  });

  const [feeConfig, setFeeConfig] = useState({
    lateFeeEnabled: true, lateFeeAmount: 50, lateFeeAfterDays: 10,
    receiptPrefix: 'RCP', dueDateDay: 10,
    smsOnPayment: true, emailOnPayment: true,
  });

  const [notifConfig, setNotifConfig] = useState({
    smsProvider:'msg91', smsEnabled: false, msg91Key:'',
    emailEnabled: false, smtpHost:'smtp.gmail.com', smtpPort:'587',
    smtpUser:'', smtpPass:'',
    attendanceAlert: true, feeReminder: true, examReminder: true,
  });

  const [academicConfig, setAcademicConfig] = useState({
    attendanceRequired: 75, passingMarks: 35, gradingSystem: 'letter',
    workingDays: 26, examPattern:'quarterly',
  });

  const save = async () => {
    setSaving(true);
    await new Promise(r => setTimeout(r, 700));
    setSaving(false);
    toast.success('Settings saved successfully');
  };

  const changePassword = async () => {
    if (!pwdForm.current)  { toast.error('Enter current password'); return; }
    if (!pwdForm.newPwd)   { toast.error('Enter new password'); return; }
    if (pwdForm.newPwd.length < 8) { toast.error('New password must be at least 8 characters'); return; }
    if (pwdForm.newPwd !== pwdForm.confirm) { toast.error('Passwords do not match'); return; }
    setPwdSaving(true);
    try {
      await api.post('/auth/change-password', { currentPassword: pwdForm.current, newPassword: pwdForm.newPwd });
      toast.success('Password changed successfully');
      setPwdForm({ current:'', newPwd:'', confirm:'' });
    } catch (e) {
      toast.error(e.response?.data?.error || 'Failed to change password');
    } finally { setPwdSaving(false); }
  };

  const ToggleSwitch = ({ value, onChange, label }) => (
    <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', padding:'10px 0', borderBottom:'1px solid #f7f7f7' }}>
      <span style={{ fontSize:13.5, color:'var(--text-dark)' }}>{label}</span>
      <button onClick={() => onChange(!value)}
        style={{ width:44, height:24, borderRadius:12, border:'none', cursor:'pointer',
          background: value ? 'var(--primary)' : '#cbd5e0', position:'relative', transition:'.2s' }}>
        <span style={{ position:'absolute', top:2, left: value ? 22 : 2,
          width:20, height:20, borderRadius:'50%', background:'#fff',
          transition:'.2s', boxShadow:'0 1px 3px rgba(0,0,0,.2)' }} />
      </button>
    </div>
  );

  return (
    <div>
      <PageHeader title="Settings" subtitle="Configure school profile and system preferences" icon="fa-gear"
        actions={<Btn icon="fa-floppy-disk" variant="primary" loading={saving} onClick={save}>Save Changes</Btn>}
      />

      <div style={{ marginBottom:16 }}>
        <Tabs tabs={TABS} active={tab} onChange={setTab} />
      </div>

      {/* PROFILE */}
      {tab === 'profile' && (
        <div style={{ display:'flex', flexDirection:'column', gap:14 }}>
          <Card title="Basic Information" icon="fa-school">
            <div style={{ padding:'0 18px 18px' }}>
              <div className="form-grid" style={{ marginBottom:12 }}>
                <div className="col-span-2">
                  <Input label="School Name" value={profile.name} onChange={e => setProfile(p=>({...p,name:e.target.value}))} />
                </div>
                <Input label="Principal Name" value={profile.principal} onChange={e => setProfile(p=>({...p,principal:e.target.value}))} />
                <Input label="Affiliation No." value={profile.affiliation} onChange={e => setProfile(p=>({...p,affiliation:e.target.value}))} />
                <Input label="Phone" type="tel" value={profile.phone} onChange={e => setProfile(p=>({...p,phone:e.target.value}))} />
                <Input label="Email" type="email" value={profile.email} onChange={e => setProfile(p=>({...p,email:e.target.value}))} />
                <Input label="Website" value={profile.website} onChange={e => setProfile(p=>({...p,website:e.target.value}))} />
                <Input label="Established Year" value={profile.estd} onChange={e => setProfile(p=>({...p,estd:e.target.value}))} />
              </div>
              <Textarea label="Address" value={profile.address} onChange={e => setProfile(p=>({...p,address:e.target.value}))} rows={2} />
              <div className="form-grid-3" style={{ marginTop:12 }}>
                <Input label="City" value={profile.city}    onChange={e => setProfile(p=>({...p,city:e.target.value}))} />
                <Input label="State" value={profile.state}  onChange={e => setProfile(p=>({...p,state:e.target.value}))} />
                <Input label="Pincode" value={profile.pincode} onChange={e => setProfile(p=>({...p,pincode:e.target.value}))} />
              </div>
            </div>
          </Card>

          <Card title="School Logo" icon="fa-image">
            <div style={{ padding:'16px 18px', display:'flex', alignItems:'center', gap:20 }}>
              <div style={{ width:80, height:80, borderRadius:16, background:'var(--primary-light)',
                display:'flex', alignItems:'center', justifyContent:'center', fontSize:32, color:'var(--primary)' }}>
                🎓
              </div>
              <div>
                <p style={{ fontSize:13.5, fontWeight:500, marginBottom:6 }}>School Logo</p>
                <p style={{ fontSize:12, color:'var(--text-light)', marginBottom:10 }}>PNG or JPG, recommended 200×200px</p>
                <label className="btn btn-secondary btn-sm" style={{ cursor:'pointer' }}>
                  <i className="fa-solid fa-upload" style={{ marginRight:6 }} />Upload Logo
                  <input type="file" accept="image/*" style={{ display:'none' }} onChange={() => toast.success('Logo updated')} />
                </label>
              </div>
            </div>
          </Card>
        </div>
      )}

      {/* FEES */}
      {tab === 'fees' && (
        <Card title="Fee Configuration" icon="fa-credit-card">
          <div style={{ padding:'0 18px 18px' }}>
            <div className="form-grid" style={{ marginBottom:16 }}>
              <Input label="Receipt Number Prefix" value={feeConfig.receiptPrefix}
                onChange={e => setFeeConfig(f=>({...f,receiptPrefix:e.target.value}))} placeholder="e.g. RCP" />
              <Input label="Fee Due Day (of month)" type="number" value={feeConfig.dueDateDay}
                onChange={e => setFeeConfig(f=>({...f,dueDateDay:e.target.value}))} />
              <Input label="Late Fee Amount (₹)" type="number" value={feeConfig.lateFeeAmount}
                onChange={e => setFeeConfig(f=>({...f,lateFeeAmount:e.target.value}))} />
              <Input label="Apply Late Fee After (days)" type="number" value={feeConfig.lateFeeAfterDays}
                onChange={e => setFeeConfig(f=>({...f,lateFeeAfterDays:e.target.value}))} />
            </div>
            <ToggleSwitch label="Enable late fee charges" value={feeConfig.lateFeeEnabled}
              onChange={v => setFeeConfig(f=>({...f,lateFeeEnabled:v}))} />
            <ToggleSwitch label="Send SMS on payment collection" value={feeConfig.smsOnPayment}
              onChange={v => setFeeConfig(f=>({...f,smsOnPayment:v}))} />
            <ToggleSwitch label="Send Email receipt on payment" value={feeConfig.emailOnPayment}
              onChange={v => setFeeConfig(f=>({...f,emailOnPayment:v}))} />
          </div>
        </Card>
      )}

      {/* NOTIFICATIONS */}
      {tab === 'notif' && (
        <div style={{ display:'flex', flexDirection:'column', gap:14 }}>
          <Card title="SMS Configuration" icon="fa-message">
            <div style={{ padding:'0 18px 18px' }}>
              <ToggleSwitch label="Enable SMS notifications" value={notifConfig.smsEnabled}
                onChange={v => setNotifConfig(n=>({...n,smsEnabled:v}))} />
              {notifConfig.smsEnabled && (
                <div className="form-grid" style={{ marginTop:12 }}>
                  <Select label="SMS Provider" value={notifConfig.smsProvider}
                    onChange={e => setNotifConfig(n=>({...n,smsProvider:e.target.value}))}
                    options={[{value:'msg91',label:'MSG91'},{value:'twilio',label:'Twilio'}]} />
                  <Input label="API Auth Key" value={notifConfig.msg91Key}
                    onChange={e => setNotifConfig(n=>({...n,msg91Key:e.target.value}))}
                    placeholder="MSG91 Auth Key" type="password" />
                </div>
              )}
              <div style={{ marginTop:12 }}>
                <ToggleSwitch label="Attendance absent alert to parents" value={notifConfig.attendanceAlert}
                  onChange={v => setNotifConfig(n=>({...n,attendanceAlert:v}))} />
                <ToggleSwitch label="Fee due reminders" value={notifConfig.feeReminder}
                  onChange={v => setNotifConfig(n=>({...n,feeReminder:v}))} />
                <ToggleSwitch label="Exam schedule reminders" value={notifConfig.examReminder}
                  onChange={v => setNotifConfig(n=>({...n,examReminder:v}))} />
              </div>
            </div>
          </Card>

          <Card title="Email Configuration" icon="fa-envelope">
            <div style={{ padding:'0 18px 18px' }}>
              <ToggleSwitch label="Enable Email notifications" value={notifConfig.emailEnabled}
                onChange={v => setNotifConfig(n=>({...n,emailEnabled:v}))} />
              {notifConfig.emailEnabled && (
                <div className="form-grid" style={{ marginTop:12 }}>
                  <Input label="SMTP Host" value={notifConfig.smtpHost}
                    onChange={e => setNotifConfig(n=>({...n,smtpHost:e.target.value}))} />
                  <Input label="SMTP Port" type="number" value={notifConfig.smtpPort}
                    onChange={e => setNotifConfig(n=>({...n,smtpPort:e.target.value}))} />
                  <Input label="SMTP Username" value={notifConfig.smtpUser}
                    onChange={e => setNotifConfig(n=>({...n,smtpUser:e.target.value}))} placeholder="your@email.com" />
                  <Input label="SMTP Password" type="password" value={notifConfig.smtpPass}
                    onChange={e => setNotifConfig(n=>({...n,smtpPass:e.target.value}))} />
                </div>
              )}
            </div>
          </Card>
        </div>
      )}

      {/* SALARY HEADS */}
      {tab === 'salary' && (() => {
        if (!salaryLoading && salaryHeads.length === 0 && staffList.length === 0) loadSalaryHeads();
        const earnings   = salaryHeads.filter(h => h.head_type === 'earning');
        const deductions = salaryHeads.filter(h => h.head_type === 'deduction');
        return (
          <div style={{ display:'flex', flexDirection:'column', gap:14 }}>

            {/* Card 1: Manage Heads */}
            <Card title="Salary Heads" icon="fa-list">
              <div style={{ padding:'0 18px 18px' }}>
                <p style={{ fontSize:13, color:'var(--text-light)', marginBottom:14 }}>
                  Define earnings (Basic, HRA, DA, Allowances) and deductions (PF, PT, TDS) applied to all staff.
                </p>

                {salaryLoading ? (
                  <div style={{ textAlign:'center', padding:24 }}><i className="fa-solid fa-spinner fa-spin"/></div>
                ) : (
                  <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:16, marginBottom:20 }}>
                    {[{ label:'Earnings', items:earnings, color:'#38a169' }, { label:'Deductions', items:deductions, color:'#e53e3e' }].map(({ label, items, color }) => (
                      <div key={label}>
                        <p style={{ fontSize:12.5, fontWeight:600, color, marginBottom:8 }}>
                          <i className={`fa-solid ${color === '#38a169' ? 'fa-plus-circle' : 'fa-minus-circle'}`} style={{ marginRight:5 }} />{label}
                        </p>
                        {items.length === 0 ? (
                          <p style={{ fontSize:12, color:'var(--text-light)', fontStyle:'italic' }}>None added yet</p>
                        ) : items.map(h => (
                          <div key={h.id} style={{ display:'flex', alignItems:'center', gap:8, padding:'6px 0', borderBottom:'1px solid #f7f7f7' }}>
                            <span style={{ flex:1, fontSize:13 }}>{h.head_name}</span>
                            <span style={{ fontSize:11, color:'var(--text-light)' }}>{h.is_fixed ? 'Fixed' : 'Variable'}</span>
                            <button onClick={() => deleteHead(h.id)} title="Delete"
                              style={{ border:'none', background:'none', color:'#e53e3e', cursor:'pointer', fontSize:13, padding:'2px 4px' }}>
                              <i className="fa-solid fa-trash-can"/>
                            </button>
                          </div>
                        ))}
                      </div>
                    ))}
                  </div>
                )}

                {/* Add new head */}
                <div style={{ background:'#f8fafb', borderRadius:10, padding:'14px 16px', border:'1px solid var(--border)' }}>
                  <p style={{ fontSize:13, fontWeight:600, marginBottom:10 }}>Add Salary Head</p>
                  <div style={{ display:'flex', gap:10, flexWrap:'wrap', alignItems:'flex-end' }}>
                    <div style={{ flex:2, minWidth:140 }}>
                      <label style={{ fontSize:12, fontWeight:500, color:'var(--text-mid)', marginBottom:4, display:'block' }}>Head Name</label>
                      <input value={newHead.headName} onChange={e => setNewHead(h=>({...h, headName:e.target.value}))}
                        placeholder="e.g. Basic Pay, HRA, PF"
                        style={{ width:'100%', padding:'8px 11px', borderRadius:8, border:'1.5px solid var(--border)', fontSize:13, fontFamily:'inherit', boxSizing:'border-box' }} />
                    </div>
                    <div style={{ flex:1, minWidth:110 }}>
                      <label style={{ fontSize:12, fontWeight:500, color:'var(--text-mid)', marginBottom:4, display:'block' }}>Type</label>
                      <select value={newHead.headType} onChange={e => setNewHead(h=>({...h, headType:e.target.value}))}
                        style={{ width:'100%', padding:'8px 11px', borderRadius:8, border:'1.5px solid var(--border)', fontSize:13, fontFamily:'inherit' }}>
                        <option value="earning">Earning</option>
                        <option value="deduction">Deduction</option>
                      </select>
                    </div>
                    <div style={{ flex:1, minWidth:90 }}>
                      <label style={{ fontSize:12, fontWeight:500, color:'var(--text-mid)', marginBottom:4, display:'block' }}>Amount Type</label>
                      <select value={newHead.isFixed ? 'fixed' : 'pct'} onChange={e => setNewHead(h=>({...h, isFixed:e.target.value==='fixed'}))}
                        style={{ width:'100%', padding:'8px 11px', borderRadius:8, border:'1.5px solid var(--border)', fontSize:13, fontFamily:'inherit' }}>
                        <option value="fixed">Fixed ₹</option>
                        <option value="pct">% of Basic</option>
                      </select>
                    </div>
                    <Btn variant="primary" icon="fa-plus" loading={headSaving} onClick={addHead}>Add</Btn>
                  </div>
                </div>
              </div>
            </Card>

            {/* Card 2: Per-staff salary */}
            <Card title="Staff Salary Components" icon="fa-user-tie">
              <div style={{ padding:'0 18px 18px' }}>
                <p style={{ fontSize:13, color:'var(--text-light)', marginBottom:14 }}>
                  Select a staff member to view and edit their salary breakdown.
                </p>
                <div style={{ display:'flex', gap:10, marginBottom:16, alignItems:'flex-end' }}>
                  <div style={{ flex:1, maxWidth:320 }}>
                    <label style={{ fontSize:12.5, fontWeight:500, color:'var(--text-mid)', marginBottom:4, display:'block' }}>Staff Member</label>
                    <select value={selStaff} onChange={e => loadStaffSalary(e.target.value)}
                      style={{ width:'100%', padding:'9px 12px', borderRadius:8, border:'1.5px solid var(--border)', fontSize:13, fontFamily:'inherit' }}>
                      <option value="">Select staff member</option>
                      {staffList.map(s => (
                        <option key={s.id} value={s.id}>{s.first_name} {s.last_name||''} {s.emp_no ? `(${s.emp_no})` : ''}</option>
                      ))}
                    </select>
                  </div>
                </div>

                {selStaff && salaryHeads.length > 0 && (
                  <>
                    <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10, marginBottom:14 }}>
                      {salaryHeads.map(h => (
                        <div key={h.id} style={{ display:'flex', alignItems:'center', gap:10, padding:'8px 10px',
                          borderRadius:8, background: h.head_type==='earning' ? '#f0fff4' : '#fff5f5',
                          border:`1px solid ${h.head_type==='earning' ? '#c6f6d5' : '#fed7d7'}` }}>
                          <div style={{ flex:1 }}>
                            <p style={{ fontSize:12.5, fontWeight:600 }}>{h.head_name}</p>
                            <p style={{ fontSize:10.5, color:'var(--text-light)', textTransform:'capitalize' }}>
                              {h.head_type} · {h.is_fixed ? 'Fixed' : '% of basic'}
                            </p>
                          </div>
                          <input
                            type="number" min="0" placeholder="0"
                            value={salaryEdit[h.id] || ''}
                            onChange={e => setSalaryEdit(m => ({ ...m, [h.id]: e.target.value }))}
                            style={{ width:90, padding:'6px 9px', borderRadius:6, border:'1.5px solid var(--border)',
                              fontSize:13, fontFamily:'inherit', textAlign:'right' }}
                          />
                        </div>
                      ))}
                    </div>
                    <Btn variant="primary" icon="fa-floppy-disk" onClick={saveStaffSalary}>Save Salary Components</Btn>
                  </>
                )}
                {selStaff && salaryHeads.length === 0 && (
                  <p style={{ fontSize:13, color:'var(--text-light)' }}>Add salary heads first before configuring per-staff amounts.</p>
                )}
              </div>
            </Card>

          </div>
        );
      })()}

      {/* SECURITY */}
      {tab === 'security' && (
        <div style={{ display:'flex', flexDirection:'column', gap:14 }}>
          <Card title="Change Password" icon="fa-key">
            <div style={{ padding:'0 18px 18px' }}>
              <p style={{ fontSize:13, color:'var(--text-light)', marginBottom:16 }}>
                Update your login password. You'll need to know your current password.
              </p>
              <div style={{ display:'flex', flexDirection:'column', gap:12, maxWidth:400 }}>
                <Input label="Current Password" type="password" value={pwdForm.current}
                  onChange={e => setPwdForm(p=>({...p,current:e.target.value}))}
                  placeholder="Enter current password" />
                <Input label="New Password" type="password" value={pwdForm.newPwd}
                  onChange={e => setPwdForm(p=>({...p,newPwd:e.target.value}))}
                  placeholder="Min 8 characters" />
                {pwdForm.newPwd && (
                  <div style={{ height:4, borderRadius:2, background:'#e2e8f0', overflow:'hidden' }}>
                    <div style={{
                      height:'100%', borderRadius:2, transition:'all .3s',
                      width: pwdForm.newPwd.length < 6 ? '25%' : pwdForm.newPwd.length < 8 ? '50%' :
                             /[A-Z]/.test(pwdForm.newPwd) && /[0-9]/.test(pwdForm.newPwd) ? '100%' : '75%',
                      background: pwdForm.newPwd.length < 6 ? '#e53e3e' : pwdForm.newPwd.length < 8 ? '#F7941D' :
                                  /[A-Z]/.test(pwdForm.newPwd) && /[0-9]/.test(pwdForm.newPwd) ? '#38a169' : '#2196F3',
                    }}/>
                  </div>
                )}
                <Input label="Confirm New Password" type="password" value={pwdForm.confirm}
                  onChange={e => setPwdForm(p=>({...p,confirm:e.target.value}))}
                  placeholder="Re-enter new password"
                  style={pwdForm.confirm && pwdForm.confirm !== pwdForm.newPwd ? { borderColor:'#e53e3e' } : {}} />
                {pwdForm.confirm && pwdForm.confirm !== pwdForm.newPwd && (
                  <p style={{ fontSize:12, color:'#e53e3e', marginTop:-8 }}>Passwords do not match</p>
                )}
                <div style={{ marginTop:4 }}>
                  <Btn variant="primary" icon="fa-lock" loading={pwdSaving} onClick={changePassword}>
                    Update Password
                  </Btn>
                </div>
              </div>
            </div>
          </Card>
        </div>
      )}

      {/* ACADEMIC */}
      {tab === 'academic' && (
        <Card title="Academic Configuration" icon="fa-graduation-cap">
          <div style={{ padding:'0 18px 18px' }}>
            <div className="form-grid">
              <Input label="Minimum Attendance (%)" type="number" value={academicConfig.attendanceRequired}
                onChange={e => setAcademicConfig(a=>({...a,attendanceRequired:e.target.value}))} />
              <Input label="Default Pass Marks (%)" type="number" value={academicConfig.passingMarks}
                onChange={e => setAcademicConfig(a=>({...a,passingMarks:e.target.value}))} />
              <Input label="Working Days per Month" type="number" value={academicConfig.workingDays}
                onChange={e => setAcademicConfig(a=>({...a,workingDays:e.target.value}))} />
              <Select label="Grading System" value={academicConfig.gradingSystem}
                onChange={e => setAcademicConfig(a=>({...a,gradingSystem:e.target.value}))}
                options={[{value:'letter',label:'Letter Grades (A+,A,B+...)'},{value:'percentage',label:'Percentage'},{value:'gpa',label:'GPA (10 point)'}]} />
              <Select label="Exam Pattern" value={academicConfig.examPattern}
                onChange={e => setAcademicConfig(a=>({...a,examPattern:e.target.value}))}
                options={[{value:'quarterly',label:'Quarterly'},{value:'half_yearly',label:'Half-Yearly'},{value:'annual',label:'Annual Only'}]} />
            </div>
          </div>
        </Card>
      )}
    </div>
  );
}
