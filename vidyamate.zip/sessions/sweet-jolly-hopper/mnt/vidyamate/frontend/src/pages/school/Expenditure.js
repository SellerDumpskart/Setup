import React, { useState, useEffect } from 'react';
import { PageHeader, Btn, DataTable, Badge, Card, Modal, Input, Select, StatMini } from '../../components/common/Common';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { expenditureService } from '../../services';
import { useSessionContext } from '../../store/sessionStore';
import { fmtCurrency, fmtDate, exportToCSV } from '../../utils';
import toast from 'react-hot-toast';

const CATS = ['Staff Salary','Building Maintenance','Electricity','Water','Stationery','Lab Equipment','Library Books','Sports Equipment','Transport','Events & Functions','Repairs','Cleaning & Sanitation','Security','Internet & Phone','Other'];
const MODES = [{value:'cash',label:'Cash'},{value:'cheque',label:'Cheque'},{value:'online',label:'Online'},{value:'upi',label:'UPI'},{value:'neft',label:'NEFT'}];
const EMPTY = { description:'', category:'', amount:'', expenseDate:new Date().toISOString().split('T')[0], mode:'cash', vendorName:'', billNo:'', remarks:'' };

export default function Expenditure() {
  const { sessionId } = useSessionContext();
  const [expenses, setExpenses] = useState([]);
  const [loading, setLoading]   = useState(true);
  const [showForm, setShow]     = useState(false);
  const [saving, setSaving]     = useState(false);
  const [form, setForm]         = useState(EMPTY);

  const load = async () => {
    setLoading(true);
    try { const { data } = await expenditureService.list(); setExpenses(data || []); }
    catch { setExpenses([]); }
    finally { setLoading(false); }
  };

  useEffect(() => { load(); }, [sessionId]);

  const handleSave = async () => {
    if (!form.description || !form.amount || !form.category) { toast.error('Fill required fields'); return; }
    setSaving(true);
    try {
      await expenditureService.create({ ...form, amount: parseFloat(form.amount) });
      toast.success('Expense recorded');
      load(); setShow(false); setForm(EMPTY);
    } catch (e) { toast.error(e.response?.data?.error || 'Failed'); }
    finally { setSaving(false); }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Remove this expense?')) return;
    await expenditureService.remove(id);
    toast.success('Removed'); load();
  };

  const total    = expenses.reduce((s,e) => s + parseFloat(e.amount||0), 0);
  const approved = expenses.filter(e => e.status === 'approved').reduce((s,e) => s + parseFloat(e.amount||0), 0);

  const catTotals = expenses.reduce((acc, e) => {
    acc[e.category] = (acc[e.category]||0) + parseFloat(e.amount||0);
    return acc;
  }, {});
  const chartData = Object.entries(catTotals).sort((a,b)=>b[1]-a[1]).slice(0,6)
    .map(([cat, amt]) => ({ name: cat.split(' ')[0], amount: amt }));

  const cols = [
    { key:'description', label:'Description',
      render:(v,row) => <div><p style={{ fontWeight:600 }}>{v}</p><p style={{ fontSize:11, color:'var(--text-light)' }}>{fmtDate(row.expense_date, {day:'2-digit',month:'short',year:'2-digit'})}</p></div>
    },
    { key:'category', label:'Category', width:160, render:v => <Badge label={v||'—'} color="teal" /> },
    { key:'amount', label:'Amount', width:120, render:v => <span style={{ fontWeight:700 }}>{fmtCurrency(v)}</span> },
    { key:'payment_mode', label:'Mode', width:90, render:v => <Badge label={v} color={{ cash:'green',online:'blue',upi:'teal',cheque:'orange',neft:'purple' }[v]||'gray'} /> },
    { key:'vendor_name', label:'Vendor', render:v => v||'—' },
    { key:'bill_no', label:'Bill No.', render:v => <span style={{ fontFamily:'monospace', fontSize:12 }}>{v||'—'}</span> },
    { key:'id', label:'', width:60,
      render:v => <button className="icon-btn danger" onClick={e => { e.stopPropagation(); handleDelete(v); }}><i className="fa-solid fa-trash"/></button>
    },
  ];

  return (
    <div>
      <PageHeader title="Expenditure" subtitle="Track and manage school expenses" icon="fa-wallet"
        actions={
          <>
            <Btn icon="fa-file-csv" variant="ghost" size="sm" onClick={() => { exportToCSV(expenses,'expenditure',cols); toast.success('Exported'); }}>Export</Btn>
            <Btn icon="fa-plus" variant="primary" onClick={() => setShow(true)}>Add Expense</Btn>
          </>
        }
      />
      <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:12, marginBottom:16 }}>
        <StatMini label="Total Expenses" value={fmtCurrency(total,true)}    icon="fa-wallet"       color="#e53e3e" />
        <StatMini label="Entries"        value={expenses.length}            icon="fa-list"         color="#00A99D" />
        <StatMini label="Categories"     value={Object.keys(catTotals).length} icon="fa-tags"      color="#9C27B0" />
        <StatMini label="This Month"     value={fmtCurrency(expenses.filter(e => new Date(e.expense_date).getMonth()===new Date().getMonth()).reduce((s,e)=>s+parseFloat(e.amount||0),0),true)} icon="fa-calendar" color="#F7941D" />
      </div>

      {chartData.length > 0 && (
        <div style={{ display:'grid', gridTemplateColumns:'2fr 1fr', gap:14, marginBottom:14 }}>
          <Card title="Expense by Category" icon="fa-chart-bar">
            <div style={{ padding:'0 16px 16px' }}>
              <ResponsiveContainer width="100%" height={180}>
                <BarChart data={chartData} barSize={26}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0"/>
                  <XAxis dataKey="name" tick={{ fontSize:10 }} axisLine={false} tickLine={false}/>
                  <YAxis tickFormatter={v => fmtCurrency(v,true)} tick={{ fontSize:9 }} axisLine={false} tickLine={false}/>
                  <Tooltip formatter={v => [fmtCurrency(v),'Amount']} cursor={{ fill:'rgba(0,0,0,.04)' }}/>
                  <Bar dataKey="amount" fill="var(--primary)" radius={[4,4,0,0]}/>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </Card>
          <Card title="Top 5 Expenses" icon="fa-list-ol">
            <div style={{ padding:'0 16px 16px' }}>
              {[...expenses].sort((a,b)=>b.amount-a.amount).slice(0,5).map((e,i) => (
                <div key={e.id} style={{ display:'flex', alignItems:'center', gap:8, padding:'7px 0', borderBottom:'1px solid #f7f7f7' }}>
                  <span style={{ width:22, height:22, borderRadius:6, background:i<3?'#F7941D18':'#f0f0f0', color:i<3?'#F7941D':'var(--text-light)', fontWeight:700, fontSize:11, display:'flex', alignItems:'center', justifyContent:'center' }}>{i+1}</span>
                  <div style={{ flex:1, overflow:'hidden' }}>
                    <p style={{ fontSize:12.5, fontWeight:500, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{e.description}</p>
                    <p style={{ fontSize:10, color:'var(--text-light)' }}>{e.category}</p>
                  </div>
                  <span style={{ fontSize:13, fontWeight:700 }}>{fmtCurrency(e.amount,true)}</span>
                </div>
              ))}
            </div>
          </Card>
        </div>
      )}

      <Card>
        <DataTable columns={cols} data={expenses} loading={loading} emptyText="No expenses recorded" />
      </Card>

      <Modal open={showForm} onClose={() => setShow(false)} title="Record Expense" size="md"
        footer={<div style={{ display:'flex', gap:8, justifyContent:'flex-end' }}><Btn variant="ghost" onClick={()=>setShow(false)}>Cancel</Btn><Btn variant="primary" icon="fa-floppy-disk" loading={saving} onClick={handleSave}>Save</Btn></div>}
      >
        <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
          <Input label="Description" required value={form.description} onChange={e=>setForm(f=>({...f,description:e.target.value}))} placeholder="What was this for?" />
          <div className="form-grid">
            <Select label="Category" required value={form.category} onChange={e=>setForm(f=>({...f,category:e.target.value}))} placeholder="Select" options={CATS} />
            <Input label="Amount (₹)" required type="number" value={form.amount} onChange={e=>setForm(f=>({...f,amount:e.target.value}))} />
            <Input label="Date" required type="date" value={form.expenseDate} onChange={e=>setForm(f=>({...f,expenseDate:e.target.value}))} />
            <Select label="Payment Mode" value={form.mode} onChange={e=>setForm(f=>({...f,mode:e.target.value}))} options={MODES} />
            <Input label="Vendor Name" value={form.vendorName} onChange={e=>setForm(f=>({...f,vendorName:e.target.value}))} />
            <Input label="Bill / Invoice No." value={form.billNo} onChange={e=>setForm(f=>({...f,billNo:e.target.value}))} />
          </div>
          <Input label="Remarks" value={form.remarks} onChange={e=>setForm(f=>({...f,remarks:e.target.value}))} />
        </div>
      </Modal>
    </div>
  );
}
