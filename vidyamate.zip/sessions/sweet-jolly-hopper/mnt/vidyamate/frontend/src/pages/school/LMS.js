import React, { useState, useEffect, useRef } from 'react';
import { PageHeader, Btn, Card, Badge, StatMini, Modal, Input, Select, Textarea } from '../../components/common/Common';
import { useSessionContext } from '../../store/sessionStore';
import { useClasses } from '../../hooks';
import { lmsService } from '../../services';
import api from '../../services/api';
import { fmtDate, STATUS_COLORS } from '../../utils';
import toast from 'react-hot-toast';

const TYPE_ICON  = { document:'fa-file-pdf', video:'fa-video', audio:'fa-headphones', image:'fa-image', link:'fa-link', assignment:'fa-file-pen', quiz:'fa-question-circle', other:'fa-file' };
const TYPE_COLOR = { document:'#e53e3e', video:'#2196F3', assignment:'#F7941D', quiz:'#9C27B0', link:'#00A99D', other:'#718096' };

export default function LMS() {
  const { sessionId } = useSessionContext();
  const { data: classesData } = useClasses(sessionId);
  const classes = classesData || [];
  const [content, setContent]   = useState([]);
  const [loading, setLoading]   = useState(true);
  const [tab, setTab]           = useState('content');
  const [showForm, setShow]     = useState(false);
  const [saving, setSaving]     = useState(false);
  const [form, setForm]         = useState({ title:'', subject:'', classId:'', contentType:'document', description:'', dueDate:'', maxMarks:'' });
  const [lmsFile, setLmsFile]   = useState(null);
  const fileInputRef            = useRef(null);

  const load = async () => {
    setLoading(true);
    try { const { data } = await lmsService.content(); setContent(data||[]); }
    catch { setContent([]); }
    finally { setLoading(false); }
  };

  useEffect(() => { load(); }, [sessionId]);

  const resetForm = () => {
    setForm({ title:'', subject:'', classId:'', contentType:'document', description:'', dueDate:'', maxMarks:'' });
    setLmsFile(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleCreate = async () => {
    if (!form.title || !form.subject) { toast.error('Fill required fields'); return; }
    setSaving(true);
    try {
      const res = await lmsService.createContent({ ...form, sessionId });
      const newId = res?.data?.id;
      // Upload file if one was selected
      if (lmsFile && newId) {
        try {
          const fd = new FormData();
          fd.append('document', lmsFile);
          await api.post(`/lms/content/${newId}/upload`, fd, {
            headers: { 'Content-Type': 'multipart/form-data' },
          });
        } catch { /* non-fatal — content was still created */ }
      }
      toast.success('Content added');
      load();
      setShow(false);
      resetForm();
    }
    catch (e) { toast.error(e.response?.data?.error||'Failed'); }
    finally { setSaving(false); }
  };

  const publish = async (id) => {
    await lmsService.publish(id);
    toast.success('Published!'); load();
  };

  const published   = content.filter(c => c.is_published).length;
  const assignments = content.filter(c => c.content_type === 'assignment' || c.content_type === 'quiz').length;

  return (
    <div>
      <PageHeader title="LMS — Learning Management" subtitle="Study materials, assignments and online classes" icon="fa-chalkboard-user"
        actions={<Btn icon="fa-plus" variant="primary" onClick={() => setShow(true)}>Add Content</Btn>}
      />
      <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:12, marginBottom:16 }}>
        <StatMini label="Total Content" value={content.length}    icon="fa-folder"    color="#00A99D" />
        <StatMini label="Published"     value={published}         icon="fa-eye"       color="#38a169" />
        <StatMini label="Assignments"   value={assignments}       icon="fa-file-pen"  color="#F7941D" />
        <StatMini label="Videos"        value={content.filter(c=>c.content_type==='video').length} icon="fa-video" color="#2196F3" />
      </div>

      {loading ? (
        <Card><div style={{ padding:48, textAlign:'center', color:'var(--text-light)' }}><i className="fa-solid fa-spinner fa-spin" style={{ fontSize:24 }}/></div></Card>
      ) : content.length === 0 ? (
        <Card><div style={{ padding:48, textAlign:'center', color:'var(--text-light)' }}>
          <i className="fa-solid fa-book" style={{ fontSize:40, opacity:.3, marginBottom:12 }}/>
          <p>No content added yet. Click "Add Content" to start.</p>
        </div></Card>
      ) : (
        <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(280px,1fr))', gap:12 }}>
          {content.map(c => {
            const icon  = TYPE_ICON[c.content_type]  || 'fa-file';
            const color = TYPE_COLOR[c.content_type] || '#718096';
            return (
              <div key={c.id} style={{ background:'#fff', borderRadius:12, padding:16, boxShadow:'var(--card-shadow)', border:'1.5px solid var(--border)', transition:'all .18s' }}
                onMouseEnter={e=>e.currentTarget.style.borderColor=color} onMouseLeave={e=>e.currentTarget.style.borderColor='var(--border)'}>
                <div style={{ display:'flex', justifyContent:'space-between', marginBottom:10 }}>
                  <div style={{ width:40, height:40, borderRadius:10, background:`${color}18`, display:'flex', alignItems:'center', justifyContent:'center' }}>
                    <i className={`fa-solid ${icon}`} style={{ color, fontSize:18 }}/>
                  </div>
                  <div style={{ display:'flex', gap:4 }}>
                    <Badge label={c.content_type} color="teal" />
                    {!c.is_published && <Badge label="Draft" color="gray" />}
                  </div>
                </div>
                <h3 style={{ fontWeight:600, fontSize:13.5, marginBottom:4 }}>{c.title}</h3>
                <p style={{ fontSize:12, color:'var(--text-light)', marginBottom:10 }}>{c.subject_name||c.subject} · {c.class_name||'All Classes'}</p>
                {c.due_date && <p style={{ fontSize:11.5, color:'var(--accent-orange)', marginBottom:8 }}>Due: {fmtDate(c.due_date,{day:'2-digit',month:'short'})}</p>}
                {c.submission_count !== null && <p style={{ fontSize:11.5, color:'var(--text-light)' }}>{c.submission_count} submissions</p>}
                {c.file_url && (
                  <a href={c.file_url} target="_blank" rel="noreferrer"
                    style={{ display:'inline-flex', alignItems:'center', gap:5, fontSize:11.5, color:'var(--primary)', textDecoration:'none', marginTop:4 }}>
                    <i className="fa-solid fa-download" style={{ fontSize:10 }}/>Download file
                  </a>
                )}
                <div style={{ display:'flex', gap:6, marginTop:10 }}>
                  {!c.is_published && <Btn size="sm" variant="success" onClick={() => publish(c.id)}>Publish</Btn>}
                  <Btn size="sm" variant="ghost" icon="fa-pen">Edit</Btn>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <Modal open={showForm} onClose={() => { setShow(false); resetForm(); }} title="Add Content" size="md"
        footer={<div style={{ display:'flex', gap:8, justifyContent:'flex-end' }}><Btn variant="ghost" onClick={()=>{ setShow(false); resetForm(); }}>Cancel</Btn><Btn variant="primary" icon="fa-floppy-disk" loading={saving} onClick={handleCreate}>Save</Btn></div>}
      >
        <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
          <Input label="Title" required value={form.title} onChange={e=>setForm(f=>({...f,title:e.target.value}))} />
          <div className="form-grid">
            <Input label="Subject" required value={form.subject} onChange={e=>setForm(f=>({...f,subject:e.target.value}))} />
            <Select label="Class" value={form.classId} onChange={e=>setForm(f=>({...f,classId:e.target.value}))} placeholder="All Classes" options={classes.map(c=>({value:c.id,label:`${c.class_name}-${c.section}`}))} />
            <Select label="Content Type" value={form.contentType} onChange={e=>setForm(f=>({...f,contentType:e.target.value}))}
              options={['document','video','audio','image','link','assignment','quiz','other'].map(t=>({value:t,label:t.charAt(0).toUpperCase()+t.slice(1)}))} />
            {(form.contentType==='assignment'||form.contentType==='quiz') && (
              <Input label="Due Date" type="date" value={form.dueDate} onChange={e=>setForm(f=>({...f,dueDate:e.target.value}))} />
            )}
          </div>
          <Textarea label="Description" value={form.description} onChange={e=>setForm(f=>({...f,description:e.target.value}))} rows={3} />
          {/* File attachment */}
          <div>
            <label style={{ fontSize:12.5, fontWeight:600, color:'var(--text-mid)', marginBottom:6, display:'block' }}>
              Attach File <span style={{ fontWeight:400, color:'var(--text-light)' }}>(PDF, DOC, MP4, MP3, image — max 10 MB)</span>
            </label>
            <div style={{ display:'flex', alignItems:'center', gap:10 }}>
              <label style={{ display:'flex', alignItems:'center', gap:6, padding:'8px 14px', borderRadius:8, border:'1.5px dashed var(--border)', cursor:'pointer', fontSize:13, color:'var(--text-mid)', background:'#fafafa', flex:1 }}>
                <i className="fa-solid fa-paperclip" style={{ color:'var(--primary)' }} />
                {lmsFile ? lmsFile.name : 'Click to choose file'}
                <input ref={fileInputRef} type="file" accept=".pdf,.doc,.docx,.xls,.xlsx,.mp4,.mp3,.jpg,.jpeg,.png"
                  style={{ display:'none' }} onChange={e => setLmsFile(e.target.files[0] || null)} />
              </label>
              {lmsFile && (
                <Btn size="sm" variant="ghost" onClick={() => { setLmsFile(null); if (fileInputRef.current) fileInputRef.current.value=''; }}>
                  <i className="fa-solid fa-xmark"/>
                </Btn>
              )}
            </div>
          </div>
        </div>
      </Modal>
    </div>
  );
}
