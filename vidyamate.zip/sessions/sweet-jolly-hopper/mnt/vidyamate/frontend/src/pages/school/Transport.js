import React, { useState, useEffect } from 'react';
import { PageHeader, Btn, Card, DataTable, Badge, StatMini, Modal, Input } from '../../components/common/Common';
import { useSessionContext } from '../../store/sessionStore';
import api from '../../services/api';
import toast from 'react-hot-toast';

export default function Transport() {
  const { sessionId } = useSessionContext();
  const [routes, setRoutes]   = useState([]);
  const [loading, setLoading] = useState(true);
  const [selRoute, setSelRoute] = useState(null);
  const [stops, setStops]     = useState([]);
  const [showForm, setShow]   = useState(false);
  const [saving, setSaving]   = useState(false);
  const [form, setForm]       = useState({ routeNo:'', routeName:'', vehicleNo:'', capacity:40, fee:500 });

  // Allocation state
  const [showAlloc, setShowAlloc]       = useState(false);
  const [allocQuery, setAllocQuery]     = useState('');
  const [allocResults, setAllocResults] = useState([]);
  const [allocStudent, setAllocStudent] = useState(null);  // { id, name, code }
  const [allocRouteId, setAllocRouteId] = useState('');
  const [allocStops, setAllocStops]     = useState([]);
  const [allocStopName, setAllocStopName] = useState('');
  const [allocSaving, setAllocSaving]   = useState(false);
  const allocTimer = React.useRef(null);

  const load = async () => {
    setLoading(true);
    try { const { data } = await api.get('/transport'); setRoutes(data||[]); }
    catch { setRoutes([]); }
    finally { setLoading(false); }
  };

  const loadStops = async (routeId) => {
    try { const { data } = await api.get(`/transport/${routeId}/stops`); setStops(data||[]); }
    catch { setStops([]); }
  };

  useEffect(() => { load(); }, []);

  const handleCreate = async () => {
    if (!form.routeName || !form.vehicleNo) { toast.error('Fill required fields'); return; }
    setSaving(true);
    try { await api.post('/transport', form); toast.success('Route added'); load(); setShow(false); setForm({ routeNo:'', routeName:'', vehicleNo:'', capacity:40, fee:500 }); }
    catch (e) { toast.error(e.response?.data?.error||'Failed'); }
    finally { setSaving(false); }
  };

  // Student search with debounce
  const searchStudents = (q) => {
    clearTimeout(allocTimer.current);
    setAllocQuery(q);
    if (!q.trim()) { setAllocResults([]); return; }
    allocTimer.current = setTimeout(async () => {
      try {
        const { data } = await api.get('/students', { params: { search: q, limit: 10 } });
        setAllocResults(data?.students || data || []);
      } catch { setAllocResults([]); }
    }, 300);
  };

  const pickStudent = (s) => {
    setAllocStudent({ id: s.id, name: `${s.first_name} ${s.last_name||''}`.trim(), code: s.student_code });
    setAllocQuery(`${s.first_name} ${s.last_name||''}`.trim());
    setAllocResults([]);
  };

  const loadAllocStops = async (routeId) => {
    setAllocRouteId(routeId);
    setAllocStopName('');
    if (!routeId) { setAllocStops([]); return; }
    try {
      const { data } = await api.get(`/transport/${routeId}/stops`);
      setAllocStops(data || []);
    } catch { setAllocStops([]); }
  };

  const handleAllocate = async () => {
    if (!allocStudent) { toast.error('Search and select a student'); return; }
    if (!allocRouteId) { toast.error('Select a route'); return; }
    setAllocSaving(true);
    try {
      await api.post('/transport/allocate', {
        studentId: allocStudent.id,
        routeId: allocRouteId,
        sessionId,
        stopName: allocStopName || null,
      });
      toast.success(`${allocStudent.name} allocated successfully`);
      setShowAlloc(false);
      setAllocQuery(''); setAllocStudent(null); setAllocRouteId(''); setAllocStopName(''); setAllocStops([]); setAllocResults([]);
      load();
    } catch (e) {
      toast.error(e.response?.data?.error || 'Allocation failed');
    } finally { setAllocSaving(false); }
  };

  const totalCap   = routes.reduce((s,r) => s + (r.capacity||0), 0);
  const totalEnrol = routes.reduce((s,r) => s + parseInt(r.enrolled_students||0), 0);

  const cols = [
    { key:'route_no',   label:'Route', width:90,
      render:(v,row) => <div><p style={{ fontWeight:700, color:'var(--primary)', fontFamily:'monospace' }}>{v}</p><p style={{ fontSize:11, color:'var(--text-light)' }}>₹{row.monthly_fee}/mo</p></div>
    },
    { key:'route_name', label:'Route Name', render:v => <span style={{ fontWeight:600 }}>{v}</span> },
    { key:'vehicle_no', label:'Vehicle', render:v => <span style={{ fontFamily:'monospace', background:'#f0f0f0', padding:'2px 8px', borderRadius:4, fontSize:12 }}>{v}</span> },
    { key:'enrolled_students', label:'Students', width:100,
      render:(v,row) => {
        const pct = row.capacity > 0 ? Math.round((parseInt(v||0)/row.capacity)*100) : 0;
        return <div><p style={{ fontWeight:600 }}>{v||0}/{row.capacity}</p>
          <div style={{ height:4, background:'#f0f0f0', borderRadius:2, marginTop:3, overflow:'hidden' }}>
            <div style={{ width:`${pct}%`, height:'100%', background: pct>=90?'#e53e3e':'#38a169', borderRadius:2 }}/>
          </div></div>;
      }
    },
    { key:'stop_count', label:'Stops', width:75, render:v => <span style={{ fontWeight:600 }}>{v||0}</span> },
    { key:'status', label:'Status', width:90, render:v => <Badge label={v||'active'} color={v==='active'?'green':'red'} /> },
    { key:'id', label:'', width:90,
      render:(v,row) => (
        <Btn size="sm" variant="secondary" onClick={e => { e.stopPropagation(); setSelRoute(row); loadStops(v); }}>Stops</Btn>
      )
    },
  ];

  return (
    <div>
      <PageHeader title="Transport" subtitle="Manage bus routes, stops and student allocation" icon="fa-bus"
        actions={
          <>
            <Btn icon="fa-user-plus" variant="secondary" onClick={() => setShowAlloc(true)}>Allocate Student</Btn>
            <Btn icon="fa-plus" variant="primary" onClick={() => setShow(true)}>Add Route</Btn>
          </>
        }
      />
      <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:12, marginBottom:16 }}>
        <StatMini label="Routes"    value={routes.length} icon="fa-route"   color="#00A99D" />
        <StatMini label="Capacity"  value={totalCap}      icon="fa-bus"     color="#2196F3" />
        <StatMini label="Enrolled"  value={totalEnrol}    icon="fa-users"   color="#F7941D" />
        <StatMini label="Available" value={totalCap-totalEnrol} icon="fa-chair" color="#38a169" />
      </div>
      <Card>
        <DataTable columns={cols} data={routes} loading={loading} emptyText="No transport routes configured" />
      </Card>

      {/* Stops modal */}
      <Modal open={!!selRoute} onClose={() => { setSelRoute(null); setStops([]); }}
        title={`${selRoute?.route_no} — ${selRoute?.route_name} Stops`} size="sm">
        {stops.length === 0
          ? <p style={{ color:'var(--text-light)', fontSize:13 }}>No stops configured for this route</p>
          : stops.map((s,i) => (
            <div key={s.id} style={{ display:'flex', alignItems:'center', gap:10, padding:'8px 0', borderBottom:'1px solid #f7f7f7' }}>
              <div style={{ width:24, height:24, borderRadius:'50%', background:i===0?'var(--primary)':'#f0f0f0', color:i===0?'#fff':'var(--text-mid)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:11, fontWeight:700, flexShrink:0 }}>{i+1}</div>
              <div>
                <p style={{ fontSize:13, fontWeight:500 }}>{s.stop_name}</p>
                {s.pickup_time && <p style={{ fontSize:11, color:'var(--text-light)' }}>Pickup: {s.pickup_time}</p>}
              </div>
            </div>
          ))
        }
      </Modal>

      {/* Add route modal */}
      <Modal open={showForm} onClose={() => setShow(false)} title="Add Transport Route" size="md"
        footer={<div style={{ display:'flex', gap:8, justifyContent:'flex-end' }}><Btn variant="ghost" onClick={()=>setShow(false)}>Cancel</Btn><Btn variant="primary" icon="fa-floppy-disk" loading={saving} onClick={handleCreate}>Save</Btn></div>}
      >
        <div className="form-grid">
          <Input label="Route No." required value={form.routeNo} onChange={e=>setForm(f=>({...f,routeNo:e.target.value}))} placeholder="R-05" />
          <Input label="Route Name" required value={form.routeName} onChange={e=>setForm(f=>({...f,routeName:e.target.value}))} placeholder="Area name" />
          <Input label="Vehicle No." required value={form.vehicleNo} onChange={e=>setForm(f=>({...f,vehicleNo:e.target.value}))} placeholder="AP 11 XX XXXX" />
          <Input label="Capacity" type="number" value={form.capacity} onChange={e=>setForm(f=>({...f,capacity:e.target.value}))} />
          <Input label="Monthly Fee (₹)" type="number" value={form.fee} onChange={e=>setForm(f=>({...f,fee:e.target.value}))} />
        </div>
      </Modal>

      {/* Allocate student modal */}
      <Modal open={showAlloc}
        onClose={() => { setShowAlloc(false); setAllocQuery(''); setAllocStudent(null); setAllocRouteId(''); setAllocStopName(''); setAllocStops([]); setAllocResults([]); }}
        title="Allocate Student to Route" size="sm"
        footer={
          <div style={{ display:'flex', gap:8, justifyContent:'flex-end' }}>
            <Btn variant="ghost" onClick={() => setShowAlloc(false)}>Cancel</Btn>
            <Btn variant="primary" icon="fa-bus" loading={allocSaving} onClick={handleAllocate}>Allocate</Btn>
          </div>
        }
      >
        <div style={{ display:'flex', flexDirection:'column', gap:14 }}>

          {/* Student search */}
          <div style={{ position:'relative' }}>
            <label style={{ fontSize:12.5, fontWeight:600, color:'var(--text-mid)', marginBottom:5, display:'block' }}>
              Student <span style={{ color:'#e53e3e' }}>*</span>
            </label>
            <div style={{ position:'relative' }}>
              <input
                value={allocQuery}
                onChange={e => { setAllocStudent(null); searchStudents(e.target.value); }}
                placeholder="Type name or admission no…"
                style={{ width:'100%', padding:'9px 12px', borderRadius:8, fontSize:13, boxSizing:'border-box',
                  border:`1.5px solid ${allocStudent ? '#38a169' : 'var(--border)'}`, fontFamily:'inherit' }}
              />
              {allocStudent && (
                <i className="fa-solid fa-circle-check" style={{ position:'absolute', right:10, top:'50%', transform:'translateY(-50%)', color:'#38a169' }} />
              )}
            </div>
            {allocResults.length > 0 && (
              <div style={{ position:'absolute', top:'100%', left:0, right:0, zIndex:99, background:'#fff',
                border:'1.5px solid var(--border)', borderRadius:8, boxShadow:'0 4px 16px rgba(0,0,0,.1)', marginTop:2 }}>
                {allocResults.map(s => (
                  <div key={s.id} onClick={() => pickStudent(s)}
                    style={{ padding:'9px 12px', cursor:'pointer', fontSize:13, borderBottom:'1px solid #f7f7f7' }}
                    onMouseEnter={e=>e.currentTarget.style.background='#f8fafb'}
                    onMouseLeave={e=>e.currentTarget.style.background='#fff'}>
                    <span style={{ fontWeight:600 }}>{s.first_name} {s.last_name||''}</span>
                    <span style={{ color:'var(--text-light)', marginLeft:8, fontSize:11.5 }}>{s.student_code}</span>
                    {s.class_name && <span style={{ color:'var(--text-light)', marginLeft:6, fontSize:11.5 }}>· Class {s.class_name}</span>}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Route select */}
          <div>
            <label style={{ fontSize:12.5, fontWeight:600, color:'var(--text-mid)', marginBottom:5, display:'block' }}>
              Route <span style={{ color:'#e53e3e' }}>*</span>
            </label>
            <select value={allocRouteId} onChange={e => loadAllocStops(e.target.value)}
              style={{ width:'100%', padding:'9px 12px', borderRadius:8, fontSize:13, boxSizing:'border-box',
                border:'1.5px solid var(--border)', fontFamily:'inherit', background:'#fff' }}>
              <option value="">Select route</option>
              {routes.map(r => (
                <option key={r.id} value={r.id}>{r.route_no} — {r.route_name} ({r.enrolled_students||0}/{r.capacity})</option>
              ))}
            </select>
          </div>

          {/* Stop select */}
          {allocRouteId && (
            <div>
              <label style={{ fontSize:12.5, fontWeight:600, color:'var(--text-mid)', marginBottom:5, display:'block' }}>Boarding Stop</label>
              <select value={allocStopName} onChange={e => setAllocStopName(e.target.value)}
                style={{ width:'100%', padding:'9px 12px', borderRadius:8, fontSize:13, boxSizing:'border-box',
                  border:'1.5px solid var(--border)', fontFamily:'inherit', background:'#fff' }}>
                <option value="">— Select stop (optional) —</option>
                {allocStops.map(s => (
                  <option key={s.id} value={s.stop_name}>
                    {s.stop_name}{s.pickup_time ? ` (${s.pickup_time})` : ''}
                  </option>
                ))}
                {allocStops.length === 0 && <option disabled>No stops configured for this route</option>}
              </select>
            </div>
          )}
        </div>
      </Modal>
    </div>
  );
}
