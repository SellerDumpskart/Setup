import React from 'react';
import { useNavigate } from 'react-router-dom';

function IllustrationPage({ code, title, subtitle, icon, actions }) {
  return (
    <div style={{
      display:'flex', flexDirection:'column', alignItems:'center',
      justifyContent:'center', minHeight:'80vh', padding:32, textAlign:'center'
    }}>
      <div style={{ width:96, height:96, borderRadius:24, background:'var(--primary-light)',
        display:'flex', alignItems:'center', justifyContent:'center',
        fontSize:40, marginBottom:24, color:'var(--primary)' }}>
        <i className={`fa-solid ${icon}`} />
      </div>
      <p style={{ fontSize:72, fontWeight:800, color:'#e2e8f0', lineHeight:1, marginBottom:8 }}>{code}</p>
      <h1 style={{ fontSize:24, fontWeight:700, color:'#1a2332', marginBottom:8 }}>{title}</h1>
      <p style={{ fontSize:14, color:'#718096', marginBottom:32, maxWidth:400 }}>{subtitle}</p>
      <div style={{ display:'flex', gap:12 }}>{actions}</div>
    </div>
  );
}

export function NotFound() {
  const navigate = useNavigate();
  return (
    <IllustrationPage
      code="404" icon="fa-compass"
      title="Page Not Found"
      subtitle="The page you're looking for doesn't exist or has been moved."
      actions={
        <>
          <button onClick={() => navigate(-1)}
            style={{ padding:'10px 20px', border:'1.5px solid var(--border)', borderRadius:8,
              fontWeight:500, cursor:'pointer', fontSize:14, color:'var(--text-mid)' }}>
            ← Go Back
          </button>
          <button onClick={() => navigate('/school')}
            style={{ padding:'10px 20px', background:'var(--primary)', color:'#fff',
              border:'none', borderRadius:8, fontWeight:600, cursor:'pointer', fontSize:14 }}>
            Go to Dashboard
          </button>
        </>
      }
    />
  );
}

export function Unauthorized() {
  const navigate = useNavigate();
  return (
    <IllustrationPage
      code="403" icon="fa-lock"
      title="Access Denied"
      subtitle="You don't have permission to view this page. Contact your administrator."
      actions={
        <button onClick={() => navigate('/school')}
          style={{ padding:'10px 20px', background:'var(--primary)', color:'#fff',
            border:'none', borderRadius:8, fontWeight:600, cursor:'pointer', fontSize:14 }}>
          Go to Dashboard
        </button>
      }
    />
  );
}

export default NotFound;
