import React, { useState, useEffect } from 'react';
import { PageHeader, Btn, Card, DataTable, Badge, StatMini, Modal, Input, Select, Textarea } from '../../components/common/Common';
import { useSessionContext } from '../../store/sessionStore';
import { leaveService } from '../../services';
import { fmtDate, STATUS_COLORS, LEAVE_TYPES } from '../../utils';
import toast from 'react-hot-toast';

const EMPTY = { applicantType:'staff', applicantName:'', leaveType:'Sick Leave', fromDate:'', toDate:'', reason:'' };

export default function Leave() {
  const { sessionId } = useSessionContext();
  const [leaves, setLeaves] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter]   = useState('all');
  const [showForm, setShow]   = useState(false);
  const [form, setForm]       = useState(EMPTY);
  const [saving, setSaving]   = useState(false);

  const load = async () => {
    setLoading(true);
    try { const { data } = await leaveService.list(filter !== 'all' ? { status:filter } : {}); setLeaves(data||[]); }
    catch { setLeaves([]); }
    finally { setLoading(false); }
  };

  useEffect(() => { load(); }, [filter]);

  const approve = async (id) => { await leaveService.approve(id); toast.success('Leave approved'); load(); };
  const reject  = async (id) => { await leaveService.reject(id, ''); toast.error('Leave rejected'); load(); };

  const handleSubmit = async () => {
    if (!form.applicantName || !form.fromDate) { toast.error('Fill required fields'); return; }
    setSaving(true);
    try {
      await leaveService.create({ applicantType:form.applicantType, fromDate:form.fromDate, toDate:form.toDate||form.fromDate, reason:form.reason });
      toast.success('Leave application submitted'); load(); setShow(false); setForm(EMPTY);
    } catch (e) { toast.error(e.response?.data?.error||'Failed'); }
    finally { setSaving(false); }
  };

  const pending = leaves.filter(l => l.status === 'pending').length;

  const cols = [
    { key:'applicant_name', label:'Applicant',
      render:(v,row) => <div><p style={{ fontWeight:600 }}>{v||row.staff_id||row.student_id}</p><Badge label={row.applicant_type} color={row.applicant_type==='staff'?'blue':'teal'} /></div>
    },
    { key:'leave_type_id', label:'Leave Type', render:(v,row) => <Badge label={row.reason?.slice(0,15)||'Leave'} color="teal" /> },
    { key:'from_date', label:'Period',
      render:(v,row) => <div><p style={{ fontWeight:500 }}>{fmtDate(v,{day:'2-digit',month:'short'})}</p><p style={{ fontSize:11, color:'var(--text-light)' }}>to {fmtDate(row.to_date,{day:'2-digit',month:'short'})}</p></div>
    },
    { key:'total_days', label:'Days', width:65, render:v => <span style={{ fontWeight:700, color:'var(--primary)' }}>{v}</span> },
    { key:'reason',    label:'Reason',  render:v => <span style={{ fontSize:12.5, color:'var(--text-mid)' }}>{v}</span> },
    { key:'status',    label:'Status',  width:100, render:v => <Badge label={v} color={STATUS_COLORS[v]||'gray'} /> },
    { key:'id', label:'', width:120,
      render:(v,row) => row.status === 'pending' ? (
        <div style={{ display:'flex', gap:4 }}>
          <Btn size="sm" variant="success" onClick={e=>{e.stopPropagation();approve(v)}}>Approve</Btn>
          <button className="icon-btn danger" onClick={e=>{e.stopPropagation();reject(v)}}><i className="fa-solid fa-xmark"/></button>
        </div>
      ) : null
    },
  ];

  return (
    <div>
      <PageHeader title="Leave Management" subtitle="Manage staff and student leave applications" icon="fa-calendar-xmark"
        actions={<Btn icon="fa-plus" variant="primary" onClick={() => setShow(true)}>Apply Leave</Btn>}
      />
      <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:12, marginBottom:16 }}>
        <StatMini label="Total"    value={leaves.length}                                      icon="fa-file-lines" color="#00A99D" />
        <StatMini label="Pending"  value={pending}                                            icon="fa-clock"      color="#F7941D" />
        <StatMini label="Approved" value={leaves.filter(l=>l.status==='approved').length}     icon="fa-circle-check" color="#38a169" />
        <StatMini label="Rejected" value={leaves.filter(l=>l.status==='rejected').length}     icon="fa-circle-xmark" color="#e53e3e" />
      </div>
      <Card>
        <div style={{ padding:'12px 16px', borderBottom:'1px solid var(--border)', display:'flex', gap:8 }}>
          {['all','pending','approved','rejected'].map(f => (
            <button key={f} onClick={() => setFilter(f)}
              style={{ padding:'6px 14px', borderRadius:7, fontSize:12.5, fontWeight:500, border:'1.5px solid', transition:'all .15s', cursor:'pointer',
                borderColor:filter===f?'var(--primary)':'var(--border)', background:filter===f?'var(--primary)':'transparent', color:filter===f?'#fff':'var(--text-mid)' }}>
              {f.charAt(0).toUpperCase()+f.slice(1)}
              {f==='pending'&&pending>0&&<span style={{ background:'#e53e3e',color:'#fff',borderRadius:10,padding:'1px 6px',fontSize:10,fontWeight:700,marginLeft:5 }}>{pending}</span>}
            </button>
          ))}
        </div>
        <DataTable columns={cols} data={leaves} loading={loading} emptyText="No leave applications" />
      </Card>
      <Modal open={showForm} onClose={() => setShow(false)} title="Apply for Leave" size="md"
        footer={<div style={{ display:'flex', gap:8, justifyContent:'flex-end' }}><Btn variant="ghost" onClick={()=>setShow(false)}>Cancel</Btn><Btn variant="primary" icon="fa-paper-plane" loading={saving} onClick={handleSubmit}>Submit</Btn></div>}
      >
        <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
          <div className="form-grid">
            <Select label="Type" value={form.applicantType} onChange={e=>setForm(f=>({...f,applicantType:e.target.value}))} options={[{value:'staff',label:'Staff'},{value:'student',label:'Student'}]} />
            <Input label="Name / Code" required value={form.applicantName} onChange={e=>setForm(f=>({...f,applicantName:e.target.value}))} />
            <Select label="Leave Type" value={form.leaveType} onChange={e=>setForm(f=>({...f,leaveType:e.target.value}))} options={LEAVE_TYPES.map(t=>({value:t,label:t}))} />
            <div/>
            <Input label="From Date" required type="date" value={form.fromDate} onChange={e=>setForm(f=>({...f,fromDate:e.target.value}))} />
            <Input label="To Date" type="date" value={form.toDate} min={form.fromDate} onChange={e=>setForm(f=>({...f,toDate:e.target.value}))} />
          </div>
          <Textarea label="Reason *" required value={form.reason} onChange={e=>setForm(f=>({...f,reason:e.target.value}))} rows={3} placeholder="Reason for leave..." />
        </div>
      </Modal>
    </div>
  );
}
