import React, { useState, useEffect } from 'react';
import { PageHeader, Btn, Card, DataTable, Badge, StatMini, Select } from '../../components/common/Common';
import { useSessionContext } from '../../store/sessionStore';
import { payrollService } from '../../services';
import { fmtCurrency, fmtDate, MONTHS } from '../../utils';

const printPayslip = (row, month, year) => {
  const MONTHS_LIST = ['January','February','March','April','May','June','July','August','September','October','November','December'];
  const mon = MONTHS_LIST[parseInt(month)-1] || month;
  const win = window.open('', '_blank');
  win.document.write(`
    <html><head><title>Payslip - ${row.first_name} ${row.last_name||''} - ${mon} ${year}</title>
    <style>
      body { font-family:Arial,sans-serif; font-size:13px; padding:30px; color:#222; }
      .header { text-align:center; border-bottom:2px solid #00A99D; padding-bottom:12px; margin-bottom:20px; }
      .header h2 { margin:0; color:#00A99D; }
      .section { margin-bottom:16px; }
      .row { display:flex; justify-content:space-between; padding:5px 0; border-bottom:1px solid #eee; }
      .label { color:#555; } .value { font-weight:600; }
      .total { display:flex; justify-content:space-between; padding:8px 0; border-top:2px solid #333; font-size:15px; font-weight:700; margin-top:8px; }
      .green { color:#38a169; } .red { color:#e53e3e; }
    </style></head><body>
    <div class="header">
      <h2>PAY SLIP</h2>
      <p>${mon} ${year}</p>
    </div>
    <div class="section">
      <div class="row"><span class="label">Employee Name</span><span class="value">${row.first_name} ${row.last_name||''}</span></div>
      <div class="row"><span class="label">Emp No.</span><span class="value">${row.emp_no||'—'}</span></div>
      <div class="row"><span class="label">Designation</span><span class="value">${row.designation||'—'}</span></div>
      <div class="row"><span class="label">Days Worked</span><span class="value">${row.days_worked||0} / 26</span></div>
    </div>
    <div class="section">
      <div class="row"><span class="label">Gross Salary</span><span class="value green">₹${parseFloat(row.gross_salary||0).toFixed(2)}</span></div>
      <div class="row"><span class="label">Deductions (PF + PT)</span><span class="value red">-₹${parseFloat(row.deductions||0).toFixed(2)}</span></div>
      <div class="total"><span>Net Salary</span><span class="green">₹${parseFloat(row.net_salary||0).toFixed(2)}</span></div>
    </div>
    <p style="margin-top:30px;font-size:11px;color:#888">Payment Status: <strong>${(row.status||'').toUpperCase()}</strong>${row.payment_date ? ` · Paid on ${row.payment_date}` : ''}</p>
    </body></html>
  `);
  win.document.close(); win.print(); win.close();
};
import toast from 'react-hot-toast';

export default function Payroll() {
  const { sessionId } = useSessionContext();
  const now = new Date();
  const [month, setMonth]   = useState(String(now.getMonth()+1));
  const [year, setYear]     = useState(String(now.getFullYear()));
  const [payroll, setPayroll] = useState([]);
  const [loading, setLoading] = useState(true);
  const [processing, setProc] = useState(false);

  const load = async () => {
    setLoading(true);
    try { const { data } = await payrollService.list(month, year); setPayroll(data||[]); }
    catch { setPayroll([]); }
    finally { setLoading(false); }
  };

  useEffect(() => { load(); }, [month, year]);

  const processAll = async () => {
    setProc(true);
    try { await payrollService.process(month, year); toast.success('Payroll processed'); load(); }
    catch (e) { toast.error(e.response?.data?.error||'Processing failed'); }
    finally { setProc(false); }
  };

  const markPaid = async (id) => {
    await payrollService.markPaid(id, 'bank_transfer');
    toast.success('Marked as paid'); load();
  };

  const totalGross = payroll.reduce((s,p) => s+parseFloat(p.gross_salary||0), 0);
  const totalNet   = payroll.reduce((s,p) => s+parseFloat(p.net_salary||0), 0);
  const totalDed   = payroll.reduce((s,p) => s+parseFloat(p.deductions||0), 0);
  const pending    = payroll.filter(p => p.status !== 'paid').length;

  const cols = [
    { key:'emp_no', label:'Emp No.', width:120,
      render:(v,row) => <div><p style={{ fontFamily:'monospace', fontSize:12, color:'var(--primary)', fontWeight:600 }}>{v}</p><p style={{ fontSize:11, color:'var(--text-light)' }}>{row.designation}</p></div>
    },
    { key:'first_name', label:'Name', render:(v,row) => <span style={{ fontWeight:600 }}>{v} {row.last_name||''}</span> },
    { key:'days_worked', label:'Days', width:70, render:v => <span style={{ fontWeight:600 }}>{v}/26</span> },
    { key:'gross_salary', label:'Gross', width:120, render:v => <span style={{ fontWeight:600 }}>{fmtCurrency(v)}</span> },
    { key:'deductions',   label:'Deductions', width:120, render:v => <span style={{ color:'var(--danger)' }}>-{fmtCurrency(v)}</span> },
    { key:'net_salary',   label:'Net Salary', width:130, render:v => <span style={{ fontWeight:700, color:'var(--accent-green)', fontSize:14 }}>{fmtCurrency(v)}</span> },
    { key:'status', label:'Status', width:90, render:v => <Badge label={v} color={v==='paid'?'green':v==='processed'?'blue':'orange'} /> },
    { key:'id', label:'', width:110,
      render:(v,row) => (
        <div style={{ display:'flex', gap:4 }}>
          {row.status === 'processed' && <Btn size="sm" variant="success" onClick={e=>{e.stopPropagation();markPaid(v)}}>Pay</Btn>}
          <button className="icon-btn" title="Print Payslip" onClick={e=>{e.stopPropagation();printPayslip(row,month,year)}}>
            <i className="fa-solid fa-print"/>
          </button>
        </div>
      )
    },
  ];

  return (
    <div>
      <PageHeader title="Payroll" subtitle="Process monthly salaries and generate pay slips" icon="fa-money-bill-wave"
        actions={
          <>
            <Btn icon="fa-file-excel" variant="ghost" size="sm">Export</Btn>
            {pending > 0 && <Btn icon="fa-money-bill" variant="primary" loading={processing} onClick={processAll}>Process Payroll ({pending} pending)</Btn>}
          </>
        }
      />
      <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:12, marginBottom:16 }}>
        <StatMini label="Total Gross" value={fmtCurrency(totalGross,true)} icon="fa-money-bill-wave" color="#00A99D" />
        <StatMini label="Deductions"  value={fmtCurrency(totalDed,true)}   icon="fa-minus-circle"   color="#e53e3e" />
        <StatMini label="Net Payable" value={fmtCurrency(totalNet,true)}   icon="fa-circle-check"  color="#38a169" />
        <StatMini label="Pending"     value={pending}                      icon="fa-clock"          color="#F7941D" />
      </div>
      <Card>
        <div style={{ padding:'12px 16px', borderBottom:'1px solid var(--border)', display:'flex', gap:10 }}>
          <Select value={month} onChange={e => setMonth(e.target.value)} style={{ width:160 }}
            options={MONTHS.map((m,i) => ({ value:String(i+1), label:m }))} />
          <Select value={year} onChange={e => setYear(e.target.value)} style={{ width:100 }}
            options={['2024','2025','2026'].map(y => ({ value:y, label:y }))} />
        </div>
        <DataTable columns={cols} data={payroll} loading={loading} emptyText="No payroll records for this period" />
      </Card>
    </div>
  );
}
