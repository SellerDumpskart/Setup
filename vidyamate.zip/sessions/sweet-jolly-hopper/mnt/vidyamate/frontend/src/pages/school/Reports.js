import React, { useState } from 'react';
import { PageHeader, Btn, Card, Select, StatMini } from '../../components/common/Common';
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { useReports } from '../../hooks';
import { useSessionContext } from '../../store/sessionStore';
import { fmtCurrency } from '../../utils';
import { reportService } from '../../services';
import api from '../../services/api';
import toast from 'react-hot-toast';

const REPORT_CARDS = [
  { icon:'fa-users',            title:'Student Report',       desc:'Complete student list with class and status',    color:'#00A99D', type:'students' },
  { icon:'fa-calendar-check',   title:'Attendance Report',    desc:'Class-wise monthly attendance summary',          color:'#2196F3', type:'attendance' },
  { icon:'fa-credit-card',      title:'Fee Collection',       desc:'Fee collected, pending, mode-wise breakdown',   color:'#F7941D', type:'fee_collection' },
  { icon:'fa-file-pen',         title:'Exam Results',         desc:'Subject-wise marks, grades and rank list',      color:'#9C27B0', type:'results' },
  { icon:'fa-users-gear',       title:'Staff Report',         desc:'Staff directory with designation and contact',  color:'#38a169', type:'staff' },
  { icon:'fa-wallet',           title:'Expenditure Report',   desc:'School expenses by category and month',         color:'#e53e3e', type:'expenditure' },
  { icon:'fa-id-card',          title:'Hall Tickets',         desc:'Generate admit cards for exam students',        color:'#F7941D', type:'hall_tickets' },
  { icon:'fa-chart-bar',        title:'Analytics Overview',   desc:'School performance overview and trends',        color:'#00A99D', type:'overview' },
];

export default function Reports() {
  const { sessionId } = useSessionContext();
  const { overview, trend, feeReport, loading } = useReports(sessionId);
  const [exporting, setExporting] = useState({});

  const handleExport = async (type) => {
    setExporting(e => ({ ...e, [type]:true }));
    try {
      const { data } = await api.get(`/export/${type}`);
      toast.success(`${type} report ready — ${data.count} records`);
      if (data.url) window.open(data.url, '_blank');
    } catch (err) {
      toast.error(err.response?.data?.error || 'Export failed');
    } finally {
      setExporting(e => ({ ...e, [type]:false }));
    }
  };

  const trendData = trend.map(t => ({ month: t.month_label?.slice(0,6)||'', pct: parseFloat(t.percentage)||0 }));
  const feeMonthly = feeReport?.byMonth?.map(m => ({ month: m.month?.slice(0,6)||'', collected: parseFloat(m.collected)||0 })) || [];
  const feeByHead  = feeReport?.byHead  || [];
  const genderData = overview ? [
    { name:'Boys', value: parseInt(overview.students?.boys||0),  color:'#2196F3' },
    { name:'Girls',value: parseInt(overview.students?.girls||0), color:'#E91E8C' },
  ] : [];

  return (
    <div>
      <PageHeader title="Reports & Analytics" subtitle="Generate, export and analyse school data" icon="fa-chart-bar" />

      {/* Quick stats */}
      <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:12, marginBottom:20 }}>
        <StatMini label="Total Students" value={(parseInt(overview?.students?.total)||0).toLocaleString()} icon="fa-users"          color="#00A99D" />
        <StatMini label="Avg Attendance" value={trendData.length ? `${(trendData.reduce((s,t)=>s+t.pct,0)/trendData.length).toFixed(1)}%` : '—'} icon="fa-calendar-check" color="#2196F3" />
        <StatMini label="Fee Collected"  value={fmtCurrency(parseFloat(overview?.fees?.collected||0), true)} icon="fa-credit-card" color="#F7941D" />
        <StatMini label="Exams Done"     value={parseInt(overview?.exams?.completed||0)} icon="fa-graduation-cap" color="#38a169" />
      </div>

      {/* Charts */}
      {!loading && (
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:14, marginBottom:20 }}>
          {trendData.length > 0 && (
            <Card title="Attendance Trend" icon="fa-chart-line">
              <div style={{ padding:'0 16px 16px' }}>
                <ResponsiveContainer width="100%" height={200}>
                  <LineChart data={trendData}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0"/>
                    <XAxis dataKey="month" tick={{ fontSize:11 }} axisLine={false} tickLine={false}/>
                    <YAxis domain={[50,100]} tick={{ fontSize:10 }} axisLine={false} tickLine={false} tickFormatter={v=>`${v}%`}/>
                    <Tooltip formatter={v=>`${v}%`}/>
                    <Line type="monotone" dataKey="pct" stroke="#00A99D" strokeWidth={2.5} dot={{ fill:'#00A99D',r:4 }} name="Attendance %"/>
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </Card>
          )}

          {feeMonthly.length > 0 && (
            <Card title="Monthly Fee Collection" icon="fa-chart-bar">
              <div style={{ padding:'0 16px 16px' }}>
                <ResponsiveContainer width="100%" height={200}>
                  <BarChart data={feeMonthly} barSize={26}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0"/>
                    <XAxis dataKey="month" tick={{ fontSize:11 }} axisLine={false} tickLine={false}/>
                    <YAxis tickFormatter={v=>`${(v/1e5).toFixed(0)}L`} tick={{ fontSize:10 }} axisLine={false} tickLine={false}/>
                    <Tooltip formatter={v=>[fmtCurrency(v),'Collected']}/>
                    <Bar dataKey="collected" fill="#F7941D" radius={[4,4,0,0]} name="Collected"/>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </Card>
          )}

          {genderData[0]?.value > 0 && (
            <Card title="Gender Distribution" icon="fa-chart-pie">
              <div style={{ padding:'0 16px 16px', display:'flex', alignItems:'center', justifyContent:'center', gap:32 }}>
                <PieChart width={160} height={180}>
                  <Pie data={genderData} cx={80} cy={90} innerRadius={45} outerRadius={70} paddingAngle={4} dataKey="value">
                    {genderData.map((e,i) => <Cell key={i} fill={e.color}/>)}
                  </Pie>
                  <Tooltip/>
                </PieChart>
                <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
                  {genderData.map(d => (
                    <div key={d.name} style={{ display:'flex', alignItems:'center', gap:10 }}>
                      <div style={{ width:12, height:12, borderRadius:3, background:d.color }}/>
                      <div>
                        <p style={{ fontWeight:700, fontSize:18 }}>{d.value}</p>
                        <p style={{ fontSize:12, color:'var(--text-light)' }}>{d.name}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </Card>
          )}
        </div>
      )}

      {/* Report download cards */}
      <h3 style={{ fontSize:14, fontWeight:700, color:'var(--text-dark)', marginBottom:12 }}>Generate & Download Reports</h3>
      <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:12 }}>
        {REPORT_CARDS.map((r, i) => (
          <div key={i} style={{ background:'#fff', borderRadius:12, padding:16,
            border:'1.5px solid var(--border)', transition:'all .2s',
            display:'flex', flexDirection:'column', gap:10 }}
            onMouseEnter={e => e.currentTarget.style.borderColor = r.color}
            onMouseLeave={e => e.currentTarget.style.borderColor = 'var(--border)'}
          >
            <div style={{ width:42, height:42, borderRadius:10, background:`${r.color}18`,
              display:'flex', alignItems:'center', justifyContent:'center' }}>
              <i className={`fa-solid ${r.icon}`} style={{ color:r.color, fontSize:18 }}/>
            </div>
            <div>
              <p style={{ fontWeight:600, fontSize:13, color:'var(--text-dark)', marginBottom:2 }}>{r.title}</p>
              <p style={{ fontSize:11.5, color:'var(--text-light)', lineHeight:1.4 }}>{r.desc}</p>
            </div>
            <div style={{ display:'flex', gap:6, marginTop:'auto' }}>
              <Btn size="sm" variant="secondary"
                loading={exporting[r.type]}
                icon="fa-download"
                onClick={() => handleExport(r.type)}>
                Export
              </Btn>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
