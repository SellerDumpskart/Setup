import React, { useState, useEffect, useCallback } from 'react';
import { PageHeader, Btn, Select, Card, Modal } from '../../components/common/Common';
import { useClasses } from '../../hooks';
import { useSessionContext } from '../../store/sessionStore';
import api from '../../services/api';
import toast from 'react-hot-toast';

const DAYS = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];

const SUBJECT_COLORS = [
  '#2196F3','#00A99D','#9C27B0','#F7941D','#e53e3e','#38a169',
  '#1565C0','#6A1B9A','#E65100','#2E7D32','#0277BD','#AD1457',
];

const getSchoolId = () =>
  JSON.parse(localStorage.getItem('vidyamate-auth') || '{}')?.state?.user?.schoolId;

export default function Timetable() {
  const { sessionId } = useSessionContext();
  const { data: classesData } = useClasses(sessionId);
  const classes = classesData || [];

  const [selClassId, setClassId] = useState('');
  const [periods,    setPeriods]  = useState([]);
  const [subjects,   setSubjects] = useState([]);
  const [teachers,   setTeachers] = useState([]);
  const [tt,         setTT]       = useState({}); // key: "Day-periodId" → entry obj
  const [loadingTT,  setLoadingTT] = useState(false);
  const [editing,    setEditing]  = useState(null);
  const [editVal,    setEditVal]  = useState({ subjectId:'', teacherId:'', roomNo:'' });
  const [saving,     setSaving]   = useState(false);

  const subjectColorMap = {};
  subjects.forEach((s, i) => { subjectColorMap[s.id] = SUBJECT_COLORS[i % SUBJECT_COLORS.length]; });

  // Load reference data once
  useEffect(() => {
    const schoolId = getSchoolId();
    Promise.all([
      api.get('/timetable/periods', { params: { schoolId } }),
      api.get('/subjects',          { params: { schoolId } }),
      api.get('/staff',             { params: { schoolId, limit:200 } }),
    ]).then(([pRes, sRes, tRes]) => {
      setPeriods(pRes.data || []);
      setSubjects(sRes.data || []);
      const allStaff = tRes.data?.staff || tRes.data || [];
      setTeachers(allStaff.filter(t =>
        t.staff_type === 'teaching' || (t.designation||'').toLowerCase().includes('teacher')
      ));
    }).catch(() => {});
  }, []);

  // Set first class once classes load
  useEffect(() => {
    if (classes.length && !selClassId) setClassId(classes[0].id);
  }, [classes]);

  // Load timetable for selected class
  const loadTimetable = useCallback(async () => {
    if (!selClassId || !sessionId) return;
    setLoadingTT(true);
    try {
      const { data } = await api.get('/timetable', {
        params: { classId: selClassId, sessionId, schoolId: getSchoolId() }
      });
      const map = {};
      (data || []).forEach(e => {
        map[`${e.day_of_week}-${e.period_id}`] = {
          subjectId:   e.subject_id,
          subjectName: e.subject_name,
          teacherId:   e.teacher_id,
          teacherName: e.teacher_name,
          roomNo:      e.room_no,
          entryId:     e.id,
        };
      });
      setTT(map);
    } catch { setTT({}); }
    finally { setLoadingTT(false); }
  }, [selClassId, sessionId]);

  useEffect(() => { loadTimetable(); }, [loadTimetable]);

  // Fallback periods if API returns none
  const displayPeriods = periods.length > 0 ? periods : [
    { id:'p1', period_name:'Period 1', start_time:'08:30', end_time:'09:15', is_break:false },
    { id:'p2', period_name:'Period 2', start_time:'09:15', end_time:'10:00', is_break:false },
    { id:'p3', period_name:'Break',    start_time:'10:00', end_time:'10:15', is_break:true  },
    { id:'p4', period_name:'Period 3', start_time:'10:15', end_time:'11:00', is_break:false },
    { id:'p5', period_name:'Period 4', start_time:'11:00', end_time:'11:45', is_break:false },
    { id:'p6', period_name:'Lunch',    start_time:'11:45', end_time:'12:15', is_break:true  },
    { id:'p7', period_name:'Period 5', start_time:'12:15', end_time:'13:00', is_break:false },
    { id:'p8', period_name:'Period 6', start_time:'13:00', end_time:'13:45', is_break:false },
  ];

  const openEdit = (day, period) => {
    const key     = `${day}-${period.id}`;
    const existing = tt[key] || {};
    setEditing({ day, periodId: period.id, periodName: period.period_name, key });
    setEditVal({ subjectId: existing.subjectId || '', teacherId: existing.teacherId || '', roomNo: existing.roomNo || '' });
  };

  const saveEdit = async () => {
    if (!editVal.subjectId) { toast.error('Select a subject'); return; }
    setSaving(true);
    try {
      await api.post('/timetable', {
        schoolId:  getSchoolId(),
        classId:   selClassId,
        sessionId,
        periodId:  editing.periodId,
        dayOfWeek: editing.day,
        subjectId: editVal.subjectId,
        teacherId: editVal.teacherId || null,
        roomNo:    editVal.roomNo    || null,
      });
      const sub     = subjects.find(s => s.id === editVal.subjectId);
      const teacher = teachers.find(t => t.id === editVal.teacherId);
      setTT(prev => ({
        ...prev,
        [editing.key]: {
          subjectId:   editVal.subjectId,
          subjectName: sub?.subject_name || '',
          teacherId:   editVal.teacherId,
          teacherName: teacher ? `${teacher.first_name} ${teacher.last_name||''}`.trim() : '',
          roomNo:      editVal.roomNo,
        }
      }));
      toast.success('Slot saved');
      setEditing(null);
    } catch (err) {
      toast.error(err.response?.data?.error || 'Failed to save');
    } finally { setSaving(false); }
  };

  const clearSlot = async () => {
    const entry = tt[editing.key];
    if (entry?.entryId) {
      try { await api.delete(`/timetable/${entry.entryId}`); } catch { /* best effort */ }
    }
    setTT(prev => { const n = { ...prev }; delete n[editing.key]; return n; });
    toast.success('Slot cleared');
    setEditing(null);
  };

  return (
    <div>
      <PageHeader title="Timetable" subtitle="Assign subjects and teachers to class periods" icon="fa-table-cells"
        actions={
          <>
            <Btn icon="fa-print"  variant="ghost" size="sm" onClick={() => window.print()}>Print</Btn>
            <Btn icon="fa-rotate" variant="ghost" size="sm" onClick={loadTimetable} disabled={loadingTT}>Reload</Btn>
          </>
        }
      />

      <div style={{ display:'flex', gap:10, marginBottom:16, alignItems:'center', flexWrap:'wrap' }}>
        <Select value={selClassId} onChange={e => setClassId(e.target.value)} style={{ width:200 }}
          options={classes.map(c => ({ value:c.id, label:`Class ${c.class_name}-${c.section}` }))}
        />
        {loadingTT && <span style={{ fontSize:13, color:'var(--text-light)' }}>
          <i className="fa-solid fa-spinner fa-spin" style={{ marginRight:5 }}/>Loading…
        </span>}
        <span style={{ fontSize:12.5, color:'var(--text-light)' }}>
          Click any cell to assign · {subjects.length} subject{subjects.length !== 1 ? 's' : ''} · {teachers.length} teacher{teachers.length !== 1 ? 's' : ''} loaded
        </span>
      </div>

      <Card>
        <div style={{ overflowX:'auto' }}>
          <table style={{ width:'100%', borderCollapse:'collapse', minWidth:900 }}>
            <thead>
              <tr>
                <th style={{ ...TH, width:130, textAlign:'left' }}>Period / Day</th>
                {DAYS.map(d => <th key={d} style={TH}>{d}</th>)}
              </tr>
            </thead>
            <tbody>
              {displayPeriods.map(period => (
                <tr key={period.id} style={{ background: period.is_break ? '#fafafa' : '#fff' }}>
                  <td style={{ ...TD_PERIOD, background: period.is_break ? '#f4f6f9' : 'var(--primary-light)' }}>
                    <p style={{ fontWeight:600, fontSize:12.5, color: period.is_break ? 'var(--text-light)' : 'var(--primary-dark)' }}>
                      {period.period_name}
                    </p>
                    <p style={{ fontSize:10.5, color:'var(--text-light)' }}>
                      {period.start_time}{period.end_time ? ` – ${period.end_time}` : ''}
                    </p>
                  </td>
                  {DAYS.map(day => {
                    if (period.is_break) return (
                      <td key={day} style={{ ...TD, background:'#f4f6f9', textAlign:'center' }}>
                        <span style={{ fontSize:11, color:'var(--text-light)', fontStyle:'italic' }}>{period.period_name}</span>
                      </td>
                    );
                    const key   = `${day}-${period.id}`;
                    const entry = tt[key];
                    const color = entry ? (subjectColorMap[entry.subjectId] || '#888') : '#ccc';
                    return (
                      <td key={day} style={TD}>
                        <div
                          onClick={() => selClassId && openEdit(day, period)}
                          style={{
                            padding:'8px 10px', borderRadius:8,
                            cursor: selClassId ? 'pointer' : 'default',
                            background: entry ? `${color}18` : '#f8f9fa',
                            border:     `1.5px solid ${entry ? `${color}40` : '#e2e8f0'}`,
                            transition:'all .15s', minHeight:52,
                            display:'flex', flexDirection:'column', justifyContent:'center'
                          }}
                          onMouseEnter={e => { if(selClassId){ e.currentTarget.style.borderColor=color; e.currentTarget.style.background=`${color}25`; }}}
                          onMouseLeave={e => { e.currentTarget.style.borderColor=entry?`${color}40`:'#e2e8f0'; e.currentTarget.style.background=entry?`${color}18`:'#f8f9fa'; }}
                        >
                          {entry ? (
                            <>
                              <p style={{ fontWeight:600, fontSize:12, color, lineHeight:1.3 }}>{entry.subjectName}</p>
                              {entry.teacherName && <p style={{ fontSize:10.5, color:'var(--text-light)', marginTop:1 }}>{entry.teacherName}</p>}
                              {entry.roomNo      && <p style={{ fontSize:10, color:'#bbb' }}>Rm {entry.roomNo}</p>}
                            </>
                          ) : (
                            <p style={{ fontSize:11, color:'#ccc', textAlign:'center' }}>
                              <i className="fa-solid fa-plus" style={{ fontSize:10 }} /> Add
                            </p>
                          )}
                        </div>
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Legend */}
        <div style={{ padding:'12px 16px', borderTop:'1px solid var(--border)', display:'flex', flexWrap:'wrap', gap:8 }}>
          {subjects.slice(0,10).map((s,i) => (
            <div key={s.id} style={{ display:'flex', alignItems:'center', gap:5, fontSize:11.5 }}>
              <div style={{ width:10, height:10, borderRadius:2, background:SUBJECT_COLORS[i%SUBJECT_COLORS.length] }}/>
              <span style={{ color:'var(--text-mid)' }}>{s.subject_name}</span>
            </div>
          ))}
          {subjects.length === 0 && (
            <span style={{ fontSize:12, color:'var(--text-light)' }}>
              No subjects yet — add them in Subjects page first.
            </span>
          )}
        </div>
      </Card>

      {/* Edit Modal */}
      <Modal open={!!editing} onClose={() => setEditing(null)}
        title={editing ? `${editing.day} · ${editing.periodName}` : ''} size="sm"
        footer={
          <div style={{ display:'flex', gap:8, justifyContent:'space-between', width:'100%' }}>
            <Btn variant="ghost" size="sm" onClick={clearSlot} style={{ color:'#e53e3e' }}>
              <i className="fa-solid fa-trash" style={{ marginRight:5 }}/>Clear
            </Btn>
            <div style={{ display:'flex', gap:8 }}>
              <Btn variant="ghost" onClick={() => setEditing(null)}>Cancel</Btn>
              <Btn variant="primary" loading={saving} onClick={saveEdit}>
                <i className="fa-solid fa-floppy-disk" style={{ marginRight:5 }}/>Save
              </Btn>
            </div>
          </div>
        }
      >
        {editing && (
          <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
            <div>
              <label style={{ fontSize:12.5, fontWeight:600, color:'var(--text-mid)', marginBottom:5, display:'block' }}>
                Subject <span style={{ color:'#e53e3e' }}>*</span>
              </label>
              <select value={editVal.subjectId} onChange={e => setEditVal(v => ({ ...v, subjectId:e.target.value }))}
                style={{ width:'100%', padding:'9px 12px', borderRadius:8, fontSize:13, boxSizing:'border-box',
                  border:'1.5px solid var(--border)', fontFamily:'inherit', background:'#fff' }}>
                <option value="">Select subject</option>
                {subjects.map(s => <option key={s.id} value={s.id}>{s.subject_name}</option>)}
              </select>
            </div>
            <div>
              <label style={{ fontSize:12.5, fontWeight:600, color:'var(--text-mid)', marginBottom:5, display:'block' }}>Teacher</label>
              <select value={editVal.teacherId} onChange={e => setEditVal(v => ({ ...v, teacherId:e.target.value }))}
                style={{ width:'100%', padding:'9px 12px', borderRadius:8, fontSize:13, boxSizing:'border-box',
                  border:'1.5px solid var(--border)', fontFamily:'inherit', background:'#fff' }}>
                <option value="">— None —</option>
                {teachers.map(t => (
                  <option key={t.id} value={t.id}>
                    {t.first_name} {t.last_name||''}{t.designation ? ` · ${t.designation}` : ''}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label style={{ fontSize:12.5, fontWeight:600, color:'var(--text-mid)', marginBottom:5, display:'block' }}>Room No.</label>
              <input value={editVal.roomNo} onChange={e => setEditVal(v => ({ ...v, roomNo:e.target.value }))}
                placeholder="Optional — e.g. 12A"
                style={{ width:'100%', padding:'9px 12px', borderRadius:8, fontSize:13, boxSizing:'border-box',
                  border:'1.5px solid var(--border)', fontFamily:'inherit' }} />
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}

const TH = { padding:'10px 12px', textAlign:'center', fontSize:12, fontWeight:600, color:'var(--text-light)', textTransform:'uppercase', letterSpacing:'0.04em', background:'#f8fafb', borderBottom:'1px solid var(--border)', whiteSpace:'nowrap' };
const TD = { padding:'6px 8px', borderBottom:'1px solid #f7f7f7', verticalAlign:'middle' };
const TD_PERIOD = { padding:'8px 12px', borderBottom:'1px solid var(--border)', verticalAlign:'middle', whiteSpace:'nowrap' };
