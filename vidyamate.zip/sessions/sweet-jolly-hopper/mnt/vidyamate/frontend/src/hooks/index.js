import { useState, useEffect, useCallback } from 'react';
import api from '../services/api';
import toast from 'react-hot-toast';
import useAuthStore from '../store/authStore';

// ── Helper ─────────────────────────────────────────────────
const getSchoolId = () =>
  JSON.parse(localStorage.getItem('vidyamate-auth') || '{}')?.state?.user?.schoolId;

const getSessionId = () =>
  JSON.parse(localStorage.getItem('vidyamate-session') || 'null');

// ── Generic data fetcher hook ──────────────────────────────
export function useFetch(endpoint, params = {}, deps = []) {
  const [data,    setData]    = useState(null);
  const [loading, setLoading] = useState(true);
  const [error,   setError]   = useState(null);

  const fetch = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const { data: res } = await api.get(endpoint, { params });
      setData(res);
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to load data');
    } finally {
      setLoading(false);
    }
  }, [endpoint, JSON.stringify(params)]);

  useEffect(() => { fetch(); }, [...deps]);

  return { data, loading, error, refetch: fetch };
}

// ── DASHBOARD ──────────────────────────────────────────────
export function useDashboard(sessionId) {
  const schoolId = getSchoolId();
  return useFetch('/dashboard', { schoolId, sessionId }, [schoolId, sessionId]);
}

// ── STUDENTS ───────────────────────────────────────────────
export function useStudents({ search, classId, status = 'active', page = 1, limit = 50 } = {}) {
  const schoolId  = getSchoolId();
  const sessionId = getSessionId();
  const [students, setStudents] = useState([]);
  const [pagination, setPagination] = useState({ total: 0, page: 1, pages: 1 });
  const [loading, setLoading]   = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await api.get('/students', {
        params: { schoolId, sessionId, search, classId, status, page, limit }
      });
      setStudents(data.students || []);
      setPagination(data.pagination || { total: 0, page: 1, pages: 1 });
    } catch {
      setStudents([]);
    } finally { setLoading(false); }
  }, [schoolId, sessionId, search, classId, status, page]);

  useEffect(() => { load(); }, [load]);

  const create = async (formData) => {
    const { data } = await api.post('/students', { ...formData, schoolId, sessionId });
    toast.success('Student admitted successfully!');
    load();
    return data;
  };

  const update = async (id, formData) => {
    const { data } = await api.put(`/students/${id}`, formData);
    toast.success('Student updated');
    load();
    return data;
  };

  const remove = async (id, reason) => {
    await api.delete(`/students/${id}`, { data: { reason } });
    toast.success('Student record cancelled');
    load();
  };

  return { students, pagination, loading, refetch: load, create, update, remove };
}

// ── STAFF ──────────────────────────────────────────────────
export function useStaff({ search, staffType, status = 'active' } = {}) {
  const schoolId = getSchoolId();
  const [staff, setStaff] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await api.get('/staff', { params: { schoolId, search, staffType, status } });
      setStaff(data.staff || []);
    } catch { setStaff([]); }
    finally { setLoading(false); }
  }, [schoolId, search, staffType, status]);

  useEffect(() => { load(); }, [load]);

  const create = async (formData) => {
    const { data } = await api.post('/staff', { ...formData, schoolId });
    toast.success('Staff added');
    load();
    return data;
  };

  const update = async (id, formData) => {
    const { data } = await api.put(`/staff/${id}`, formData);
    toast.success('Staff updated');
    load();
    return data;
  };

  const resetPassword = async (id) => {
    await api.post(`/staff/${id}/reset-password`);
    toast.success('Password reset email sent');
  };

  return { staff, loading, refetch: load, create, update, resetPassword };
}

// ── CLASSES ────────────────────────────────────────────────
export function useClasses(sessionId) {
  const schoolId = getSchoolId();
  return useFetch('/classes', { schoolId, sessionId }, [schoolId, sessionId]);
}

// ── ATTENDANCE ─────────────────────────────────────────────
export function useAttendance(classId, date) {
  const schoolId  = getSchoolId();
  const sessionId = getSessionId();
  const [records, setRecords] = useState([]);
  const [stats,   setStats]   = useState({ total: 0, present: 0, absent: 0 });
  const [loading, setLoading] = useState(false);
  const [saving,  setSaving]  = useState(false);

  const load = useCallback(async () => {
    if (!classId || !date) return;
    setLoading(true);
    try {
      const { data } = await api.get('/attendance', { params: { schoolId, classId, date, sessionId } });
      setRecords(data.students || []);
      setStats(data.stats || { total: 0, present: 0, absent: 0 });
    } catch { setRecords([]); }
    finally { setLoading(false); }
  }, [schoolId, classId, date, sessionId]);

  useEffect(() => { load(); }, [load]);

  const markAll = useCallback(async (recordList) => {
    setSaving(true);
    try {
      await api.post('/attendance/mark', {
        records: recordList.map(r => ({ studentId: r.id, status: r.status, remarks: r.remarks })),
        classId, sessionId, date
      });
      toast.success(`Attendance saved for ${recordList.length} students`);
      load();
    } catch (err) {
      toast.error(err.response?.data?.error || 'Failed to save attendance');
    } finally { setSaving(false); }
  }, [classId, sessionId, date]);

  return { records, stats, loading, saving, refetch: load, markAll };
}

// ── FEES ───────────────────────────────────────────────────
export function useFees(sessionId) {
  const schoolId = getSchoolId();
  const [feeHeads, setFeeHeads] = useState([]);
  const [payments, setPayments] = useState([]);
  const [loading, setLoading]   = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [headsRes, paymentsRes] = await Promise.all([
        api.get('/fees/heads',    { params: { schoolId, sessionId } }),
        api.get('/fees/payments', { params: { schoolId } }),
      ]);
      setFeeHeads(headsRes.data || []);
      setPayments(paymentsRes.data || []);
    } catch { setFeeHeads([]); setPayments([]); }
    finally { setLoading(false); }
  }, [schoolId, sessionId]);

  useEffect(() => { load(); }, [load]);

  const collectPayment = async (paymentData) => {
    const { data } = await api.post('/fees/collect', { ...paymentData });
    toast.success(`Payment collected — Receipt: ${data.receiptNo}`);
    load();
    return data;
  };

  const applyDiscount = async (discountData) => {
    await api.post('/fees/discount', discountData);
    toast.success('Discount applied');
    load();
  };

  return { feeHeads, payments, loading, refetch: load, collectPayment, applyDiscount };
}

// ── EXAMS ──────────────────────────────────────────────────
export function useExams(sessionId) {
  const schoolId = getSchoolId();
  const [exams, setExams]   = useState([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await api.get('/exams', { params: { schoolId, sessionId } });
      setExams(data || []);
    } catch { setExams([]); }
    finally { setLoading(false); }
  }, [schoolId, sessionId]);

  useEffect(() => { load(); }, [load]);

  const create = async (examData) => {
    const { data } = await api.post('/exams', { ...examData, schoolId, sessionId });
    toast.success('Exam scheduled');
    load();
    return data;
  };

  const generateHallTickets = async (examId, classId) => {
    const { data } = await api.post('/exams/hall-tickets/generate', {
      examId, classId, schoolId: getSchoolId()
    });
    toast.success(`${data.tickets?.length || 0} hall tickets generated`);
    return data;
  };

  return { exams, loading, refetch: load, create, generateHallTickets };
}

// ── REPORTS ────────────────────────────────────────────────
export function useReports(sessionId) {
  const schoolId = getSchoolId();
  const [overview,  setOverview]  = useState(null);
  const [trend,     setTrend]     = useState([]);
  const [feeReport, setFeeReport] = useState(null);
  const [loading,   setLoading]   = useState(true);

  useEffect(() => {
    if (!sessionId) return;
    setLoading(true);
    Promise.all([
      api.get('/reports/overview',        { params: { schoolId, sessionId } }),
      api.get('/reports/attendance-trend', { params: { schoolId, sessionId } }),
      api.get('/reports/fee-collection',   { params: { schoolId, sessionId } }),
    ]).then(([ov, tr, fee]) => {
      setOverview(ov.data);
      setTrend(tr.data || []);
      setFeeReport(fee.data);
    }).catch(() => {})
      .finally(() => setLoading(false));
  }, [schoolId, sessionId]);

  return { overview, trend, feeReport, loading };
}

// ── MASTERS ────────────────────────────────────────────────
export function useMasters(type) {
  const { user } = useAuthStore();
  const orgId = user?.orgId;
  const [masters, setMasters] = useState({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!orgId) return;
    api.get('/masters', { params: { orgId, type } })
      .then(r => setMasters(r.data || {}))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [orgId, type]);

  const getList = (masterType) =>
    (masters[masterType] || []).map(m => ({ value: m.value, label: m.value }));

  return { masters, loading, getList };
}

// ── NOTIFICATIONS ──────────────────────────────────────────
export function useNotifications() {
  const [notifications, setNotifications] = useState([]);
  const [unreadCount,   setUnreadCount]   = useState(0);

  const load = useCallback(async () => {
    try {
      const { data } = await api.get('/notifications');
      setNotifications(data || []);
      setUnreadCount((data || []).filter(n => !n.is_read).length);
    } catch { /* silent */ }
  }, []);

  useEffect(() => {
    load();
    // Poll every 60 seconds
    const interval = setInterval(load, 60000);
    return () => clearInterval(interval);
  }, [load]);

  const markAllRead = async () => {
    await api.put('/notifications/read-all');
    setUnreadCount(0);
    load();
  };

  return { notifications, unreadCount, refetch: load, markAllRead };
}

// ── SESSION CONTEXT ────────────────────────────────────────
export function useSession() {
  const { user } = useAuthStore();
  const [sessions, setSessions] = useState([]);
  const [current,  setCurrent]  = useState(null);

  useEffect(() => {
    if (!user?.orgId) return;
    api.get('/sessions', { params: { orgId: user.orgId } })
      .then(r => {
        const list = r.data || [];
        setSessions(list);
        const cur = list.find(s => s.is_current);
        setCurrent(cur);
        if (cur) localStorage.setItem('vidyamate-session', JSON.stringify(cur.id));
      }).catch(() => {});
  }, [user?.orgId]);

  return { sessions, current, sessionId: current?.id };
}
