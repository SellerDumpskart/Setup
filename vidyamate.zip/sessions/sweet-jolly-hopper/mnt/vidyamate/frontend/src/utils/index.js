// ══════════════════════════════════════════════════════════
// FORMATTERS
// ══════════════════════════════════════════════════════════

export const fmtCurrency = (n, compact = false) => {
  const num = parseFloat(n) || 0;
  if (compact) {
    if (num >= 1e7) return `₹${(num / 1e7).toFixed(2)}Cr`;
    if (num >= 1e5) return `₹${(num / 1e5).toFixed(2)}L`;
    if (num >= 1e3) return `₹${(num / 1e3).toFixed(1)}K`;
    return `₹${num.toLocaleString('en-IN')}`;
  }
  return `₹${num.toLocaleString('en-IN', { minimumFractionDigits: 0, maximumFractionDigits: 2 })}`;
};

export const fmtDate = (d, opts) => {
  if (!d) return '—';
  return new Date(d).toLocaleDateString('en-IN', opts || { day: '2-digit', month: 'short', year: 'numeric' });
};

export const fmtDateTime = (d) => {
  if (!d) return '—';
  return new Date(d).toLocaleString('en-IN', {
    day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit'
  });
};

export const fmtRelative = (d) => {
  if (!d) return '—';
  const diff = Date.now() - new Date(d).getTime();
  const min  = Math.floor(diff / 60000);
  const hr   = Math.floor(diff / 3600000);
  const day  = Math.floor(diff / 86400000);
  if (min < 1)  return 'Just now';
  if (min < 60) return `${min}m ago`;
  if (hr < 24)  return `${hr}h ago`;
  if (day < 7)  return `${day}d ago`;
  return fmtDate(d);
};

export const fmtName = (first, last) =>
  [first, last].filter(Boolean).join(' ') || '—';

export const fmtPercent = (val, total) => {
  if (!total) return '0%';
  return `${((val / total) * 100).toFixed(1)}%`;
};

export const fmtPhone = (phone) => {
  if (!phone) return '—';
  const clean = phone.replace(/\D/g, '');
  if (clean.length === 10) return `${clean.slice(0,5)}-${clean.slice(5)}`;
  return phone;
};

// ══════════════════════════════════════════════════════════
// VALIDATORS
// ══════════════════════════════════════════════════════════

export const validators = {
  required: (v) => (!v || String(v).trim() === '') ? 'This field is required' : '',
  phone: (v) => {
    if (!v) return 'Phone number required';
    return /^[6-9]\d{9}$/.test(v.replace(/\D/g, '')) ? '' : 'Enter valid 10-digit mobile number';
  },
  email: (v) => {
    if (!v) return '';
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v) ? '' : 'Enter valid email address';
  },
  aadhaar: (v) => {
    if (!v) return '';
    return /^\d{12}$/.test(v.replace(/\s/g, '')) ? '' : 'Aadhaar must be 12 digits';
  },
  pincode: (v) => {
    if (!v) return '';
    return /^\d{6}$/.test(v) ? '' : 'Pincode must be 6 digits';
  },
  minLength: (min) => (v) =>
    (!v || v.length < min) ? `Must be at least ${min} characters` : '',
  maxLength: (max) => (v) =>
    (v && v.length > max) ? `Must be at most ${max} characters` : '',
  positiveNumber: (v) =>
    (!v || parseFloat(v) <= 0) ? 'Must be a positive number' : '',
  dateNotFuture: (v) =>
    (v && new Date(v) > new Date()) ? 'Date cannot be in the future' : '',
};

export const validateForm = (rules, values) => {
  const errors = {};
  for (const [field, fieldRules] of Object.entries(rules)) {
    const ruleList = Array.isArray(fieldRules) ? fieldRules : [fieldRules];
    for (const rule of ruleList) {
      const err = rule(values[field]);
      if (err) { errors[field] = err; break; }
    }
  }
  return errors;
};

// ══════════════════════════════════════════════════════════
// GRADE CALCULATOR
// ══════════════════════════════════════════════════════════

export const calcGrade = (marks, maxMarks = 100) => {
  const pct = (marks / maxMarks) * 100;
  if (pct >= 90) return { grade: 'A+', color: '#38a169', bg: '#e6f4ea' };
  if (pct >= 80) return { grade: 'A',  color: '#38a169', bg: '#e6f4ea' };
  if (pct >= 70) return { grade: 'B+', color: '#2196F3', bg: '#e8f1fd' };
  if (pct >= 60) return { grade: 'B',  color: '#2196F3', bg: '#e8f1fd' };
  if (pct >= 50) return { grade: 'C',  color: '#F7941D', bg: '#fff3e0' };
  if (pct >= 35) return { grade: 'D',  color: '#F7941D', bg: '#fff3e0' };
  return { grade: 'F', color: '#e53e3e', bg: '#fde8e8' };
};

export const calcAttendanceStatus = (pct) => {
  if (pct >= 75) return { label: 'Regular', color: '#38a169' };
  if (pct >= 60) return { label: 'Warning',  color: '#F7941D' };
  return { label: 'Shortage', color: '#e53e3e' };
};

// ══════════════════════════════════════════════════════════
// EXCEL EXPORT
// ══════════════════════════════════════════════════════════

export const exportToCSV = (data, filename, columns) => {
  if (!data?.length) return;

  const headers = columns.map(c => c.label || c.key).join(',');
  const rows = data.map(row =>
    columns.map(c => {
      const val = row[c.key];
      if (val === null || val === undefined) return '';
      const str = String(val).replace(/"/g, '""');
      return str.includes(',') || str.includes('\n') ? `"${str}"` : str;
    }).join(',')
  ).join('\n');

  const csv  = `${headers}\n${rows}`;
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url  = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href     = url;
  link.download = `${filename}_${new Date().toISOString().split('T')[0]}.csv`;
  link.click();
  URL.revokeObjectURL(url);
};

// ══════════════════════════════════════════════════════════
// PRINT
// ══════════════════════════════════════════════════════════

export const printElement = (elementId, title = 'Print') => {
  const el = document.getElementById(elementId);
  if (!el) return;
  const win = window.open('', '_blank');
  win.document.write(`
    <html><head><title>${title}</title>
    <style>
      body { font-family: Arial, sans-serif; font-size: 12px; }
      table { width:100%; border-collapse:collapse; }
      th,td { border:1px solid #ccc; padding:6px 10px; text-align:left; }
      th { background:#00A99D; color:#fff; }
      .no-print { display:none; }
      @media print { .no-print { display:none !important; } }
    </style>
    </head><body>${el.innerHTML}</body></html>
  `);
  win.document.close();
  win.print();
  win.close();
};

// ══════════════════════════════════════════════════════════
// LOCAL STORAGE HELPERS
// ══════════════════════════════════════════════════════════

export const storage = {
  get: (key, fallback = null) => {
    try { return JSON.parse(localStorage.getItem(key)) ?? fallback; }
    catch { return fallback; }
  },
  set: (key, value) => {
    try { localStorage.setItem(key, JSON.stringify(value)); }
    catch { /* quota exceeded */ }
  },
  remove: (key) => localStorage.removeItem(key),
};

// ══════════════════════════════════════════════════════════
// CONSTANTS
// ══════════════════════════════════════════════════════════

export const CLASSES = ['I','II','III','IV','V','VI','VII','VIII','IX','X','XI','XII'];
export const SECTIONS = ['A','B','C','D','E'];
export const BLOOD_GROUPS = ['A+','A-','B+','B-','AB+','AB-','O+','O-'];
export const RELIGIONS = ['Hindu','Muslim','Christian','Sikh','Buddhist','Jain','Other'];
export const CATEGORIES = ['General','OBC','SC','ST','EWS','Minority'];
export const GENDERS = [{ value:'male', label:'Male' }, { value:'female', label:'Female' }, { value:'other', label:'Other' }];
export const OCCUPATIONS = ['Government Employee','Private Employee','Business','Farmer','Doctor','Engineer','Teacher','Retired','Labour','Housewife','Other'];
export const STATES = ['Andhra Pradesh','Telangana','Karnataka','Tamil Nadu','Maharashtra','Gujarat','Rajasthan','Uttar Pradesh','Delhi','Kerala','Odisha','West Bengal','Bihar','Punjab','Haryana'];
export const PAYMENT_MODES = [
  { value:'cash',   label:'Cash' },
  { value:'online', label:'Online Transfer' },
  { value:'upi',    label:'UPI' },
  { value:'cheque', label:'Cheque' },
  { value:'neft',   label:'NEFT/IMPS' },
  { value:'card',   label:'Card' },
];
export const STAFF_TYPES = [
  { value:'teaching',     label:'Teaching Staff' },
  { value:'non_teaching', label:'Non-Teaching Staff' },
  { value:'support',      label:'Support Staff' },
  { value:'admin',        label:'Admin' },
];
export const ROLES = [
  { value:'super_admin',  label:'Super Admin' },
  { value:'org_admin',    label:'Organization Admin' },
  { value:'principal',    label:'Principal' },
  { value:'teacher',      label:'Teacher' },
  { value:'accountant',   label:'Accountant' },
  { value:'non_teaching', label:'Non-Teaching Staff' },
];
export const DAYS = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
export const MONTHS = ['January','February','March','April','May','June','July','August','September','October','November','December'];
export const FEE_TYPES = ['tuition','bus','hostel','exam','library','sports','other'];
export const LEAVE_TYPES = ['Sick Leave','Casual Leave','Earned Leave','Medical Leave','Maternity Leave','Emergency Leave','Privilege Leave'];
export const NOTICE_TYPES = ['general','exam','fee','holiday','urgent','circular'];
export const EXAM_TYPES = ['unit_test','midterm','final','quarterly','half_yearly','annual','other'];

// Status badge color mappings
export const STATUS_COLORS = {
  active: 'green', inactive: 'red', pending: 'orange', approved: 'green',
  rejected: 'red', paid: 'green', partial: 'orange', overdue: 'red',
  draft: 'gray', published: 'green', scheduled: 'orange', completed: 'green',
  cancelled: 'gray', ongoing: 'blue', transferred: 'blue', alumni: 'purple',
};
