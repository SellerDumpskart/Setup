import axios from 'axios';

const api = axios.create({
  baseURL: '/api/v1',
  timeout: 15000,
});

// Attach access token to every request
api.interceptors.request.use((config) => {
  // Read directly from localStorage to avoid circular imports
  const stored = JSON.parse(localStorage.getItem('vidyamate-auth') || '{}');
  const token = stored?.state?.accessToken;
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// On 401 → try refresh token, retry once
api.interceptors.response.use(
  (res) => res,
  async (err) => {
    const original = err.config;
    if (err.response?.status === 401 && !original._retry) {
      original._retry = true;
      try {
        const stored = JSON.parse(localStorage.getItem('vidyamate-auth') || '{}');
        const refreshToken = stored?.state?.refreshToken;
        if (!refreshToken) throw new Error('No refresh token');

        const { data } = await axios.post('/api/v1/auth/refresh', { refreshToken });

        // Update store
        const state = JSON.parse(localStorage.getItem('vidyamate-auth'));
        state.state.accessToken = data.accessToken;
        state.state.refreshToken = data.refreshToken;
        localStorage.setItem('vidyamate-auth', JSON.stringify(state));

        original.headers.Authorization = `Bearer ${data.accessToken}`;
        return api(original);
      } catch (_) {
        // Refresh failed - clear auth and redirect to login
        localStorage.removeItem('vidyamate-auth');
        window.location.href = '/login';
      }
    }
    return Promise.reject(err);
  }
);

export default api;
