import api from './api';

const schoolId = () =>
  JSON.parse(localStorage.getItem('vidyamate-auth') || '{}')?.state?.user?.schoolId;

const sessionId = () =>
  JSON.parse(localStorage.getItem('vidyamate-session') || 'null');

// ── AUTH ───────────────────────────────────────────────────
export const authService = {
  login:          (email, password) => api.post('/auth/login', { email, password }),
  refresh:        (refreshToken)    => api.post('/auth/refresh', { refreshToken }),
  logout:         ()                => api.post('/auth/logout'),
  me:             ()                => api.get('/auth/me'),
  changePassword: (currentPassword, newPassword) =>
                    api.post('/auth/change-password', { currentPassword, newPassword }),
};

// ── DASHBOARD ──────────────────────────────────────────────
export const dashboardService = {
  get: (params = {}) => api.get('/dashboard', { params: { schoolId: schoolId(), sessionId: sessionId(), ...params } }),
};

// ── ORGANIZATIONS ──────────────────────────────────────────
export const orgService = {
  list:   (params = {})    => api.get('/organizations', { params }),
  create: (data)           => api.post('/organizations', data),
  update: (id, data)       => api.put(`/organizations/${id}`, data),
  remove: (id)             => api.delete(`/organizations/${id}`),
};

// ── SCHOOLS ────────────────────────────────────────────────
export const schoolService = {
  list:   (orgId, params = {}) => api.get('/schools', { params: { orgId, ...params } }),
  create: (data)               => api.post('/schools', data),
  update: (id, data)           => api.put(`/schools/${id}`, data),
};

// ── SESSIONS ───────────────────────────────────────────────
export const sessionService = {
  list:       (orgId)    => api.get('/sessions', { params: { orgId } }),
  create:     (data)     => api.post('/sessions', data),
  setCurrent: (id)       => api.put(`/sessions/${id}/set-current`),
};

// ── MASTERS ────────────────────────────────────────────────
export const masterService = {
  list:   (orgId, type)  => api.get('/masters', { params: { orgId, type } }),
  create: (data)         => api.post('/masters', data),
  update: (id, data)     => api.put(`/masters/${id}`, data),
  remove: (id)           => api.delete(`/masters/${id}`),
};

// ── USERS ──────────────────────────────────────────────────
export const userService = {
  list:          (params = {})    => api.get('/users', { params }),
  create:        (data)           => api.post('/users', data),
  update:        (id, data)       => api.put(`/users/${id}`, data),
  resetPassword: (id, newPassword) => api.post(`/users/${id}/reset-password`, { newPassword }),
};

// ── STAFF ──────────────────────────────────────────────────
export const staffService = {
  list:          (params = {})     => api.get('/staff', { params: { schoolId: schoolId(), ...params } }),
  get:           (id)              => api.get(`/staff/${id}`),
  create:        (data)            => api.post('/staff', { ...data, schoolId: schoolId() }),
  update:        (id, data)        => api.put(`/staff/${id}`, data),
  remove:        (id)              => api.delete(`/staff/${id}`),
  resetPassword: (id, newPassword) => api.post(`/staff/${id}/reset-password`, { newPassword }),
};

// ── STUDENTS ───────────────────────────────────────────────
export const studentService = {
  list:   (params = {})  => api.get('/students', { params: { schoolId: schoolId(), sessionId: sessionId(), ...params } }),
  get:    (id)           => api.get(`/students/${id}`),
  create: (data)         => api.post('/students', { ...data, schoolId: schoolId(), sessionId: sessionId() }),
  update: (id, data)     => api.put(`/students/${id}`, data),
  remove: (id, reason)   => api.delete(`/students/${id}`, { data: { reason } }),
};

// ── CLASSES ────────────────────────────────────────────────
export const classService = {
  list:          () => api.get('/classes', { params: { schoolId: schoolId(), sessionId: sessionId() } }),
  create:        (data) => api.post('/classes', { ...data, schoolId: schoolId(), sessionId: sessionId() }),
  getSubjects:   (id) => api.get(`/classes/${id}/subjects`),
  addSubject:    (id, data) => api.post(`/classes/${id}/subjects`, data),
};

// ── SUBJECTS ───────────────────────────────────────────────
export const subjectService = {
  list:   () => api.get('/subjects', { params: { schoolId: schoolId() } }),
  create: (data) => api.post('/subjects', { ...data, schoolId: schoolId() }),
  update: (id, data) => api.put(`/subjects/${id}`, data),
};

// ── ATTENDANCE ─────────────────────────────────────────────
export const attendanceService = {
  get:    (classId, date) => api.get('/attendance', { params: { schoolId: schoolId(), classId, date, sessionId: sessionId() } }),
  mark:   (records, classId, date) => api.post('/attendance/mark', { records, classId, date, sessionId: sessionId() }),
  report: (classId, month, year)   => api.get('/attendance/report', { params: { schoolId: schoolId(), classId, month, year, sessionId: sessionId() } }),
  summary:(date) => api.get('/attendance/summary', { params: { schoolId: schoolId(), date, sessionId: sessionId() } }),
};

// ── FEES ───────────────────────────────────────────────────
export const feeService = {
  heads:        () => api.get('/fees/heads',    { params: { schoolId: schoolId(), sessionId: sessionId() } }),
  createHead:   (data) => api.post('/fees/heads', { ...data, schoolId: schoolId(), sessionId: sessionId() }),
  studentFees:  (studentId) => api.get(`/fees/student/${studentId}`, { params: { sessionId: sessionId() } }),
  collect:      (data) => api.post('/fees/collect', data),
  payments:     (params = {}) => api.get('/fees/payments', { params: { schoolId: schoolId(), ...params } }),
  discount:     (data) => api.post('/fees/discount', data),
  defaulters:   () => api.get('/fees/defaulters', { params: { schoolId: schoolId(), sessionId: sessionId() } }),
};

// ── EXAMS ──────────────────────────────────────────────────
export const examService = {
  list:             () => api.get('/exams', { params: { schoolId: schoolId(), sessionId: sessionId() } }),
  create:           (data) => api.post('/exams', { ...data, schoolId: schoolId(), sessionId: sessionId() }),
  update:           (id, data) => api.put(`/exams/${id}`, data),
  schedule:         (id) => api.get(`/exams/${id}/schedule`),
  setSchedule:      (id, data) => api.post(`/exams/${id}/schedule`, data),
  results:          (params) => api.get('/exams/results', { params }),
  enterMarks:       (data) => api.post('/exams/results/enter', { ...data, sessionId: sessionId() }),
  generateTickets:  (examId, classId) => api.post('/exams/hall-tickets/generate', { examId, classId, schoolId: schoolId() }),
  hallTickets:      (examId, classId) => api.get('/exams/hall-tickets', { params: { examId, classId } }),
};

// ── EXPENDITURE ────────────────────────────────────────────
export const expenditureService = {
  list:   (params = {}) => api.get('/expenditure', { params: { schoolId: schoolId(), sessionId: sessionId(), ...params } }),
  create: (data)        => api.post('/expenditure', { ...data, schoolId: schoolId(), sessionId: sessionId() }),
  update: (id, data)    => api.put(`/expenditure/${id}`, data),
  remove: (id)          => api.delete(`/expenditure/${id}`),
};

// ── PAYROLL ────────────────────────────────────────────────
export const payrollService = {
  list:     (month, year) => api.get('/payroll', { params: { schoolId: schoolId(), sessionId: sessionId(), month, year } }),
  process:  (month, year) => api.post('/payroll/process', { schoolId: schoolId(), sessionId: sessionId(), month, year }),
  markPaid: (id, mode)    => api.put(`/payroll/${id}/mark-paid`, { paymentMode: mode }),
};

// ── LEAVE ──────────────────────────────────────────────────
export const leaveService = {
  list:    (params = {}) => api.get('/leave', { params: { schoolId: schoolId(), ...params } }),
  create:  (data)        => api.post('/leave', { ...data, schoolId: schoolId() }),
  approve: (id)          => api.put(`/leave/${id}/approve`),
  reject:  (id, remarks) => api.put(`/leave/${id}/reject`, { remarks }),
};

// ── HOSTEL ─────────────────────────────────────────────────
export const hostelService = {
  list:     ()            => api.get('/hostel', { params: { schoolId: schoolId() } }),
  rooms:    (hostelId)    => api.get(`/hostel/${hostelId}/rooms`),
  allocate: (data)        => api.post('/hostel/allocate', { ...data, sessionId: sessionId() }),
};

// ── HOLIDAYS ───────────────────────────────────────────────
export const holidayService = {
  list:   (params = {}) => api.get('/holidays', { params: { schoolId: schoolId(), sessionId: sessionId(), ...params } }),
  create: (data)        => api.post('/holidays', { ...data, schoolId: schoolId(), sessionId: sessionId() }),
  update: (id, data)    => api.put(`/holidays/${id}`, data),
  remove: (id)          => api.delete(`/holidays/${id}`),
};

// ── NOTICES ────────────────────────────────────────────────
export const noticeService = {
  list:   (params = {}) => api.get('/notices', { params: { schoolId: schoolId(), ...params } }),
  create: (data)        => api.post('/notices', { ...data, schoolId: schoolId(), sessionId: sessionId() }),
  remove: (id)          => api.delete(`/notices/${id}`),
};

// ── REPORTS ────────────────────────────────────────────────
export const reportService = {
  overview:         () => api.get('/reports/overview',         { params: { schoolId: schoolId(), sessionId: sessionId() } }),
  attendanceTrend:  () => api.get('/reports/attendance-trend', { params: { schoolId: schoolId(), sessionId: sessionId() } }),
  feeCollection:    () => api.get('/reports/fee-collection',   { params: { schoolId: schoolId(), sessionId: sessionId() } }),
  classStrength:    () => api.get('/reports/class-strength',   { params: { schoolId: schoolId(), sessionId: sessionId() } }),
  topPerformers:    (examId, classId) => api.get('/reports/top-performers', { params: { schoolId: schoolId(), sessionId: sessionId(), examId, classId } }),
  expenditure:      () => api.get('/reports/expenditure',      { params: { schoolId: schoolId(), sessionId: sessionId() } }),
};

// ── TIMETABLE ──────────────────────────────────────────────
export const timetableService = {
  periods:  ()           => api.get('/timetable/periods', { params: { schoolId: schoolId() } }),
  setPeriod:(data)       => api.post('/timetable/periods', { ...data, schoolId: schoolId() }),
  get:      (classId)    => api.get('/timetable', { params: { schoolId: schoolId(), classId, sessionId: sessionId() } }),
  save:     (data)       => api.post('/timetable', { ...data, schoolId: schoolId(), sessionId: sessionId() }),
  remove:   (id)         => api.delete(`/timetable/${id}`),
};

// ── LMS ────────────────────────────────────────────────────
export const lmsService = {
  content:       (params = {})  => api.get('/lms/content',  { params: { schoolId: schoolId(), sessionId: sessionId(), ...params } }),
  createContent: (data)         => api.post('/lms/content', { ...data, schoolId: schoolId() }),
  publish:       (id)           => api.put(`/lms/content/${id}/publish`),
  submit:        (data)         => api.post('/lms/content/submit', data),
  grade:         (id, data)     => api.put(`/lms/submissions/${id}/grade`, data),
  classes:       ()             => api.get('/lms/classes', { params: { schoolId: schoolId() } }),
  scheduleClass: (data)         => api.post('/lms/classes', { ...data, schoolId: schoolId() }),
};

// ── TEACHER DESK ───────────────────────────────────────────
export const teacherDeskService = {
  homework:      () => api.get('/teacher-desk/homework', { params: { schoolId: schoolId() } }),
  addHomework:   (data) => api.post('/teacher-desk/homework', { ...data, schoolId: schoolId(), sessionId: sessionId() }),
  diary:         () => api.get('/teacher-desk/diary', { params: { schoolId: schoolId() } }),
  writeDiary:    (data) => api.post('/teacher-desk/diary', { ...data, schoolId: schoolId() }),
  enterMarks:    (data) => api.post('/teacher-desk/marks', { ...data, sessionId: sessionId() }),
};

// ── COMMUNICATION ──────────────────────────────────────────
export const commService = {
  templates:       ()            => api.get('/school-communication/templates', { params: { schoolId: schoolId() } }),
  addTemplate:     (data)        => api.post('/school-communication/templates', { ...data, schoolId: schoolId() }),
  broadcasts:      ()            => api.get('/school-communication/broadcasts', { params: { schoolId: schoolId() } }),
  send:            (data)        => api.post('/school-communication/broadcasts', { ...data, schoolId: schoolId() }),
  messages:        (params = {}) => api.get('/school-communication/messages', { params: { schoolId: schoolId(), ...params } }),
  sendMessage:     (data)        => api.post('/school-communication/messages', { ...data, schoolId: schoolId() }),
  markRead:        (parentId)    => api.put(`/school-communication/messages/${parentId}/read`),
  logs:            (params = {}) => api.get('/school-communication/logs', { params: { schoolId: schoolId(), ...params } }),
};

// ── NOTIFICATIONS ──────────────────────────────────────────
export const notificationService = {
  list:       ()   => api.get('/notifications'),
  markRead:   (id) => api.put(`/notifications/${id}/read`),
  markAllRead:()   => api.put('/notifications/read-all'),
};
