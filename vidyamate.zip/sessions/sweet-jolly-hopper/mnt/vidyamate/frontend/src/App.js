import React, { Suspense, lazy } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import useAuthStore from './store/authStore';
import { SessionProvider } from './store/sessionStore';
import SchoolLayout from './components/layout/SchoolLayout';
import AdminLayout  from './components/layout/AdminLayout';
import LoginPage      from './pages/auth/LoginPage';
import ForgotPassword from './pages/auth/ForgotPassword';
import ResetPassword  from './pages/auth/ResetPassword';
import ErrorBoundary  from './components/ErrorBoundary';
import { NotFound, Unauthorized } from './pages/NotFound';

// School pages
const Dashboard       = lazy(() => import('./pages/school/Dashboard'));
const Students        = lazy(() => import('./pages/school/Students'));
const StudentForm     = lazy(() => import('./pages/school/StudentForm'));
const StaffList       = lazy(() => import('./pages/school/StaffList'));
const Attendance      = lazy(() => import('./pages/school/Attendance'));
const Settings        = lazy(() => import('./pages/school/Settings'));
const Subjects        = lazy(() => import('./pages/school/Subjects'));
const Classes         = lazy(() => import('./pages/school/Classes'));
const Fees            = lazy(() => import('./pages/school/Fees'));
const Expenditure     = lazy(() => import('./pages/school/Expenditure'));
const Exams           = lazy(() => import('./pages/school/Exams'));
const HallTickets     = lazy(() => import('./pages/school/HallTickets'));
const Results         = lazy(() => import('./pages/school/Results'));
const Hostel          = lazy(() => import('./pages/school/Hostel'));
const Reports         = lazy(() => import('./pages/school/Reports'));
const Notices         = lazy(() => import('./pages/school/Notices'));
const Payroll         = lazy(() => import('./pages/school/Payroll'));
const Leave           = lazy(() => import('./pages/school/Leave'));
const HolidayMaster   = lazy(() => import('./pages/school/HolidayMaster'));
const RollNumbers     = lazy(() => import('./pages/school/RollNumbers'));
const Timetable       = lazy(() => import('./pages/school/Timetable'));
const LMS             = lazy(() => import('./pages/school/LMS'));
const TeacherDesk     = lazy(() => import('./pages/school/TeacherDesk'));
const Communication   = lazy(() => import('./pages/school/SchoolCommunication'));
const Transport         = lazy(() => import('./pages/school/Transport'));
const BiometricDevices  = lazy(() => import('./pages/school/BiometricDevices'));

// Admin pages
const AdminDashboard    = lazy(() => import('./pages/admin/AdminDashboard'));
const Organizations     = lazy(() => import('./pages/admin/Organizations'));
const SchoolReg         = lazy(() => import('./pages/admin/SchoolRegistration'));
const Sessions          = lazy(() => import('./pages/admin/Sessions'));
const Masters           = lazy(() => import('./pages/admin/Masters'));
const Users             = lazy(() => import('./pages/admin/Users'));

const Spinner = () => (
  <div style={{ display:'flex', alignItems:'center', justifyContent:'center',
    height:'100vh', flexDirection:'column', gap:12, color:'#718096' }}>
    <div style={{ width:36, height:36, border:'3px solid #e2e8f0',
      borderTopColor:'#00A99D', borderRadius:'50%',
      animation:'spin 0.8s linear infinite' }} />
    <p style={{ fontSize:13 }}>Loading...</p>
    <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
  </div>
);

const Protected = ({ children, roles }) => {
  const { isAuthenticated, user } = useAuthStore();
  if (!isAuthenticated) return <Navigate to="/login" replace />;
  if (roles && !roles.includes(user?.role)) return <Navigate to="/school" replace />;
  return children;
};

export default function App() {
  const { user, isAuthenticated } = useAuthStore();

  return (
    <ErrorBoundary>
    <SessionProvider>
    <BrowserRouter>
      <Toaster position="top-right" toastOptions={{ duration: 3000 }} />
      <Suspense fallback={<Spinner />}>
        <Routes>
          <Route path="/login"          element={<LoginPage />} />
          <Route path="/forgot-password" element={<ForgotPassword />} />
          <Route path="/reset-password"  element={<ResetPassword />} />

          {/* Admin */}
          <Route path="/admin" element={
            <Protected roles={['super_admin','org_admin']}>
              <AdminLayout />
            </Protected>
          }>
            <Route index element={<AdminDashboard />} />
            <Route path="organizations" element={<Organizations />} />
            <Route path="schools"       element={<SchoolReg />} />
            <Route path="sessions"      element={<Sessions />} />
            <Route path="masters"       element={<Masters />} />
            <Route path="users"         element={<Users />} />
          </Route>

          {/* School */}
          <Route path="/school" element={
            <Protected><SchoolLayout /></Protected>
          }>
            <Route index                     element={<Dashboard />} />
            <Route path="students"           element={<Students />} />
            <Route path="students/new"       element={<StudentForm />} />
            <Route path="students/:id"       element={<StudentForm />} />
            <Route path="staff"              element={<StaffList />} />
            <Route path="attendance"         element={<Attendance />} />
            <Route path="fees"               element={<Fees />} />
            <Route path="expenditure"        element={<Expenditure />} />
            <Route path="exams"              element={<Exams />} />
            <Route path="hall-tickets"       element={<HallTickets />} />
            <Route path="results"            element={<Results />} />
            <Route path="hostel"             element={<Hostel />} />
            <Route path="reports"            element={<Reports />} />
            <Route path="notices"            element={<Notices />} />
            <Route path="payroll"            element={<Payroll />} />
            <Route path="leave"              element={<Leave />} />
            <Route path="holidays"           element={<HolidayMaster />} />
            <Route path="roll-numbers"       element={<RollNumbers />} />
            <Route path="timetable"          element={<Timetable />} />
            <Route path="lms"                element={<LMS />} />
            <Route path="teacher-desk"       element={<TeacherDesk />} />
            <Route path="communication"      element={<Communication />} />
            <Route path="transport"          element={<Transport />} />
            <Route path="biometric"          element={<BiometricDevices />} />
            <Route path="settings"           element={<Settings />} />
            <Route path="subjects"           element={<Subjects />} />
            <Route path="classes"            element={<Classes />} />
          </Route>

          <Route path="/unauthorized" element={<Unauthorized />} />
          <Route path="*"             element={<NotFound />} />

          <Route path="/" element={
            <Navigate to={
              !isAuthenticated ? '/login' :
              (user?.role === 'super_admin' || user?.role === 'org_admin') ? '/admin' : '/school'
            } replace />
          } />
        </Routes>
      </Suspense>
    </BrowserRouter>
    </SessionProvider>
    </ErrorBoundary>
  );
}
