import React, { useState, useRef, useEffect } from 'react';
import './Common.css';

/* ── PAGE HEADER ────────────────────────────────────────── */
export function PageHeader({ title, subtitle, icon, actions }) {
  return (
    <div className="page-header">
      <div className="page-header-left">
        <div className="page-header-icon">
          <i className={`fa-solid ${icon}`} />
        </div>
        <div>
          <h1 className="page-title">{title}</h1>
          {subtitle && <p className="page-subtitle">{subtitle}</p>}
        </div>
      </div>
      {actions && <div className="page-header-actions">{actions}</div>}
    </div>
  );
}

/* ── BUTTON ─────────────────────────────────────────────── */
export function Btn({ children, variant='primary', size='md', icon, loading, onClick, type='button', disabled, className='' }) {
  return (
    <button
      type={type}
      className={`btn btn-${variant} btn-${size} ${className}`}
      onClick={onClick}
      disabled={disabled || loading}
    >
      {loading
        ? <i className="fa-solid fa-spinner fa-spin" />
        : icon && <i className={`fa-solid ${icon}`} />
      }
      {children}
    </button>
  );
}

/* ── BADGE ──────────────────────────────────────────────── */
export function Badge({ label, color='green' }) {
  return <span className={`badge badge-${color}`}>{label}</span>;
}

/* ── INPUT ──────────────────────────────────────────────── */
export function Input({ label, icon, error, required, ...props }) {
  return (
    <div className="field">
      {label && <label className="field-label">{label}{required && <span className="req">*</span>}</label>}
      <div className={`field-wrap ${error ? 'has-error' : ''}`}>
        {icon && <i className={`fa-solid ${icon} field-icon`} />}
        <input className={`field-input ${icon ? 'has-icon' : ''}`} {...props} />
      </div>
      {error && <p className="field-error">{error}</p>}
    </div>
  );
}

/* ── SELECT ─────────────────────────────────────────────── */
export function Select({ label, options=[], error, required, placeholder, ...props }) {
  return (
    <div className="field">
      {label && <label className="field-label">{label}{required && <span className="req">*</span>}</label>}
      <div className={`field-wrap ${error ? 'has-error' : ''}`}>
        <select className="field-input field-select" {...props}>
          {placeholder && <option value="">{placeholder}</option>}
          {options.map(o =>
            typeof o === 'string'
              ? <option key={o} value={o}>{o}</option>
              : <option key={o.value} value={o.value}>{o.label}</option>
          )}
        </select>
        <i className="fa-solid fa-chevron-down select-arrow" />
      </div>
      {error && <p className="field-error">{error}</p>}
    </div>
  );
}

/* ── TEXTAREA ───────────────────────────────────────────── */
export function Textarea({ label, error, required, rows=3, ...props }) {
  return (
    <div className="field">
      {label && <label className="field-label">{label}{required && <span className="req">*</span>}</label>}
      <textarea className={`field-input field-textarea ${error ? 'has-error' : ''}`} rows={rows} {...props} />
      {error && <p className="field-error">{error}</p>}
    </div>
  );
}

/* ── CARD ───────────────────────────────────────────────── */
export function Card({ children, title, icon, actions, className='' }) {
  return (
    <div className={`card ${className}`}>
      {(title || actions) && (
        <div className="card-header">
          {title && (
            <div className="card-title">
              {icon && <i className={`fa-solid ${icon}`} />}
              <span>{title}</span>
            </div>
          )}
          {actions && <div className="card-actions">{actions}</div>}
        </div>
      )}
      {children}
    </div>
  );
}

/* ── DATA TABLE ─────────────────────────────────────────── */
export function DataTable({ columns, data, loading, onRowClick, emptyText='No records found' }) {
  if (loading) return (
    <div className="table-loading">
      <i className="fa-solid fa-spinner fa-spin" />
      <span>Loading...</span>
    </div>
  );

  return (
    <div className="table-wrap">
      <table className="data-table">
        <thead>
          <tr>
            {columns.map(col => (
              <th key={col.key} style={{ width: col.width }}>
                {col.label}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {data.length === 0 ? (
            <tr><td colSpan={columns.length}>
              <div className="table-empty">
                <i className="fa-regular fa-folder-open" />
                <p>{emptyText}</p>
              </div>
            </td></tr>
          ) : data.map((row, i) => (
            <tr key={row.id || i}
              onClick={() => onRowClick && onRowClick(row)}
              className={onRowClick ? 'clickable' : ''}
            >
              {columns.map(col => (
                <td key={col.key}>
                  {col.render ? col.render(row[col.key], row) : row[col.key]}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

/* ── MODAL ──────────────────────────────────────────────── */
export function Modal({ open, onClose, title, children, size='md', footer }) {
  useEffect(() => {
    if (open) document.body.style.overflow = 'hidden';
    else document.body.style.overflow = '';
    return () => { document.body.style.overflow = ''; };
  }, [open]);

  if (!open) return null;

  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className={`modal modal-${size}`}>
        <div className="modal-header">
          <h3 className="modal-title">{title}</h3>
          <button className="modal-close" onClick={onClose}>
            <i className="fa-solid fa-xmark" />
          </button>
        </div>
        <div className="modal-body">{children}</div>
        {footer && <div className="modal-footer">{footer}</div>}
      </div>
    </div>
  );
}

/* ── SEARCH BAR ─────────────────────────────────────────── */
export function SearchBar({ value, onChange, placeholder='Search...' }) {
  return (
    <div className="search-bar">
      <i className="fa-solid fa-magnifying-glass" />
      <input
        type="text"
        placeholder={placeholder}
        value={value}
        onChange={e => onChange(e.target.value)}
      />
      {value && (
        <button onClick={() => onChange('')}>
          <i className="fa-solid fa-xmark" />
        </button>
      )}
    </div>
  );
}

/* ── TABS ───────────────────────────────────────────────── */
export function Tabs({ tabs, active, onChange }) {
  return (
    <div className="tabs">
      {tabs.map(t => (
        <button
          key={t.key}
          className={`tab ${active === t.key ? 'active' : ''}`}
          onClick={() => onChange(t.key)}
        >
          {t.icon && <i className={`fa-solid ${t.icon}`} />}
          {t.label}
          {t.count !== undefined && (
            <span className="tab-count">{t.count}</span>
          )}
        </button>
      ))}
    </div>
  );
}

/* ── AVATAR ─────────────────────────────────────────────── */
export function Avatar({ name='', photo, size=36, color }) {
  const initials = name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0,2);
  const colors = ['#00A99D','#2196F3','#9C27B0','#F7941D','#e53e3e','#38a169'];
  const bg = color || colors[name.charCodeAt(0) % colors.length];

  return (
    <div className="avatar" style={{ width: size, height: size, background: bg, fontSize: size * 0.38, borderRadius: size * 0.27 }}>
      {photo ? <img src={photo} alt={name} /> : <span>{initials || '?'}</span>}
    </div>
  );
}

/* ── CONFIRM DIALOG ─────────────────────────────────────── */
export function Confirm({ open, onClose, onConfirm, title, message, danger }) {
  return (
    <Modal open={open} onClose={onClose} title={title} size="sm"
      footer={
        <div style={{ display:'flex', gap:10, justifyContent:'flex-end' }}>
          <Btn variant="ghost" onClick={onClose}>Cancel</Btn>
          <Btn variant={danger ? 'danger' : 'primary'} onClick={onConfirm}>Confirm</Btn>
        </div>
      }
    >
      <p style={{ color:'var(--text-mid)', fontSize:14 }}>{message}</p>
    </Modal>
  );
}

/* ── STAT MINI ──────────────────────────────────────────── */
export function StatMini({ label, value, icon, color='#00A99D' }) {
  return (
    <div className="stat-mini" style={{ '--c': color }}>
      <i className={`fa-solid ${icon}`} />
      <div>
        <p className="sm-value">{value}</p>
        <p className="sm-label">{label}</p>
      </div>
    </div>
  );
}

/* ── PAGINATION ─────────────────────────────────────────── */
export function Pagination({ page, pages, total, limit, onChange }) {
  if (pages <= 1) return null;
  return (
    <div className="pagination">
      <span className="page-info">
        Showing {Math.min((page-1)*limit+1, total)}–{Math.min(page*limit, total)} of {total}
      </span>
      <div className="page-buttons">
        <button disabled={page<=1} onClick={() => onChange(page-1)}>
          <i className="fa-solid fa-chevron-left" />
        </button>
        {Array.from({ length: Math.min(pages, 7) }, (_, i) => {
          const p = i + 1;
          return (
            <button key={p} className={page===p ? 'active' : ''} onClick={() => onChange(p)}>{p}</button>
          );
        })}
        <button disabled={page>=pages} onClick={() => onChange(page+1)}>
          <i className="fa-solid fa-chevron-right" />
        </button>
      </div>
    </div>
  );
}
