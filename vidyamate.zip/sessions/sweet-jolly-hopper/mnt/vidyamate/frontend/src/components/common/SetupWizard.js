import React, { useState } from 'react';
import api from '../../services/api';
import toast from 'react-hot-toast';

const STORAGE_KEY = 'vidyamate-setup-done';

const getUser = () =>
  JSON.parse(localStorage.getItem('vidyamate-auth') || '{}')?.state?.user || {};

export function isSetupDone() {
  return !!localStorage.getItem(STORAGE_KEY);
}

export function markSetupDone() {
  localStorage.setItem(STORAGE_KEY, '1');
}

// ── Reusable mini form components ──────────────────────────
const Field = ({ label, required, error, children }) => (
  <div style={{ display:'flex', flexDirection:'column', gap:4 }}>
    <label style={{ fontSize:12.5, fontWeight:600, color:'#4a5568' }}>
      {label}{required && <span style={{ color:'#e53e3e', marginLeft:2 }}>*</span>}
    </label>
    {children}
    {error && <span style={{ fontSize:11, color:'#e53e3e' }}>{error}</span>}
  </div>
);

const WInput = ({ label, required, error, ...props }) => (
  <Field label={label} required={required} error={error}>
    <input {...props} style={{
      width:'100%', boxSizing:'border-box',
      padding:'9px 12px', borderRadius:8, fontSize:13,
      border:`1.5px solid ${error ? '#fc8181' : '#e2e8f0'}`,
      outline:'none', transition:'.15s',
      fontFamily:'inherit',
      ...(props.style||{})
    }} />
  </Field>
);

const WSelect = ({ label, required, error, options, placeholder, ...props }) => (
  <Field label={label} required={required} error={error}>
    <select {...props} style={{
      width:'100%', boxSizing:'border-box',
      padding:'9px 12px', borderRadius:8, fontSize:13,
      border:`1.5px solid ${error ? '#fc8181' : '#e2e8f0'}`,
      background:'#fff', outline:'none',
      fontFamily:'inherit',
      ...(props.style||{})
    }}>
      {placeholder && <option value="">{placeholder}</option>}
      {options.map(o => <option key={o.value||o} value={o.value||o}>{o.label||o}</option>)}
    </select>
  </Field>
);

// ── Steps ──────────────────────────────────────────────────
const STEPS = [
  { id:'school',  label:'School Profile',    icon:'fa-school' },
  { id:'session', label:'Academic Session',  icon:'fa-calendar' },
  { id:'fees',    label:'Fee Heads',         icon:'fa-credit-card' },
  { id:'done',    label:'All Set!',          icon:'fa-check-circle' },
];

const FEE_TYPES    = ['tuition','transport','hostel','exam','library','sports','uniform','other'];
const FEE_FREQ     = ['yearly','half-yearly','quarterly','monthly','one-time'];
const EMPTY_FEE    = { name:'', type:'tuition', amount:'', frequency:'yearly' };
const INDIAN_STATES = ['Andhra Pradesh','Arunachal Pradesh','Assam','Bihar','Chhattisgarh','Goa','Gujarat','Haryana','Himachal Pradesh','Jharkhand','Karnataka','Kerala','Madhya Pradesh','Maharashtra','Manipur','Meghalaya','Mizoram','Nagaland','Odisha','Punjab','Rajasthan','Sikkim','Tamil Nadu','Telangana','Tripura','Uttar Pradesh','Uttarakhand','West Bengal'];

export default function SetupWizard({ onComplete }) {
  const user = getUser();
  const [step, setStep]     = useState(0);
  const [saving, setSaving] = useState(false);

  // Step 0 — School profile
  const [school, setSchool] = useState({
    name: '', email: '', phone: '', address: '', city: '', state: 'Andhra Pradesh',
    pincode: '', principal: '', medium: 'English Medium',
  });
  const [schoolErr, setSchoolErr] = useState({});

  // Step 1 — Academic session
  const curYear = new Date().getFullYear();
  const [session, setSession] = useState({
    name: `${curYear}-${String(curYear+1).slice(-2)}`,
    startDate: `${curYear}-06-01`,
    endDate:   `${curYear+1}-03-31`,
  });
  const [sessionErr, setSessionErr] = useState({});

  // Step 2 — Fee heads
  const [feeHeads, setFeeHeads] = useState([{ ...EMPTY_FEE, name:'Tuition Fee', type:'tuition', amount:'', frequency:'yearly' }]);
  const [feeErr, setFeeErr]     = useState([]);

  const setS = (k, v) => { setSchool(s => ({ ...s, [k]: v })); setSchoolErr(e => ({ ...e, [k]: '' })); };
  const setSess = (k, v) => { setSession(s => ({ ...s, [k]: v })); setSessionErr(e => ({ ...e, [k]: '' })); };
  const setFee = (i, k, v) => setFeeHeads(arr => arr.map((f, idx) => idx === i ? { ...f, [k]: v } : f));

  // ── Validation ─────────────────────────────────────────
  const validateSchool = () => {
    const e = {};
    if (!school.name.trim())  e.name  = 'School name is required';
    if (!school.phone.trim()) e.phone = 'Contact number is required';
    setSchoolErr(e);
    return !Object.keys(e).length;
  };

  const validateSession = () => {
    const e = {};
    if (!session.name.trim())      e.name      = 'Session name is required';
    if (!session.startDate)        e.startDate = 'Start date required';
    if (!session.endDate)          e.endDate   = 'End date required';
    if (session.startDate && session.endDate && session.endDate <= session.startDate)
      e.endDate = 'End must be after start';
    setSessionErr(e);
    return !Object.keys(e).length;
  };

  const validateFees = () => {
    const errs = feeHeads.map(f => {
      const e = {};
      if (!f.name.trim()) e.name = 'Name required';
      return e;
    });
    setFeeErr(errs);
    return errs.every(e => !Object.keys(e).length);
  };

  // ── API calls ───────────────────────────────────────────
  const saveSchool = async () => {
    if (!validateSchool()) return false;
    setSaving(true);
    try {
      if (user.schoolId) {
        await api.put(`/schools/${user.schoolId}`, {
          name: school.name, email: school.email, contactNumber: school.phone,
          city: school.city, state: school.state,
        });
      }
      return true;
    } catch (err) {
      toast.error(err.response?.data?.error || 'Could not save school profile');
      return false;
    } finally { setSaving(false); }
  };

  const saveSession = async () => {
    if (!validateSession()) return false;
    setSaving(true);
    try {
      await api.post('/sessions', {
        organizationId: user.orgId,
        sessionName:    session.name,
        startDate:      session.startDate,
        endDate:        session.endDate,
        isCurrent:      true,
      });
      return true;
    } catch (err) {
      // "already exists" type errors are OK — let the user proceed
      if (err.response?.status === 409 || err.response?.status === 400) return true;
      toast.error(err.response?.data?.error || 'Could not create session');
      return false;
    } finally { setSaving(false); }
  };

  const saveFees = async () => {
    if (!validateFees()) return false;
    // Filter out blank-named heads
    const heads = feeHeads.filter(f => f.name.trim());
    if (heads.length === 0) return true; // skip step is allowed
    setSaving(true);
    try {
      for (const f of heads) {
        await api.post('/fees/heads', {
          schoolId:  user.schoolId,
          sessionId: user.sessionId,
          feeName:   f.name,
          feeType:   f.type,
          amount:    parseFloat(f.amount) || 0,
          frequency: f.frequency,
        });
      }
      return true;
    } catch (err) {
      toast.error(err.response?.data?.error || 'Could not save fee heads');
      return false;
    } finally { setSaving(false); }
  };

  const handleNext = async () => {
    if (step === 0) {
      const ok = await saveSchool();
      if (ok) setStep(1);
    } else if (step === 1) {
      const ok = await saveSession();
      if (ok) setStep(2);
    } else if (step === 2) {
      const ok = await saveFees();
      if (ok) setStep(3);
    } else {
      markSetupDone();
      onComplete();
    }
  };

  const handleSkip = () => {
    if (step < 3) setStep(s => s + 1);
  };

  // ── Render ──────────────────────────────────────────────
  return (
    <div style={{
      position:'fixed', inset:0, background:'rgba(0,0,0,.55)', zIndex:9999,
      display:'flex', alignItems:'center', justifyContent:'center',
      backdropFilter:'blur(4px)',
    }}>
      <div style={{
        background:'#fff', borderRadius:20, width:'100%', maxWidth:600,
        maxHeight:'90vh', overflowY:'auto',
        boxShadow:'0 25px 60px rgba(0,0,0,.25)',
        margin:16,
      }}>
        {/* Header */}
        <div style={{ background:'linear-gradient(135deg,#00A99D,#007a73)', padding:'28px 32px 20px', borderRadius:'20px 20px 0 0', color:'#fff' }}>
          <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:6 }}>
            <div style={{ width:36, height:36, borderRadius:10, background:'rgba(255,255,255,.2)', display:'flex', alignItems:'center', justifyContent:'center' }}>
              <i className="fa-solid fa-wand-magic-sparkles" style={{ fontSize:16 }} />
            </div>
            <div>
              <h2 style={{ margin:0, fontSize:18, fontWeight:700 }}>Welcome to VidyaMate!</h2>
              <p style={{ margin:0, fontSize:12.5, opacity:.85 }}>Quick setup — takes about 2 minutes</p>
            </div>
          </div>

          {/* Progress steps */}
          <div style={{ display:'flex', alignItems:'center', marginTop:20, gap:0 }}>
            {STEPS.map((s, i) => (
              <React.Fragment key={s.id}>
                <div style={{ display:'flex', flexDirection:'column', alignItems:'center', flex:1 }}>
                  <div style={{
                    width:32, height:32, borderRadius:'50%',
                    background: i <= step ? '#fff' : 'rgba(255,255,255,.25)',
                    display:'flex', alignItems:'center', justifyContent:'center',
                    transition:'.3s',
                  }}>
                    {i < step
                      ? <i className="fa-solid fa-check" style={{ color:'#00A99D', fontSize:14 }} />
                      : <i className={`fa-solid ${s.icon}`} style={{ color: i===step ? '#00A99D' : 'rgba(255,255,255,.6)', fontSize:13 }} />
                    }
                  </div>
                  <span style={{ fontSize:10, marginTop:4, opacity: i<=step ? 1 : .6, fontWeight: i===step ? 700 : 400, textAlign:'center' }}>
                    {s.label}
                  </span>
                </div>
                {i < STEPS.length-1 && (
                  <div style={{ height:2, flex:2, background: i < step ? '#fff' : 'rgba(255,255,255,.25)', transition:'.3s', marginBottom:16 }} />
                )}
              </React.Fragment>
            ))}
          </div>
        </div>

        {/* Body */}
        <div style={{ padding:'24px 32px 8px' }}>

          {/* STEP 0 — SCHOOL PROFILE */}
          {step === 0 && (
            <div>
              <h3 style={{ fontSize:16, fontWeight:700, color:'#2d3748', marginBottom:4 }}>School Profile</h3>
              <p style={{ fontSize:13, color:'#718096', marginBottom:20 }}>Basic information about your school.</p>
              <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:14 }}>
                <div style={{ gridColumn:'1 / -1' }}>
                  <WInput label="School Name" required value={school.name} error={schoolErr.name}
                    onChange={e => setS('name', e.target.value)} placeholder="e.g. Sri Vivekananda E/M High School" />
                </div>
                <WInput label="Contact Number" required value={school.phone} error={schoolErr.phone}
                  onChange={e => setS('phone', e.target.value)} placeholder="10-digit mobile" />
                <WInput label="Email" type="email" value={school.email}
                  onChange={e => setS('email', e.target.value)} placeholder="school@example.com" />
                <WInput label="Principal Name" value={school.principal}
                  onChange={e => setS('principal', e.target.value)} placeholder="e.g. Dr. Ramaiah" />
                <WSelect label="Medium" value={school.medium} onChange={e => setS('medium', e.target.value)}
                  options={['English Medium','Telugu Medium','Hindi Medium','Urdu Medium','Bilingual']} />
                <WInput label="City" value={school.city} onChange={e => setS('city', e.target.value)} placeholder="City" />
                <WSelect label="State" value={school.state} onChange={e => setS('state', e.target.value)} options={INDIAN_STATES} />
              </div>
            </div>
          )}

          {/* STEP 1 — ACADEMIC SESSION */}
          {step === 1 && (
            <div>
              <h3 style={{ fontSize:16, fontWeight:700, color:'#2d3748', marginBottom:4 }}>Academic Session</h3>
              <p style={{ fontSize:13, color:'#718096', marginBottom:20 }}>Define the current academic year. You can add more sessions later.</p>
              <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:14 }}>
                <div style={{ gridColumn:'1 / -1' }}>
                  <WInput label="Session Name" required value={session.name} error={sessionErr.name}
                    onChange={e => setSess('name', e.target.value)} placeholder="e.g. 2025-26" />
                </div>
                <WInput label="Start Date" required type="date" value={session.startDate} error={sessionErr.startDate}
                  onChange={e => setSess('startDate', e.target.value)} />
                <WInput label="End Date" required type="date" value={session.endDate} error={sessionErr.endDate}
                  onChange={e => setSess('endDate', e.target.value)} />
              </div>
              <div style={{ background:'#f0fdfb', border:'1px solid #b2f5ea', borderRadius:8, padding:'10px 14px', marginTop:16, fontSize:12.5, color:'#2d6a4f' }}>
                <i className="fa-solid fa-circle-info" style={{ marginRight:6 }} />
                This will be set as the current active session for all modules.
              </div>
            </div>
          )}

          {/* STEP 2 — FEE HEADS */}
          {step === 2 && (
            <div>
              <h3 style={{ fontSize:16, fontWeight:700, color:'#2d3748', marginBottom:4 }}>Fee Heads</h3>
              <p style={{ fontSize:13, color:'#718096', marginBottom:16 }}>Add the fee types you collect. You can always add more later.</p>
              {feeHeads.map((f, i) => (
                <div key={i} style={{ border:'1px solid #e2e8f0', borderRadius:10, padding:'14px 16px', marginBottom:10, position:'relative' }}>
                  <div style={{ display:'grid', gridTemplateColumns:'2fr 1fr 1fr 1fr', gap:10, alignItems:'end' }}>
                    <WInput label={i===0 ? 'Fee Name' : ''} required value={f.name} error={feeErr[i]?.name}
                      onChange={e => setFee(i,'name',e.target.value)} placeholder="e.g. Tuition Fee" />
                    <WSelect label={i===0 ? 'Type' : ''} value={f.type}
                      onChange={e => setFee(i,'type',e.target.value)}
                      options={FEE_TYPES.map(t => ({ value:t, label:t.charAt(0).toUpperCase()+t.slice(1) }))} />
                    <WInput label={i===0 ? 'Amount (₹)' : ''} type="number" value={f.amount}
                      onChange={e => setFee(i,'amount',e.target.value)} placeholder="0" />
                    <WSelect label={i===0 ? 'Frequency' : ''} value={f.frequency}
                      onChange={e => setFee(i,'frequency',e.target.value)}
                      options={FEE_FREQ.map(fr => ({ value:fr, label:fr.replace('-',' ') }))} />
                  </div>
                  {feeHeads.length > 1 && (
                    <button onClick={() => setFeeHeads(arr => arr.filter((_,idx)=>idx!==i))}
                      style={{ position:'absolute', top:10, right:10, background:'none', border:'none',
                        color:'#fc8181', cursor:'pointer', fontSize:14 }}>
                      <i className="fa-solid fa-trash" />
                    </button>
                  )}
                </div>
              ))}
              {feeHeads.length < 6 && (
                <button onClick={() => setFeeHeads(arr => [...arr, { ...EMPTY_FEE }])}
                  style={{ background:'none', border:'1.5px dashed #b2d8d8', borderRadius:8, padding:'8px 16px',
                    color:'#00A99D', fontSize:13, cursor:'pointer', width:'100%', marginTop:4 }}>
                  <i className="fa-solid fa-plus" style={{ marginRight:6 }} />Add Fee Head
                </button>
              )}
              <p style={{ fontSize:12, color:'#718096', marginTop:10 }}>
                <i className="fa-solid fa-circle-info" style={{ marginRight:5 }} />
                Leave amounts as 0 if they vary by class — you can set them per-class in Fees → Assign.
              </p>
            </div>
          )}

          {/* STEP 3 — DONE */}
          {step === 3 && (
            <div style={{ textAlign:'center', padding:'12px 0 20px' }}>
              <div style={{ width:80, height:80, borderRadius:'50%', background:'#e6f9f7',
                display:'flex', alignItems:'center', justifyContent:'center', margin:'0 auto 16px' }}>
                <i className="fa-solid fa-graduation-cap" style={{ fontSize:36, color:'#00A99D' }} />
              </div>
              <h3 style={{ fontSize:20, fontWeight:700, color:'#2d3748', marginBottom:8 }}>You're all set!</h3>
              <p style={{ fontSize:14, color:'#718096', lineHeight:1.7, maxWidth:400, margin:'0 auto 20px' }}>
                VidyaMate is ready to use. Start by adding students, or explore the dashboard to see what's available.
              </p>
              <div style={{ display:'flex', gap:10, justifyContent:'center', flexWrap:'wrap' }}>
                {[
                  { icon:'fa-user-plus',     label:'Add Students',  color:'#00A99D' },
                  { icon:'fa-chalkboard',    label:'Set up Classes', color:'#F7941D' },
                  { icon:'fa-credit-card',   label:'Assign Fees',   color:'#38a169' },
                ].map(card => (
                  <div key={card.label} style={{ background:'#f8fafc', borderRadius:10, padding:'14px 18px',
                    border:'1px solid #e2e8f0', textAlign:'center', minWidth:110 }}>
                    <i className={`fa-solid ${card.icon}`} style={{ fontSize:22, color:card.color, marginBottom:6, display:'block' }} />
                    <span style={{ fontSize:12, color:'#4a5568', fontWeight:500 }}>{card.label}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div style={{ padding:'16px 32px 24px', display:'flex', justifyContent:'space-between', alignItems:'center' }}>
          <button
            onClick={step === 3 ? undefined : handleSkip}
            style={{ background:'none', border:'none', color:'#a0aec0', cursor:'pointer', fontSize:13,
              visibility: step === 3 ? 'hidden' : 'visible' }}>
            Skip this step →
          </button>
          <button onClick={handleNext} disabled={saving}
            style={{ background: saving ? '#9ae6e0' : '#00A99D', color:'#fff',
              border:'none', borderRadius:10, padding:'11px 28px', fontSize:14, fontWeight:600,
              cursor: saving ? 'not-allowed' : 'pointer', display:'flex', alignItems:'center', gap:8,
              transition:'.2s' }}>
            {saving
              ? <><i className="fa-solid fa-spinner fa-spin" /> Saving...</>
              : step === 3
                ? <><i className="fa-solid fa-rocket" /> Start Using VidyaMate</>
                : <><i className="fa-solid fa-arrow-right" /> Next</>
            }
          </button>
        </div>
      </div>
    </div>
  );
}
