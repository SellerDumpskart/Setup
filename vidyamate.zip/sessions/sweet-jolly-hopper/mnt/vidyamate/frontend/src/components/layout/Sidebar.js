import React, { useState } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import './Sidebar.css';

const MENU = [
  {
    section: 'main',
    items: [
      { path: '/school',          icon: 'fa-house',           label: 'Home',                 exact: true },
    ]
  },
  {
    section: 'modules',
    items: [
      { path: '/school/administration', icon: 'fa-users-gear',     label: 'Administration',
        sub: [
          { path: '/school/staff',          label: 'Staff Master' },
          { path: '/school/holidays',       label: 'Holiday Master' },
          { path: '/school/roll-numbers',   label: 'Roll No. Allotment' },
          { path: '/school/subjects',       label: 'Add Subject' },
          { path: '/school/classes',        label: 'Class Subject' },
          { path: '/school/biometric',      label: 'Biometric Devices' },
        ]
      },
      { path: '/school/students',       icon: 'fa-user-graduate',  label: 'Admission' },
      { path: '/school/attendance',     icon: 'fa-calendar-check', label: 'Attendance' },
      { path: '/school/exams',          icon: 'fa-file-pen',       label: 'Examination' },
      { path: '/school/fees',           icon: 'fa-credit-card',    label: 'Fees' },
      { path: '/school/hostel',         icon: 'fa-bed',            label: 'Hostel' },
      { path: '/school/lms',            icon: 'fa-chalkboard-user',label: 'LMS' },
      { path: '/school/payroll',        icon: 'fa-money-bill-wave',label: 'Payroll' },
      { path: '/school/reports',        icon: 'fa-chart-bar',      label: 'Reports' },
      { path: '/school/communication',  icon: 'fa-envelope-open-text', label: 'School Communication' },
      { path: '/school/teacher-desk',   icon: 'fa-chalkboard',    label: 'Teacher Desk' },
      { path: '/school/timetable',      icon: 'fa-table-cells',   label: 'Timetable' },
      { path: '/school/transport',      icon: 'fa-bus',           label: 'Transport' },
      { path: '/school/expenditure',    icon: 'fa-wallet',        label: 'Expenditure' },
      { path: '/school/settings',       icon: 'fa-gear',          label: 'Settings' },
    ]
  }
];

export default function Sidebar({ collapsed, onToggle }) {
  const location = useLocation();
  const [openMenu, setOpenMenu] = useState('');

  const toggleMenu = (label) => {
    setOpenMenu(prev => prev === label ? '' : label);
  };

  const isActive = (path, exact = false) => {
    if (exact) return location.pathname === path;
    return location.pathname.startsWith(path);
  };

  return (
    <aside className={`sidebar ${collapsed ? 'collapsed' : ''}`}>
      {/* Logo */}
      <div className="sidebar-logo">
        <div className="logo-icon">
          <i className="fa-solid fa-graduation-cap" />
        </div>
        {!collapsed && (
          <div className="logo-text">
            <span className="logo-name">VidyaMate</span>
            <span className="logo-sub">School ERP</span>
          </div>
        )}
        <button className="sidebar-toggle" onClick={onToggle}>
          <i className={`fa-solid fa-chevron-${collapsed ? 'right' : 'left'}`} />
        </button>
      </div>

      {/* Nav */}
      <nav className="sidebar-nav">
        {MENU.map(group => (
          <div key={group.section} className="nav-group">
            {group.items.map(item => (
              <div key={item.path} className="nav-item-wrap">
                {item.sub ? (
                  <>
                    <button
                      className={`nav-item has-sub ${isActive(item.path) ? 'active' : ''}`}
                      onClick={() => toggleMenu(item.label)}
                      title={collapsed ? item.label : ''}
                    >
                      <i className={`fa-solid ${item.icon} nav-icon`} />
                      {!collapsed && <span className="nav-label">{item.label}</span>}
                      {!collapsed && (
                        <i className={`fa-solid fa-chevron-${openMenu === item.label ? 'down' : 'right'} nav-arrow`} />
                      )}
                    </button>
                    {!collapsed && openMenu === item.label && (
                      <div className="sub-menu">
                        {item.sub.map(s => (
                          <NavLink
                            key={s.path}
                            to={s.path}
                            className={({ isActive }) =>
                              `sub-item ${isActive ? 'active' : ''}`
                            }
                          >
                            <span className="sub-dot" />
                            {s.label}
                          </NavLink>
                        ))}
                      </div>
                    )}
                  </>
                ) : (
                  <NavLink
                    to={item.path}
                    end={item.exact}
                    className={({ isActive }) =>
                      `nav-item ${isActive ? 'active' : ''}`
                    }
                    title={collapsed ? item.label : ''}
                  >
                    <i className={`fa-solid ${item.icon} nav-icon`} />
                    {!collapsed && <span className="nav-label">{item.label}</span>}
                  </NavLink>
                )}
              </div>
            ))}
          </div>
        ))}
      </nav>

      {/* Bottom user hint */}
      {!collapsed && (
        <div className="sidebar-footer">
          <i className="fa-solid fa-shield-halved" />
          <span>School Portal</span>
        </div>
      )}
    </aside>
  );
}
