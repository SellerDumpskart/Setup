import React from 'react';

export default class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, info) {
    console.error('VidyaMate Error:', error, info);
  }

  render() {
    if (!this.state.hasError) return this.props.children;

    return (
      <div style={{
        display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center',
        minHeight:'60vh', padding:32, textAlign:'center'
      }}>
        <div style={{ width:72, height:72, borderRadius:20, background:'#fde8e8',
          display:'flex', alignItems:'center', justifyContent:'center',
          fontSize:32, marginBottom:20 }}>
          ⚠️
        </div>
        <h2 style={{ fontSize:20, fontWeight:700, color:'#1a2332', marginBottom:8 }}>
          Something went wrong
        </h2>
        <p style={{ fontSize:14, color:'#718096', marginBottom:24, maxWidth:420 }}>
          {this.state.error?.message || 'An unexpected error occurred. Please refresh the page.'}
        </p>
        <button
          onClick={() => { this.setState({ hasError:false, error:null }); window.location.reload(); }}
          style={{ padding:'10px 24px', background:'#00A99D', color:'#fff',
            border:'none', borderRadius:8, fontWeight:600, fontSize:14, cursor:'pointer' }}>
          Reload Page
        </button>
        {process.env.NODE_ENV === 'development' && (
          <pre style={{ marginTop:24, padding:16, background:'#f7f7f7', borderRadius:8,
            fontSize:11, textAlign:'left', maxWidth:600, overflow:'auto',
            color:'#e53e3e', border:'1px solid #fed7d7' }}>
            {this.state.error?.stack}
          </pre>
        )}
      </div>
    );
  }
}
