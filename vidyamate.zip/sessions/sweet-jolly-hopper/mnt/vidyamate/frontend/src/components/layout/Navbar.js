import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import useAuthStore from '../../store/authStore';
import { useSessionContext } from '../../store/sessionStore';
import { useNotifications } from '../../hooks';
import './Navbar.css';

export default function Navbar({ sidebarCollapsed, onToggleSidebar }) {
  const { user, logout } = useAuthStore();
  const { sessions, currentSession, switchSession } = useSessionContext();
  const { notifications, unreadCount, markAllRead } = useNotifications();
  const navigate = useNavigate();
  const [profileOpen, setProfileOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const profileRef = useRef(null);

  // Close dropdowns on outside click
  useEffect(() => {
    const handler = (e) => {
      if (profileRef.current && !profileRef.current.contains(e.target)) {
        setProfileOpen(false);
        setNotifOpen(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const handleLogout = async () => {
    await logout();
    navigate('/login');
  };

  const initials = user
    ? `${user.firstName?.[0] || ''}${user.lastName?.[0] || ''}`.toUpperCase() || 'U'
    : 'U';

  return (
    <header className="navbar" style={{
      left: sidebarCollapsed ? 'var(--sidebar-collapsed)' : 'var(--sidebar-width)'
    }}>
      {/* Left */}
      <div className="navbar-left">
        <button className="navbar-hamburger" onClick={onToggleSidebar}>
          <i className="fa-solid fa-bars" />
        </button>

        {/* Breadcrumb / School name */}
        <div className="navbar-school">
          <i className="fa-solid fa-school" />
          <span>{user?.schoolName || 'School Portal'}</span>
        </div>
      </div>

      {/* Right */}
      <div className="navbar-right" ref={profileRef}>

        {/* Session selector */}
        {sessions.length > 1 ? (
          <select
            value={currentSession?.id || ''}
            onChange={e => switchSession(e.target.value)}
            className="session-select"
          >
            {sessions.map(s => (
              <option key={s.id} value={s.id}>{s.session_name}</option>
            ))}
          </select>
        ) : (
          <div className="session-badge">
            <i className="fa-regular fa-calendar" />
            <span>{currentSession?.session_name || 'AY 2025–26'}</span>
          </div>
        )}

        {/* Search */}
        <div className="navbar-search">
          <i className="fa-solid fa-magnifying-glass" />
          <input type="text" placeholder="Search student..." />
        </div>

        {/* Notifications */}
        <div className="navbar-icon-btn" onClick={() => { setNotifOpen(!notifOpen); setProfileOpen(false); }}>
          <i className="fa-regular fa-bell" />
          {unreadCount > 0 && <span className="notif-badge">{unreadCount > 9 ? '9+' : unreadCount}</span>}
          {notifOpen && (
            <div className="notif-dropdown">
              <div className="dropdown-header">
                <span>Notifications</span>
                <button className="mark-all" onClick={e => { e.stopPropagation(); markAllRead(); }}>Mark all read</button>
              </div>
              {notifications.length === 0 ? (
                <div style={{ padding:'20px', textAlign:'center', color:'#718096', fontSize:12 }}>
                  No new notifications
                </div>
              ) : notifications.slice(0,5).map((n, i) => (
                <div className="notif-item" key={n.id || i}>
                  <div className="notif-dot" style={{ background: n.notif_type === 'error' ? '#e53e3e' : n.notif_type === 'warning' ? '#F7941D' : '#00A99D' }}>
                    <i className={`fa-solid ${n.notif_type === 'fee' ? 'fa-money-bill' : n.notif_type === 'attendance' ? 'fa-calendar-check' : 'fa-bell'}`} />
                  </div>
                  <div className="notif-body">
                    <p className="notif-title">{n.title}</p>
                    <p className="notif-text">{n.message}</p>
                    <p className="notif-time">{new Date(n.created_at).toLocaleTimeString('en-IN', { hour:'2-digit', minute:'2-digit' })}</p>
                  </div>
                </div>
              ))}
              <div className="dropdown-footer">
                <button onClick={() => setNotifOpen(false)}>View all notifications</button>
              </div>
            </div>
          )}
        </div>

        {/* Profile */}
        <div className="navbar-profile" onClick={() => setProfileOpen(!profileOpen)}>
          <div className="profile-avatar">
            {user?.photo
              ? <img src={user.photo} alt="profile" />
              : <span>{initials}</span>
            }
          </div>
          <div className="profile-info">
            <span className="profile-name">{user?.firstName} {user?.lastName}</span>
            <span className="profile-role">{user?.role?.replace('_', ' ')}</span>
          </div>
          <i className="fa-solid fa-chevron-down profile-arrow" />

          {profileOpen && (
            <div className="profile-dropdown">
              <div className="profile-dropdown-header">
                <div className="pd-avatar">{initials}</div>
                <div>
                  <p className="pd-name">{user?.firstName} {user?.lastName}</p>
                  <p className="pd-email">{user?.email}</p>
                </div>
              </div>
              <div className="pd-divider" />
              {[
                { icon: 'fa-user', label: 'My Profile' },
                { icon: 'fa-gear', label: 'Settings' },
                { icon: 'fa-key', label: 'Change Password' },
              ].map((item, i) => (
                <button className="pd-item" key={i}>
                  <i className={`fa-solid ${item.icon}`} />
                  {item.label}
                </button>
              ))}
              <div className="pd-divider" />
              <button className="pd-item pd-logout" onClick={handleLogout}>
                <i className="fa-solid fa-right-from-bracket" />
                Sign Out
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
