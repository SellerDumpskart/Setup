import React, { useState } from 'react';
import { Outlet } from 'react-router-dom';
import Sidebar from './Sidebar';
import Navbar from './Navbar';
import SetupWizard, { isSetupDone } from '../common/SetupWizard';
import useAuthStore from '../../store/authStore';
import './SchoolLayout.css';

export default function SchoolLayout() {
  const [collapsed, setCollapsed] = useState(false);
  const { user } = useAuthStore();

  // Show wizard only for school-level roles (not super_admin viewing school routes)
  const isSchoolUser = user?.role && !['super_admin','org_admin'].includes(user.role);
  const [wizardDone, setWizardDone] = useState(isSetupDone);

  const showWizard = isSchoolUser && !wizardDone;

  return (
    <div className="school-layout">
      <Sidebar collapsed={collapsed} onToggle={() => setCollapsed(c => !c)} />
      <div className={`layout-main ${collapsed ? 'collapsed' : ''}`}>
        <Navbar sidebarCollapsed={collapsed} onToggleSidebar={() => setCollapsed(c => !c)} />
        <main className="layout-content">
          <Outlet />
        </main>
      </div>
      {showWizard && <SetupWizard onComplete={() => setWizardDone(true)} />}
    </div>
  );
}
