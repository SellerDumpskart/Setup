import React from 'react';
import { Outlet, NavLink } from 'react-router-dom';
import './AdminLayout.css';

const ADMIN_MENU = [
  { path: '/admin', label: 'Dashboard', icon: 'fa-gauge', exact: true },
  { path: '/admin/organizations', label: 'Organizations', icon: 'fa-building' },
  { path: '/admin/schools', label: 'Schools', icon: 'fa-school' },
  { path: '/admin/sessions', label: 'Sessions', icon: 'fa-calendar' },
  { path: '/admin/masters', label: 'Masters', icon: 'fa-list' },
  { path: '/admin/users', label: 'Users', icon: 'fa-users' },
];

export default function AdminLayout() {
  return (
    <div className="admin-layout">
      <aside className="admin-sidebar">
        <div className="admin-logo">
          <i className="fa-solid fa-graduation-cap" />
          <span>VidyaMate Admin</span>
        </div>
        <nav>
          {ADMIN_MENU.map(m => (
            <NavLink key={m.path} to={m.path} end={m.exact}
              className={({ isActive }) => `admin-nav-item ${isActive ? 'active' : ''}`}>
              <i className={`fa-solid ${m.icon}`} />
              {m.label}
            </NavLink>
          ))}
        </nav>
      </aside>
      <main className="admin-main"><Outlet /></main>
    </div>
  );
}
