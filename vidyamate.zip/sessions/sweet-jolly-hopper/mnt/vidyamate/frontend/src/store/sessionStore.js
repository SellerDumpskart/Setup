import React, { createContext, useContext, useState, useEffect } from 'react';
import api from '../services/api';
import useAuthStore from './authStore';

const SessionContext = createContext({
  sessions: [],
  currentSession: null,
  sessionId: null,
  switchSession: () => {},
  loading: true,
});

export function SessionProvider({ children }) {
  const { user, isAuthenticated } = useAuthStore();
  const [sessions, setSessions]         = useState([]);
  const [currentSession, setCurrentSession] = useState(null);
  const [loading, setLoading]           = useState(true);

  useEffect(() => {
    if (!isAuthenticated || !user?.orgId) {
      setLoading(false);
      return;
    }

    api.get('/sessions', { params: { orgId: user.orgId } })
      .then(({ data }) => {
        setSessions(data || []);
        // Use saved session or pick current one
        const savedId = localStorage.getItem('vidyamate-session-id');
        const saved = savedId && data.find(s => s.id === savedId);
        const current = saved || data.find(s => s.is_current) || data[0];
        if (current) {
          setCurrentSession(current);
          localStorage.setItem('vidyamate-session-id', current.id);
        }
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [isAuthenticated, user?.orgId]);

  const switchSession = (sessionId) => {
    const found = sessions.find(s => s.id === sessionId);
    if (found) {
      setCurrentSession(found);
      localStorage.setItem('vidyamate-session-id', found.id);
    }
  };

  return (
    <SessionContext.Provider value={{
      sessions,
      currentSession,
      sessionId: currentSession?.id || null,
      switchSession,
      loading,
    }}>
      {children}
    </SessionContext.Provider>
  );
}

export const useSessionContext = () => useContext(SessionContext);
export default SessionContext;
