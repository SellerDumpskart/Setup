/**
 * Business Logic Tests
 * Tests query construction, data transformation, edge cases
 */
const { test, describe } = require('node:test');
const assert = require('node:assert/strict');

// ── Student query builder (mirrors studentController logic) ──
describe('Student query builder', () => {
  const buildStudentQuery = ({ schoolId, sessionId, classId, search, status, page = 1, limit = 50 }) => {
    const where  = ['s.school_id = $1', 's.session_id = $2'];
    const params = [schoolId, sessionId];
    let idx = 3;

    if (status)  { where.push(`s.status = $${idx++}`);   params.push(status); }
    if (classId) { where.push(`s.class_id = $${idx++}`); params.push(classId); }
    if (search) {
      where.push(`(LOWER(s.first_name || ' ' || COALESCE(s.last_name,'')) LIKE $${idx} OR s.student_code LIKE $${idx} OR s.aadhaar_no = $${idx + 1})`);
      params.push(`%${search.toLowerCase()}%`);
      params.push(search);
      idx += 2;
    }

    const offset = (page - 1) * limit;
    params.push(limit, offset);

    return {
      where: where.join(' AND '),
      params,
      limitIdx: idx,
      offsetIdx: idx + 1,
    };
  };

  test('base query has school_id and session_id', () => {
    const q = buildStudentQuery({ schoolId: 's1', sessionId: 'se1' });
    assert.ok(q.where.includes('school_id'));
    assert.ok(q.where.includes('session_id'));
  });

  test('status filter adds correct clause', () => {
    const q = buildStudentQuery({ schoolId: 's1', sessionId: 'se1', status: 'active' });
    assert.ok(q.where.includes('status'));
    assert.ok(q.params.includes('active'));
  });

  test('class filter adds class_id clause', () => {
    const q = buildStudentQuery({ schoolId: 's1', sessionId: 'se1', classId: 'c1' });
    assert.ok(q.where.includes('class_id'));
    assert.ok(q.params.includes('c1'));
  });

  test('search adds LIKE clause', () => {
    const q = buildStudentQuery({ schoolId: 's1', sessionId: 'se1', search: 'ravi' });
    assert.ok(q.where.includes('LIKE'));
    assert.ok(q.params.some(p => p.includes('ravi')));
  });

  test('search is case-insensitive (lowercased)', () => {
    const q = buildStudentQuery({ schoolId: 's1', sessionId: 'se1', search: 'RAVI' });
    assert.ok(q.params.some(p => typeof p === 'string' && p.includes('ravi')));
  });

  test('pagination: page 2 with limit 20 gives offset 20', () => {
    const q = buildStudentQuery({ schoolId: 's1', sessionId: 'se1', page: 2, limit: 20 });
    assert.ok(q.params.includes(20));  // limit
    assert.ok(q.params.includes(20));  // offset (also 20 for page 2)
  });

  test('no SQL injection in search (parameterized)', () => {
    const malicious = "'; DROP TABLE students; --";
    const q = buildStudentQuery({ schoolId: 's1', sessionId: 'se1', search: malicious });
    // The where clause should only have placeholders, not the actual value
    assert.ok(!q.where.includes('DROP'));
    assert.ok(q.params.some(p => typeof p === 'string' && p.includes('drop')));
  });
});

// ── Fee defaulter calculation ──────────────────────────────
describe('Fee defaulter detection', () => {
  const isDefaulter = (fee) => {
    const balance = parseFloat(fee.total_amount) - parseFloat(fee.concession || 0) - parseFloat(fee.paid_amount || 0);
    const dueDate = fee.due_date ? new Date(fee.due_date) : null;
    return balance > 0 && dueDate && dueDate < new Date();
  };

  test('zero balance is not a defaulter', () => {
    assert.ok(!isDefaulter({ total_amount: 5000, concession: 0, paid_amount: 5000, due_date: '2020-01-01' }));
  });

  test('unpaid past due is defaulter', () => {
    assert.ok(isDefaulter({ total_amount: 5000, concession: 0, paid_amount: 0, due_date: '2020-01-01' }));
  });

  test('unpaid future due is NOT defaulter yet', () => {
    const futureDate = new Date(Date.now() + 86400000 * 30).toISOString().split('T')[0];
    assert.ok(!isDefaulter({ total_amount: 5000, concession: 0, paid_amount: 0, due_date: futureDate }));
  });

  test('partial payment still defaulter if balance and overdue', () => {
    assert.ok(isDefaulter({ total_amount: 5000, concession: 0, paid_amount: 2000, due_date: '2020-01-01' }));
  });

  test('full concession waiver is not a defaulter', () => {
    assert.ok(!isDefaulter({ total_amount: 5000, concession: 5000, paid_amount: 0, due_date: '2020-01-01' }));
  });
});

// ── Attendance summary aggregation ────────────────────────
describe('Attendance summary aggregation', () => {
  const records = [
    { student_id: 's1', status: 'present' },
    { student_id: 's2', status: 'absent'  },
    { student_id: 's3', status: 'present' },
    { student_id: 's4', status: 'leave'   },
    { student_id: 's5', status: 'present' },
  ];

  const summarize = (recs) => ({
    total:   recs.length,
    present: recs.filter(r => r.status === 'present').length,
    absent:  recs.filter(r => r.status === 'absent').length,
    leave:   recs.filter(r => r.status === 'leave').length,
    pct:     recs.length === 0 ? 0 : Math.round(recs.filter(r => r.status === 'present').length / recs.length * 100),
  });

  test('counts total correctly', () => {
    assert.equal(summarize(records).total, 5);
  });

  test('counts present correctly', () => {
    assert.equal(summarize(records).present, 3);
  });

  test('counts absent correctly', () => {
    assert.equal(summarize(records).absent, 1);
  });

  test('calculates percentage', () => {
    assert.equal(summarize(records).pct, 60);
  });

  test('empty class returns zeros', () => {
    const s = summarize([]);
    assert.equal(s.total, 0);
    assert.equal(s.present, 0);
    assert.equal(s.pct, 0, 'pct should be 0 (not NaN) for empty class');
  });
});

// ── Role-based data filtering ──────────────────────────────
describe('Role-based data access', () => {
  const canViewAllSchools = (role) =>
    ['super_admin', 'org_admin'].includes(role);

  const canEditFees = (role) =>
    ['super_admin', 'org_admin', 'principal', 'accountant'].includes(role);

  const canMarkAttendance = (role) =>
    ['super_admin', 'org_admin', 'principal', 'teacher'].includes(role);

  test('super_admin views all schools', () => assert.ok(canViewAllSchools('super_admin')));
  test('principal cannot view all schools', () => assert.ok(!canViewAllSchools('principal')));
  test('accountant can edit fees', () => assert.ok(canEditFees('accountant')));
  test('non_teaching cannot edit fees', () => assert.ok(!canEditFees('non_teaching')));
  test('teacher can mark attendance', () => assert.ok(canMarkAttendance('teacher')));
  test('accountant cannot mark attendance', () => assert.ok(!canMarkAttendance('accountant')));
});

// ── Hall ticket number format ──────────────────────────────
describe('Hall ticket number generation', () => {
  const genTicketNo = (examName, studentCode) => {
    const examShort = examName.replace(/\s+/g, '').slice(0, 6).toUpperCase();
    const stuShort  = studentCode.split('-').pop();
    return `HT-${examShort}-${stuShort}`;
  };

  test('generates correct format', () => {
    const no = genTicketNo('Mid Term Exam 2025', 'STU-2025-0042');
    assert.ok(no.startsWith('HT-'));
    assert.ok(no.includes('0042'));
  });

  test('exam name is shortened to 6 chars', () => {
    const no = genTicketNo('Mid Term Exam 2025', 'STU-001');
    const parts = no.split('-');
    assert.ok(parts[1].length <= 6);
  });

  test('different students get different tickets', () => {
    const t1 = genTicketNo('Exam', 'STU-001');
    const t2 = genTicketNo('Exam', 'STU-002');
    assert.notEqual(t1, t2);
  });
});

// ── Payroll deduction calculation ─────────────────────────
describe('Payroll deduction calculation', () => {
  // Approximate 13% deduction model used in the system
  const calcDeductions = (gross) => Math.round(gross * 0.13 * 100) / 100;
  const calcNet        = (gross) => gross - calcDeductions(gross);

  test('deduction is 13% of gross', () => {
    assert.equal(calcDeductions(10000), 1300);
  });

  test('net = gross - deductions', () => {
    const gross = 25000;
    assert.equal(calcNet(gross), gross - calcDeductions(gross));
  });

  test('zero gross = zero deductions', () => {
    assert.equal(calcDeductions(0), 0);
    assert.equal(calcNet(0), 0);
  });

  test('result rounds to 2 decimal places', () => {
    const ded = calcDeductions(10001);
    const decimals = ded.toString().split('.')[1]?.length || 0;
    assert.ok(decimals <= 2, `Expected ≤2 decimals, got ${decimals}`);
  });
});

// ── Communication broadcast target resolution ─────────────
describe('Broadcast recipient resolution', () => {
  const mockStudents = [
    { id: 's1', father_phone: '9876543210', father_email: 'f1@test.com', status: 'active' },
    { id: 's2', father_phone: '9876543211', father_email: null,           status: 'active' },
    { id: 's3', father_phone: null,          father_email: 'f3@test.com', status: 'active' },
    { id: 's4', father_phone: '9876543212', father_email: 'f4@test.com', status: 'dropped' },
  ];

  const getPhones = (students) =>
    students.filter(s => s.status === 'active' && s.father_phone).map(s => s.father_phone);

  const getEmails = (students) =>
    students.filter(s => s.status === 'active' && s.father_email).map(s => s.father_email);

  test('only active students included', () => {
    const phones = getPhones(mockStudents);
    assert.ok(!phones.includes('9876543212'), 'Dropped student should not be included');
  });

  test('null phones are excluded', () => {
    const phones = getPhones(mockStudents);
    assert.ok(!phones.includes(null));
    assert.equal(phones.length, 2);
  });

  test('null emails are excluded', () => {
    const emails = getEmails(mockStudents);
    assert.ok(!emails.includes(null));
    assert.equal(emails.length, 2);
  });
});
