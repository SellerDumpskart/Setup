/**
 * Utility Function Tests
 * Tests formatters, grade calc, export helpers
 */
const { test, describe } = require('node:test');
const assert = require('node:assert/strict');

// ── Currency formatter ─────────────────────────────────────
describe('Currency formatting', () => {
  const fmtINR = (n) => `₹${Number(n).toLocaleString('en-IN', { minimumFractionDigits: 0 })}`;
  const fmtCompact = (n) => {
    if (n >= 1e7) return `₹${(n/1e7).toFixed(2)}Cr`;
    if (n >= 1e5) return `₹${(n/1e5).toFixed(2)}L`;
    if (n >= 1e3) return `₹${(n/1e3).toFixed(1)}K`;
    return fmtINR(n);
  };

  test('formats thousands with Indian comma', () => {
    const result = fmtINR(10000);
    assert.ok(result.includes('10,000') || result.includes('10000'), `Got: ${result}`);
  });

  test('compact: lakhs formatting', () => {
    assert.equal(fmtCompact(500000), '₹5.00L');
    assert.equal(fmtCompact(1500000), '₹15.00L');
  });

  test('compact: crore formatting', () => {
    assert.equal(fmtCompact(10000000), '₹1.00Cr');
  });

  test('compact: thousands', () => {
    assert.equal(fmtCompact(5000), '₹5.0K');
  });

  test('handles zero', () => {
    assert.ok(fmtINR(0).includes('0'));
  });
});

// ── Date formatters ────────────────────────────────────────
describe('Date formatting', () => {
  const fmtDate = (d, opts = {}) => {
    if (!d) return '—';
    return new Date(d).toLocaleDateString('en-IN', {
      day: '2-digit', month: 'short', year: 'numeric', ...opts
    });
  };

  test('returns — for null', () => assert.equal(fmtDate(null), '—'));
  test('returns — for undefined', () => assert.equal(fmtDate(undefined), '—'));

  test('formats ISO date string', () => {
    const result = fmtDate('2025-06-15');
    assert.ok(result.includes('Jun') || result.includes('06'));
    assert.ok(result.includes('2025'));
  });

  test('handles Date objects', () => {
    const d = new Date('2025-01-01');
    const result = fmtDate(d);
    assert.ok(result.includes('2025'));
  });
});

// ── Student code generation ────────────────────────────────
describe('Student code generation', () => {
  const genCode = (year, count) =>
    `STU-${year}-${String(count).padStart(4, '0')}`;

  test('generates padded 4-digit code', () => {
    assert.equal(genCode(2025, 1),    'STU-2025-0001');
    assert.equal(genCode(2025, 100),  'STU-2025-0100');
    assert.equal(genCode(2025, 9999), 'STU-2025-9999');
  });

  test('year is embedded correctly', () => {
    assert.ok(genCode(2026, 1).includes('2026'));
  });
});

// ── Excel column widths ────────────────────────────────────
describe('Excel export column definitions', () => {
  const STUDENT_COLS = [
    { header:'#',            key:'sno',         width:5  },
    { header:'Student Code', key:'student_code', width:16 },
    { header:'Name',         key:'name',         width:24 },
    { header:'Class',        key:'class',        width:10 },
    { header:'Roll No.',     key:'roll_number',  width:10 },
    { header:'Gender',       key:'gender',       width:10 },
    { header:'DOB',          key:'dob',          width:14 },
    { header:'Father Name',  key:'father_name',  width:22 },
    { header:'Father Phone', key:'father_phone', width:14 },
    { header:'Status',       key:'status',       width:12 },
  ];

  test('all columns have header, key, and width', () => {
    STUDENT_COLS.forEach(col => {
      assert.ok(col.header, `Missing header for ${col.key}`);
      assert.ok(col.key,    `Missing key`);
      assert.ok(col.width > 0, `Width must be positive for ${col.key}`);
    });
  });

  test('no duplicate keys', () => {
    const keys = STUDENT_COLS.map(c => c.key);
    const unique = new Set(keys);
    assert.equal(unique.size, keys.length, 'Duplicate column keys found');
  });

  test('total columns count is correct', () => {
    assert.equal(STUDENT_COLS.length, 10);
  });
});

// ── SMS message formatting ─────────────────────────────────
describe('SMS message templates', () => {
  const feeReminder = (name, amount, dueDate) =>
    `Dear Parent, fee of Rs.${amount} for ${name} is due on ${dueDate}. Please pay at the earliest. -VidyaMate`;

  const absentAlert = (name, date) =>
    `${name} was marked ABSENT on ${date}. Please contact the school if this is an error. -VidyaMate`;

  test('fee reminder contains student name', () => {
    const msg = feeReminder('Ravi Kumar', 5000, '30 Jun 2025');
    assert.ok(msg.includes('Ravi Kumar'));
  });

  test('fee reminder contains amount', () => {
    const msg = feeReminder('Test', 5000, '30 Jun');
    assert.ok(msg.includes('5000'));
  });

  test('absent alert under 160 chars (1 SMS)', () => {
    const msg = absentAlert('Priya Sharma', '15 Jun 2025');
    assert.ok(msg.length <= 160, `Message is ${msg.length} chars, exceeds 160`);
  });

  test('fee reminder ends with branding', () => {
    const msg = feeReminder('Test', 1000, '1 Jul');
    assert.ok(msg.endsWith('-VidyaMate'));
  });

  test('no undefined in messages', () => {
    const msg = feeReminder('Name', 1000, 'date');
    assert.ok(!msg.includes('undefined'));
  });
});

// ── Pagination helpers ─────────────────────────────────────
describe('Pagination calculation', () => {
  const calcPagination = (total, page, limit) => ({
    total,
    page:  parseInt(page),
    limit: parseInt(limit),
    pages: Math.ceil(total / limit),
    offset: (page - 1) * limit,
  });

  test('first page offset is 0', () => {
    const p = calcPagination(100, 1, 20);
    assert.equal(p.offset, 0);
  });

  test('second page offset is limit', () => {
    const p = calcPagination(100, 2, 20);
    assert.equal(p.offset, 20);
  });

  test('correct total pages', () => {
    assert.equal(calcPagination(100, 1, 20).pages, 5);
    assert.equal(calcPagination(101, 1, 20).pages, 6);
    assert.equal(calcPagination(20, 1, 20).pages, 1);
  });

  test('empty result set', () => {
    const p = calcPagination(0, 1, 50);
    assert.equal(p.pages, 0);
    assert.equal(p.offset, 0);
  });
});

// ── Empoyee number generation ──────────────────────────────
describe('Employee number generation', () => {
  const genEmpNo = (count) => `ESV${String(count + 1).padStart(6, '0')}`;

  test('first employee = ESV000001', () => assert.equal(genEmpNo(0), 'ESV000001'));
  test('tenth employee = ESV000010', () => assert.equal(genEmpNo(9), 'ESV000010'));
  test('always 9 chars total',       () => assert.equal(genEmpNo(0).length, 9));
});

// ── File upload validation ─────────────────────────────────
describe('File upload validation', () => {
  const ALLOWED_EXTS = ['.jpg','.jpeg','.png','.gif','.webp','.pdf','.doc','.docx','.xls','.xlsx','.mp4','.mp3'];
  const MAX_SIZE_MB  = 10;

  const isAllowed = (filename) => {
    const ext = filename.toLowerCase().slice(filename.lastIndexOf('.'));
    return ALLOWED_EXTS.includes(ext);
  };

  test('allows images', () => {
    assert.ok(isAllowed('photo.jpg'));
    assert.ok(isAllowed('doc.PNG'));
  });

  test('allows documents', () => {
    assert.ok(isAllowed('cert.pdf'));
    assert.ok(isAllowed('report.docx'));
  });

  test('blocks executables', () => {
    assert.ok(!isAllowed('virus.exe'));
    assert.ok(!isAllowed('script.sh'));
    assert.ok(!isAllowed('hack.js'));
  });

  test('blocks SQL files', () => {
    assert.ok(!isAllowed('dump.sql'));
  });

  test('max file size is 10MB', () => {
    assert.equal(MAX_SIZE_MB, 10);
    assert.equal(MAX_SIZE_MB * 1024 * 1024, 10485760);
  });
});
