/**
 * End-to-End Flow Tests (mocked)
 * Simulates complete user journeys: login → action → response
 * Uses in-memory state to simulate database
 */
const { test, describe, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const bcrypt = require('bcryptjs');
const jwt    = require('jsonwebtoken');

process.env.JWT_SECRET         = 'test-jwt-secret-32-chars-minimum!!';
process.env.JWT_REFRESH_SECRET = 'test-refresh-secret-32-chars-min!';

// ── In-memory database ─────────────────────────────────────
class MockDB {
  constructor() {
    this.tables = {
      users: [],
      students: [],
      fee_payments: [],
      student_attendance: [],
      payroll: [],
      staff: [],
    };
  }

  async seed() {
    const hash = await bcrypt.hash('Admin@123', 10);
    this.tables.users.push({
      id: 'u-001', email: 'admin@vidyamate.in', password_hash: hash,
      first_name: 'Super', last_name: 'Admin', role: 'super_admin',
      school_id: 's-001', organization_id: 'o-001', is_active: true
    });
    this.tables.staff.push({
      id: 'st-001', school_id: 's-001', emp_no: 'ESV000001',
      first_name: 'Test', last_name: 'Teacher', staff_type: 'teaching',
      salary: 25000, status: 'active'
    });
  }
}

// ── Auth service (mirrors authController logic) ────────────
class AuthService {
  constructor(db) { this.db = db; }

  async login(email, password) {
    const user = this.db.tables.users.find(u => u.email.toLowerCase() === email.toLowerCase());
    if (!user)        return { error: 'Invalid email or password', status: 401 };
    if (!user.is_active) return { error: 'Account is inactive', status: 401 };

    const valid = await bcrypt.compare(password, user.password_hash);
    if (!valid)       return { error: 'Invalid email or password', status: 401 };

    const payload = { id: user.id, role: user.role, school_id: user.school_id };
    const accessToken  = jwt.sign(payload, process.env.JWT_SECRET,         { expiresIn: '15m' });
    const refreshToken = jwt.sign({ id: user.id }, process.env.JWT_REFRESH_SECRET, { expiresIn: '7d' });

    return {
      accessToken, refreshToken,
      user: { id: user.id, email: user.email, firstName: user.first_name,
              role: user.role, schoolId: user.school_id }
    };
  }

  verifyToken(token) {
    return jwt.verify(token, process.env.JWT_SECRET);
  }

  async refresh(refreshToken) {
    const decoded = jwt.verify(refreshToken, process.env.JWT_REFRESH_SECRET);
    const user    = this.db.tables.users.find(u => u.id === decoded.id);
    if (!user || !user.is_active) return null;

    const payload  = { id: user.id, role: user.role, school_id: user.school_id };
    const newAccess = jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: '15m' });
    const newRefresh= jwt.sign({ id: user.id }, process.env.JWT_REFRESH_SECRET, { expiresIn: '7d' });
    return { accessToken: newAccess, refreshToken: newRefresh };
  }
}

// ── Student service (mirrors studentController logic) ──────
class StudentService {
  constructor(db) { this.db = db; this.counter = 0; }

  create(data, schoolId, sessionId) {
    if (!data.firstName) throw new Error('First name required');
    if (!data.gender)    throw new Error('Gender required');

    this.counter++;
    const year = new Date().getFullYear();
    const code = `STU-${year}-${String(this.counter).padStart(4,'0')}`;

    const student = {
      id:           `s-${this.counter}`,
      school_id:    schoolId,
      session_id:   sessionId,
      student_code: code,
      first_name:   data.firstName,
      last_name:    data.lastName || '',
      gender:       data.gender,
      status:       'active',
      admission_date: new Date().toISOString().split('T')[0],
    };

    this.db.tables.students.push(student);
    return student;
  }

  list(schoolId, { status = 'active', search } = {}) {
    let results = this.db.tables.students.filter(s => s.school_id === schoolId);
    if (status) results = results.filter(s => s.status === status);
    if (search) {
      const q = search.toLowerCase();
      results = results.filter(s =>
        `${s.first_name} ${s.last_name}`.toLowerCase().includes(q) ||
        s.student_code.includes(q)
      );
    }
    return results;
  }

  updateStatus(id, status, reason) {
    const idx = this.db.tables.students.findIndex(s => s.id === id);
    if (idx === -1) throw new Error('Student not found');
    this.db.tables.students[idx].status        = status;
    this.db.tables.students[idx].cancel_reason = reason;
    return this.db.tables.students[idx];
  }
}

// ── Fee service (mirrors feesController logic) ─────────────
class FeeService {
  constructor(db) { this.db = db; this.receiptCounter = 0; }

  collectPayment({ studentId, amount, paymentMode = 'cash', schoolId }) {
    if (!studentId)        throw new Error('studentId required');
    if (amount === undefined || amount === null || amount === '') throw new Error('amount required');
    const n = parseFloat(amount);
    if (isNaN(n) || n <= 0) throw new Error('Amount must be positive');

    this.receiptCounter++;
    const year    = new Date().getFullYear();
    const receipt = `RCP-${year}-${String(this.receiptCounter).padStart(5,'0')}`;

    const payment = {
      id: `pay-${this.receiptCounter}`,
      student_id:   studentId,
      school_id:    schoolId,
      receipt_no:   receipt,
      amount:       parseFloat(amount),
      payment_mode: paymentMode,
      payment_date: new Date().toISOString().split('T')[0],
      status:       'paid',
    };
    this.db.tables.fee_payments.push(payment);
    return payment;
  }

  getPayments(schoolId, studentId) {
    let payments = this.db.tables.fee_payments.filter(p => p.school_id === schoolId);
    if (studentId) payments = payments.filter(p => p.student_id === studentId);
    return payments;
  }

  getTotalCollected(schoolId) {
    return this.db.tables.fee_payments
      .filter(p => p.school_id === schoolId)
      .reduce((sum, p) => sum + p.amount, 0);
  }
}

// ══════════════════════════════════════════════════════════
// TESTS
// ══════════════════════════════════════════════════════════

let db, auth, students, fees;

describe('Complete user journey: Admin login', () => {
  beforeEach(async () => {
    db = new MockDB();
    await db.seed();
    auth = new AuthService(db);
  });

  test('admin can login with correct credentials', async () => {
    const result = await auth.login('admin@vidyamate.in', 'Admin@123');
    assert.ok(result.accessToken);
    assert.ok(result.refreshToken);
    assert.equal(result.user.role, 'super_admin');
  });

  test('login returns correct user shape', async () => {
    const result = await auth.login('admin@vidyamate.in', 'Admin@123');
    assert.ok(result.user.id);
    assert.ok(result.user.email);
    assert.ok(result.user.firstName);
    assert.ok(result.user.schoolId);
  });

  test('wrong password fails', async () => {
    const result = await auth.login('admin@vidyamate.in', 'WrongPassword');
    assert.ok(result.error);
    assert.equal(result.status, 401);
  });

  test('unknown email fails', async () => {
    const result = await auth.login('hacker@evil.com', 'Admin@123');
    assert.ok(result.error);
  });

  test('case-insensitive email login', async () => {
    const result = await auth.login('ADMIN@VIDYAMATE.IN', 'Admin@123');
    assert.ok(result.accessToken, 'Should login with uppercase email');
  });

  test('access token is verifiable', async () => {
    const { accessToken } = await auth.login('admin@vidyamate.in', 'Admin@123');
    const decoded = auth.verifyToken(accessToken);
    assert.equal(decoded.role, 'super_admin');
  });

  test('refresh flow generates new tokens', async () => {
    const { refreshToken } = await auth.login('admin@vidyamate.in', 'Admin@123');
    const newTokens = await auth.refresh(refreshToken);
    assert.ok(newTokens.accessToken);
    assert.ok(newTokens.refreshToken);
    assert.notEqual(newTokens.accessToken, refreshToken);
  });
});

describe('Complete journey: Student admission', () => {
  beforeEach(async () => {
    db = new MockDB();
    await db.seed();
    students = new StudentService(db);
  });

  test('admit a new student', () => {
    const s = students.create({ firstName:'Ravi', lastName:'Kumar', gender:'male' }, 's-001', 'se-001');
    assert.ok(s.id);
    assert.ok(s.student_code.startsWith('STU-'));
    assert.equal(s.status, 'active');
    assert.equal(s.first_name, 'Ravi');
  });

  test('student code is auto-generated', () => {
    const s1 = students.create({ firstName:'A', gender:'male' }, 's-001', 'se-001');
    const s2 = students.create({ firstName:'B', gender:'female' }, 's-001', 'se-001');
    assert.notEqual(s1.student_code, s2.student_code);
  });

  test('student code increments sequentially', () => {
    const s1 = students.create({ firstName:'A', gender:'male' }, 's-001', 'se-001');
    const s2 = students.create({ firstName:'B', gender:'female' }, 's-001', 'se-001');
    const n1 = parseInt(s1.student_code.split('-').pop());
    const n2 = parseInt(s2.student_code.split('-').pop());
    assert.equal(n2, n1 + 1);
  });

  test('gender required', () => {
    assert.throws(() => students.create({ firstName:'Test' }, 's-001', 'se-001'), /gender/i);
  });

  test('first name required', () => {
    assert.throws(() => students.create({ gender:'male' }, 's-001', 'se-001'), /first name/i);
  });

  test('can list admitted students', () => {
    students.create({ firstName:'Ravi', gender:'male' }, 's-001', 'se-001');
    students.create({ firstName:'Priya', gender:'female' }, 's-001', 'se-001');
    const list = students.list('s-001');
    assert.equal(list.length, 2);
  });

  test('list filters by school_id', () => {
    students.create({ firstName:'Ravi', gender:'male' }, 's-001', 'se-001');
    students.create({ firstName:'Other', gender:'male' }, 's-999', 'se-001');
    const list = students.list('s-001');
    assert.equal(list.length, 1);
    assert.equal(list[0].first_name, 'Ravi');
  });

  test('search works', () => {
    students.create({ firstName:'Ravi', lastName:'Kumar', gender:'male' }, 's-001', 'se-001');
    students.create({ firstName:'Priya', gender:'female' }, 's-001', 'se-001');
    const found = students.list('s-001', { search: 'ravi' });
    assert.equal(found.length, 1);
    assert.equal(found[0].first_name, 'Ravi');
  });

  test('TC cancel changes status', () => {
    const s = students.create({ firstName:'Ravi', gender:'male' }, 's-001', 'se-001');
    students.updateStatus(s.id, 'cancelled', 'Transfer');
    const updated = students.list('s-001', { status: 'cancelled' });
    assert.equal(updated.length, 1);
    assert.equal(updated[0].cancel_reason, 'Transfer');
  });
});

describe('Complete journey: Fee collection', () => {
  beforeEach(async () => {
    db = new MockDB();
    await db.seed();
    students = new StudentService(db);
    fees     = new FeeService(db);
  });

  test('collect a fee payment', () => {
    const s = students.create({ firstName:'Ravi', gender:'male' }, 's-001', 'se-001');
    const p = fees.collectPayment({ studentId: s.id, amount: 5000, schoolId: 's-001' });
    assert.ok(p.receipt_no.startsWith('RCP-'));
    assert.equal(p.amount, 5000);
    assert.equal(p.status, 'paid');
  });

  test('receipt numbers are unique', () => {
    const s = students.create({ firstName:'Ravi', gender:'male' }, 's-001', 'se-001');
    const p1 = fees.collectPayment({ studentId: s.id, amount: 1000, schoolId: 's-001' });
    const p2 = fees.collectPayment({ studentId: s.id, amount: 2000, schoolId: 's-001' });
    assert.notEqual(p1.receipt_no, p2.receipt_no);
  });

  test('payment mode is saved', () => {
    const s = students.create({ firstName:'Ravi', gender:'male' }, 's-001', 'se-001');
    const p = fees.collectPayment({ studentId: s.id, amount: 500, paymentMode: 'upi', schoolId: 's-001' });
    assert.equal(p.payment_mode, 'upi');
  });

  test('zero amount is rejected', () => {
    const s = students.create({ firstName:'Ravi', gender:'male' }, 's-001', 'se-001');
    assert.throws(() => fees.collectPayment({ studentId: s.id, amount: 0, schoolId: 's-001' }), /positive/i);
  });

  test('negative amount is rejected', () => {
    const s = students.create({ firstName:'Ravi', gender:'male' }, 's-001', 'se-001');
    assert.throws(() => fees.collectPayment({ studentId: s.id, amount: -100, schoolId: 's-001' }), /positive/i);
  });

  test('total collected accumulates correctly', () => {
    const s = students.create({ firstName:'Ravi', gender:'male' }, 's-001', 'se-001');
    fees.collectPayment({ studentId: s.id, amount: 3000, schoolId: 's-001' });
    fees.collectPayment({ studentId: s.id, amount: 2000, schoolId: 's-001' });
    assert.equal(fees.getTotalCollected('s-001'), 5000);
  });

  test('payments are school-isolated', () => {
    const s1 = students.create({ firstName:'A', gender:'male' }, 's-001', 'se-001');
    const s2 = students.create({ firstName:'B', gender:'male' }, 's-999', 'se-001');
    fees.collectPayment({ studentId: s1.id, amount: 1000, schoolId: 's-001' });
    fees.collectPayment({ studentId: s2.id, amount: 9999, schoolId: 's-999' });
    assert.equal(fees.getTotalCollected('s-001'), 1000);
    assert.equal(fees.getTotalCollected('s-999'), 9999);
  });

  test('get payments by student', () => {
    const s1 = students.create({ firstName:'A', gender:'male' }, 's-001', 'se-001');
    const s2 = students.create({ firstName:'B', gender:'male' }, 's-001', 'se-001');
    fees.collectPayment({ studentId: s1.id, amount: 1000, schoolId: 's-001' });
    fees.collectPayment({ studentId: s1.id, amount: 500,  schoolId: 's-001' });
    fees.collectPayment({ studentId: s2.id, amount: 2000, schoolId: 's-001' });
    const s1payments = fees.getPayments('s-001', s1.id);
    assert.equal(s1payments.length, 2);
  });
});

describe('Complete journey: Admin deactivates a user', () => {
  beforeEach(async () => {
    db = new MockDB();
    await db.seed();
    auth = new AuthService(db);
  });

  test('deactivated user cannot login', async () => {
    // Deactivate the admin
    db.tables.users[0].is_active = false;
    const result = await auth.login('admin@vidyamate.in', 'Admin@123');
    assert.ok(result.error);
    assert.ok(result.error.includes('inactive'));
    assert.equal(result.status, 401);
  });

  test('reactivated user can login again', async () => {
    db.tables.users[0].is_active = false;
    let result = await auth.login('admin@vidyamate.in', 'Admin@123');
    assert.ok(result.error);

    db.tables.users[0].is_active = true;
    result = await auth.login('admin@vidyamate.in', 'Admin@123');
    assert.ok(result.accessToken);
  });
});

describe('Multi-school isolation', () => {
  beforeEach(async () => {
    db = new MockDB();
    await db.seed();
    students = new StudentService(db);
  });

  test('students of school A are not visible to school B', () => {
    students.create({ firstName:'SchoolA Student', gender:'male' }, 'school-A', 'se-001');
    students.create({ firstName:'SchoolB Student', gender:'male' }, 'school-B', 'se-001');

    const schoolAList = students.list('school-A');
    const schoolBList = students.list('school-B');

    assert.equal(schoolAList.length, 1);
    assert.equal(schoolBList.length, 1);
    assert.equal(schoolAList[0].first_name, 'SchoolA Student');
    assert.equal(schoolBList[0].first_name, 'SchoolB Student');
  });
});
