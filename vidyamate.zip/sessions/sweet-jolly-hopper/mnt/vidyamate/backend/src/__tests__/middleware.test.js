/**
 * Middleware Unit Tests
 * Tests auth middleware, error handler, validation
 */
const { test, describe } = require('node:test');
const assert = require('node:assert/strict');
const jwt    = require('jsonwebtoken');

process.env.JWT_SECRET         = 'test-jwt-secret-32-chars-minimum!!';
process.env.JWT_REFRESH_SECRET = 'test-refresh-secret-32-chars-min!';

// ── Mock req/res/next ──────────────────────────────────────
const makeReq = (overrides = {}) => ({
  headers: {},
  user:    null,
  body:    {},
  query:   {},
  params:  {},
  ip:      '127.0.0.1',
  ...overrides,
});

const makeRes = () => {
  const res = { statusCode: 200, body: null };
  res.status = (code) => { res.statusCode = code; return res; };
  res.json   = (body)  => { res.body = body;       return res; };
  return res;
};

const makeNext = () => {
  const fn = (err) => { fn.called = true; fn.error = err; };
  fn.called = false; fn.error = null;
  return fn;
};

// ── Auth middleware logic ──────────────────────────────────
const authenticate = (req, res, next) => {
  const header = req.headers['authorization'];
  if (!header || !header.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'No token provided' });
  }
  const token = header.slice(7);
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;
    next();
  } catch (err) {
    if (err.name === 'TokenExpiredError') {
      return res.status(401).json({ error: 'Token expired' });
    }
    return res.status(401).json({ error: 'Invalid token' });
  }
};

const authorize = (...roles) => (req, res, next) => {
  if (!req.user) return res.status(401).json({ error: 'Not authenticated' });
  if (!roles.includes(req.user.role)) {
    return res.status(403).json({ error: 'Insufficient permissions' });
  }
  next();
};

// ── Auth middleware tests ──────────────────────────────────
describe('authenticate middleware', () => {
  const validToken = jwt.sign(
    { id: 'u-001', role: 'teacher', school_id: 's-001' },
    process.env.JWT_SECRET,
    { expiresIn: '15m' }
  );

  test('passes with valid Bearer token', () => {
    const req  = makeReq({ headers: { authorization: `Bearer ${validToken}` } });
    const res  = makeRes();
    const next = makeNext();
    authenticate(req, res, next);
    assert.ok(next.called);
    assert.equal(next.error, undefined);
    assert.equal(req.user.id, 'u-001');
    assert.equal(req.user.role, 'teacher');
  });

  test('rejects missing Authorization header', () => {
    const req = makeReq();
    const res = makeRes();
    const next = makeNext();
    authenticate(req, res, next);
    assert.ok(!next.called);
    assert.equal(res.statusCode, 401);
    assert.equal(res.body.error, 'No token provided');
  });

  test('rejects malformed token', () => {
    const req  = makeReq({ headers: { authorization: 'Bearer not.a.valid.jwt.token' } });
    const res  = makeRes();
    const next = makeNext();
    authenticate(req, res, next);
    assert.ok(!next.called);
    assert.equal(res.statusCode, 401);
  });

  test('rejects token signed with wrong secret', () => {
    const badToken = jwt.sign({ id: 'u-001', role: 'super_admin' }, 'wrong-secret');
    const req      = makeReq({ headers: { authorization: `Bearer ${badToken}` } });
    const res      = makeRes();
    const next     = makeNext();
    authenticate(req, res, next);
    assert.equal(res.statusCode, 401);
    assert.ok(res.body.error.includes('Invalid'));
  });

  test('rejects expired token', () => {
    const expired = jwt.sign(
      { id: 'u-001', role: 'teacher' },
      process.env.JWT_SECRET,
      { expiresIn: '-1s' }  // expired 1 second ago
    );
    const req  = makeReq({ headers: { authorization: `Bearer ${expired}` } });
    const res  = makeRes();
    const next = makeNext();
    authenticate(req, res, next);
    assert.equal(res.statusCode, 401);
    assert.ok(res.body.error.includes('expired'));
  });

  test('rejects token without Bearer prefix', () => {
    const req  = makeReq({ headers: { authorization: validToken } });
    const res  = makeRes();
    const next = makeNext();
    authenticate(req, res, next);
    assert.equal(res.statusCode, 401);
  });
});

describe('authorize middleware', () => {
  const makeAuthedReq = (role) => makeReq({
    user: { id: 'u-001', role, school_id: 's-001' }
  });

  test('allows exact role match', () => {
    const next = makeNext();
    authorize('principal')(makeAuthedReq('principal'), makeRes(), next);
    assert.ok(next.called);
  });

  test('allows any matching role from list', () => {
    const next = makeNext();
    authorize('super_admin', 'org_admin', 'principal')(makeAuthedReq('org_admin'), makeRes(), next);
    assert.ok(next.called);
  });

  test('blocks unauthorized role', () => {
    const res  = makeRes();
    const next = makeNext();
    authorize('super_admin')(makeAuthedReq('teacher'), res, next);
    assert.ok(!next.called);
    assert.equal(res.statusCode, 403);
    assert.ok(res.body.error.includes('permissions'));
  });

  test('blocks when no user on request', () => {
    const res  = makeRes();
    const next = makeNext();
    authorize('teacher')(makeReq(), res, next);
    assert.equal(res.statusCode, 401);
  });

  test('teacher cannot access super_admin routes', () => {
    const res  = makeRes();
    const next = makeNext();
    authorize('super_admin', 'org_admin')(makeAuthedReq('teacher'), res, next);
    assert.equal(res.statusCode, 403);
  });
});

describe('error handler middleware', () => {
  const errorHandler = (err, req, res, next) => {
    const status  = err.status || err.statusCode || 500;
    const message = err.message || 'Internal server error';
    
    // Don't leak stack traces in production
    const body = process.env.NODE_ENV === 'production'
      ? { error: message }
      : { error: message, ...(err.details && { details: err.details }) };
    
    res.status(status).json(body);
  };

  test('returns 500 for generic errors', () => {
    const err = new Error('Something broke');
    const res = makeRes();
    errorHandler(err, makeReq(), res, makeNext());
    assert.equal(res.statusCode, 500);
    assert.equal(res.body.error, 'Something broke');
  });

  test('respects custom status code', () => {
    const err  = Object.assign(new Error('Not found'), { status: 404 });
    const res  = makeRes();
    errorHandler(err, makeReq(), res, makeNext());
    assert.equal(res.statusCode, 404);
  });

  test('returns validation details in dev', () => {
    const err  = Object.assign(new Error('Validation failed'), { details: [{ field: 'email', message: 'Required' }] });
    const res  = makeRes();
    process.env.NODE_ENV = 'development';
    errorHandler(err, makeReq(), res, makeNext());
    assert.ok(res.body.details);
    process.env.NODE_ENV = 'test';
  });

  test('handles PostgreSQL unique violation', () => {
    const pgError = Object.assign(new Error('duplicate key value violates unique constraint "users_email_key"'), { code: '23505' });
    const res     = makeRes();
    errorHandler(pgError, makeReq(), res, makeNext());
    assert.equal(res.statusCode, 500); // Would be caught by controller normally
  });
});

describe('role hierarchy', () => {
  // Document and test the role permission model
  const ROLES = {
    super_admin:  5,
    org_admin:    4,
    principal:    3,
    teacher:      2,
    accountant:   2,
    non_teaching: 1,
  };

  const canAccess = (userRole, requiredRoles) => requiredRoles.includes(userRole);

  test('super_admin can do everything', () => {
    const allRoutes = [
      ['super_admin','org_admin','principal'],
      ['super_admin','org_admin'],
      ['super_admin'],
    ];
    allRoutes.forEach(roles => {
      assert.ok(canAccess('super_admin', roles));
    });
  });

  test('teacher cannot manage organizations', () => {
    assert.ok(!canAccess('teacher', ['super_admin', 'org_admin']));
  });

  test('accountant can collect fees', () => {
    assert.ok(canAccess('accountant', ['super_admin','org_admin','principal','accountant']));
  });

  test('teacher can access teacher routes', () => {
    assert.ok(canAccess('teacher', ['super_admin','org_admin','principal','teacher','accountant']));
  });

  test('non_teaching has most restricted access', () => {
    assert.ok(!canAccess('non_teaching', ['super_admin','org_admin','principal','teacher','accountant']));
  });
});

describe('UUID parameter validation', () => {
  const { validationResult, param } = require('express-validator');

  const validateUUID = async (id) => {
    const req = { params: { id } };
    await param('id').isUUID().withMessage('Invalid ID format').run(req);
    return validationResult(req);
  };

  test('valid UUID v4 passes', async () => {
    const result = await validateUUID('550e8400-e29b-41d4-a716-446655440000');
    assert.ok(result.isEmpty(), 'Valid UUID should pass validation');
  });

  test('valid UUID v4 with lowercase passes', async () => {
    const result = await validateUUID('6ba7b810-9dad-11d1-80b4-00c04fd430c8');
    assert.ok(result.isEmpty());
  });

  test('SQL injection string fails', async () => {
    const result = await validateUUID("' OR '1'='1");
    assert.ok(!result.isEmpty(), 'SQL injection should fail UUID validation');
    assert.ok(result.errors[0].msg.includes('Invalid ID'));
  });

  test('empty string fails', async () => {
    const result = await validateUUID('');
    assert.ok(!result.isEmpty());
  });

  test('numeric ID fails', async () => {
    const result = await validateUUID('12345');
    assert.ok(!result.isEmpty());
  });

  test('path traversal fails', async () => {
    const result = await validateUUID('../etc/passwd');
    assert.ok(!result.isEmpty());
  });

  test('malformed UUID fails', async () => {
    const result = await validateUUID('not-a-real-uuid-here');
    assert.ok(!result.isEmpty());
  });
});
