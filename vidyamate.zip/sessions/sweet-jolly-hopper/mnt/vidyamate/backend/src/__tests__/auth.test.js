/**
 * Auth Controller Unit Tests
 * Tests JWT generation, token validation, password hashing
 * Uses Node.js built-in test runner (node:test)
 */
const { test, describe, before, after } = require('node:test');
const assert = require('node:assert/strict');

// ── Mock database ──────────────────────────────────────────
const mockDb = {
  rows: [],
  query: async (sql, params) => {
    // Simple SQL pattern matching for tests
    if (sql.includes('SELECT') && sql.includes('users') && sql.includes('email')) {
      const email = params[0]?.toLowerCase();
      const user  = mockDb.users.find(u => u.email.toLowerCase() === email);
      return { rows: user ? [user] : [] };
    }
    if (sql.includes('SELECT') && sql.includes('users') && sql.includes('id =')) {
      const user = mockDb.users.find(u => u.id === params[0]);
      return { rows: user ? [user] : [] };
    }
    if (sql.includes('UPDATE users SET last_login')) return { rows: [] };
    if (sql.includes('INSERT INTO audit_logs'))       return { rows: [] };
    if (sql.includes('reset_token'))                  return { rows: [] };
    return { rows: [] };
  },
  users: []
};

// Override the database module
require.cache[require.resolve('../config/database')] = {
  id: require.resolve('../config/database'),
  filename: require.resolve('../config/database'),
  loaded: true,
  exports: { query: mockDb.query, withTransaction: async (fn) => fn(mockDb) }
};

const bcrypt   = require('bcryptjs');
const jwt      = require('jsonwebtoken');
const crypto   = require('crypto');

// Set JWT secrets for tests
process.env.JWT_SECRET         = 'test-jwt-secret-32-chars-minimum!!';
process.env.JWT_REFRESH_SECRET = 'test-refresh-secret-32-chars-min!';
process.env.JWT_EXPIRES_IN     = '15m';

// ── Helpers ────────────────────────────────────────────────
async function hashPassword(pw) {
  return bcrypt.hash(pw, 10);
}

function generateTokens(user) {
  const payload = { id: user.id, role: user.role, school_id: user.school_id };
  const accessToken  = jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: '15m' });
  const refreshToken = jwt.sign({ id: user.id }, process.env.JWT_REFRESH_SECRET, { expiresIn: '7d' });
  return { accessToken, refreshToken };
}

// ── Tests ──────────────────────────────────────────────────

describe('Password hashing', () => {
  test('bcrypt hash is not plaintext', async () => {
    const hash = await hashPassword('Admin@123');
    assert.notEqual(hash, 'Admin@123');
    assert.ok(hash.startsWith('$2'));
  });

  test('bcrypt compare succeeds for correct password', async () => {
    const hash  = await hashPassword('Admin@123');
    const valid = await bcrypt.compare('Admin@123', hash);
    assert.equal(valid, true);
  });

  test('bcrypt compare fails for wrong password', async () => {
    const hash  = await hashPassword('Admin@123');
    const valid = await bcrypt.compare('wrong-password', hash);
    assert.equal(valid, false);
  });

  test('seed hash matches Admin@123', async () => {
    // Correct hash generated fresh — verified with bcrypt.compare
    const seedHash = '$2a$12$9MP4PW5f7Bt4tqtKx8fKr.TjvRSNjO0MjKXqUIruGjr3w3MS7eNoe';
    const valid    = await bcrypt.compare('Admin@123', seedHash);
    assert.equal(valid, true, 'Seed data hash must match Admin@123');
  });
});

describe('JWT token generation', () => {
  const mockUser = { id: 'u-test-001', role: 'principal', school_id: 's-001' };

  test('generates valid access token', () => {
    const { accessToken } = generateTokens(mockUser);
    assert.ok(typeof accessToken === 'string');
    assert.ok(accessToken.split('.').length === 3, 'JWT must have 3 parts');
  });

  test('access token contains correct payload', () => {
    const { accessToken } = generateTokens(mockUser);
    const decoded = jwt.verify(accessToken, process.env.JWT_SECRET);
    assert.equal(decoded.id,        mockUser.id);
    assert.equal(decoded.role,      mockUser.role);
    assert.equal(decoded.school_id, mockUser.school_id);
  });

  test('refresh token is separate from access token', () => {
    const { accessToken, refreshToken } = generateTokens(mockUser);
    assert.notEqual(accessToken, refreshToken);
  });

  test('refresh token contains only id (no role)', () => {
    const { refreshToken } = generateTokens(mockUser);
    const decoded = jwt.verify(refreshToken, process.env.JWT_REFRESH_SECRET);
    assert.equal(decoded.id, mockUser.id);
    assert.equal(decoded.role, undefined, 'Refresh token should not contain role');
  });

  test('tampered access token is rejected', () => {
    const { accessToken } = generateTokens(mockUser);
    const tampered = accessToken.slice(0, -5) + 'XXXXX';
    assert.throws(
      () => jwt.verify(tampered, process.env.JWT_SECRET),
      { name: 'JsonWebTokenError' }
    );
  });

  test('token signed with wrong secret is rejected', () => {
    const fakeToken = jwt.sign({ id: 'hacker', role: 'super_admin' }, 'wrong-secret');
    assert.throws(
      () => jwt.verify(fakeToken, process.env.JWT_SECRET),
      { name: 'JsonWebTokenError' }
    );
  });
});

describe('Password reset token', () => {
  test('generates 64-char hex token', () => {
    const token = crypto.randomBytes(32).toString('hex');
    assert.equal(token.length, 64);
    assert.ok(/^[0-9a-f]+$/.test(token));
  });

  test('two tokens are always different', () => {
    const t1 = crypto.randomBytes(32).toString('hex');
    const t2 = crypto.randomBytes(32).toString('hex');
    assert.notEqual(t1, t2);
  });

  test('expiry is 1 hour from now', () => {
    const expiry = new Date(Date.now() + 3600000);
    const diff   = expiry.getTime() - Date.now();
    assert.ok(diff > 3590000 && diff <= 3600000, 'Expiry should be ~1 hour');
  });
});

describe('Input validation rules', () => {
  // Test the validation logic directly without Express
  const isValidPhone = (phone) => /^[6-9]\d{9}$/.test(phone?.replace(/\D/g, ''));
  const isValidEmail = (email) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  const isValidAadhaar = (a)   => /^\d{12}$/.test(a?.replace(/\s/g, ''));

  test('valid Indian mobile number', () => {
    assert.ok(isValidPhone('9876543210'));
    assert.ok(isValidPhone('6000000000'));
  });

  test('invalid mobile: starts with 1', () => {
    assert.ok(!isValidPhone('1234567890'));
  });

  test('invalid mobile: 9 digits', () => {
    assert.ok(!isValidPhone('987654321'));
  });

  test('valid email addresses', () => {
    assert.ok(isValidEmail('admin@vidyamate.in'));
    assert.ok(isValidEmail('teacher.name@school.com'));
  });

  test('invalid emails', () => {
    assert.ok(!isValidEmail('notanemail'));
    assert.ok(!isValidEmail('@nodomain'));
  });

  test('valid 12-digit Aadhaar', () => {
    assert.ok(isValidAadhaar('123456789012'));
    assert.ok(isValidAadhaar('1234 5678 9012'));
  });

  test('invalid Aadhaar: 11 digits', () => {
    assert.ok(!isValidAadhaar('12345678901'));
  });
});

describe('Grade calculation logic', () => {
  const calcGrade = (marks, max = 100) => {
    const pct = (marks / max) * 100;
    if (pct >= 90) return 'A+';
    if (pct >= 80) return 'A';
    if (pct >= 70) return 'B+';
    if (pct >= 60) return 'B';
    if (pct >= 50) return 'C';
    if (pct >= 35) return 'D';
    return 'F';
  };

  test('95/100 = A+', () => assert.equal(calcGrade(95), 'A+'));
  test('80/100 = A',  () => assert.equal(calcGrade(80), 'A'));
  test('75/100 = B+', () => assert.equal(calcGrade(75), 'B+'));
  test('60/100 = B',  () => assert.equal(calcGrade(60), 'B'));
  test('50/100 = C',  () => assert.equal(calcGrade(50), 'C'));
  test('35/100 = D',  () => assert.equal(calcGrade(35), 'D'));
  test('34/100 = F',  () => assert.equal(calcGrade(34), 'F'));
  test('0/100 = F',   () => assert.equal(calcGrade(0),  'F'));
  test('85/100 = A',  () => assert.equal(calcGrade(85), 'A'));
  test('works with custom max: 45/50 = 90% = A+', () => assert.equal(calcGrade(45, 50), 'A+'));
});

describe('Fee calculation logic', () => {
  const calcBalance = (total, concession, paid) => {
    const net = total - concession;
    return net - paid;
  };

  const calcStatus = (total, concession, paid) => {
    const balance = calcBalance(total, concession, paid);
    const net = total - concession;
    if (balance <= 0)     return 'paid';
    if (paid > 0)         return 'partial';
    return 'pending';
  };

  test('full payment = paid',    () => assert.equal(calcStatus(5000, 0,    5000), 'paid'));
  test('no payment = pending',   () => assert.equal(calcStatus(5000, 0,    0),    'pending'));
  test('partial payment',        () => assert.equal(calcStatus(5000, 0,    2000), 'partial'));
  test('full concession = paid', () => assert.equal(calcStatus(5000, 5000, 0),    'paid'));
  test('partial concession',     () => {
    // 5000 - 1000 concession = 4000 net, paid 4000 = paid
    assert.equal(calcStatus(5000, 1000, 4000), 'paid');
  });
  test('balance is 0 when fully paid', () => {
    assert.equal(calcBalance(5000, 0, 5000), 0);
  });
  test('balance accounts for concession', () => {
    assert.equal(calcBalance(5000, 500, 2000), 2500);
  });
});

describe('Attendance percentage calculation', () => {
  const calcPct = (present, total) => {
    if (!total) return 0;
    return Math.round((present / total) * 100 * 10) / 10;
  };
  const status = (pct) => pct >= 75 ? 'Regular' : pct >= 60 ? 'Warning' : 'Shortage';

  test('100% attendance',  () => assert.equal(calcPct(26, 26), 100));
  test('75% attendance',   () => assert.equal(calcPct(75, 100), 75));
  test('0% attendance',    () => assert.equal(calcPct(0, 26), 0));
  test('zero total = 0',   () => assert.equal(calcPct(0, 0), 0));
  test('80% = Regular',    () => assert.equal(status(80), 'Regular'));
  test('74% = Warning',    () => assert.equal(status(74), 'Warning'));
  test('60% = Warning',    () => assert.equal(status(60), 'Warning'));
  test('59% = Shortage',   () => assert.equal(status(59), 'Shortage'));
});

describe('Receipt number generation', () => {
  const genReceipt = (count, year = 2025) => 
    `RCP-${year}-${String(count + 1).padStart(5, '0')}`;

  test('first receipt = RCP-2025-00001', () => assert.equal(genReceipt(0), 'RCP-2025-00001'));
  test('100th receipt = RCP-2025-00100', () => assert.equal(genReceipt(99), 'RCP-2025-00100'));
  test('receipt is always 5 digits',     () => {
    const r = genReceipt(9);
    assert.ok(r.endsWith('-00010'), `Expected -00010, got ${r}`);
  });
});

describe('SQL injection prevention', () => {
  // Parameterized queries prevent injection - test our patterns
  test('parameterized query uses $1 placeholders', () => {
    const query = `SELECT * FROM students WHERE school_id = $1 AND status = $2`;
    assert.ok(query.includes('$1'));
    assert.ok(query.includes('$2'));
    assert.ok(!query.includes("' OR '1'='1"));
  });

  test('dangerous input stays in params array, not query string', () => {
    const maliciousInput = "'; DROP TABLE students; --";
    const params         = [maliciousInput];
    const query          = `SELECT * FROM students WHERE first_name = $1`;
    // The query string itself has no user input
    assert.ok(!query.includes(maliciousInput));
    assert.equal(params[0], maliciousInput);
  });
});
