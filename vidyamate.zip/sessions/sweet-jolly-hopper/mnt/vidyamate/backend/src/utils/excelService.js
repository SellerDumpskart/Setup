const ExcelJS = require('exceljs');
const path    = require('path');
const fs      = require('fs');

const UPLOAD_DIR  = process.env.UPLOAD_DIR || './uploads';
const EXCEL_DIR   = path.join(UPLOAD_DIR, 'exports');
if (!fs.existsSync(EXCEL_DIR)) fs.mkdirSync(EXCEL_DIR, { recursive: true });

const PRIMARY = '00A99D';
const HEADER_FILL = { type:'pattern', pattern:'solid', fgColor:{ argb: `FF${PRIMARY}` } };
const HEADER_FONT = { bold:true, color:{ argb:'FFFFFFFF' }, size:11 };

// ── Base workbook builder ─────────────────────────────────
const createWorkbook = (sheetName) => {
  const wb   = new ExcelJS.Workbook();
  wb.creator  = 'VidyaMate';
  wb.created  = new Date();
  const ws   = wb.addWorksheet(sheetName, {
    pageSetup: { paperSize: 9, orientation: 'landscape' }
  });
  return { wb, ws };
};

const styleHeader = (ws, cols) => {
  ws.columns = cols.map(c => ({ header: c.header, key: c.key, width: c.width || 20 }));
  const headerRow = ws.getRow(1);
  headerRow.eachCell(cell => {
    cell.fill = HEADER_FILL;
    cell.font = HEADER_FONT;
    cell.alignment = { vertical:'middle', horizontal:'center' };
    cell.border = { bottom:{ style:'thin', color:{ argb:'FFCCCCCC' } } };
  });
  headerRow.height = 28;
};

const addRow = (ws, rowData, rowIndex) => {
  const row = ws.addRow(rowData);
  row.height = 20;
  if (rowIndex % 2 === 0) {
    row.eachCell(cell => {
      cell.fill = { type:'pattern', pattern:'solid', fgColor:{ argb:'FFF5FAFA' } };
    });
  }
  row.eachCell(cell => {
    cell.alignment = { vertical:'middle' };
    cell.border = { bottom:{ style:'hair', color:{ argb:'FFE2E8F0' } } };
  });
};

const saveWorkbook = async (wb, filename) => {
  const filePath = path.join(EXCEL_DIR, filename);
  await wb.xlsx.writeFile(filePath);
  return { filePath, url: `/uploads/exports/${filename}` };
};

// ── STUDENT LIST EXPORT ──────────────────────────────────
const exportStudents = async (students, schoolName) => {
  const { wb, ws } = createWorkbook('Students');

  ws.mergeCells('A1:J1');
  ws.getCell('A1').value = `${schoolName} — Student List`;
  ws.getCell('A1').font  = { bold:true, size:14, color:{ argb:`FF${PRIMARY}` } };
  ws.getCell('A1').alignment = { horizontal:'center' };
  ws.addRow([]);

  styleHeader(ws, [
    { header:'#',           key:'sno',         width:5  },
    { header:'Student Code',key:'student_code', width:16 },
    { header:'Name',        key:'name',         width:24 },
    { header:'Class',       key:'class',        width:10 },
    { header:'Roll No.',    key:'roll_number',  width:10 },
    { header:'Gender',      key:'gender',       width:10 },
    { header:'DOB',         key:'dob',          width:14 },
    { header:'Father Name', key:'father_name',  width:22 },
    { header:'Father Phone',key:'father_phone', width:14 },
    { header:'Status',      key:'status',       width:12 },
  ]);

  students.forEach((s, i) => {
    addRow(ws, {
      sno:          i + 1,
      student_code: s.student_code,
      name:         `${s.first_name} ${s.last_name || ''}`.trim(),
      class:        s.class_name ? `${s.class_name}-${s.section}` : '—',
      roll_number:  s.roll_number || '—',
      gender:       s.gender || '—',
      dob:          s.date_of_birth ? new Date(s.date_of_birth).toLocaleDateString('en-IN') : '—',
      father_name:  s.father_name || '—',
      father_phone: s.father_phone || '—',
      status:       s.status,
    }, i);
  });

  ws.addRow([]);
  ws.addRow([`Total Students: ${students.length}`]);

  const filename = `students_${Date.now()}.xlsx`;
  return saveWorkbook(wb, filename);
};

// ── FEE COLLECTION EXPORT ────────────────────────────────
const exportFeeCollection = async (payments, schoolName) => {
  const { wb, ws } = createWorkbook('Fee Collection');

  ws.mergeCells('A1:H1');
  ws.getCell('A1').value = `${schoolName} — Fee Collection Report`;
  ws.getCell('A1').font  = { bold:true, size:14, color:{ argb:`FF${PRIMARY}` } };
  ws.getCell('A1').alignment = { horizontal:'center' };
  ws.addRow([]);

  styleHeader(ws, [
    { header:'Receipt No.', key:'receipt_no',   width:16 },
    { header:'Date',        key:'payment_date', width:14 },
    { header:'Student',     key:'student',      width:24 },
    { header:'Class',       key:'class',        width:10 },
    { header:'Fee Type',    key:'fee_type',     width:18 },
    { header:'Amount (₹)',  key:'amount',       width:14 },
    { header:'Mode',        key:'mode',         width:12 },
    { header:'Status',      key:'status',       width:10 },
  ]);

  let total = 0;
  payments.forEach((p, i) => {
    total += parseFloat(p.amount) || 0;
    addRow(ws, {
      receipt_no:   p.receipt_no,
      payment_date: p.payment_date ? new Date(p.payment_date).toLocaleDateString('en-IN') : '—',
      student:      `${p.first_name || ''} ${p.last_name || ''}`.trim() || p.student_code,
      class:        p.class_name ? `${p.class_name}-${p.section}` : '—',
      fee_type:     p.fee_name || '—',
      amount:       parseFloat(p.amount),
      mode:         p.payment_mode?.toUpperCase() || '—',
      status:       'Paid',
    }, i);
  });

  ws.addRow([]);
  const totalRow = ws.addRow(['','','','','Total Collected', total, '', '']);
  totalRow.getCell(5).font = { bold:true, color:{ argb:`FF${PRIMARY}` } };
  totalRow.getCell(6).font = { bold:true };
  totalRow.getCell(6).numFmt = '#,##0.00';

  ws.getColumn('amount').numFmt = '#,##0.00';

  const filename = `fee_collection_${Date.now()}.xlsx`;
  return saveWorkbook(wb, filename);
};

// ── ATTENDANCE REPORT EXPORT ─────────────────────────────
const exportAttendance = async (report, className, month, year, schoolName) => {
  const { wb, ws } = createWorkbook('Attendance');

  ws.mergeCells('A1:G1');
  ws.getCell('A1').value = `${schoolName} — Attendance Report — Class ${className} — ${month}/${year}`;
  ws.getCell('A1').font  = { bold:true, size:14, color:{ argb:`FF${PRIMARY}` } };
  ws.getCell('A1').alignment = { horizontal:'center' };
  ws.addRow([]);

  styleHeader(ws, [
    { header:'Roll',      key:'roll',    width:8  },
    { header:'Name',      key:'name',    width:26 },
    { header:'Present',   key:'present', width:12 },
    { header:'Absent',    key:'absent',  width:12 },
    { header:'Leave',     key:'leave',   width:12 },
    { header:'Total',     key:'total',   width:12 },
    { header:'% Attend.', key:'pct',     width:12 },
  ]);

  report.forEach((r, i) => {
    const row = addRow(ws, {
      roll:    r.roll_number || i + 1,
      name:    `${r.first_name} ${r.last_name || ''}`.trim(),
      present: parseInt(r.present_days) || 0,
      absent:  parseInt(r.absent_days)  || 0,
      leave:   parseInt(r.leave_days)   || 0,
      total:   parseInt(r.total_marked) || 0,
      pct:     parseFloat(r.percentage) || 0,
    }, i);
  });

  ws.getColumn('pct').numFmt  = '0.0"%"';

  const filename = `attendance_${className}_${month}_${year}_${Date.now()}.xlsx`;
  return saveWorkbook(wb, filename);
};

// ── EXAM RESULTS EXPORT ──────────────────────────────────
const exportResults = async (results, examName, className, schoolName) => {
  const { wb, ws } = createWorkbook('Results');

  ws.mergeCells('A1:L1');
  ws.getCell('A1').value = `${schoolName} — ${examName} — ${className}`;
  ws.getCell('A1').font  = { bold:true, size:14, color:{ argb:`FF${PRIMARY}` } };
  ws.getCell('A1').alignment = { horizontal:'center' };
  ws.addRow([]);

  styleHeader(ws, [
    { header:'Rank',  key:'rank',   width:8  },
    { header:'Roll',  key:'roll',   width:8  },
    { header:'Name',  key:'name',   width:26 },
    { header:'Eng',   key:'eng',    width:8  },
    { header:'Math',  key:'math',   width:8  },
    { header:'Sci',   key:'sci',    width:8  },
    { header:'Soc',   key:'soc',    width:8  },
    { header:'Lang',  key:'lang',   width:8  },
    { header:'Total', key:'total',  width:10 },
    { header:'%',     key:'pct',    width:8  },
    { header:'Grade', key:'grade',  width:8  },
    { header:'Result',key:'result', width:10 },
  ]);

  results.forEach((r, i) => {
    addRow(ws, {
      rank:   r.rank || i + 1,
      roll:   r.roll_number,
      name:   `${r.first_name} ${r.last_name || ''}`.trim(),
      eng:    r.english  || 0,
      math:   r.maths    || 0,
      sci:    r.science  || 0,
      soc:    r.social   || 0,
      lang:   r.telugu   || r.hindi || 0,
      total:  r.total    || 0,
      pct:    parseFloat(r.pct)  || 0,
      grade:  r.grade    || '—',
      result: r.passed ? 'PASS' : 'FAIL',
    }, i);
  });

  ws.getColumn('pct').numFmt = '0.0"%"';

  const filename = `results_${examName.replace(/\s+/g,'_')}_${Date.now()}.xlsx`;
  return saveWorkbook(wb, filename);
};

// ── STAFF LIST EXPORT ────────────────────────────────────
const exportStaff = async (staff, schoolName) => {
  const { wb, ws } = createWorkbook('Staff');

  styleHeader(ws, [
    { header:'#',            key:'sno',   width:5  },
    { header:'Emp No.',      key:'emp',   width:14 },
    { header:'Name',         key:'name',  width:26 },
    { header:'Designation',  key:'desig', width:20 },
    { header:'Type',         key:'type',  width:16 },
    { header:'Qualification',key:'qual',  width:18 },
    { header:'Phone',        key:'phone', width:14 },
    { header:'Email',        key:'email', width:26 },
    { header:'Status',       key:'status',width:12 },
  ]);

  staff.forEach((s, i) => {
    addRow(ws, {
      sno:   i + 1,
      emp:   s.emp_no,
      name:  `${s.first_name} ${s.last_name || ''}`.trim(),
      desig: s.designation || '—',
      type:  s.staff_type?.replace('_',' ') || '—',
      qual:  s.qualification || '—',
      phone: s.phone || '—',
      email: s.email || '—',
      status:s.status,
    }, i);
  });

  const filename = `staff_${Date.now()}.xlsx`;
  return saveWorkbook(wb, filename);
};

module.exports = { exportStudents, exportFeeCollection, exportAttendance, exportResults, exportStaff };
