const path = require('path');
const fs   = require('fs');

const UPLOAD_DIR = process.env.UPLOAD_DIR || './uploads';
const PDF_DIR    = path.join(UPLOAD_DIR, 'pdfs');
if (!fs.existsSync(PDF_DIR)) fs.mkdirSync(PDF_DIR, { recursive: true });

// ── HTML → PDF via Puppeteer (optional - graceful fallback) ──
let puppeteer = null;
try { puppeteer = require('puppeteer'); } catch { /* not installed */ }

const htmlToPdf = async (html, filename) => {
  if (!puppeteer) {
    // Fallback: save HTML file
    const filePath = path.join(PDF_DIR, filename.replace('.pdf', '.html'));
    fs.writeFileSync(filePath, html);
    return `/uploads/pdfs/${filename.replace('.pdf', '.html')}`;
  }

  const browser = await puppeteer.launch({ args: ['--no-sandbox','--disable-setuid-sandbox'] });
  const page    = await browser.newPage();
  await page.setContent(html, { waitUntil: 'networkidle0' });
  const filePath = path.join(PDF_DIR, filename);
  await page.pdf({ path: filePath, format: 'A4', printBackground: true, margin: { top:'15mm', bottom:'15mm', left:'10mm', right:'10mm' } });
  await browser.close();
  return `/uploads/pdfs/${filename}`;
};

// ── HALL TICKET HTML ──────────────────────────────────────
const generateHallTicketHtml = (tickets, exam, school) => {
  const rows = tickets.map(t => `
    <div class="ticket">
      <div class="ticket-header">
        <div class="school-logo">🎓</div>
        <div class="school-info">
          <h2>${school?.name || 'VidyaMate School'}</h2>
          <p>HALL TICKET — ${exam.exam_name}</p>
          <p>${exam.start_date ? new Date(exam.start_date).toLocaleDateString('en-IN', { day:'2-digit', month:'long', year:'numeric' }) : ''}</p>
        </div>
        <div class="admit-text">ADMIT CARD</div>
      </div>
      <div class="ticket-body">
        <div class="field-row">
          <div class="field"><label>Hall Ticket No.</label><span>${t.hall_ticket_no}</span></div>
          <div class="field"><label>Roll No.</label><span>${t.student?.roll_number || '—'}</span></div>
        </div>
        <div class="field-row">
          <div class="field"><label>Student Name</label><span>${t.student?.first_name} ${t.student?.last_name || ''}</span></div>
          <div class="field"><label>Class</label><span>${t.student?.class_name}-${t.student?.section}</span></div>
        </div>
        <div class="field-row">
          <div class="field"><label>Date of Birth</label><span>${t.student?.date_of_birth ? new Date(t.student.date_of_birth).toLocaleDateString('en-IN') : '—'}</span></div>
          <div class="field"><label>Exam Dates</label><span>${exam.start_date ? new Date(exam.start_date).toLocaleDateString('en-IN',{day:'2-digit',month:'short'}) : ''} – ${exam.end_date ? new Date(exam.end_date).toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'}) : ''}</span></div>
        </div>
      </div>
      <div class="ticket-footer">
        <div class="sig">Principal's Signature</div>
        <div class="sig">Student's Signature</div>
      </div>
    </div>
  `).join('<div class="page-break"></div>');

  return `<!DOCTYPE html><html><head><meta charset="UTF-8">
<style>
  body { font-family: Arial, sans-serif; font-size: 13px; color: #222; }
  .ticket { border: 2px solid #00A99D; border-radius: 10px; padding: 20px; margin-bottom: 20px; max-width: 700px; }
  .ticket-header { display: flex; align-items: center; gap: 14px; border-bottom: 1px dashed #ccc; padding-bottom: 12px; margin-bottom: 14px; }
  .school-logo { font-size: 36px; }
  .school-info h2 { margin: 0; font-size: 15px; color: #00A99D; }
  .school-info p { margin: 2px 0; font-size: 12px; color: #555; }
  .admit-text { margin-left: auto; background: #00A99D; color: #fff; padding: 6px 14px; border-radius: 6px; font-weight: 700; font-size: 12px; }
  .ticket-body { display: flex; flex-direction: column; gap: 10px; }
  .field-row { display: flex; gap: 20px; }
  .field { flex: 1; }
  .field label { display: block; font-size: 10px; text-transform: uppercase; color: #888; font-weight: 600; margin-bottom: 2px; }
  .field span { font-size: 14px; font-weight: 600; color: #222; }
  .ticket-footer { display: flex; justify-content: space-between; margin-top: 18px; padding-top: 12px; border-top: 1px dashed #ccc; }
  .sig { text-align: center; font-size: 11px; color: #888; padding-top: 30px; border-top: 1px solid #ccc; width: 160px; }
  .page-break { page-break-after: always; }
</style></head><body>${rows}</body></html>`;
};

// ── FEE RECEIPT HTML ──────────────────────────────────────
const generateReceiptHtml = (payment, student, school) => `
<!DOCTYPE html><html><head><meta charset="UTF-8">
<style>
  body { font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 30px; }
  .header { text-align: center; border-bottom: 2px solid #00A99D; padding-bottom: 16px; margin-bottom: 20px; }
  .header h1 { color: #00A99D; margin: 0; font-size: 20px; }
  .receipt-no { background: #f0fafa; border: 1px solid #00A99D; border-radius: 8px; padding: 10px 16px; margin-bottom: 20px; display: flex; justify-content: space-between; }
  .receipt-no span { font-weight: 700; color: #00A99D; font-size: 15px; }
  .row { display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid #f0f0f0; }
  .row label { color: #888; font-size: 13px; }
  .row span { font-weight: 600; color: #222; }
  .total { background: #00A99D; color: #fff; padding: 12px 16px; border-radius: 8px; display: flex; justify-content: space-between; font-size: 16px; font-weight: 700; margin-top: 16px; }
  .footer { margin-top: 24px; text-align: center; font-size: 11px; color: #aaa; }
</style></head><body>
  <div class="header"><h1>${school?.name || 'VidyaMate School'}</h1><p>FEE RECEIPT</p></div>
  <div class="receipt-no"><span>Receipt No: ${payment.receipt_no}</span><span>Date: ${new Date(payment.created_at).toLocaleDateString('en-IN',{day:'2-digit',month:'long',year:'numeric'})}</span></div>
  <div class="row"><label>Student Name</label><span>${student?.first_name} ${student?.last_name || ''}</span></div>
  <div class="row"><label>Student Code</label><span>${student?.student_code}</span></div>
  <div class="row"><label>Class</label><span>${student?.class_name}-${student?.section}</span></div>
  <div class="row"><label>Fee Type</label><span>${payment.fee_name || 'School Fee'}</span></div>
  <div class="row"><label>Payment Mode</label><span>${payment.payment_mode?.toUpperCase()}</span></div>
  ${payment.transaction_id ? `<div class="row"><label>Transaction ID</label><span>${payment.transaction_id}</span></div>` : ''}
  <div class="total"><span>Amount Paid</span><span>₹${Number(payment.amount).toLocaleString('en-IN')}</span></div>
  <div class="footer">This is a computer-generated receipt. No signature required.</div>
</body></html>`;

// ── PAYSLIP HTML ──────────────────────────────────────────
const generatePayslipHtml = (payroll, staff, school) => `
<!DOCTYPE html><html><head><meta charset="UTF-8">
<style>
  body { font-family: Arial, sans-serif; max-width: 650px; margin: 0 auto; padding: 30px; font-size: 13px; }
  .header { text-align: center; border-bottom: 2px solid #00A99D; padding-bottom: 16px; margin-bottom: 20px; }
  .header h1 { color: #00A99D; margin:0; font-size:18px; }
  h3 { color: #00A99D; font-size: 13px; text-transform: uppercase; letter-spacing: .05em; margin: 16px 0 8px; }
  table { width: 100%; border-collapse: collapse; }
  td { padding: 7px 10px; border-bottom: 1px solid #f0f0f0; }
  td:last-child { text-align: right; font-weight: 600; }
  .total-row td { background: #00A99D; color: #fff; font-weight: 700; font-size: 14px; }
</style></head><body>
  <div class="header">
    <h1>${school?.name || 'VidyaMate School'}</h1>
    <p>SALARY SLIP — ${['','January','February','March','April','May','June','July','August','September','October','November','December'][payroll.month]} ${payroll.year}</p>
  </div>
  <h3>Employee Details</h3>
  <table>
    <tr><td>Name</td><td>${staff?.first_name} ${staff?.last_name || ''}</td></tr>
    <tr><td>Employee No.</td><td>${staff?.emp_no}</td></tr>
    <tr><td>Designation</td><td>${staff?.designation}</td></tr>
    <tr><td>Days Worked</td><td>${payroll.days_worked} / 26</td></tr>
  </table>
  <h3>Earnings</h3>
  <table>
    <tr><td>Basic Salary</td><td>₹${Number(payroll.gross_salary).toLocaleString('en-IN')}</td></tr>
  </table>
  <h3>Deductions</h3>
  <table>
    <tr><td>PF + PT + TDS</td><td>₹${Number(payroll.deductions).toLocaleString('en-IN')}</td></tr>
  </table>
  <table style="margin-top:16px">
    <tr class="total-row"><td>Net Salary</td><td>₹${Number(payroll.net_salary).toLocaleString('en-IN')}</td></tr>
  </table>
</body></html>`;

module.exports = { htmlToPdf, generateHallTicketHtml, generateReceiptHtml, generatePayslipHtml };
