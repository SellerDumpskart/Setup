const { query, withTransaction } = require('../config/database');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');

const getStaff = async (req, res, next) => {
  try {
    const { schoolId, staffType, search, status = 'active', page = 1, limit = 100 } = req.query;
    const sid = schoolId || req.user.school_id;
    const offset = (page - 1) * limit;

    let where = ['school_id = $1'];
    const params = [sid];
    let idx = 2;

    if (status)    { where.push(`status = $${idx++}`);      params.push(status); }
    if (staffType) { where.push(`staff_type = $${idx++}`);  params.push(staffType); }
    if (search) {
      where.push(`(LOWER(first_name || ' ' || COALESCE(last_name,'')) LIKE $${idx} OR emp_no LIKE $${idx} OR LOWER(email) LIKE $${idx})`);
      params.push(`%${search.toLowerCase()}%`);
      idx++;
    }

    const whereClause = where.join(' AND ');
    const [countRes, dataRes] = await Promise.all([
      query(`SELECT COUNT(*) FROM staff WHERE ${whereClause}`, params),
      query(`SELECT id, emp_no, first_name, last_name, phone, email, qualification,
              designation, staff_type, photo_url, status, date_of_joining, user_id
             FROM staff WHERE ${whereClause}
             ORDER BY first_name
             LIMIT $${idx} OFFSET $${idx + 1}`, [...params, limit, offset]),
    ]);

    res.json({
      staff: dataRes.rows,
      pagination: { total: parseInt(countRes.rows[0].count), page: +page, limit: +limit }
    });
  } catch (err) { next(err); }
};

const getOneStaff = async (req, res, next) => {
  try {
    const { rows } = await query('SELECT * FROM staff WHERE id = $1', [req.params.id]);
    if (!rows.length) return res.status(404).json({ error: 'Staff not found' });
    res.json(rows[0]);
  } catch (err) { next(err); }
};

const createStaff = async (req, res, next) => {
  try {
    const {
      schoolId, empNo, firstName, lastName, gender, dateOfBirth, dateOfJoining,
      phone, email, address, city, state, qualification, designation, staffType,
      salary, aadhaarNo, panNo, bankAccount, bankIfsc, bankName, password
    } = req.body;
    const sid = schoolId || req.user.school_id;

    await withTransaction(async (client) => {
      // Auto-generate emp_no if not provided
      let resolvedEmpNo = empNo;
      if (!resolvedEmpNo) {
        const { rows } = await client.query('SELECT COUNT(*) FROM staff WHERE school_id = $1', [sid]);
        resolvedEmpNo = `ESV${String(parseInt(rows[0].count) + 1).padStart(6, '0')}`;
      }

      // Create user account if email + password provided
      let userId = null;
      if (email && password) {
        const hash = await bcrypt.hash(password, 12);
        const userRes = await client.query(
          `INSERT INTO users (id, school_id, username, email, password_hash, first_name, last_name, role)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id`,
          [uuidv4(), sid, email.split('@')[0], email, hash, firstName, lastName, staffType === 'teaching' ? 'teacher' : 'non_teaching']
        );
        userId = userRes.rows[0].id;
      }

      const staffId = uuidv4();
      const { rows } = await client.query(
        `INSERT INTO staff (id, school_id, user_id, emp_no, first_name, last_name, gender,
          date_of_birth, date_of_joining, phone, email, address, city, state,
          qualification, designation, staff_type, salary, aadhaar_no, pan_no,
          bank_account, bank_ifsc, bank_name)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23)
         RETURNING *`,
        [staffId, sid, userId, resolvedEmpNo, firstName, lastName, gender,
         dateOfBirth, dateOfJoining, phone, email, address, city, state,
         qualification, designation, staffType || 'teaching', salary,
         aadhaarNo, panNo, bankAccount, bankIfsc, bankName]
      );

      res.status(201).json({ message: 'Staff added successfully', staff: rows[0] });
    });
  } catch (err) { next(err); }
};

const updateStaff = async (req, res, next) => {
  try {
    const allowed = ['first_name','last_name','phone','email','designation','staff_type',
                     'qualification','salary','status','photo_url','address','city','state'];
    const updates = [], values = [];
    let idx = 1;
    for (const [key, val] of Object.entries(req.body)) {
      const col = key.replace(/([A-Z])/g, '_$1').toLowerCase();
      if (allowed.includes(col)) { updates.push(`${col} = $${idx++}`); values.push(val); }
    }
    if (!updates.length) return res.status(400).json({ error: 'No valid fields' });
    values.push(req.params.id);
    const { rows } = await query(`UPDATE staff SET ${updates.join(', ')} WHERE id = $${idx} RETURNING *`, values);
    if (!rows.length) return res.status(404).json({ error: 'Staff not found' });
    res.json(rows[0]);
  } catch (err) { next(err); }
};

const deleteStaff = async (req, res, next) => {
  try {
    await query("UPDATE staff SET status = 'inactive' WHERE id = $1", [req.params.id]);
    res.json({ message: 'Staff deactivated' });
  } catch (err) { next(err); }
};

const resetStaffPassword = async (req, res, next) => {
  try {
    const { newPassword } = req.body;
    const { rows } = await query('SELECT user_id FROM staff WHERE id = $1', [req.params.id]);
    if (!rows.length || !rows[0].user_id) return res.status(404).json({ error: 'No user account for this staff' });
    const hash = await bcrypt.hash(newPassword || 'School@123', 12);
    await query('UPDATE users SET password_hash = $1 WHERE id = $2', [hash, rows[0].user_id]);
    res.json({ message: 'Password reset successfully' });
  } catch (err) { next(err); }
};

module.exports = { getStaff, getOneStaff, createStaff, updateStaff, deleteStaff, resetStaffPassword };
