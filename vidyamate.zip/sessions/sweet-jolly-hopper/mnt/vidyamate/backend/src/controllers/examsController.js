const { query, withTransaction } = require('../config/database');
const { v4: uuidv4 } = require('uuid');

// ── EXAMS ──────────────────────────────────────────────────

const getExams = async (req, res, next) => {
  try {
    const { schoolId, sessionId, status } = req.query;
    const sid = schoolId || req.user.school_id;
    let where = ['school_id = $1', 'session_id = $2'];
    const params = [sid, sessionId];
    if (status) { where.push(`status = $3`); params.push(status); }
    const { rows } = await query(
      `SELECT * FROM exams WHERE ${where.join(' AND ')} ORDER BY start_date`,
      params
    );
    res.json(rows);
  } catch (err) { next(err); }
};

const createExam = async (req, res, next) => {
  try {
    const { schoolId, sessionId, examName, examType, startDate, endDate, totalMarks = 100, passMarks = 35 } = req.body;
    const sid = schoolId || req.user.school_id;
    const { rows } = await query(
      `INSERT INTO exams (school_id, session_id, exam_name, exam_type, start_date, end_date, total_marks, pass_marks)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
      [sid, sessionId, examName, examType, startDate, endDate, totalMarks, passMarks]
    );
    res.status(201).json(rows[0]);
  } catch (err) { next(err); }
};

const updateExam = async (req, res, next) => {
  try {
    const { examName, examType, startDate, endDate, totalMarks, passMarks, status } = req.body;
    const { rows } = await query(
      `UPDATE exams SET exam_name=$1, exam_type=$2, start_date=$3, end_date=$4,
       total_marks=$5, pass_marks=$6, status=$7 WHERE id=$8 RETURNING *`,
      [examName, examType, startDate, endDate, totalMarks, passMarks, status, req.params.id]
    );
    if (!rows.length) return res.status(404).json({ error: 'Exam not found' });
    res.json(rows[0]);
  } catch (err) { next(err); }
};

// ── EXAM SCHEDULE ──────────────────────────────────────────

const getSchedule = async (req, res, next) => {
  try {
    const { rows } = await query(
      `SELECT es.*, s.subject_name, c.class_name, c.section
       FROM exam_schedules es
       JOIN subjects s ON es.subject_id = s.id
       JOIN classes c ON es.class_id = c.id
       WHERE es.exam_id = $1 ORDER BY es.exam_date, es.start_time`,
      [req.params.id]
    );
    res.json(rows);
  } catch (err) { next(err); }
};

const setSchedule = async (req, res, next) => {
  try {
    const { classId, subjectId, examDate, startTime, endTime, roomNo, maxMarks, passMarks } = req.body;
    const { rows } = await query(
      `INSERT INTO exam_schedules (exam_id, class_id, subject_id, exam_date, start_time, end_time, room_no, max_marks, pass_marks)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
       ON CONFLICT (exam_id, class_id, subject_id)
       DO UPDATE SET exam_date=$4, start_time=$5, end_time=$6, room_no=$7, max_marks=$8, pass_marks=$9
       RETURNING *`,
      [req.params.id, classId, subjectId, examDate, startTime, endTime, roomNo, maxMarks || 100, passMarks || 35]
    );
    res.json(rows[0]);
  } catch (err) { next(err); }
};

// ── RESULTS / MARKS ────────────────────────────────────────

const getResults = async (req, res, next) => {
  try {
    const { examId, classId, subjectId } = req.query;
    let where = ['er.exam_id = $1'];
    const params = [examId];
    let idx = 2;
    if (classId)   { where.push(`s.class_id = $${idx++}`);   params.push(classId); }
    if (subjectId) { where.push(`er.subject_id = $${idx++}`); params.push(subjectId); }

    const { rows } = await query(
      `SELECT er.*, s.first_name, s.last_name, s.student_code, s.roll_number,
              sub.subject_name, c.class_name, c.section
       FROM exam_results er
       JOIN students s ON er.student_id = s.id
       JOIN subjects sub ON er.subject_id = sub.id
       LEFT JOIN classes c ON s.class_id = c.id
       WHERE ${where.join(' AND ')}
       ORDER BY s.roll_number, sub.subject_name`,
      params
    );
    res.json(rows);
  } catch (err) { next(err); }
};

const enterMarks = async (req, res, next) => {
  try {
    // Bulk marks entry: [{ studentId, subjectId, marksObtained, isAbsent, remarks }]
    const { examId, sessionId, records } = req.body;
    const enteredBy = req.user.id;

    const calcGrade = (marks, max) => {
      const pct = (marks / max) * 100;
      if (pct >= 90) return 'A+';
      if (pct >= 80) return 'A';
      if (pct >= 70) return 'B+';
      if (pct >= 60) return 'B';
      if (pct >= 50) return 'C';
      if (pct >= 35) return 'D';
      return 'F';
    };

    await withTransaction(async (client) => {
      for (const r of records) {
        const grade = r.isAbsent ? 'AB' : calcGrade(r.marksObtained, r.maxMarks || 100);
        await client.query(
          `INSERT INTO exam_results
             (student_id, exam_id, subject_id, session_id, marks_obtained, max_marks, pass_marks, grade, is_absent, remarks, entered_by)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)
           ON CONFLICT (student_id, exam_id, subject_id)
           DO UPDATE SET marks_obtained=$5, grade=$8, is_absent=$9, remarks=$10, entered_by=$11`,
          [r.studentId, examId, r.subjectId, sessionId, r.marksObtained, r.maxMarks || 100,
           r.passMarks || 35, grade, r.isAbsent || false, r.remarks, enteredBy]
        );
      }
    });

    res.json({ message: `Marks entered for ${records.length} records` });
  } catch (err) { next(err); }
};

// ── HALL TICKETS ───────────────────────────────────────────

const generateHallTickets = async (req, res, next) => {
  try {
    const { examId, classId } = req.body;
    const schoolId = req.user.school_id;

    // Get all eligible students
    let studentsQuery = `
      SELECT s.id, s.student_code, s.first_name, s.last_name, s.roll_number,
             s.date_of_birth, c.class_name, c.section
      FROM students s
      JOIN classes c ON s.class_id = c.id
      WHERE s.school_id = $1 AND s.status = 'active'`;
    const params = [schoolId];
    if (classId) { studentsQuery += ` AND s.class_id = $2`; params.push(classId); }

    const { rows: students } = await query(studentsQuery, params);
    const exam = (await query('SELECT * FROM exams WHERE id = $1', [examId])).rows[0];
    if (!exam) return res.status(404).json({ error: 'Exam not found' });

    // Generate hall ticket records
    const tickets = [];
    await withTransaction(async (client) => {
      for (const s of students) {
        const ticketNo = `HT-${exam.exam_name.replace(/\s+/g,'').slice(0,6).toUpperCase()}-${s.student_code.split('-').pop()}`;
        const { rows } = await client.query(
          `INSERT INTO hall_tickets (student_id, exam_id, hall_ticket_no, issued_date, is_issued)
           VALUES ($1, $2, $3, CURRENT_DATE, TRUE)
           ON CONFLICT (student_id, exam_id) DO UPDATE SET is_issued=TRUE RETURNING *`,
          [s.id, examId, ticketNo]
        );
        tickets.push({ ...rows[0], student: s, exam });
      }
    });

    res.json({ message: `${tickets.length} hall tickets generated`, tickets });
  } catch (err) { next(err); }
};

const getHallTickets = async (req, res, next) => {
  try {
    const { examId, classId } = req.query;
    const { rows } = await query(
      `SELECT ht.*, s.first_name, s.last_name, s.student_code, s.roll_number,
              s.date_of_birth, c.class_name, c.section, e.exam_name, e.start_date, e.end_date
       FROM hall_tickets ht
       JOIN students s ON ht.student_id = s.id
       JOIN exams e ON ht.exam_id = e.id
       LEFT JOIN classes c ON s.class_id = c.id
       WHERE ht.exam_id = $1 ${classId ? 'AND s.class_id = $2' : ''}
       ORDER BY c.class_name, s.roll_number`,
      classId ? [examId, classId] : [examId]
    );
    res.json(rows);
  } catch (err) { next(err); }
};

module.exports = { getExams, createExam, updateExam, getSchedule, setSchedule, getResults, enterMarks, generateHallTickets, getHallTickets };
