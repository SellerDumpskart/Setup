const { query, withTransaction } = require('../config/database');

// GET /attendance?schoolId=&classId=&date=&sessionId=
const getAttendance = async (req, res, next) => {
  try {
    const { classId, date = new Date().toISOString().split('T')[0], sessionId } = req.query;
    const schoolId = req.query.schoolId || req.user.school_id;

    // Get all students in class
    const studentsRes = await query(
      `SELECT s.id, s.student_code, s.first_name, s.last_name, s.roll_number,
              COALESCE(a.status, 'present') as attendance_status,
              a.remarks
       FROM students s
       LEFT JOIN student_attendance a
         ON a.student_id = s.id AND a.attendance_date = $1
       WHERE s.school_id = $2 AND s.class_id = $3 AND s.status = 'active'
       ORDER BY s.roll_number, s.first_name`,
      [date, schoolId, classId]
    );

    // Stats
    const present = studentsRes.rows.filter(s => s.attendance_status === 'present').length;
    const absent  = studentsRes.rows.filter(s => s.attendance_status === 'absent').length;

    res.json({
      date,
      students: studentsRes.rows,
      stats: { total: studentsRes.rows.length, present, absent, leave: studentsRes.rows.length - present - absent }
    });
  } catch (err) { next(err); }
};

// POST /attendance/mark — mark single or bulk
const markAttendance = async (req, res, next) => {
  try {
    const { records, classId, sessionId, date = new Date().toISOString().split('T')[0] } = req.body;
    // records: [{ studentId, status, remarks }]
    if (!records?.length) return res.status(400).json({ error: 'No records provided' });

    const schoolId = req.user.school_id;
    const markedBy = req.user.id;

    await withTransaction(async (client) => {
      for (const rec of records) {
        await client.query(
          `INSERT INTO student_attendance
             (student_id, class_id, session_id, attendance_date, status, remarks, marked_by)
           VALUES ($1, $2, $3, $4, $5, $6, $7)
           ON CONFLICT (student_id, attendance_date)
           DO UPDATE SET status = EXCLUDED.status, remarks = EXCLUDED.remarks, marked_by = EXCLUDED.marked_by`,
          [rec.studentId, classId, sessionId, date, rec.status || 'present', rec.remarks || null, markedBy]
        );
      }
    });

    res.json({ message: `Attendance marked for ${records.length} students`, date });
  } catch (err) { next(err); }
};

// GET /attendance/report?schoolId=&classId=&month=&year=&sessionId=
const getAttendanceReport = async (req, res, next) => {
  try {
    const { classId, month, year, sessionId } = req.query;
    const schoolId = req.query.schoolId || req.user.school_id;

    const { rows } = await query(
      `SELECT s.id, s.first_name, s.last_name, s.roll_number,
              COUNT(a.id) FILTER (WHERE a.status = 'present') as present_days,
              COUNT(a.id) FILTER (WHERE a.status = 'absent')  as absent_days,
              COUNT(a.id) FILTER (WHERE a.status = 'leave')   as leave_days,
              COUNT(a.id) as total_marked,
              ROUND(COUNT(a.id) FILTER (WHERE a.status = 'present') * 100.0 /
                NULLIF(COUNT(a.id), 0), 1) as percentage
       FROM students s
       LEFT JOIN student_attendance a ON a.student_id = s.id
         AND EXTRACT(MONTH FROM a.attendance_date) = $3
         AND EXTRACT(YEAR  FROM a.attendance_date) = $4
       WHERE s.school_id = $1 AND s.class_id = $2 AND s.status = 'active'
       GROUP BY s.id, s.first_name, s.last_name, s.roll_number
       ORDER BY s.roll_number`,
      [schoolId, classId, month, year]
    );

    res.json({ report: rows, month, year });
  } catch (err) { next(err); }
};

// GET /attendance/summary?schoolId=&sessionId=&date=
const getSummary = async (req, res, next) => {
  try {
    const { sessionId, date = new Date().toISOString().split('T')[0] } = req.query;
    const schoolId = req.query.schoolId || req.user.school_id;

    const { rows } = await query(
      `SELECT c.class_name, c.section,
              COUNT(s.id) as total,
              COUNT(a.id) FILTER (WHERE a.status = 'present') as present,
              COUNT(a.id) FILTER (WHERE a.status = 'absent')  as absent
       FROM classes c
       JOIN students s ON s.class_id = c.id AND s.status = 'active'
       LEFT JOIN student_attendance a ON a.student_id = s.id AND a.attendance_date = $1
       WHERE c.school_id = $2 AND c.session_id = $3
       GROUP BY c.id, c.class_name, c.section
       ORDER BY c.class_name, c.section`,
      [date, schoolId, sessionId]
    );

    res.json({ summary: rows, date });
  } catch (err) { next(err); }
};

module.exports = { getAttendance, markAttendance, getAttendanceReport, getSummary };
