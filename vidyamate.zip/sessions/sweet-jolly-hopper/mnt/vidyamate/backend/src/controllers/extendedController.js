const { query, withTransaction } = require('../config/database');

// ══════════════════════════════════════════════════════════
// TIMETABLE CONTROLLER
// ══════════════════════════════════════════════════════════

const getPeriods = async (req, res, next) => {
  try {
    const sid = req.query.schoolId || req.user.school_id;
    const { rows } = await query(
      `SELECT * FROM timetable_periods WHERE school_id = $1 ORDER BY period_no`, [sid]
    );
    res.json(rows);
  } catch (e) { next(e); }
};

const upsertPeriod = async (req, res, next) => {
  try {
    const sid = req.query.schoolId || req.user.school_id;
    const { periodNo, periodName, startTime, endTime, isBreak } = req.body;
    const { rows } = await query(
      `INSERT INTO timetable_periods (school_id, period_no, period_name, start_time, end_time, is_break)
       VALUES ($1,$2,$3,$4,$5,$6)
       ON CONFLICT (school_id, period_no)
       DO UPDATE SET period_name=$3, start_time=$4, end_time=$5, is_break=$6
       RETURNING *`,
      [sid, periodNo, periodName, startTime, endTime, isBreak || false]
    );
    res.json(rows[0]);
  } catch (e) { next(e); }
};

const getTimetable = async (req, res, next) => {
  try {
    const { classId, sessionId } = req.query;
    const sid = req.query.schoolId || req.user.school_id;
    const { rows } = await query(
      `SELECT t.*, p.period_name, p.start_time, p.end_time, p.is_break,
              s.subject_name, s.subject_code,
              st.first_name || ' ' || COALESCE(st.last_name,'') as teacher_name
       FROM timetable t
       JOIN timetable_periods p ON t.period_id = p.id
       LEFT JOIN subjects s ON t.subject_id = s.id
       LEFT JOIN staff st ON t.teacher_id = st.id
       WHERE t.school_id = $1 AND t.class_id = $2 AND t.session_id = $3
       ORDER BY t.day_of_week, p.period_no`,
      [sid, classId, sessionId]
    );
    // Reshape into day → period grid
    const grid = {};
    for (const row of rows) {
      if (!grid[row.day_of_week]) grid[row.day_of_week] = {};
      grid[row.day_of_week][row.period_id] = row;
    }
    res.json({ entries: rows, grid });
  } catch (e) { next(e); }
};

const saveTimetableEntry = async (req, res, next) => {
  try {
    const { classId, sessionId, periodId, dayOfWeek, subjectId, teacherId, roomNo, schoolId } = req.body;
    const sid = schoolId || req.user.school_id;
    const { rows } = await query(
      `INSERT INTO timetable (school_id, class_id, session_id, period_id, day_of_week, subject_id, teacher_id, room_no)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
       ON CONFLICT (class_id, period_id, day_of_week, session_id)
       DO UPDATE SET subject_id=$6, teacher_id=$7, room_no=$8
       RETURNING *`,
      [sid, classId, sessionId, periodId, dayOfWeek, subjectId, teacherId, roomNo]
    );
    res.json(rows[0]);
  } catch (e) { next(e); }
};

const deleteTimetableEntry = async (req, res, next) => {
  try {
    await query(`DELETE FROM timetable WHERE id = $1`, [req.params.id]);
    res.json({ message: 'Entry removed' });
  } catch (e) { next(e); }
};

// ══════════════════════════════════════════════════════════
// LMS CONTROLLER
// ══════════════════════════════════════════════════════════

const getContent = async (req, res, next) => {
  try {
    const { classId, subjectId, type, sessionId, page = 1, limit = 50 } = req.query;
    const sid = req.query.schoolId || req.user.school_id;
    const offset = (page - 1) * limit;
    let where = ['school_id = $1']; const params = [sid];
    if (classId)   { where.push(`class_id = $${params.length+1}`);   params.push(classId); }
    if (subjectId) { where.push(`subject_id = $${params.length+1}`); params.push(subjectId); }
    if (type)      { where.push(`content_type = $${params.length+1}`); params.push(type); }
    const { rows } = await query(
      `SELECT lc.*, s.subject_name, c.class_name, c.section,
              st.first_name || ' ' || COALESCE(st.last_name,'') as teacher_name,
              (SELECT COUNT(*) FROM lms_submissions ls WHERE ls.content_id = lc.id) as submission_count
       FROM lms_content lc
       LEFT JOIN subjects s ON lc.subject_id = s.id
       LEFT JOIN classes c ON lc.class_id = c.id
       LEFT JOIN staff st ON lc.teacher_id = st.id
       WHERE ${where.join(' AND ')}
       ORDER BY lc.created_at DESC
       LIMIT $${params.length+1} OFFSET $${params.length+2}`,
      [...params, limit, offset]
    );
    res.json(rows);
  } catch (e) { next(e); }
};

const createContent = async (req, res, next) => {
  try {
    const {
      schoolId, classId, subjectId, sessionId, title, description,
      contentType, fileUrl, externalUrl, dueDate, maxMarks
    } = req.body;
    const sid = schoolId || req.user.school_id;
    // Resolve teacher_id from logged in user
    const teacherRes = await query(
      `SELECT id FROM staff WHERE user_id = $1`, [req.user.id]
    );
    const teacherId = teacherRes.rows[0]?.id || null;
    const { rows } = await query(
      `INSERT INTO lms_content
         (school_id, class_id, subject_id, teacher_id, session_id, title, description,
          content_type, file_url, external_url, due_date, max_marks, is_published)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12, FALSE) RETURNING *`,
      [sid, classId, subjectId, teacherId, sessionId, title, description,
       contentType || 'document', fileUrl, externalUrl, dueDate, maxMarks]
    );
    res.status(201).json(rows[0]);
  } catch (e) { next(e); }
};

const publishContent = async (req, res, next) => {
  try {
    const { rows } = await query(
      `UPDATE lms_content SET is_published=TRUE, published_at=NOW() WHERE id=$1 RETURNING *`,
      [req.params.id]
    );
    res.json(rows[0]);
  } catch (e) { next(e); }
};

const submitAssignment = async (req, res, next) => {
  try {
    const { contentId, studentId, textAnswer, fileUrl } = req.body;
    const { rows } = await query(
      `INSERT INTO lms_submissions (content_id, student_id, text_answer, file_url, status)
       VALUES ($1,$2,$3,$4,'submitted')
       ON CONFLICT (content_id, student_id)
       DO UPDATE SET text_answer=$3, file_url=$4, submitted_at=NOW(), status='submitted'
       RETURNING *`,
      [contentId, studentId, textAnswer, fileUrl]
    );
    res.json(rows[0]);
  } catch (e) { next(e); }
};

const gradeSubmission = async (req, res, next) => {
  try {
    const { marksObtained, feedback } = req.body;
    const teacherRes = await query(`SELECT id FROM staff WHERE user_id=$1`, [req.user.id]);
    const { rows } = await query(
      `UPDATE lms_submissions
       SET marks_obtained=$1, feedback=$2, graded_by=$3, graded_at=NOW(), status='graded'
       WHERE id=$4 RETURNING *`,
      [marksObtained, feedback, teacherRes.rows[0]?.id, req.params.id]
    );
    res.json(rows[0]);
  } catch (e) { next(e); }
};

const getOnlineClasses = async (req, res, next) => {
  try {
    const sid = req.query.schoolId || req.user.school_id;
    const { rows } = await query(
      `SELECT oc.*, s.subject_name, c.class_name,
              st.first_name || ' ' || COALESCE(st.last_name,'') as teacher_name
       FROM lms_online_classes oc
       LEFT JOIN subjects s ON oc.subject_id = s.id
       LEFT JOIN classes c ON oc.class_id = c.id
       LEFT JOIN staff st ON oc.teacher_id = st.id
       WHERE oc.school_id = $1 ORDER BY oc.scheduled_at DESC`, [sid]
    );
    res.json(rows);
  } catch (e) { next(e); }
};

const scheduleOnlineClass = async (req, res, next) => {
  try {
    const { schoolId, classId, subjectId, title, description, meetingLink, platform, scheduledAt, durationMin } = req.body;
    const sid = schoolId || req.user.school_id;
    const teacherRes = await query(`SELECT id FROM staff WHERE user_id=$1`, [req.user.id]);
    const { rows } = await query(
      `INSERT INTO lms_online_classes
         (school_id, class_id, subject_id, teacher_id, title, description,
          meeting_link, platform, scheduled_at, duration_min)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING *`,
      [sid, classId, subjectId, teacherRes.rows[0]?.id, title, description,
       meetingLink, platform || 'google_meet', scheduledAt, durationMin || 60]
    );
    res.status(201).json(rows[0]);
  } catch (e) { next(e); }
};

// ══════════════════════════════════════════════════════════
// TEACHER DESK CONTROLLER
// ══════════════════════════════════════════════════════════

const getHomework = async (req, res, next) => {
  try {
    const sid = req.query.schoolId || req.user.school_id;
    const teacherRes = await query(`SELECT id FROM staff WHERE user_id=$1`, [req.user.id]);
    const teacherId = teacherRes.rows[0]?.id;
    const { rows } = await query(
      `SELECT hw.*, s.subject_name, c.class_name, c.section
       FROM teacher_homework hw
       LEFT JOIN subjects s ON hw.subject_id = s.id
       LEFT JOIN classes c ON hw.class_id = c.id
       WHERE hw.school_id=$1 ${teacherId ? 'AND hw.teacher_id=$2' : ''}
       ORDER BY hw.assigned_date DESC`,
      teacherId ? [sid, teacherId] : [sid]
    );
    res.json(rows);
  } catch (e) { next(e); }
};

const createHomework = async (req, res, next) => {
  try {
    const { schoolId, sessionId, classId, subjectId, title, description, assignedDate, dueDate, fileUrl } = req.body;
    const sid = schoolId || req.user.school_id;
    const teacherRes = await query(`SELECT id FROM staff WHERE user_id=$1`, [req.user.id]);
    const { rows } = await query(
      `INSERT INTO teacher_homework
         (school_id, session_id, class_id, subject_id, teacher_id, title, description, assigned_date, due_date, file_url)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING *`,
      [sid, sessionId, classId, subjectId, teacherRes.rows[0]?.id,
       title, description, assignedDate || new Date().toISOString().split('T')[0], dueDate, fileUrl]
    );
    res.status(201).json(rows[0]);
  } catch (e) { next(e); }
};

const getDiary = async (req, res, next) => {
  try {
    const sid = req.query.schoolId || req.user.school_id;
    const teacherRes = await query(`SELECT id FROM staff WHERE user_id=$1`, [req.user.id]);
    const { rows } = await query(
      `SELECT d.*, s.subject_name, c.class_name, c.section
       FROM teacher_diary d
       LEFT JOIN subjects s ON d.subject_id = s.id
       LEFT JOIN classes c ON d.class_id = c.id
       WHERE d.school_id=$1 AND d.teacher_id=$2
       ORDER BY d.diary_date DESC LIMIT 30`,
      [sid, teacherRes.rows[0]?.id]
    );
    res.json(rows);
  } catch (e) { next(e); }
};

const writeDiary = async (req, res, next) => {
  try {
    const { schoolId, classId, subjectId, diaryDate, content } = req.body;
    const sid = schoolId || req.user.school_id;
    const teacherRes = await query(`SELECT id FROM staff WHERE user_id=$1`, [req.user.id]);
    const { rows } = await query(
      `INSERT INTO teacher_diary (teacher_id, school_id, class_id, subject_id, diary_date, content)
       VALUES ($1,$2,$3,$4,$5,$6) RETURNING *`,
      [teacherRes.rows[0]?.id, sid, classId, subjectId, diaryDate, content]
    );
    res.status(201).json(rows[0]);
  } catch (e) { next(e); }
};

const enterMarksTeacher = async (req, res, next) => {
  try {
    const { examId, subjectId, sessionId, records } = req.body;
    const teacherRes = await query(`SELECT id FROM staff WHERE user_id=$1`, [req.user.id]);

    await withTransaction(async (client) => {
      for (const r of records) {
        await client.query(
          `INSERT INTO teacher_marks_entry (student_id, exam_id, subject_id, teacher_id, marks, max_marks, is_absent, remarks)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
           ON CONFLICT (student_id, exam_id, subject_id)
           DO UPDATE SET marks=$5, is_absent=$7, remarks=$8`,
          [r.studentId, examId, subjectId, teacherRes.rows[0]?.id,
           r.marks, r.maxMarks || 100, r.isAbsent || false, r.remarks]
        );
      }
    });
    res.json({ message: `Marks saved for ${records.length} students` });
  } catch (e) { next(e); }
};

// ══════════════════════════════════════════════════════════
// SCHOOL COMMUNICATION CONTROLLER
// ══════════════════════════════════════════════════════════

const getTemplates = async (req, res, next) => {
  try {
    const sid = req.query.schoolId || req.user.school_id;
    const { rows } = await query(
      `SELECT * FROM communication_templates WHERE school_id=$1 AND is_active=TRUE ORDER BY template_name`, [sid]
    );
    res.json(rows);
  } catch (e) { next(e); }
};

const createTemplate = async (req, res, next) => {
  try {
    const { schoolId, templateName, templateType, subject, body, variables } = req.body;
    const sid = schoolId || req.user.school_id;
    const { rows } = await query(
      `INSERT INTO communication_templates (school_id, template_name, template_type, subject, body, variables)
       VALUES ($1,$2,$3,$4,$5,$6) RETURNING *`,
      [sid, templateName, templateType || 'sms', subject, body, JSON.stringify(variables || [])]
    );
    res.status(201).json(rows[0]);
  } catch (e) { next(e); }
};

const getBroadcasts = async (req, res, next) => {
  try {
    const sid = req.query.schoolId || req.user.school_id;
    const { rows } = await query(
      `SELECT bc.*, u.username as created_by_name
       FROM bulk_communications bc LEFT JOIN users u ON bc.created_by=u.id
       WHERE bc.school_id=$1 ORDER BY bc.created_at DESC`, [sid]
    );
    res.json(rows);
  } catch (e) { next(e); }
};

const sendBroadcast = async (req, res, next) => {
  try {
    const {
      schoolId, sessionId, title, message, channel,
      targetGroup, targetClassId, scheduledAt
    } = req.body;
    const sid = schoolId || req.user.school_id;
    const notifService = require('../services/notificationService');

    // Count recipients
    let recipientCount = 0;
    if (targetGroup === 'all' || targetGroup === 'parents') {
      const { rows } = await query(
        `SELECT COUNT(*) FROM students WHERE school_id=$1 AND status='active'`, [sid]
      );
      recipientCount = parseInt(rows[0].count);
    } else if (targetGroup === 'staff') {
      const { rows } = await query(
        `SELECT COUNT(*) FROM staff WHERE school_id=$1 AND status='active'`, [sid]
      );
      recipientCount = parseInt(rows[0].count);
    }

    const { rows } = await query(
      `INSERT INTO bulk_communications
         (school_id, title, message, channel, target_group, target_class_id,
          total_recipients, status, scheduled_at, created_by)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING *`,
      [sid, title, message, channel || 'sms', targetGroup, targetClassId,
       recipientCount, scheduledAt ? 'queued' : 'sending', scheduledAt, req.user.id]
    );

    const broadcast = rows[0];

    // If not scheduled, send immediately (fire & forget)
    if (!scheduledAt) {
      setImmediate(async () => {
        try {
          // Get recipient contacts
          let phones = [], emails = [];
          if (targetGroup === 'parents' || targetGroup === 'all') {
            const { rows: parents } = await query(
              `SELECT p.father_phone, p.mother_phone, p.father_email
               FROM students s JOIN parents p ON s.parent_id=p.id
               WHERE s.school_id=$1 AND s.status='active'
               ${targetClassId ? 'AND s.class_id=$2' : ''}`,
              targetClassId ? [sid, targetClassId] : [sid]
            );
            phones = parents.flatMap(p => [p.father_phone, p.mother_phone].filter(Boolean));
            emails = parents.map(p => p.father_email).filter(Boolean);
          }

          const results = await notifService.notifyBulk({ schoolId: sid, phones, emails, subject: title, message });
          const sentCount = (results.sms?.success ? phones.length : 0) + (results.email?.filter(r=>r.success).length || 0);
          await query(
            `UPDATE bulk_communications SET status='sent', sent_count=$1, sent_at=NOW() WHERE id=$2`,
            [sentCount, broadcast.id]
          );
        } catch (err) {
          await query(`UPDATE bulk_communications SET status='failed' WHERE id=$1`, [broadcast.id]);
        }
      });
    }

    res.status(201).json(broadcast);
  } catch (e) { next(e); }
};

const getParentMessages = async (req, res, next) => {
  try {
    const sid = req.query.schoolId || req.user.school_id;
    const { studentId } = req.query;
    let where = ['school_id=$1']; const params = [sid];
    if (studentId) { where.push(`student_id=$${params.length+1}`); params.push(studentId); }
    const { rows } = await query(
      `SELECT pm.*, p.father_name, p.father_phone
       FROM parent_messages pm LEFT JOIN parents p ON pm.parent_id=p.id
       WHERE ${where.join(' AND ')} ORDER BY pm.created_at DESC LIMIT 100`, params
    );
    res.json(rows);
  } catch (e) { next(e); }
};

const sendParentMessage = async (req, res, next) => {
  try {
    const { schoolId, parentId, studentId, message, senderType } = req.body;
    const sid = schoolId || req.user.school_id;
    const staffRes = await query(`SELECT id FROM staff WHERE user_id=$1`, [req.user.id]);
    const { rows } = await query(
      `INSERT INTO parent_messages (school_id, parent_id, student_id, staff_id, sender_type, message)
       VALUES ($1,$2,$3,$4,$5,$6) RETURNING *`,
      [sid, parentId, studentId, staffRes.rows[0]?.id, senderType || 'staff', message]
    );
    res.status(201).json(rows[0]);
  } catch (e) { next(e); }
};

const markMessagesRead = async (req, res, next) => {
  try {
    await query(
      `UPDATE parent_messages SET is_read=TRUE, read_at=NOW()
       WHERE school_id=$1 AND parent_id=$2 AND is_read=FALSE`,
      [req.user.school_id, req.params.parentId]
    );
    res.json({ message: 'Marked as read' });
  } catch (e) { next(e); }
};

const getCommunicationLogs = async (req, res, next) => {
  try {
    const sid = req.query.schoolId || req.user.school_id;
    const { channel, status, page = 1, limit = 50 } = req.query;
    const offset = (page - 1) * limit;
    let where = ['school_id=$1']; const params = [sid];
    if (channel) { where.push(`channel=$${params.length+1}`); params.push(channel); }
    if (status)  { where.push(`status=$${params.length+1}`);  params.push(status); }
    const { rows } = await query(
      `SELECT * FROM communication_logs WHERE ${where.join(' AND ')}
       ORDER BY created_at DESC LIMIT $${params.length+1} OFFSET $${params.length+2}`,
      [...params, limit, offset]
    );
    res.json(rows);
  } catch (e) { next(e); }
};

module.exports = {
  // Timetable
  getPeriods, upsertPeriod, getTimetable, saveTimetableEntry, deleteTimetableEntry,
  // LMS
  getContent, createContent, publishContent, submitAssignment, gradeSubmission,
  getOnlineClasses, scheduleOnlineClass,
  // Teacher Desk
  getHomework, createHomework, getDiary, writeDiary, enterMarksTeacher,
  // Communication
  getTemplates, createTemplate, getBroadcasts, sendBroadcast,
  getParentMessages, sendParentMessage, markMessagesRead, getCommunicationLogs,
};
