const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { query } = require('../config/database');
const logger = require('../utils/logger');

const generateTokens = (user) => {
  const payload = { id: user.id, role: user.role, school_id: user.school_id };
  const accessToken = jwt.sign(payload, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || '15m'
  });
  const refreshToken = jwt.sign(payload, process.env.JWT_REFRESH_SECRET, {
    expiresIn: process.env.JWT_REFRESH_EXPIRES_IN || '7d'
  });
  return { accessToken, refreshToken };
};

// POST /api/v1/auth/login
const login = async (req, res, next) => {
  try {
    const { email, password } = req.body;
    if (!email || !password)
      return res.status(400).json({ error: 'Email and password are required' });

    const { rows } = await query(
      `SELECT u.*, s.name AS school_name, o.name AS org_name
       FROM users u
       LEFT JOIN schools s ON u.school_id = s.id
       LEFT JOIN organizations o ON u.organization_id = o.id
       WHERE LOWER(u.email) = LOWER($1)`,
      [email]
    );

    if (!rows.length)
      return res.status(401).json({ error: 'Invalid email or password' });

    const user = rows[0];
    if (!user.is_active)
      return res.status(401).json({ error: 'Account is inactive. Contact administrator.' });

    const valid = await bcrypt.compare(password, user.password_hash);
    if (!valid)
      return res.status(401).json({ error: 'Invalid email or password' });

    const { accessToken, refreshToken } = generateTokens(user);

    // Update last login
    await query('UPDATE users SET last_login = NOW() WHERE id = $1', [user.id]);

    // Audit log
    await query(
      'INSERT INTO audit_logs (user_id, school_id, action, ip_address) VALUES ($1,$2,$3,$4)',
      [user.id, user.school_id, 'LOGIN', req.ip]
    );

    res.json({
      accessToken,
      refreshToken,
      user: {
        id: user.id,
        email: user.email,
        firstName: user.first_name,
        lastName: user.last_name,
        role: user.role,
        schoolId: user.school_id,
        schoolName: user.school_name,
        orgId: user.organization_id,
        orgName: user.org_name,
        photo: user.photo_url
      }
    });
  } catch (err) { next(err); }
};

// POST /api/v1/auth/refresh
const refresh = async (req, res, next) => {
  try {
    const { refreshToken } = req.body;
    if (!refreshToken)
      return res.status(400).json({ error: 'Refresh token required' });

    const decoded = jwt.verify(refreshToken, process.env.JWT_REFRESH_SECRET);
    const { rows } = await query(
      'SELECT id, role, school_id, is_active FROM users WHERE id = $1',
      [decoded.id]
    );
    if (!rows.length || !rows[0].is_active)
      return res.status(401).json({ error: 'Invalid refresh token' });

    const tokens = generateTokens(rows[0]);
    res.json(tokens);
  } catch (err) {
    return res.status(401).json({ error: 'Invalid or expired refresh token' });
  }
};

// POST /api/v1/auth/logout
const logout = async (req, res) => {
  // With JWT, logout is client-side (clear tokens)
  // In production you'd blacklist the token in Redis
  res.json({ message: 'Logged out successfully' });
};

// GET /api/v1/auth/me
const me = async (req, res, next) => {
  try {
    const { rows } = await query(
      `SELECT u.id, u.email, u.first_name, u.last_name, u.role, u.photo_url,
              u.school_id, u.organization_id, u.last_login,
              s.name AS school_name, o.name AS org_name
       FROM users u
       LEFT JOIN schools s ON u.school_id = s.id
       LEFT JOIN organizations o ON u.organization_id = o.id
       WHERE u.id = $1`,
      [req.user.id]
    );
    if (!rows.length) return res.status(404).json({ error: 'User not found' });
    const u = rows[0];
    res.json({
      id: u.id, email: u.email,
      firstName: u.first_name, lastName: u.last_name,
      role: u.role, photo: u.photo_url,
      schoolId: u.school_id, schoolName: u.school_name,
      orgId: u.organization_id, orgName: u.org_name,
      lastLogin: u.last_login
    });
  } catch (err) { next(err); }
};

// POST /api/v1/auth/change-password
const changePassword = async (req, res, next) => {
  try {
    const { currentPassword, newPassword } = req.body;
    if (!currentPassword || !newPassword)
      return res.status(400).json({ error: 'Both current and new password required' });
    if (newPassword.length < 8)
      return res.status(400).json({ error: 'New password must be at least 8 characters' });

    const { rows } = await query('SELECT password_hash FROM users WHERE id = $1', [req.user.id]);
    const valid = await bcrypt.compare(currentPassword, rows[0].password_hash);
    if (!valid) return res.status(401).json({ error: 'Current password is incorrect' });

    const hash = await bcrypt.hash(newPassword, 12);
    await query('UPDATE users SET password_hash = $1 WHERE id = $2', [hash, req.user.id]);
    res.json({ message: 'Password changed successfully' });
  } catch (err) { next(err); }
};

module.exports = { login, refresh, logout, me, changePassword };
