const { query, withTransaction } = require('../config/database');
const { v4: uuidv4 } = require('uuid');

// Generate student code: SCH-YYYY-XXXX
const generateStudentCode = async (schoolId) => {
  const year = new Date().getFullYear();
  const { rows } = await query(
    'SELECT COUNT(*) FROM students WHERE school_id=$1', [schoolId]
  );
  const seq = String(parseInt(rows[0].count) + 1).padStart(4, '0');
  return `STU-${year}-${seq}`;
};

// GET /api/v1/students?schoolId=&sessionId=&classId=&search=&page=&limit=
const getStudents = async (req, res, next) => {
  try {
    const { schoolId, sessionId, classId, search, status = 'active', page = 1, limit = 50 } = req.query;
    const sid = schoolId || req.user.school_id;
    const offset = (page - 1) * limit;

    let where = ['s.school_id = $1'];
    const params = [sid];
    let idx = 2;

    if (sessionId) { where.push(`s.session_id = $${idx++}`); params.push(sessionId); }
    if (classId)   { where.push(`s.class_id = $${idx++}`);   params.push(classId);   }
    if (status)    { where.push(`s.status = $${idx++}`);      params.push(status);    }
    if (search) {
      where.push(`(
        LOWER(s.first_name || ' ' || COALESCE(s.last_name,'')) LIKE $${idx} OR
        LOWER(s.student_code) LIKE $${idx} OR
        s.aadhaar_no LIKE $${idx}
      )`);
      params.push(`%${search.toLowerCase()}%`);
      idx++;
    }

    const whereClause = where.join(' AND ');
    const countResult = await query(
      `SELECT COUNT(*) FROM students s WHERE ${whereClause}`,
      params
    );

    const result = await query(
      `SELECT s.id, s.student_code, s.first_name, s.last_name, s.gender,
              s.date_of_birth, s.photo_url, s.status, s.roll_number,
              s.admission_date, s.aadhaar_no, s.pen_number,
              c.class_name, c.section,
              p.father_name, p.father_phone
       FROM students s
       LEFT JOIN classes c ON s.class_id = c.id
       LEFT JOIN parents p ON s.parent_id = p.id
       WHERE ${whereClause}
       ORDER BY c.class_name, s.roll_number, s.first_name
       LIMIT $${idx} OFFSET $${idx+1}`,
      [...params, limit, offset]
    );

    res.json({
      students: result.rows,
      pagination: {
        total: parseInt(countResult.rows[0].count),
        page: parseInt(page),
        limit: parseInt(limit),
        pages: Math.ceil(countResult.rows[0].count / limit)
      }
    });
  } catch (err) { next(err); }
};

// GET /api/v1/students/:id
const getStudent = async (req, res, next) => {
  try {
    const { rows } = await query(
      `SELECT s.*,
              c.class_name, c.section,
              p.father_name, p.father_phone, p.father_email, p.father_occ,
              p.mother_name, p.mother_phone, p.mother_email,
              p.guardian_name, p.guardian_phone, p.address
       FROM students s
       LEFT JOIN classes c ON s.class_id = c.id
       LEFT JOIN parents p ON s.parent_id = p.id
       WHERE s.id = $1`,
      [req.params.id]
    );
    if (!rows.length) return res.status(404).json({ error: 'Student not found' });
    res.json(rows[0]);
  } catch (err) { next(err); }
};

// POST /api/v1/students
const createStudent = async (req, res, next) => {
  try {
    const {
      schoolId, sessionId, classId,
      firstName, lastName, dateOfBirth, gender, bloodGroup,
      category, religion, nationality, motherTongue, aadhaarNo,
      penNumber, apaarId, childId, applicationNo,
      identificationMark, height, weight, medicalConditions,
      prevSchool, prevClass, prevPercentage, tcNumber,
      // Parent info
      fatherName, fatherPhone, fatherEmail, fatherOcc, fatherIncome,
      motherName, motherPhone, motherEmail, motherOcc, motherIncome,
      guardianName, guardianPhone, guardianRel,
      address, city, state, pincode
    } = req.body;

    const sid = schoolId || req.user.school_id;

    await withTransaction(async (client) => {
      // Create parent record
      const parentId = uuidv4();
      await client.query(
        `INSERT INTO parents (id, school_id, father_name, father_phone, father_email,
          father_occ, father_income, mother_name, mother_phone, mother_email,
          mother_occ, mother_income, guardian_name, guardian_phone, guardian_rel,
          address, city, state, pincode)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19)`,
        [parentId, sid, fatherName, fatherPhone, fatherEmail, fatherOcc, fatherIncome,
         motherName, motherPhone, motherEmail, motherOcc, motherIncome,
         guardianName, guardianPhone, guardianRel, address, city, state, pincode]
      );

      // Generate student code
      const { rows: cnt } = await client.query(
        'SELECT COUNT(*) FROM students WHERE school_id=$1', [sid]
      );
      const year = new Date().getFullYear();
      const seq = String(parseInt(cnt[0].count) + 1).padStart(4, '0');
      const studentCode = `STU-${year}-${seq}`;

      // Create student
      const studentId = uuidv4();
      const { rows } = await client.query(
        `INSERT INTO students (id, school_id, session_id, class_id, parent_id,
          student_code, pen_number, apaar_id, child_id, application_no, aadhaar_no,
          first_name, last_name, date_of_birth, gender, blood_group, category, religion,
          nationality, mother_tongue, identification_mark, height, weight, medical_conditions,
          prev_school, prev_class, prev_percentage, tc_number)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,
                 $21,$22,$23,$24,$25,$26,$27,$28)
         RETURNING *`,
        [studentId, sid, sessionId, classId, parentId, studentCode, penNumber, apaarId,
         childId, applicationNo, aadhaarNo, firstName, lastName, dateOfBirth, gender,
         bloodGroup, category, religion, nationality, motherTongue, identificationMark,
         height, weight, medicalConditions, prevSchool, prevClass, prevPercentage, tcNumber]
      );

      res.status(201).json({
        message: 'Student admitted successfully',
        student: rows[0]
      });
    });
  } catch (err) { next(err); }
};

// PUT /api/v1/students/:id
const updateStudent = async (req, res, next) => {
  try {
    const fields = req.body;
    const allowed = ['first_name','last_name','date_of_birth','gender','blood_group',
                     'category','religion','nationality','mother_tongue','aadhaar_no',
                     'pen_number','class_id','roll_number','height','weight',
                     'medical_conditions','status','photo_url'];

    const updates = [];
    const values = [];
    let idx = 1;

    for (const [key, val] of Object.entries(fields)) {
      const col = key.replace(/([A-Z])/g, '_$1').toLowerCase();
      if (allowed.includes(col)) {
        updates.push(`${col} = $${idx++}`);
        values.push(val);
      }
    }

    if (!updates.length) return res.status(400).json({ error: 'No valid fields to update' });

    values.push(req.params.id);
    const { rows } = await query(
      `UPDATE students SET ${updates.join(', ')} WHERE id = $${idx} RETURNING *`,
      values
    );
    if (!rows.length) return res.status(404).json({ error: 'Student not found' });
    res.json(rows[0]);
  } catch (err) { next(err); }
};

// DELETE /api/v1/students/:id  (soft delete - marks as cancelled)
const deleteStudent = async (req, res, next) => {
  try {
    const { reason } = req.body;
    await query(
      "UPDATE students SET status='cancelled', cancel_reason=$1 WHERE id=$2",
      [reason, req.params.id]
    );
    res.json({ message: 'Student record cancelled' });
  } catch (err) { next(err); }
};

module.exports = { getStudents, getStudent, createStudent, updateStudent, deleteStudent };
