const { query, withTransaction } = require('../config/database');
const { v4: uuidv4 } = require('uuid');

// ── FEE HEADS ──────────────────────────────────────────────

const getFeeHeads = async (req, res, next) => {
  try {
    const { schoolId, sessionId } = req.query;
    const sid = schoolId || req.user.school_id;
    const { rows } = await query(
      `SELECT fh.*,
              COALESCE(SUM(sf.total_amount - sf.concession), 0) as total_assigned,
              COALESCE(SUM(sf.paid_amount), 0) as total_paid,
              COALESCE(SUM(sf.balance), 0) as total_balance
       FROM fee_heads fh
       LEFT JOIN student_fees sf ON sf.fee_head_id = fh.id
       WHERE fh.school_id = $1 AND fh.session_id = $2
       GROUP BY fh.id
       ORDER BY fh.fee_name`,
      [sid, sessionId]
    );
    res.json(rows);
  } catch (err) { next(err); }
};

const createFeeHead = async (req, res, next) => {
  try {
    const { schoolId, sessionId, feeName, feeType, amount, frequency, dueDay } = req.body;
    const sid = schoolId || req.user.school_id;
    const { rows } = await query(
      `INSERT INTO fee_heads (school_id, session_id, fee_name, fee_type, amount, frequency, due_day)
       VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
      [sid, sessionId, feeName, feeType || 'tuition', amount || 0, frequency || 'yearly', dueDay || 10]
    );
    res.status(201).json(rows[0]);
  } catch (err) { next(err); }
};

// ── STUDENT FEES ───────────────────────────────────────────

const getStudentFees = async (req, res, next) => {
  try {
    const { studentId } = req.params;
    const { sessionId } = req.query;

    const { rows } = await query(
      `SELECT sf.*, fh.fee_name, fh.fee_type, fh.frequency,
              s.first_name, s.last_name, s.student_code,
              c.class_name, c.section
       FROM student_fees sf
       JOIN fee_heads fh ON sf.fee_head_id = fh.id
       JOIN students s ON sf.student_id = s.id
       LEFT JOIN classes c ON s.class_id = c.id
       WHERE sf.student_id = $1 AND sf.session_id = $2
       ORDER BY fh.fee_name`,
      [studentId, sessionId]
    );
    res.json(rows);
  } catch (err) { next(err); }
};

const assignFees = async (req, res, next) => {
  try {
    // Bulk assign fee heads to a class or individual student
    const { studentIds, feeHeadId, sessionId, totalAmount, concession = 0, dueDate } = req.body;

    await withTransaction(async (client) => {
      for (const studentId of studentIds) {
        await client.query(
          `INSERT INTO student_fees (student_id, fee_head_id, session_id, total_amount, concession, due_date)
           VALUES ($1, $2, $3, $4, $5, $6)
           ON CONFLICT (student_id, fee_head_id, session_id)
           DO UPDATE SET total_amount = EXCLUDED.total_amount, concession = EXCLUDED.concession`,
          [studentId, feeHeadId, sessionId, totalAmount, concession, dueDate]
        );
      }
    });

    res.json({ message: `Fees assigned to ${studentIds.length} students` });
  } catch (err) { next(err); }
};

// ── PAYMENTS ───────────────────────────────────────────────

const collectPayment = async (req, res, next) => {
  try {
    const {
      studentId, studentFeeId, amount, paymentMode = 'cash',
      transactionId, bankRef, razorpayId, remarks
    } = req.body;
    const collectedBy = req.user.id;

    await withTransaction(async (client) => {
      // Generate receipt number
      const { rows: cnt } = await client.query('SELECT COUNT(*) FROM fee_payments');
      const receiptNo = `RCP-${new Date().getFullYear()}-${String(parseInt(cnt[0].count) + 1).padStart(5, '0')}`;

      // Insert payment
      const payRes = await client.query(
        `INSERT INTO fee_payments
           (student_id, student_fee_id, receipt_no, amount, payment_mode,
            transaction_id, razorpay_id, bank_ref, remarks, collected_by)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING *`,
        [studentId, studentFeeId, receiptNo, amount, paymentMode,
         transactionId, razorpayId, bankRef, remarks, collectedBy]
      );

      // Update paid_amount on student_fees
      await client.query(
        `UPDATE student_fees
         SET paid_amount = paid_amount + $1,
             status = CASE
               WHEN paid_amount + $1 >= net_amount THEN 'paid'
               WHEN paid_amount + $1 > 0 THEN 'partial'
               ELSE status END
         WHERE id = $2`,
        [amount, studentFeeId]
      );

      res.status(201).json({ message: 'Payment collected', payment: payRes.rows[0], receiptNo });
    });
  } catch (err) { next(err); }
};

const getPayments = async (req, res, next) => {
  try {
    const { schoolId, studentId, sessionId, page = 1, limit = 50 } = req.query;
    const sid = schoolId || req.user.school_id;
    const offset = (page - 1) * limit;

    let where = ['s.school_id = $1'];
    const params = [sid];
    let idx = 2;

    if (studentId) { where.push(`fp.student_id = $${idx++}`); params.push(studentId); }

    const { rows } = await query(
      `SELECT fp.*, s.first_name, s.last_name, s.student_code,
              fh.fee_name, fh.fee_type,
              c.class_name, c.section
       FROM fee_payments fp
       JOIN students s ON fp.student_id = s.id
       JOIN student_fees sf ON fp.student_fee_id = sf.id
       JOIN fee_heads fh ON sf.fee_head_id = fh.id
       LEFT JOIN classes c ON s.class_id = c.id
       WHERE ${where.join(' AND ')}
       ORDER BY fp.created_at DESC
       LIMIT $${idx} OFFSET $${idx + 1}`,
      [...params, limit, offset]
    );

    res.json(rows);
  } catch (err) { next(err); }
};

// ── DISCOUNTS ──────────────────────────────────────────────

const applyDiscount = async (req, res, next) => {
  try {
    const { studentFeeId, studentId, discountAmount, discountReason, authorityName, remarks } = req.body;
    const givenBy = req.user.id;

    await withTransaction(async (client) => {
      await client.query(
        `INSERT INTO fee_discounts
           (student_fee_id, student_id, discount_amount, discount_reason, authority_name, given_by, remarks)
         VALUES ($1,$2,$3,$4,$5,$6,$7)`,
        [studentFeeId, studentId, discountAmount, discountReason, authorityName, givenBy, remarks]
      );

      await client.query(
        `UPDATE student_fees SET concession = concession + $1 WHERE id = $2`,
        [discountAmount, studentFeeId]
      );
    });

    res.json({ message: 'Discount applied successfully' });
  } catch (err) { next(err); }
};

// ── DEFAULTERS ─────────────────────────────────────────────

const getDefaulters = async (req, res, next) => {
  try {
    const { schoolId, sessionId, minBalance = 0 } = req.query;
    const sid = schoolId || req.user.school_id;

    const { rows } = await query(
      `SELECT s.id, s.student_code, s.first_name, s.last_name,
              c.class_name, c.section,
              SUM(sf.balance) as total_balance,
              p.father_name, p.father_phone
       FROM students s
       JOIN student_fees sf ON sf.student_id = s.id AND sf.session_id = $2
       LEFT JOIN classes c ON s.class_id = c.id
       LEFT JOIN parents p ON s.parent_id = p.id
       WHERE s.school_id = $1 AND sf.balance > $3
       GROUP BY s.id, s.student_code, s.first_name, s.last_name,
                c.class_name, c.section, p.father_name, p.father_phone
       ORDER BY total_balance DESC`,
      [sid, sessionId, minBalance]
    );

    res.json(rows);
  } catch (err) { next(err); }
};

module.exports = { getFeeHeads, createFeeHead, getStudentFees, assignFees, collectPayment, getPayments, applyDiscount, getDefaulters };
