const { query } = require('../config/database');

// GET /reports/overview?schoolId=&sessionId=
const getOverview = async (req, res, next) => {
  try {
    const { sessionId } = req.query;
    const schoolId = req.query.schoolId || req.user.school_id;

    const [students, staff, fees, attendance, exams] = await Promise.all([
      // Student stats
      query(`SELECT
               COUNT(*) as total,
               COUNT(*) FILTER (WHERE gender = 'male') as boys,
               COUNT(*) FILTER (WHERE gender = 'female') as girls,
               COUNT(*) FILTER (WHERE status = 'active') as active
             FROM students WHERE school_id = $1 AND session_id = $2`,
        [schoolId, sessionId]),

      // Staff stats
      query(`SELECT COUNT(*) as total,
               COUNT(*) FILTER (WHERE staff_type = 'teaching') as teachers,
               COUNT(*) FILTER (WHERE staff_type = 'non_teaching') as non_teaching
             FROM staff WHERE school_id = $1 AND status = 'active'`, [schoolId]),

      // Fee stats
      query(`SELECT
               COALESCE(SUM(sf.total_amount - sf.concession), 0) as total_fees,
               COALESCE(SUM(sf.paid_amount), 0) as collected,
               COALESCE(SUM(sf.balance), 0) as pending
             FROM student_fees sf
             JOIN students s ON sf.student_id = s.id
             WHERE s.school_id = $1 AND sf.session_id = $2`, [schoolId, sessionId]),

      // Today's attendance
      query(`SELECT
               COUNT(*) FILTER (WHERE a.status = 'present') as present,
               COUNT(*) FILTER (WHERE a.status = 'absent') as absent,
               COUNT(DISTINCT a.student_id) as marked
             FROM student_attendance a
             JOIN students s ON a.student_id = s.id
             WHERE s.school_id = $1 AND a.attendance_date = CURRENT_DATE`, [schoolId]),

      // Exam stats
      query(`SELECT COUNT(*) as total,
               COUNT(*) FILTER (WHERE status = 'completed') as completed,
               COUNT(*) FILTER (WHERE status = 'scheduled') as scheduled
             FROM exams WHERE school_id = $1 AND session_id = $2`, [schoolId, sessionId]),
    ]);

    res.json({
      students: students.rows[0],
      staff: staff.rows[0],
      fees: fees.rows[0],
      attendance: attendance.rows[0],
      exams: exams.rows[0],
    });
  } catch (err) { next(err); }
};

// GET /reports/attendance-trend?schoolId=&sessionId=&months=6
const getAttendanceTrend = async (req, res, next) => {
  try {
    const { sessionId, months = 6 } = req.query;
    const schoolId = req.query.schoolId || req.user.school_id;

    const { rows } = await query(
      `SELECT
         TO_CHAR(a.attendance_date, 'Mon YYYY') as month_label,
         EXTRACT(YEAR FROM a.attendance_date) as year,
         EXTRACT(MONTH FROM a.attendance_date) as month,
         COUNT(*) FILTER (WHERE a.status = 'present') as present,
         COUNT(*) as total,
         ROUND(COUNT(*) FILTER (WHERE a.status = 'present') * 100.0 / NULLIF(COUNT(*), 0), 1) as percentage
       FROM student_attendance a
       JOIN students s ON a.student_id = s.id
       WHERE s.school_id = $1
         AND a.attendance_date >= CURRENT_DATE - INTERVAL '${months} months'
       GROUP BY month_label, year, month
       ORDER BY year, month`,
      [schoolId]
    );
    res.json(rows);
  } catch (err) { next(err); }
};

// GET /reports/fee-collection?schoolId=&sessionId=
const getFeeCollection = async (req, res, next) => {
  try {
    const { sessionId } = req.query;
    const schoolId = req.query.schoolId || req.user.school_id;

    const [byHead, byMonth, byMode] = await Promise.all([
      // By fee head
      query(`SELECT fh.fee_name, fh.fee_type,
               SUM(sf.total_amount - sf.concession) as total,
               SUM(sf.paid_amount) as paid,
               SUM(sf.balance) as balance
             FROM fee_heads fh
             JOIN student_fees sf ON sf.fee_head_id = fh.id
             WHERE fh.school_id = $1 AND fh.session_id = $2
             GROUP BY fh.id, fh.fee_name, fh.fee_type ORDER BY fh.fee_name`,
        [schoolId, sessionId]),

      // Monthly collection
      query(`SELECT TO_CHAR(fp.payment_date, 'Mon YYYY') as month,
               SUM(fp.amount) as collected,
               COUNT(*) as transactions
             FROM fee_payments fp
             JOIN students s ON fp.student_id = s.id
             WHERE s.school_id = $1
               AND fp.payment_date >= CURRENT_DATE - INTERVAL '12 months'
             GROUP BY month ORDER BY MIN(fp.payment_date)`,
        [schoolId]),

      // By payment mode
      query(`SELECT fp.payment_mode, SUM(fp.amount) as amount, COUNT(*) as count
             FROM fee_payments fp
             JOIN students s ON fp.student_id = s.id
             WHERE s.school_id = $1 GROUP BY fp.payment_mode`, [schoolId]),
    ]);

    res.json({ byHead: byHead.rows, byMonth: byMonth.rows, byMode: byMode.rows });
  } catch (err) { next(err); }
};

// GET /reports/class-strength?schoolId=&sessionId=
const getClassStrength = async (req, res, next) => {
  try {
    const { sessionId } = req.query;
    const schoolId = req.query.schoolId || req.user.school_id;

    const { rows } = await query(
      `SELECT c.class_name, c.section,
              COUNT(s.id) as total,
              COUNT(s.id) FILTER (WHERE s.gender = 'male') as boys,
              COUNT(s.id) FILTER (WHERE s.gender = 'female') as girls
       FROM classes c
       LEFT JOIN students s ON s.class_id = c.id AND s.status = 'active'
       WHERE c.school_id = $1 AND c.session_id = $2
       GROUP BY c.id, c.class_name, c.section
       ORDER BY c.class_name, c.section`,
      [schoolId, sessionId]
    );
    res.json(rows);
  } catch (err) { next(err); }
};

// GET /reports/top-performers?schoolId=&sessionId=&examId=&classId=&limit=10
const getTopPerformers = async (req, res, next) => {
  try {
    const { sessionId, examId, classId, limit = 10 } = req.query;
    const schoolId = req.query.schoolId || req.user.school_id;

    const { rows } = await query(
      `SELECT s.id, s.first_name, s.last_name, s.student_code, s.roll_number,
              c.class_name, c.section,
              SUM(er.marks_obtained) as total_marks,
              SUM(er.max_marks) as max_possible,
              ROUND(SUM(er.marks_obtained) * 100.0 / NULLIF(SUM(er.max_marks), 0), 1) as percentage,
              RANK() OVER (ORDER BY SUM(er.marks_obtained) DESC) as rank
       FROM exam_results er
       JOIN students s ON er.student_id = s.id
       LEFT JOIN classes c ON s.class_id = c.id
       WHERE s.school_id = $1 AND er.session_id = $2 AND er.exam_id = $3
         AND er.is_absent = FALSE ${classId ? 'AND s.class_id = $5' : ''}
       GROUP BY s.id, s.first_name, s.last_name, s.student_code, s.roll_number, c.class_name, c.section
       ORDER BY total_marks DESC
       LIMIT $4`,
      classId ? [schoolId, sessionId, examId, limit, classId] : [schoolId, sessionId, examId, limit]
    );
    res.json(rows);
  } catch (err) { next(err); }
};

// GET /reports/expenditure?schoolId=&sessionId=
const getExpenditureReport = async (req, res, next) => {
  try {
    const { sessionId } = req.query;
    const schoolId = req.query.schoolId || req.user.school_id;

    const [byCategory, monthly, total] = await Promise.all([
      query(`SELECT category, SUM(amount) as total, COUNT(*) as entries
             FROM expenditures WHERE school_id = $1 AND session_id = $2
             GROUP BY category ORDER BY total DESC`, [schoolId, sessionId]),

      query(`SELECT TO_CHAR(expense_date, 'Mon YYYY') as month,
               SUM(amount) as total
             FROM expenditures WHERE school_id = $1 AND session_id = $2
             GROUP BY month ORDER BY MIN(expense_date)`, [schoolId, sessionId]),

      query(`SELECT SUM(amount) as grand_total,
               COUNT(*) as total_entries
             FROM expenditures WHERE school_id = $1 AND session_id = $2`, [schoolId, sessionId]),
    ]);

    res.json({ byCategory: byCategory.rows, monthly: monthly.rows, summary: total.rows[0] });
  } catch (err) { next(err); }
};

module.exports = { getOverview, getAttendanceTrend, getFeeCollection, getClassStrength, getTopPerformers, getExpenditureReport };
