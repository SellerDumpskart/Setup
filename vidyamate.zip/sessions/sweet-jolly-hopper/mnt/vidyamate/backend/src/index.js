require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const compression = require('compression');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');
const path = require('path');

const logger = require('./utils/logger');
const { errorHandler, notFound } = require('./middleware/errorHandler');

// Route imports
const authRoutes       = require('./routes/auth');
const orgRoutes        = require('./routes/organizations');
const schoolRoutes     = require('./routes/schools');
const sessionRoutes    = require('./routes/sessions');
const masterRoutes     = require('./routes/masters');
const userRoutes       = require('./routes/users');
const staffRoutes      = require('./routes/staff');
const studentRoutes    = require('./routes/students');
const classRoutes      = require('./routes/classes');
const subjectRoutes    = require('./routes/subjects');
const attendanceRoutes = require('./routes/attendance');
const feeRoutes        = require('./routes/fees');
const expenditureRoutes = require('./routes/expenditure');
const examRoutes       = require('./routes/exams');
const hallTicketRoutes = require('./routes/hallTickets');
const hostelRoutes     = require('./routes/hostel');
const noticeRoutes     = require('./routes/notices');
const reportRoutes     = require('./routes/reports');
const dashboardRoutes  = require('./routes/dashboard');
const payrollRoutes    = require('./routes/payroll');
const leaveRoutes      = require('./routes/leave');
const notificationRoutes  = require('./routes/notifications');
const timetableRoutes     = require('./routes/timetable');
const lmsRoutes           = require('./routes/lms');
const teacherDeskRoutes   = require('./routes/teacherDesk');
const commRoutes          = require('./routes/schoolCommunication');
const transportRoutes     = require('./routes/transport');

const app = express();

// ── Security ────────────────────────────────────────────────
app.use(helmet());
app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:3000',
  credentials: true,
}));

// ── Rate limiting ────────────────────────────────────────────
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 min
  max: 300,
  message: { error: 'Too many requests. Please try again later.' }
});
app.use('/api/', limiter);

// Stricter limit for auth routes
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  message: { error: 'Too many login attempts. Please try again in 15 minutes.' }
});

// ── Body parsing ─────────────────────────────────────────────
app.use(compression());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// ── Logging ──────────────────────────────────────────────────
app.use(morgan('combined', { stream: { write: msg => logger.info(msg.trim()) } }));

// ── Static files (uploads) ───────────────────────────────────
app.use('/uploads', express.static(path.join(__dirname, '../uploads')));

// ── Health check ─────────────────────────────────────────────
app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    service: 'VidyaMate API',
    version: '1.0.0'
  });
});

// ── API Routes ───────────────────────────────────────────────
const v1 = '/api/v1';

app.use(`${v1}/auth`,          authLimiter, authRoutes);
app.use(`${v1}/organizations`, orgRoutes);
app.use(`${v1}/schools`,       schoolRoutes);
app.use(`${v1}/sessions`,      sessionRoutes);
app.use(`${v1}/masters`,       masterRoutes);
app.use(`${v1}/users`,         userRoutes);
app.use(`${v1}/staff`,         staffRoutes);
app.use(`${v1}/students`,      studentRoutes);
app.use(`${v1}/classes`,       classRoutes);
app.use(`${v1}/subjects`,      subjectRoutes);
app.use(`${v1}/attendance`,    attendanceRoutes);
app.use(`${v1}/fees`,          feeRoutes);
app.use(`${v1}/expenditure`,   expenditureRoutes);
app.use(`${v1}/exams`,         examRoutes);
app.use(`${v1}/hall-tickets`,  hallTicketRoutes);
app.use(`${v1}/hostel`,        hostelRoutes);
app.use(`${v1}/notices`,       noticeRoutes);
app.use(`${v1}/reports`,       reportRoutes);
app.use(`${v1}/dashboard`,     dashboardRoutes);
app.use(`${v1}/payroll`,       payrollRoutes);
app.use(`${v1}/leave`,         leaveRoutes);
app.use(`${v1}/notifications`,       notificationRoutes);
app.use(`${v1}/timetable`,           timetableRoutes);
app.use(`${v1}/lms`,                 lmsRoutes);
app.use(`${v1}/teacher-desk`,        teacherDeskRoutes);
app.use(`${v1}/school-communication`,commRoutes);
app.use(`${v1}/transport`,           transportRoutes);
app.use(`${v1}/holidays`,            require('./routes/holidays'));
app.use(`${v1}/export`,              require('./routes/exports'));

// ── Serve React build in production ─────────────────────────
// The unified Dockerfile copies frontend/build → /app/public
// All non-API, non-upload GET requests serve index.html (React Router)
if (process.env.NODE_ENV === 'production') {
  const publicPath = path.join(__dirname, '../public');
  app.use(express.static(publicPath));
  app.get(/^(?!\/api\/|\/uploads\/)/, (_req, res) => {
    res.sendFile(path.join(publicPath, 'index.html'));
  });
}

// ── Error handling ───────────────────────────────────────────
app.use(notFound);
app.use(errorHandler);

// ── Start server ─────────────────────────────────────────────
const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  logger.info(`VidyaMate API running on port ${PORT} [${process.env.NODE_ENV}]`);
});

module.exports = app;
