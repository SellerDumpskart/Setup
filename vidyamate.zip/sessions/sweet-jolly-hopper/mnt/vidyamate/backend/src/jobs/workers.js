/**
 * VidyaMate Background Job Workers
 * Uses Bull queue backed by Redis
 * Falls back to direct execution if Redis unavailable
 */
const logger = require('../utils/logger');

let Queue;
try {
  Queue = require('bull');
} catch {
  logger.warn('Bull not available — jobs will run synchronously');
}

const REDIS_URL = process.env.REDIS_URL || 'redis://localhost:6379';

// ── Queue factory ─────────────────────────────────────────
const createQueue = (name) => {
  if (!Queue) return null;
  try {
    const q = new Queue(name, REDIS_URL);
    q.on('error',     (err) => logger.error(`Queue ${name} error:`, err.message));
    q.on('failed',    (job, err) => logger.error(`Job ${job.id} failed:`, err.message));
    q.on('completed', (job) => logger.info(`Job ${job.id} completed`));
    return q;
  } catch {
    return null;
  }
};

// ── Queues ────────────────────────────────────────────────
const pdfQueue   = createQueue('pdf-generation');
const smsQueue   = createQueue('sms-dispatch');
const emailQueue = createQueue('email-dispatch');
const reportQueue= createQueue('report-generation');

// ── PDF GENERATION WORKER ─────────────────────────────────
const processPdfJob = async (job) => {
  const { type, data, filename } = job.data;
  const { htmlToPdf, generateHallTicketHtml, generateReceiptHtml, generatePayslipHtml } = require('../utils/pdfService');
  const db = require('../config/database');

  let html = '';
  if (type === 'hall_ticket') {
    html = generateHallTicketHtml(data.tickets, data.exam, data.school);
  } else if (type === 'receipt') {
    html = generateReceiptHtml(data.payment, data.student, data.school);
  } else if (type === 'payslip') {
    html = generatePayslipHtml(data.payroll, data.staff, data.school);
  }

  const url = await htmlToPdf(html, filename);

  // Update record with PDF URL
  if (type === 'hall_ticket' && data.hallTicketId) {
    await db.query(`UPDATE hall_tickets SET pdf_url=$1 WHERE id=$2`, [url, data.hallTicketId]);
  } else if (type === 'receipt' && data.paymentId) {
    // Store receipt URL in a receipts table or return via webhook
    logger.info(`Receipt PDF generated: ${url}`);
  } else if (type === 'payslip' && data.payrollId) {
    await db.query(`UPDATE payroll SET slip_url=$1 WHERE id=$2`, [url, data.payrollId]);
  }

  return { url };
};

// ── SMS DISPATCH WORKER ───────────────────────────────────
const processSmsJob = async (job) => {
  const { phones, message, schoolId } = job.data;
  const { sendSMS } = require('../services/notificationService');
  return sendSMS({ to: phones, message, schoolId });
};

// ── EMAIL DISPATCH WORKER ─────────────────────────────────
const processEmailJob = async (job) => {
  const { to, subject, html, text, schoolId } = job.data;
  const { sendEmail } = require('../services/notificationService');
  return sendEmail({ to, subject, html, text, schoolId });
};

// ── REPORT GENERATION WORKER ──────────────────────────────
const processReportJob = async (job) => {
  const { reportType, params, schoolId, sessionId } = job.data;
  const db = require('../config/database');
  const excel = require('../utils/excelService');

  const school = (await db.query('SELECT name FROM schools WHERE id=$1', [schoolId])).rows[0];

  if (reportType === 'students') {
    const { rows } = await db.query(
      `SELECT s.*, c.class_name, c.section, p.father_name, p.father_phone
       FROM students s
       LEFT JOIN classes c ON s.class_id = c.id
       LEFT JOIN parents p ON s.parent_id = p.id
       WHERE s.school_id=$1 AND s.session_id=$2 AND s.status='active'
       ORDER BY c.class_name, s.roll_number`, [schoolId, sessionId]
    );
    return excel.exportStudents(rows, school?.name);
  }

  if (reportType === 'fee_collection') {
    const { rows } = await db.query(
      `SELECT fp.*, s.first_name, s.last_name, s.student_code, fh.fee_name, c.class_name, c.section
       FROM fee_payments fp
       JOIN students s ON fp.student_id = s.id
       JOIN student_fees sf ON fp.student_fee_id = sf.id
       JOIN fee_heads fh ON sf.fee_head_id = fh.id
       LEFT JOIN classes c ON s.class_id = c.id
       WHERE s.school_id=$1 ORDER BY fp.payment_date DESC`, [schoolId]
    );
    return excel.exportFeeCollection(rows, school?.name);
  }

  if (reportType === 'staff') {
    const { rows } = await db.query(
      `SELECT * FROM staff WHERE school_id=$1 AND status='active' ORDER BY first_name`, [schoolId]
    );
    return excel.exportStaff(rows, school?.name);
  }

  throw new Error(`Unknown report type: ${reportType}`);
};

// ── Register processors ───────────────────────────────────
if (pdfQueue)    pdfQueue.process(5,    processPdfJob);
if (smsQueue)    smsQueue.process(10,   processSmsJob);
if (emailQueue)  emailQueue.process(10, processEmailJob);
if (reportQueue) reportQueue.process(3, processReportJob);

// ── Job dispatchers (call from routes/controllers) ────────
const dispatchPdf = async (type, data, filename) => {
  if (pdfQueue) return pdfQueue.add({ type, data, filename }, { attempts: 3, backoff: 5000 });
  return processPdfJob({ data: { type, data, filename } });
};

const dispatchSms = async (phones, message, schoolId) => {
  if (smsQueue) return smsQueue.add({ phones, message, schoolId }, { attempts: 3, backoff: 10000 });
  return processSmsJob({ data: { phones, message, schoolId } });
};

const dispatchEmail = async (to, subject, html, text, schoolId) => {
  if (emailQueue) return emailQueue.add({ to, subject, html, text, schoolId }, { attempts: 3, backoff: 10000 });
  return processEmailJob({ data: { to, subject, html, text, schoolId } });
};

const dispatchReport = async (reportType, params, schoolId, sessionId) => {
  if (reportQueue) return reportQueue.add({ reportType, params, schoolId, sessionId }, { attempts: 2 });
  return processReportJob({ data: { reportType, params, schoolId, sessionId } });
};

// ── Fee reminder scheduled job ────────────────────────────
const scheduleFeeReminders = async () => {
  try {
    const db = require('../config/database');
    const { rows } = await db.query(`
      SELECT s.id, s.first_name, s.last_name, sf.balance,
             p.father_name, p.father_phone, p.father_email,
             sc.id as school_id
      FROM student_fees sf
      JOIN students s ON sf.student_id = s.id
      JOIN parents p ON s.parent_id = p.id
      JOIN schools sc ON s.school_id = sc.id
      WHERE sf.balance > 0 AND sf.due_date < CURRENT_DATE + INTERVAL '3 days'
      LIMIT 500
    `);

    for (const student of rows) {
      const msg = `Dear ${student.father_name || 'Parent'}, fee of ₹${Number(student.balance).toLocaleString('en-IN')} for ${student.first_name} is due. Please pay at the earliest. -VidyaMate`;
      if (student.father_phone) {
        await dispatchSms([student.father_phone], msg, student.school_id);
      }
    }

    logger.info(`Fee reminders dispatched for ${rows.length} students`);
  } catch (err) {
    logger.error('Fee reminder job failed:', err.message);
  }
};

// ── Attendance alert job ──────────────────────────────────
const sendAbsentAlerts = async (absentStudents, schoolId) => {
  const date = new Date().toLocaleDateString('en-IN', { day:'2-digit', month:'short', year:'numeric' });
  for (const s of absentStudents) {
    if (s.father_phone) {
      const msg = `${s.first_name} ${s.last_name || ''} was marked ABSENT on ${date}. -VidyaMate`;
      await dispatchSms([s.father_phone], msg, schoolId);
    }
  }
};

module.exports = {
  pdfQueue, smsQueue, emailQueue, reportQueue,
  dispatchPdf, dispatchSms, dispatchEmail, dispatchReport,
  scheduleFeeReminders, sendAbsentAlerts,
};
