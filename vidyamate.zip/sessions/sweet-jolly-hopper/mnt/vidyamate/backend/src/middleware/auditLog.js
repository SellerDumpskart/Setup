const { query } = require('../config/database');
const logger = require('../utils/logger');

// Middleware to log POST/PUT/DELETE operations to audit_logs
const auditLog = (tableName) => async (req, res, next) => {
  // Capture original json method to intercept response
  const originalJson = res.json.bind(res);
  res.json = function(data) {
    // Log asynchronously — don't block response
    if (['POST','PUT','PATCH','DELETE'].includes(req.method) && req.user) {
      const action = req.method === 'POST' ? 'CREATE'
                   : req.method === 'PUT' || req.method === 'PATCH' ? 'UPDATE'
                   : 'DELETE';
      const recordId = data?.id || req.params?.id || null;

      query(
        `INSERT INTO audit_logs (user_id, school_id, action, table_name, record_id, new_values, ip_address, user_agent)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`,
        [
          req.user.id,
          req.user.school_id,
          action,
          tableName,
          recordId,
          req.method !== 'DELETE' ? JSON.stringify(data) : null,
          req.ip,
          req.get('user-agent')
        ]
      ).catch(err => logger.error('Audit log failed:', err.message));
    }
    return originalJson(data);
  };
  next();
};

// Get audit logs for a record
const getAuditLogs = async (req, res, next) => {
  try {
    const { tableName, recordId, userId } = req.query;
    let where = ['1=1']; const params = [];
    if (tableName) { where.push(`table_name = $${params.length+1}`); params.push(tableName); }
    if (recordId)  { where.push(`record_id = $${params.length+1}`);  params.push(recordId); }
    if (userId)    { where.push(`user_id = $${params.length+1}`);    params.push(userId); }

    const { rows } = await query(
      `SELECT al.*, u.username, u.email
       FROM audit_logs al LEFT JOIN users u ON al.user_id = u.id
       WHERE ${where.join(' AND ')}
       ORDER BY al.created_at DESC LIMIT 100`,
      params
    );
    res.json(rows);
  } catch (err) { next(err); }
};

module.exports = { auditLog, getAuditLogs };
