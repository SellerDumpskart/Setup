const jwt = require('jsonwebtoken');
const { query } = require('../config/database');

// Verify JWT and attach user to request
const authenticate = async (req, res, next) => {
  try {
    const header = req.headers.authorization;
    if (!header || !header.startsWith('Bearer ')) {
      return res.status(401).json({ error: 'No token provided' });
    }
    const token = header.split(' ')[1];
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    const { rows } = await query(
      'SELECT id, email, role, school_id, organization_id, is_active FROM users WHERE id = $1',
      [decoded.id]
    );
    if (!rows.length || !rows[0].is_active) {
      return res.status(401).json({ error: 'User not found or inactive' });
    }
    req.user = rows[0];
    next();
  } catch (err) {
    if (err.name === 'TokenExpiredError') {
      return res.status(401).json({ error: 'Token expired' });
    }
    return res.status(401).json({ error: 'Invalid token' });
  }
};

// Role-based access: pass allowed roles
const authorize = (...roles) => (req, res, next) => {
  if (!roles.includes(req.user.role)) {
    return res.status(403).json({ error: 'Access denied: insufficient permissions' });
  }
  next();
};

// School-level isolation: ensures user can only access their school's data
const schoolAccess = (req, res, next) => {
  const schoolId = req.params.schoolId || req.query.schoolId || req.body.schoolId;
  if (req.user.role === 'super_admin') return next();
  if (req.user.role === 'org_admin') {
    // Verified at route level via org check
    return next();
  }
  if (schoolId && req.user.school_id !== schoolId) {
    return res.status(403).json({ error: 'Access denied: wrong school' });
  }
  next();
};

module.exports = { authenticate, authorize, schoolAccess };
