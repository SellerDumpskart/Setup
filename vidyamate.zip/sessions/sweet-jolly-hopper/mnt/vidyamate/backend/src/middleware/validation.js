const { validationResult, body, param, query } = require('express-validator');

// Run validations and return 422 if any fail
const validate = (validations) => async (req, res, next) => {
  await Promise.all(validations.map(v => v.run(req)));
  const errors = validationResult(req);
  if (errors.isEmpty()) return next();
  return res.status(422).json({
    error: 'Validation failed',
    details: errors.array().map(e => ({ field: e.path, message: e.msg }))
  });
};

// ── Auth ──────────────────────────────────────────────────
const loginRules = validate([
  body('email').isEmail().withMessage('Valid email required'),
  body('password').notEmpty().withMessage('Password required'),
]);

// ── Student ───────────────────────────────────────────────
const createStudentRules = validate([
  body('firstName').trim().notEmpty().withMessage('Student first name required'),
  body('gender').isIn(['male','female','other']).withMessage('Invalid gender'),
  body('fatherPhone').isMobilePhone('en-IN').withMessage('Valid 10-digit phone required'),
  body('aadhaarNo').optional().isLength({ min:12, max:12 }).isNumeric().withMessage('Aadhaar must be 12 digits'),
  body('classId').notEmpty().withMessage('Class required'),
]);

// ── Staff ─────────────────────────────────────────────────
const createStaffRules = validate([
  body('firstName').trim().notEmpty().withMessage('Staff first name required'),
  body('phone').isMobilePhone('en-IN').withMessage('Valid phone required'),
  body('staffType').isIn(['teaching','non_teaching','support','admin']).withMessage('Invalid staff type'),
]);

// ── Fee ───────────────────────────────────────────────────
const collectPaymentRules = validate([
  body('studentId').notEmpty().withMessage('Student ID required'),
  body('amount').isFloat({ min: 1 }).withMessage('Amount must be positive'),
  body('paymentMode').isIn(['cash','online','upi','cheque','dd','neft','card']).withMessage('Invalid payment mode'),
]);

// ── Attendance ────────────────────────────────────────────
const markAttendanceRules = validate([
  body('classId').notEmpty().withMessage('Class ID required'),
  body('records').isArray({ min: 1 }).withMessage('At least one record required'),
  body('records.*.studentId').notEmpty().withMessage('Student ID required in each record'),
  body('records.*.status').isIn(['present','absent','holiday','leave','late']).withMessage('Invalid status'),
]);

// ── Exam ──────────────────────────────────────────────────
const createExamRules = validate([
  body('examName').trim().notEmpty().withMessage('Exam name required'),
  body('startDate').isISO8601().withMessage('Valid start date required'),
]);

// ── Expenditure ───────────────────────────────────────────
const createExpenditureRules = validate([
  body('description').trim().notEmpty().withMessage('Description required'),
  body('amount').isFloat({ min: 0.01 }).withMessage('Amount must be positive'),
  body('category').notEmpty().withMessage('Category required'),
]);

// ── Notice ────────────────────────────────────────────────
const createNoticeRules = validate([
  body('title').trim().notEmpty().withMessage('Title required'),
  body('content').trim().notEmpty().withMessage('Content required'),
]);

// ── Broadcast ─────────────────────────────────────────────
const broadcastRules = validate([
  body('title').trim().notEmpty().withMessage('Title required'),
  body('message').trim().notEmpty().withMessage('Message required'),
  body('channel').isIn(['sms','email','push','whatsapp','all']).withMessage('Invalid channel'),
]);

// ── Generic id param ─────────────────────────────────────
const uuidParam = validate([
  param('id').isUUID().withMessage('Invalid ID format'),
]);

module.exports = {
  validate,
  loginRules,
  createStudentRules,
  createStaffRules,
  collectPaymentRules,
  markAttendanceRules,
  createExamRules,
  createExpenditureRules,
  createNoticeRules,
  broadcastRules,
  uuidParam,
};
