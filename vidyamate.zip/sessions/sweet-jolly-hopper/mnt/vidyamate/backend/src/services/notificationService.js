const nodemailer = require('nodemailer');
const axios = require('axios');
const { query } = require('../config/database');
const logger = require('../utils/logger');

// ── EMAIL SERVICE ──────────────────────────────────────────
const createTransporter = () => {
  return nodemailer.createTransport({
    host: process.env.SMTP_HOST || 'smtp.gmail.com',
    port: parseInt(process.env.SMTP_PORT) || 587,
    secure: false,
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS,
    },
  });
};

const sendEmail = async ({ to, subject, html, text, schoolId }) => {
  try {
    if (!process.env.SMTP_USER) {
      logger.warn('Email not configured — skipping send');
      return { success: false, reason: 'not_configured' };
    }
    const transporter = createTransporter();
    const info = await transporter.sendMail({
      from: `"${process.env.FROM_NAME || 'VidyaMate'}" <${process.env.FROM_EMAIL || process.env.SMTP_USER}>`,
      to, subject, html, text,
    });

    // Log to DB
    await query(
      `INSERT INTO communication_logs (school_id, channel, recipient, subject, message, status, provider_ref, sent_at)
       VALUES ($1,'email',$2,$3,$4,'sent',$5,NOW())`,
      [schoolId, to, subject, text || html?.replace(/<[^>]+>/g, ''), info.messageId]
    ).catch(() => {});

    return { success: true, messageId: info.messageId };
  } catch (err) {
    logger.error('Email send failed:', err.message);
    await query(
      `INSERT INTO communication_logs (school_id, channel, recipient, subject, message, status)
       VALUES ($1,'email',$2,$3,$4,'failed')`,
      [schoolId, to, subject, text || '']
    ).catch(() => {});
    return { success: false, error: err.message };
  }
};

// ── SMS SERVICE (MSG91) ────────────────────────────────────
const sendSMS = async ({ to, message, schoolId }) => {
  try {
    if (!process.env.MSG91_AUTH_KEY) {
      logger.warn('SMS not configured — skipping send');
      return { success: false, reason: 'not_configured' };
    }

    const phones = Array.isArray(to) ? to : [to];
    const response = await axios.post('https://api.msg91.com/api/v5/flow/', {
      template_id: process.env.MSG91_TEMPLATE_ID,
      short_url: '0',
      recipients: phones.map(p => ({ mobiles: p.replace(/[^0-9]/g, ''), VAR1: message }))
    }, {
      headers: {
        authkey: process.env.MSG91_AUTH_KEY,
        'Content-Type': 'application/JSON'
      }
    });

    // Log
    for (const phone of phones) {
      await query(
        `INSERT INTO communication_logs (school_id, channel, recipient, message, status, sent_at)
         VALUES ($1,'sms',$2,$3,'sent',NOW())`,
        [schoolId, phone, message]
      ).catch(() => {});
    }

    return { success: true, data: response.data };
  } catch (err) {
    logger.error('SMS send failed:', err.message);
    return { success: false, error: err.message };
  }
};

// ── BULK NOTIFICATIONS ─────────────────────────────────────
const notifyFeeReminder = async ({ schoolId, studentId, studentName, feeAmount, dueDate, parentPhone, parentEmail }) => {
  const message = `Dear Parent, fee of Rs.${feeAmount} for ${studentName} is due on ${dueDate}. Please pay at the earliest. -VidyaMate`;
  const results = [];

  if (parentPhone) results.push(await sendSMS({ to: parentPhone, message, schoolId }));
  if (parentEmail) results.push(await sendEmail({
    to: parentEmail,
    subject: `Fee Reminder — ${studentName}`,
    html: `<p>${message}</p>`,
    schoolId
  }));

  return results;
};

const notifyAttendance = async ({ schoolId, studentName, date, status, parentPhone }) => {
  if (status !== 'absent') return;
  const message = `${studentName} was marked ABSENT on ${date}. Please contact the school if this is an error. -VidyaMate`;
  return sendSMS({ to: parentPhone, message, schoolId });
};

const notifyBulk = async ({ schoolId, phones, emails, subject, message }) => {
  const results = { sms: null, email: null };
  if (phones?.length) results.sms  = await sendSMS({ to: phones, message, schoolId });
  if (emails?.length) results.email = await Promise.all(
    emails.map(email => sendEmail({ to: email, subject, html: `<p>${message}</p>`, text: message, schoolId }))
  );
  return results;
};

// ── APP NOTIFICATIONS (in-app) ─────────────────────────────
const createNotification = async ({ userId, schoolId, title, message, type = 'info', channel = 'app' }) => {
  try {
    const { rows } = await query(
      `INSERT INTO notifications (user_id, school_id, title, message, notif_type, channel, sent_at)
       VALUES ($1,$2,$3,$4,$5,$6,NOW()) RETURNING id`,
      [userId, schoolId, title, message, type, channel]
    );
    return rows[0];
  } catch (err) {
    logger.error('Notification creation failed:', err.message);
  }
};

module.exports = { sendEmail, sendSMS, notifyFeeReminder, notifyAttendance, notifyBulk, createNotification };
