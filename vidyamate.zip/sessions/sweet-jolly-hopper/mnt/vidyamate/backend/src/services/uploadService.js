const multer = require('multer');
const path   = require('path');
const fs     = require('fs');
const { v4: uuidv4 } = require('uuid');

const UPLOAD_DIR = process.env.UPLOAD_DIR || './uploads';

// Ensure directories exist
['students','staff','documents','bills','profiles','content'].forEach(dir => {
  const p = path.join(UPLOAD_DIR, dir);
  if (!fs.existsSync(p)) fs.mkdirSync(p, { recursive: true });
});

// Storage config
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    let folder = 'documents';
    if (file.fieldname === 'photo' || file.fieldname === 'profile') folder = 'profiles';
    else if (req.baseUrl?.includes('students')) folder = 'students';
    else if (req.baseUrl?.includes('staff'))    folder = 'staff';
    else if (req.baseUrl?.includes('expenditure') || req.baseUrl?.includes('fees')) folder = 'bills';
    else if (req.baseUrl?.includes('lms'))      folder = 'content';
    cb(null, path.join(UPLOAD_DIR, folder));
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, `${uuidv4()}${ext}`);
  }
});

// File filter
const fileFilter = (req, file, cb) => {
  const allowed = ['.jpg','.jpeg','.png','.gif','.webp','.pdf','.doc','.docx','.xls','.xlsx','.mp4','.mp3'];
  const ext = path.extname(file.originalname).toLowerCase();
  if (allowed.includes(ext)) cb(null, true);
  else cb(new Error(`File type ${ext} not allowed`), false);
};

const upload = multer({
  storage,
  fileFilter,
  limits: { fileSize: parseInt(process.env.MAX_FILE_SIZE) || 10 * 1024 * 1024 } // 10MB
});

// Helper: get public URL for uploaded file
const getFileUrl = (filePath) => {
  if (!filePath) return null;
  const relative = filePath.replace(UPLOAD_DIR, '').replace(/\\/g, '/');
  return `/uploads${relative}`;
};

// Multer field configurations
const uploadPhoto    = upload.single('photo');
const uploadDocument = upload.single('document');
const uploadMultiple = upload.fields([
  { name:'photo',       maxCount:1 },
  { name:'birthCert',   maxCount:1 },
  { name:'tc',          maxCount:1 },
  { name:'aadhaar',     maxCount:1 },
  { name:'casteCert',   maxCount:1 },
  { name:'incomeCert',  maxCount:1 },
  { name:'bill',        maxCount:1 },
  { name:'content',     maxCount:5 },
]);

module.exports = { upload, uploadPhoto, uploadDocument, uploadMultiple, getFileUrl };
