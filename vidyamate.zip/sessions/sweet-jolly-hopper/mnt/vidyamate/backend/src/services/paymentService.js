const axios = require('axios');
const crypto = require('crypto');
const logger = require('../utils/logger');

const RAZORPAY_KEY_ID     = process.env.RAZORPAY_KEY_ID;
const RAZORPAY_KEY_SECRET = process.env.RAZORPAY_KEY_SECRET;
const BASE_URL = 'https://api.razorpay.com/v1';

const getHeaders = () => ({
  'Content-Type': 'application/json',
  'Authorization': `Basic ${Buffer.from(`${RAZORPAY_KEY_ID}:${RAZORPAY_KEY_SECRET}`).toString('base64')}`
});

// Create a Razorpay order
const createOrder = async ({ amount, currency = 'INR', receiptId, notes = {} }) => {
  try {
    if (!RAZORPAY_KEY_ID) {
      logger.warn('Razorpay not configured');
      return { success: false, reason: 'not_configured' };
    }

    const response = await axios.post(`${BASE_URL}/orders`, {
      amount: Math.round(amount * 100), // Razorpay expects paise
      currency,
      receipt: receiptId,
      notes
    }, { headers: getHeaders() });

    return { success: true, order: response.data };
  } catch (err) {
    logger.error('Razorpay order creation failed:', err.response?.data || err.message);
    return { success: false, error: err.response?.data?.error?.description || err.message };
  }
};

// Verify payment signature (called after frontend payment)
const verifyPayment = ({ orderId, paymentId, signature }) => {
  try {
    const expectedSignature = crypto
      .createHmac('sha256', RAZORPAY_KEY_SECRET)
      .update(`${orderId}|${paymentId}`)
      .digest('hex');

    return expectedSignature === signature;
  } catch (err) {
    logger.error('Razorpay verification failed:', err.message);
    return false;
  }
};

// Fetch payment details
const fetchPayment = async (paymentId) => {
  try {
    const response = await axios.get(`${BASE_URL}/payments/${paymentId}`, { headers: getHeaders() });
    return { success: true, payment: response.data };
  } catch (err) {
    return { success: false, error: err.message };
  }
};

module.exports = { createOrder, verifyPayment, fetchPayment };
