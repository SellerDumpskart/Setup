const router = require('express').Router();
const { uuidParam } = require('../middleware/validation');
const { authenticate } = require('../middleware/auth');
const db = require('../config/database');

router.get('/', authenticate, async (req, res, next) => {
  try {
    const { rows } = await db.query(
      `SELECT * FROM notifications WHERE user_id=$1 ORDER BY created_at DESC LIMIT 30`,
      [req.user.id]
    );
    res.json(rows);
  } catch(e){ next(e); }
});

router.put('/read-all', authenticate, async (req, res, next) => {
  try {
    await db.query(`UPDATE notifications SET is_read=TRUE, read_at=NOW() WHERE user_id=$1`, [req.user.id]);
    res.json({ message: 'All marked as read' });
  } catch(e){ next(e); }
});

router.put('/:id/read', authenticate, async (req, res, next) => {
  try {
    await db.query(`UPDATE notifications SET is_read=TRUE, read_at=NOW() WHERE id=$1 AND user_id=$2`, [req.params.id, req.user.id]);
    res.json({ message: 'Marked as read' });
  } catch(e){ next(e); }
});

module.exports = router;
