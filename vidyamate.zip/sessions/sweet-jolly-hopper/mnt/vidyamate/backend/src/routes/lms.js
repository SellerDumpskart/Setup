const router = require('express').Router();
const { authenticate } = require('../middleware/auth');
const {
  getContent, createContent, publishContent,
  submitAssignment, gradeSubmission, getOnlineClasses, scheduleOnlineClass
} = require('../controllers/extendedController');
const { uploadDocument, getFileUrl } = require('../services/uploadService');
const db = require('../config/database');

router.get('/content',               authenticate, getContent);
router.post('/content',              authenticate, createContent);
router.put('/content/:id/publish',   authenticate, publishContent);
router.post('/content/submit',       authenticate, submitAssignment);
router.put('/submissions/:id/grade', authenticate, gradeSubmission);
router.get('/classes',               authenticate, getOnlineClasses);
router.post('/classes',              authenticate, scheduleOnlineClass);
// POST /lms/content/:id/upload — attach file to existing content record
router.post('/content/:id/upload', authenticate, (req, res, next) => {
  uploadDocument(req, res, async (err) => {
    if (err) return res.status(400).json({ error: err.message });
    if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
    try {
      const fileUrl = getFileUrl(req.file.path);
      const { rows } = await db.query(
        `UPDATE lms_content SET file_url = $1 WHERE id = $2 RETURNING *`,
        [fileUrl, req.params.id]
      );
      if (!rows.length) return res.status(404).json({ error: 'Content not found' });
      res.json(rows[0]);
    } catch (e) { next(e); }
  });
});

module.exports = router;
