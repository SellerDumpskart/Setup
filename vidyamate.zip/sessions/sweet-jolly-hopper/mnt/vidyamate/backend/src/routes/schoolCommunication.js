const router = require('express').Router();
const { authenticate, authorize } = require('../middleware/auth');
const {
  getTemplates, createTemplate, getBroadcasts, sendBroadcast,
  getParentMessages, sendParentMessage, markMessagesRead, getCommunicationLogs
} = require('../controllers/extendedController');

router.get('/templates',                    authenticate, getTemplates);
router.post('/templates',                   authenticate, createTemplate);
router.get('/broadcasts',                   authenticate, getBroadcasts);
router.post('/broadcasts',                  authenticate, authorize('super_admin','org_admin','principal'), sendBroadcast);
router.get('/messages',                     authenticate, getParentMessages);
router.post('/messages',                    authenticate, sendParentMessage);
router.put('/messages/:parentId/read',      authenticate, markMessagesRead);
router.get('/logs',                         authenticate, getCommunicationLogs);
module.exports = router;
