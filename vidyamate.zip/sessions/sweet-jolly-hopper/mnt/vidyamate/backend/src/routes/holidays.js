const router = require('express').Router();
const { uuidParam } = require('../middleware/validation');
const { authenticate, authorize } = require('../middleware/auth');
const db = require('../config/database');

// GET /holidays?schoolId=&sessionId=
router.get('/', authenticate, async (req, res, next) => {
  try {
    const { sessionId, upcoming } = req.query;
    const schoolId = req.query.schoolId || req.user.school_id;

    let where = ['h.school_id = $1', 'h.session_id = $2'];
    const params = [schoolId, sessionId];

    if (upcoming === 'true') {
      where.push('h.from_date >= CURRENT_DATE');
    }

    const { rows } = await db.query(
      `SELECT * FROM holidays
       WHERE ${where.join(' AND ')}
       ORDER BY from_date ASC`,
      params
    );
    res.json(rows);
  } catch (e) { next(e); }
});

// POST /holidays
router.post('/', authenticate, authorize('super_admin','org_admin','principal'), async (req, res, next) => {
  try {
    const {
      schoolId, sessionId,
      holidayName, holidayType = 'government',
      fromDate, toDate, applicableTo = 'all', description
    } = req.body;
    const sid = schoolId || req.user.school_id;

    if (!holidayName || !fromDate) {
      return res.status(400).json({ error: 'Holiday name and date required' });
    }

    const { rows } = await db.query(
      `INSERT INTO holidays
         (school_id, session_id, holiday_name, holiday_type, from_date, to_date, applicable_to, description)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
      [sid, sessionId, holidayName, holidayType, fromDate, toDate || fromDate, applicableTo, description]
    );
    res.status(201).json(rows[0]);
  } catch (e) { next(e); }
});

// PUT /holidays/:id
router.put('/:id', uuidParam, authenticate, authorize('super_admin','org_admin','principal'), async (req, res, next) => {
  try {
    const { holidayName, holidayType, fromDate, toDate, applicableTo, description } = req.body;
    const { rows } = await db.query(
      `UPDATE holidays
       SET holiday_name=$1, holiday_type=$2, from_date=$3,
           to_date=$4, applicable_to=$5, description=$6,
           updated_at=NOW()
       WHERE id=$7 RETURNING *`,
      [holidayName, holidayType, fromDate, toDate || fromDate, applicableTo, description, req.params.id]
    );
    if (!rows.length) return res.status(404).json({ error: 'Holiday not found' });
    res.json(rows[0]);
  } catch (e) { next(e); }
});

// DELETE /holidays/:id
router.delete('/:id', uuidParam, authenticate, authorize('super_admin','org_admin','principal'), async (req, res, next) => {
  try {
    await db.query('DELETE FROM holidays WHERE id=$1', [req.params.id]);
    res.json({ message: 'Holiday removed' });
  } catch (e) { next(e); }
});

module.exports = router;
