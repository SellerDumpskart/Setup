const router = require('express').Router();
const { uuidParam } = require('../middleware/validation');
const { authenticate, authorize } = require('../middleware/auth');
const db = require('../config/database');

router.get('/', authenticate, async (req, res, next) => {
  try {
    const { schoolId, sessionId, category, page=1, limit=50 } = req.query;
    const sid = schoolId || req.user.school_id;
    const offset = (page-1)*limit;
    let where = ['school_id=$1','session_id=$2']; const params=[sid,sessionId];
    if (category) { where.push(`category=$3`); params.push(category); }
    const { rows } = await db.query(
      `SELECT e.*, u.username as created_by_name
       FROM expenditures e LEFT JOIN users u ON e.created_by=u.id
       WHERE ${where.join(' AND ')} ORDER BY expense_date DESC
       LIMIT $${params.length+1} OFFSET $${params.length+2}`,
      [...params, limit, offset]
    );
    res.json(rows);
  } catch(e){ next(e); }
});

router.post('/', authenticate, authorize('super_admin','org_admin','principal','accountant'), async (req, res, next) => {
  try {
    const { schoolId, sessionId, description, amount, category, expenseDate, paymentMode, vendorName, billNo, remarks } = req.body;
    const sid = schoolId || req.user.school_id;
    const { rows } = await db.query(
      `INSERT INTO expenditures (school_id, session_id, description, amount, category, expense_date, payment_mode, vendor_name, bill_no, remarks, created_by)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING *`,
      [sid, sessionId, description, amount, category, expenseDate, paymentMode, vendorName, billNo, remarks, req.user.id]
    );
    res.status(201).json(rows[0]);
  } catch(e){ next(e); }
});

router.put('/:id', uuidParam, authenticate, authorize('super_admin','org_admin','principal','accountant'), async (req, res, next) => {
  try {
    const { description, amount, category, expenseDate, paymentMode, vendorName, billNo } = req.body;
    const { rows } = await db.query(
      `UPDATE expenditures SET description=$1, amount=$2, category=$3, expense_date=$4, payment_mode=$5, vendor_name=$6, bill_no=$7 WHERE id=$8 RETURNING *`,
      [description, amount, category, expenseDate, paymentMode, vendorName, billNo, req.params.id]
    );
    res.json(rows[0]);
  } catch(e){ next(e); }
});

router.delete('/:id', uuidParam, authenticate, authorize('super_admin','org_admin','principal'), async (req, res, next) => {
  try {
    await db.query(`DELETE FROM expenditures WHERE id=$1`, [req.params.id]);
    res.json({ message: 'Expenditure removed' });
  } catch(e){ next(e); }
});

module.exports = router;
