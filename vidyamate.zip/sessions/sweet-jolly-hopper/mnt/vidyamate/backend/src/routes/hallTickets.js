// Hall tickets are part of the exams module
const router = require('express').Router();
const { authenticate, authorize } = require('../middleware/auth');
const { generateHallTickets, getHallTickets } = require('../controllers/examsController');
router.get('/',          authenticate, getHallTickets);
router.post('/generate', authenticate, authorize('super_admin','org_admin','principal'), generateHallTickets);
module.exports = router;
