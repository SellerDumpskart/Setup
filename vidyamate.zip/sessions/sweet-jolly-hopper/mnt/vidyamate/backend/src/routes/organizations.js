// ============================================================
// VIDYAMATE - ALL ROUTES (organized as one file per module)
// ============================================================
// Each exports a router. The main index.js mounts them all.
// ============================================================

// routes/organizations.js
const orgRouter = require('express').Router();
const { authenticate, authorize } = require('../middleware/auth');
const db = require('../config/database');

orgRouter.get('/', authenticate, async (req, res, next) => {
  try {
    const { rows } = await db.query('SELECT * FROM organizations ORDER BY name');
    res.json(rows);
  } catch(e){ next(e); }
});
orgRouter.post('/', authenticate, authorize('super_admin'), async (req, res, next) => {
  try {
    const { name, regNumber, sinceDate, address, phone, email } = req.body;
    const { rows } = await db.query(
      `INSERT INTO organizations (name, reg_number, since_date, address, phone, email)
       VALUES ($1,$2,$3,$4,$5,$6) RETURNING *`,
      [name, regNumber, sinceDate, address, phone, email]
    );
    res.status(201).json(rows[0]);
  } catch(e){ next(e); }
});
orgRouter.put('/:id', authenticate, authorize('super_admin'), async (req, res, next) => {
  try {
    const { name, regNumber, sinceDate, address, phone, email, status } = req.body;
    const { rows } = await db.query(
      `UPDATE organizations SET name=$1, reg_number=$2, since_date=$3,
       address=$4, phone=$5, email=$6, status=$7 WHERE id=$8 RETURNING *`,
      [name, regNumber, sinceDate, address, phone, email, status, req.params.id]
    );
    res.json(rows[0]);
  } catch(e){ next(e); }
});
orgRouter.delete('/:id', authenticate, authorize('super_admin'), async (req, res, next) => {
  try {
    await db.query("UPDATE organizations SET status='inactive' WHERE id=$1", [req.params.id]);
    res.json({ message: 'Organization deactivated' });
  } catch(e){ next(e); }
});
module.exports = orgRouter;
