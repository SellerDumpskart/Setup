// routes/auth.js
const router = require('express').Router();
const { login, refresh, logout, me, changePassword } = require('../controllers/authController');
const { authenticate } = require('../middleware/auth');

router.post('/login', login);
router.post('/refresh', refresh);
router.post('/logout', authenticate, logout);
router.get('/me', authenticate, me);
router.post('/change-password', authenticate, changePassword);

module.exports = router;

// Forgot password — send reset email
router.post('/forgot-password', async (req, res, next) => {
  try {
    const { email } = req.body;
    if (!email) return res.status(400).json({ error: 'Email required' });

    const db = require('../config/database');
    const { rows } = await db.query('SELECT id, first_name FROM users WHERE LOWER(email)=LOWER($1) AND is_active=TRUE', [email]);
    if (!rows.length) {
      // Don't reveal if email exists
      return res.json({ message: 'If that email is registered, you will receive a reset link shortly.' });
    }

    const crypto = require('crypto');
    const token  = crypto.randomBytes(32).toString('hex');
    const expiry = new Date(Date.now() + 3600000); // 1 hour

    await db.query('UPDATE users SET reset_token=$1, reset_token_exp=$2 WHERE id=$3', [token, expiry, rows[0].id]);

    const { sendEmail } = require('../services/notificationService');
    await sendEmail({
      to: email,
      subject: 'VidyaMate — Password Reset',
      html: `<p>Hi ${rows[0].first_name},</p><p>Click the link below to reset your password (expires in 1 hour):</p><p><a href="${process.env.FRONTEND_URL}/reset-password?token=${token}">Reset Password</a></p>`,
      text: `Reset link: ${process.env.FRONTEND_URL}/reset-password?token=${token}`,
    });

    res.json({ message: 'If that email is registered, you will receive a reset link shortly.' });
  } catch (e) { next(e); }
});

// Reset password with token
router.post('/reset-password', async (req, res, next) => {
  try {
    const { token, newPassword } = req.body;
    if (!token || !newPassword) return res.status(400).json({ error: 'Token and new password required' });
    if (newPassword.length < 8) return res.status(400).json({ error: 'Password must be at least 8 characters' });

    const db   = require('../config/database');
    const bcrypt = require('bcryptjs');
    const { rows } = await db.query(
      'SELECT id FROM users WHERE reset_token=$1 AND reset_token_exp > NOW() AND is_active=TRUE', [token]
    );
    if (!rows.length) return res.status(400).json({ error: 'Invalid or expired reset token' });

    const hash = await bcrypt.hash(newPassword, 12);
    await db.query('UPDATE users SET password_hash=$1, reset_token=NULL, reset_token_exp=NULL WHERE id=$2', [hash, rows[0].id]);

    res.json({ message: 'Password reset successfully. You can now login.' });
  } catch (e) { next(e); }
});
