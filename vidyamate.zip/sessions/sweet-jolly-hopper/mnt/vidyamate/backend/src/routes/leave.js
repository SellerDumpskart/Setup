const router = require('express').Router();
const { uuidParam } = require('../middleware/validation');
const { authenticate } = require('../middleware/auth');
const db = require('../config/database');

router.get('/', authenticate, async (req, res, next) => {
  try {
    const { schoolId, status, applicantType } = req.query;
    const sid = schoolId || req.user.school_id;
    let where = ['school_id=$1']; const params = [sid];
    if (status)        { where.push(`status=$${params.length+1}`);         params.push(status); }
    if (applicantType) { where.push(`applicant_type=$${params.length+1}`); params.push(applicantType); }
    const { rows } = await db.query(
      `SELECT la.*,
              CASE WHEN la.staff_id IS NOT NULL
                   THEN (SELECT first_name||' '||COALESCE(last_name,'') FROM staff WHERE id=la.staff_id)
                   ELSE (SELECT first_name||' '||COALESCE(last_name,'') FROM students WHERE id=la.student_id) END as applicant_name
       FROM leave_applications la WHERE ${where.join(' AND ')} ORDER BY la.created_at DESC`, params
    );
    res.json(rows);
  } catch(e){ next(e); }
});

router.post('/', authenticate, async (req, res, next) => {
  try {
    const { schoolId, applicantType, staffId, studentId, leaveTypeId, fromDate, toDate, reason } = req.body;
    const sid = schoolId || req.user.school_id;
    const days = Math.ceil((new Date(toDate||fromDate) - new Date(fromDate)) / 86400000) + 1;
    const { rows } = await db.query(
      `INSERT INTO leave_applications (school_id, applicant_type, staff_id, student_id, leave_type_id, from_date, to_date, total_days, reason)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,
      [sid, applicantType, staffId, studentId, leaveTypeId, fromDate, toDate||fromDate, days, reason]
    );
    res.status(201).json(rows[0]);
  } catch(e){ next(e); }
});

router.put('/:id/approve', authenticate, async (req, res, next) => {
  try {
    const { rows } = await db.query(
      `UPDATE leave_applications SET status='approved', approved_by=$1 WHERE id=$2 RETURNING *`,
      [req.user.id, req.params.id]
    );
    res.json(rows[0]);
  } catch(e){ next(e); }
});

router.put('/:id/reject', authenticate, async (req, res, next) => {
  try {
    const { remarks } = req.body;
    const { rows } = await db.query(
      `UPDATE leave_applications SET status='rejected', remarks=$1, approved_by=$2 WHERE id=$3 RETURNING *`,
      [remarks, req.user.id, req.params.id]
    );
    res.json(rows[0]);
  } catch(e){ next(e); }
});

module.exports = router;
