const router = require('express').Router();
const { authenticate } = require('../middleware/auth');
const { markAttendanceRules } = require('../middleware/validation');
const { getAttendance, markAttendance, getAttendanceReport, getSummary } = require('../controllers/attendanceController');

router.get('/',        authenticate, getAttendance);
router.post('/mark',   authenticate, markAttendanceRules, markAttendance);
router.get('/report',  authenticate, getAttendanceReport);
router.get('/summary', authenticate, getSummary);

// ── Staff Attendance ────────────────────────────────────────

// GET /attendance/staff?date=YYYY-MM-DD
router.get('/staff', authenticate, async (req, res, next) => {
  try {
    const { date = new Date().toISOString().split('T')[0] } = req.query;
    const schoolId = req.query.schoolId || req.user.school_id;
    const db = require('../config/database');

    const { rows } = await db.query(
      `SELECT s.id, s.staff_code, s.first_name, s.last_name, s.designation, s.staff_type, s.photo_url,
              COALESCE(sa.status, 'present') AS attendance_status,
              sa.remarks, sa.check_in_time, sa.check_out_time
       FROM staff s
       LEFT JOIN staff_attendance sa
         ON sa.staff_id = s.id AND sa.attendance_date = $1
       WHERE s.school_id = $2 AND s.status = 'active'
       ORDER BY s.staff_type, s.first_name`,
      [date, schoolId]
    );

    const present = rows.filter(r => r.attendance_status === 'present').length;
    const absent  = rows.filter(r => r.attendance_status === 'absent').length;
    const leave   = rows.filter(r => r.attendance_status === 'leave').length;

    res.json({
      date,
      staff: rows,
      stats: { total: rows.length, present, absent, leave }
    });
  } catch (e) { next(e); }
});

// POST /attendance/staff/mark
router.post('/staff/mark', authenticate, async (req, res, next) => {
  try {
    const { records, date = new Date().toISOString().split('T')[0] } = req.body;
    if (!records?.length) return res.status(400).json({ error: 'No records provided' });

    const db = require('../config/database');
    const { withTransaction } = require('../config/database');
    const markedBy = req.user.id;

    await withTransaction(async (client) => {
      for (const rec of records) {
        await client.query(
          `INSERT INTO staff_attendance
             (staff_id, attendance_date, status, remarks, marked_by)
           VALUES ($1, $2, $3, $4, $5)
           ON CONFLICT (staff_id, attendance_date)
           DO UPDATE SET status = EXCLUDED.status, remarks = EXCLUDED.remarks, marked_by = EXCLUDED.marked_by`,
          [rec.staffId, date, rec.status || 'present', rec.remarks || null, markedBy]
        );
      }
    });

    res.json({ message: `Staff attendance marked for ${records.length} members`, date });
  } catch (e) { next(e); }
});

// ── Biometric Device Webhook ────────────────────────────────
// POST /attendance/device  — no JWT; authenticated by X-Device-Key header

router.post('/device', async (req, res, next) => {
  try {
    const db = require('../config/database');
    const { withTransaction } = require('../config/database');

    // Authenticate via X-Device-Key header against per-device secret (or env fallback)
    const deviceKey = req.headers['x-device-key'];
    if (!deviceKey) return res.status(401).json({ error: 'Missing X-Device-Key header' });

    const { device_id, punches } = req.body;
    if (!device_id || !Array.isArray(punches) || punches.length === 0) {
      return res.status(400).json({ error: 'device_id and punches[] are required' });
    }

    // Look up device record and verify secret
    const { rows: devRows } = await db.query(
      `SELECT * FROM biometric_devices WHERE device_id = $1 AND is_active = TRUE LIMIT 1`,
      [device_id]
    );

    let schoolId;
    if (devRows.length > 0) {
      const dev = devRows[0];
      // Check per-device secret first, then global env fallback
      if (deviceKey !== dev.secret_key && deviceKey !== process.env.DEVICE_SECRET_KEY) {
        return res.status(403).json({ error: 'Invalid device key' });
      }
      schoolId = dev.school_id;
      // Update last_ping
      await db.query(`UPDATE biometric_devices SET last_ping = NOW() WHERE id = $1`, [dev.id]);
    } else {
      // Allow global key for unregistered devices (for initial setup)
      if (!process.env.DEVICE_SECRET_KEY || deviceKey !== process.env.DEVICE_SECRET_KEY) {
        return res.status(403).json({ error: 'Device not registered and global key invalid' });
      }
      schoolId = req.body.school_id;
      if (!schoolId) return res.status(400).json({ error: 'school_id required for unregistered device' });
    }

    let matched = 0, unmatched = 0;

    for (const punch of punches) {
      const { user_id, punch_time, punch_type } = punch;
      if (!user_id || !punch_time) continue;

      const punchTs = new Date(punch_time);
      const dateStr = punchTs.toISOString().split('T')[0];
      const timeStr = punchTs.toTimeString().slice(0, 8);

      // 1. Check manual mapping table first
      const { rows: mapRows } = await db.query(
        `SELECT entity_type, entity_id FROM biometric_user_map
         WHERE school_id = $1 AND biometric_user_id = $2
           AND (device_id = $3 OR device_id IS NULL)
         ORDER BY device_id NULLS LAST LIMIT 1`,
        [schoolId, String(user_id), device_id]
      );

      // 2. Auto-match against student_code or emp_no
      let entityType = null, entityId = null;
      if (mapRows.length > 0) {
        entityType = mapRows[0].entity_type;
        entityId   = mapRows[0].entity_id;
      } else {
        const { rows: stuRows } = await db.query(
          `SELECT id FROM students WHERE school_id = $1 AND student_code = $2 LIMIT 1`,
          [schoolId, String(user_id)]
        );
        if (stuRows.length > 0) {
          entityType = 'student';
          entityId   = stuRows[0].id;
        } else {
          const { rows: staffRows } = await db.query(
            `SELECT id FROM staff WHERE school_id = $1 AND emp_no = $2 LIMIT 1`,
            [schoolId, String(user_id)]
          );
          if (staffRows.length > 0) {
            entityType = 'staff';
            entityId   = staffRows[0].id;
          }
        }
      }

      if (!entityType) {
        // Log unmatched
        await db.query(
          `INSERT INTO biometric_unmatched_log
             (school_id, device_id, user_id, punch_time, punch_type, raw_payload)
           VALUES ($1, $2, $3, $4, $5, $6)`,
          [schoolId, device_id, String(user_id), punchTs, punch_type, JSON.stringify(punch)]
        );
        unmatched++;
        continue;
      }

      // 3. Upsert attendance
      if (entityType === 'student') {
        if (punch_type === 0) {
          // Check-in → mark present
          await db.query(
            `INSERT INTO student_attendance
               (student_id, school_id, attendance_date, status, source)
             VALUES ($1, $2, $3, 'present', 'biometric')
             ON CONFLICT (student_id, attendance_date)
             DO UPDATE SET status = 'present', source = 'biometric'`,
            [entityId, schoolId, dateStr]
          ).catch(() => {
            // Fallback if constraint name differs
            return db.query(
              `INSERT INTO student_attendance
                 (student_id, school_id, attendance_date, status, source)
               VALUES ($1, $2, $3, 'present', 'biometric')
               ON CONFLICT DO NOTHING`,
              [entityId, schoolId, dateStr]
            );
          });
        }
      } else {
        // Staff
        const checkInCol  = punch_type === 0 ? `, check_in_time = '${timeStr}'` : '';
        const checkOutCol = punch_type === 1 ? `, check_out_time = '${timeStr}'` : '';
        await db.query(
          `INSERT INTO staff_attendance
             (staff_id, attendance_date, status, check_in_time, check_out_time, source)
           VALUES ($1, $2, 'present', $3, $4, 'biometric')
           ON CONFLICT (staff_id, attendance_date)
           DO UPDATE SET status = 'present',
             check_in_time  = CASE WHEN $5 = 0 THEN $3 ELSE staff_attendance.check_in_time END,
             check_out_time = CASE WHEN $5 = 1 THEN $4 ELSE staff_attendance.check_out_time END,
             source = 'biometric'`,
          [entityId, dateStr,
           punch_type === 0 ? timeStr : null,
           punch_type === 1 ? timeStr : null,
           punch_type]
        );
      }
      matched++;
    }

    res.json({ ok: true, matched, unmatched, total: punches.length });
  } catch (e) { next(e); }
});

// ── Biometric Device CRUD ────────────────────────────────────
// GET /attendance/devices
router.get('/devices', authenticate, async (req, res, next) => {
  try {
    const db = require('../config/database');
    const schoolId = req.query.schoolId || req.user.school_id;
    // Online = last_ping within 5 minutes
    const { rows } = await db.query(
      `SELECT id, device_name, device_id, location, is_active, last_ping,
              (last_ping > NOW() - INTERVAL '5 minutes') AS is_online,
              created_at
       FROM biometric_devices
       WHERE school_id = $1
       ORDER BY created_at DESC`,
      [schoolId]
    );
    res.json(rows);
  } catch (e) { next(e); }
});

// POST /attendance/devices — register a new device
router.post('/devices', authenticate, async (req, res, next) => {
  try {
    const db = require('../config/database');
    const { v4: uuidv4 } = require('uuid');
    const crypto = require('crypto');

    const schoolId = req.body.schoolId || req.user.school_id;
    const { device_name, device_id, location } = req.body;
    if (!device_name || !device_id) {
      return res.status(400).json({ error: 'device_name and device_id are required' });
    }

    // Auto-generate a strong secret key
    const secret_key = crypto.randomBytes(32).toString('hex');

    const { rows } = await db.query(
      `INSERT INTO biometric_devices (id, school_id, device_name, device_id, location, secret_key)
       VALUES ($1, $2, $3, $4, $5, $6)
       ON CONFLICT (school_id, device_id)
       DO UPDATE SET device_name = EXCLUDED.device_name,
                     location    = EXCLUDED.location
       RETURNING *`,
      [uuidv4(), schoolId, device_name, device_id, location || null, secret_key]
    );
    // Return secret_key only on creation (caller must save it)
    res.status(201).json({ ...rows[0], secret_key });
  } catch (e) { next(e); }
});

// PUT /attendance/devices/:id — update device
router.put('/devices/:id', authenticate, async (req, res, next) => {
  try {
    const db = require('../config/database');
    const { device_name, location, is_active } = req.body;
    const { rows } = await db.query(
      `UPDATE biometric_devices
       SET device_name = COALESCE($1, device_name),
           location    = COALESCE($2, location),
           is_active   = COALESCE($3, is_active)
       WHERE id = $4
       RETURNING id, device_name, device_id, location, is_active, last_ping`,
      [device_name || null, location || null, is_active ?? null, req.params.id]
    );
    if (!rows.length) return res.status(404).json({ error: 'Device not found' });
    res.json(rows[0]);
  } catch (e) { next(e); }
});

// DELETE /attendance/devices/:id
router.delete('/devices/:id', authenticate, async (req, res, next) => {
  try {
    const db = require('../config/database');
    await db.query(`DELETE FROM biometric_devices WHERE id = $1`, [req.params.id]);
    res.json({ message: 'Device deleted' });
  } catch (e) { next(e); }
});

// GET /attendance/unmatched — list unmatched punch logs
router.get('/unmatched', authenticate, async (req, res, next) => {
  try {
    const db = require('../config/database');
    const schoolId = req.query.schoolId || req.user.school_id;
    const { rows } = await db.query(
      `SELECT * FROM biometric_unmatched_log
       WHERE school_id = $1 AND resolved = FALSE
       ORDER BY punch_time DESC LIMIT 200`,
      [schoolId]
    );
    res.json(rows);
  } catch (e) { next(e); }
});

// POST /attendance/unmatched/:id/map — map unmatched punch to student/staff
router.post('/unmatched/:id/map', authenticate, async (req, res, next) => {
  try {
    const db = require('../config/database');
    const { v4: uuidv4 } = require('uuid');
    const { entity_type, entity_id } = req.body;
    if (!['student','staff'].includes(entity_type) || !entity_id) {
      return res.status(400).json({ error: 'entity_type (student|staff) and entity_id required' });
    }
    // Get log entry
    const { rows: logRows } = await db.query(
      `SELECT * FROM biometric_unmatched_log WHERE id = $1`, [req.params.id]
    );
    if (!logRows.length) return res.status(404).json({ error: 'Log entry not found' });
    const log = logRows[0];

    // Save mapping
    await db.query(
      `INSERT INTO biometric_user_map
         (id, school_id, device_id, biometric_user_id, entity_type, entity_id)
       VALUES ($1, $2, $3, $4, $5, $6)
       ON CONFLICT (school_id, biometric_user_id)
       DO UPDATE SET entity_type = EXCLUDED.entity_type, entity_id = EXCLUDED.entity_id`,
      [uuidv4(), log.school_id, log.device_id, log.user_id, entity_type, entity_id]
    );
    // Mark log entry resolved
    await db.query(
      `UPDATE biometric_unmatched_log SET resolved = TRUE WHERE id = $1`, [req.params.id]
    );

    res.json({ message: 'Mapping saved and log resolved' });
  } catch (e) { next(e); }
});

module.exports = router;
