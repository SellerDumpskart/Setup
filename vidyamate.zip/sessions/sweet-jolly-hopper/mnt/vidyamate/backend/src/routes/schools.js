const router = require('express').Router();
const { uuidParam } = require('../middleware/validation');
const { authenticate, authorize } = require('../middleware/auth');
const db = require('../config/database');

router.get('/', authenticate, async (req, res, next) => {
  try {
    const { orgId, status } = req.query;
    let where = ['1=1']; const params = [];
    if (orgId)  { where.push(`organization_id = $${params.length+1}`); params.push(orgId); }
    if (status) { where.push(`status = $${params.length+1}`);          params.push(status); }
    const { rows } = await db.query(`SELECT * FROM schools WHERE ${where.join(' AND ')} ORDER BY name`, params);
    res.json(rows);
  } catch(e){ next(e); }
});

router.post('/', authenticate, authorize('super_admin','org_admin'), async (req, res, next) => {
  try {
    const { organizationId, name, contactNumber, email, address, city, state, pincode, medium } = req.body;
    const { rows } = await db.query(
      `INSERT INTO schools (organization_id, name, contact_number, email, address, city, state, pincode, medium)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,
      [organizationId, name, contactNumber, email, address, city, state, pincode, medium]
    );
    res.status(201).json(rows[0]);
  } catch(e){ next(e); }
});

router.put('/:id', uuidParam, authenticate, authorize('super_admin','org_admin'), async (req, res, next) => {
  try {
    const { name, contactNumber, email, city, state, status } = req.body;
    const { rows } = await db.query(
      `UPDATE schools SET name=$1, contact_number=$2, email=$3, city=$4, state=$5, status=$6 WHERE id=$7 RETURNING *`,
      [name, contactNumber, email, city, state, status, req.params.id]
    );
    res.json(rows[0]);
  } catch(e){ next(e); }
});

module.exports = router;
