const router = require('express').Router();
const { uuidParam } = require('../middleware/validation');
const { authenticate, authorize } = require('../middleware/auth');
const db = require('../config/database');

router.get('/', authenticate, async (req, res, next) => {
  try {
    const { orgId } = req.query;
    const { rows } = await db.query(
      `SELECT * FROM academic_sessions ${orgId ? 'WHERE organization_id = $1' : ''} ORDER BY start_date DESC`,
      orgId ? [orgId] : []
    );
    res.json(rows);
  } catch(e){ next(e); }
});

router.post('/', authenticate, authorize('super_admin','org_admin'), async (req, res, next) => {
  try {
    const { organizationId, sessionName, startDate, endDate, isCurrent } = req.body;
    if (isCurrent) {
      await db.query(`UPDATE academic_sessions SET is_current=FALSE WHERE organization_id=$1`, [organizationId]);
    }
    const { rows } = await db.query(
      `INSERT INTO academic_sessions (organization_id, session_name, start_date, end_date, is_current)
       VALUES ($1,$2,$3,$4,$5) RETURNING *`,
      [organizationId, sessionName, startDate, endDate, isCurrent || false]
    );
    res.status(201).json(rows[0]);
  } catch(e){ next(e); }
});

router.put('/:id/set-current', authenticate, authorize('super_admin','org_admin'), async (req, res, next) => {
  try {
    const { rows } = await db.query('SELECT organization_id FROM academic_sessions WHERE id=$1', [req.params.id]);
    if (!rows.length) return res.status(404).json({ error: 'Session not found' });
    await db.query(`UPDATE academic_sessions SET is_current=FALSE WHERE organization_id=$1`, [rows[0].organization_id]);
    await db.query(`UPDATE academic_sessions SET is_current=TRUE  WHERE id=$1`, [req.params.id]);
    res.json({ message: 'Session set as current' });
  } catch(e){ next(e); }
});

module.exports = router;
