const router = require('express').Router();
const { uuidParam } = require('../middleware/validation');
const { authenticate, authorize } = require('../middleware/auth');
const db = require('../config/database');
const { v4: uuid } = require('uuid');

router.get('/', authenticate, async (req, res, next) => {
  try {
    const { schoolId, sessionId } = req.query;
    const sid = schoolId || req.user.school_id;
    const { rows } = await db.query(
      `SELECT c.*, COUNT(s.id) as student_count,
              st.first_name || ' ' || COALESCE(st.last_name,'') as class_teacher_name
       FROM classes c
       LEFT JOIN students s ON s.class_id = c.id AND s.status = 'active'
       LEFT JOIN staff st ON c.class_teacher_id = st.id
       WHERE c.school_id = $1 AND c.session_id = $2
       GROUP BY c.id, st.first_name, st.last_name
       ORDER BY c.class_name, c.section`,
      [sid, sessionId]
    );
    res.json(rows);
  } catch(e){ next(e); }
});

router.post('/', authenticate, authorize('super_admin','org_admin','principal'), async (req, res, next) => {
  try {
    const { schoolId, sessionId, className, section, capacity, classTeacherId, roomNumber } = req.body;
    const sid = schoolId || req.user.school_id;
    const { rows } = await db.query(
      `INSERT INTO classes (school_id, session_id, class_name, section, capacity, class_teacher_id, room_number)
       VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
      [sid, sessionId, className, section || 'A', capacity || 50, classTeacherId, roomNumber]
    );
    res.status(201).json(rows[0]);
  } catch(e){ next(e); }
});

router.get('/:id/subjects', authenticate, async (req, res, next) => {
  try {
    const { rows } = await db.query(
      `SELECT cs.*, s.subject_name, s.subject_code,
              st.first_name || ' ' || COALESCE(st.last_name,'') as teacher_name
       FROM class_subjects cs
       JOIN subjects s ON cs.subject_id = s.id
       LEFT JOIN staff st ON cs.teacher_id = st.id
       WHERE cs.class_id = $1`, [req.params.id]
    );
    res.json(rows);
  } catch(e){ next(e); }
});

router.post('/:id/subjects', authenticate, authorize('super_admin','org_admin','principal'), async (req, res, next) => {
  try {
    const { subjectId, teacherId, isCompulsory = true, maxMarks = 100, passMarks = 35 } = req.body;
    const { rows } = await db.query(
      `INSERT INTO class_subjects (class_id, subject_id, teacher_id, is_compulsory, max_marks, pass_marks)
       VALUES ($1,$2,$3,$4,$5,$6)
       ON CONFLICT (class_id, subject_id) DO UPDATE
       SET teacher_id=$3, is_compulsory=$4, max_marks=$5, pass_marks=$6
       RETURNING *`,
      [req.params.id, subjectId, teacherId, isCompulsory, maxMarks, passMarks]
    );
    res.json(rows[0]);
  } catch(e){ next(e); }
});

module.exports = router;
