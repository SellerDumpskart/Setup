const router = require('express').Router();
const { authenticate } = require('../middleware/auth');
const { query } = require('../config/database');

// GET /api/v1/dashboard?schoolId=xxx&sessionId=xxx
router.get('/', authenticate, async (req, res, next) => {
  try {
    const { schoolId, sessionId } = req.query;
    const sid = schoolId || req.user.school_id;

    const [students, teachers, staff, feeStats, attendance, holidays, notices, birthdays] =
      await Promise.all([
        // Total students
        query('SELECT COUNT(*) FROM students WHERE school_id=$1 AND session_id=$2 AND status=$3',
              [sid, sessionId, 'active']),

        // Total teachers
        query(`SELECT COUNT(*) FROM staff WHERE school_id=$1 AND status='active'
               AND staff_type='teaching'`, [sid]),

        // Total staff
        query("SELECT COUNT(*) FROM staff WHERE school_id=$1 AND status='active'", [sid]),

        // Fee summary per head
        query(`SELECT fh.fee_name, fh.fee_type,
                      COALESCE(SUM(sf.total_amount - sf.concession), 0) AS total,
                      COALESCE(SUM(sf.paid_amount), 0) AS paid,
                      COALESCE(SUM(sf.balance), 0) AS balance
               FROM fee_heads fh
               LEFT JOIN student_fees sf ON sf.fee_head_id = fh.id AND sf.session_id = $2
               WHERE fh.school_id = $1 AND fh.session_id = $2
               GROUP BY fh.id, fh.fee_name, fh.fee_type
               ORDER BY fh.fee_name`, [sid, sessionId]),

        // Today's attendance
        query(`SELECT
                 COUNT(*) FILTER (WHERE status='present') AS present,
                 COUNT(*) FILTER (WHERE status='absent')  AS absent,
                 COUNT(*) AS total
               FROM student_attendance
               WHERE class_id IN (SELECT id FROM classes WHERE school_id=$1 AND session_id=$2)
               AND attendance_date = CURRENT_DATE`, [sid, sessionId]),

        // Upcoming holidays (next 30 days)
        query(`SELECT holiday_name, from_date, to_date, holiday_type
               FROM holidays
               WHERE school_id=$1 AND from_date >= CURRENT_DATE
               AND from_date <= CURRENT_DATE + INTERVAL '30 days'
               ORDER BY from_date LIMIT 5`, [sid]),

        // Latest notices
        query(`SELECT id, title, notice_type, published_at
               FROM notices
               WHERE school_id=$1 AND is_published=TRUE
               AND (expires_at IS NULL OR expires_at > NOW())
               ORDER BY published_at DESC LIMIT 5`, [sid]),

        // Today's birthdays (staff)
        query(`SELECT first_name, last_name, designation, photo_url
               FROM staff
               WHERE school_id=$1 AND status='active'
               AND EXTRACT(MONTH FROM date_of_birth) = EXTRACT(MONTH FROM CURRENT_DATE)
               AND EXTRACT(DAY FROM date_of_birth) = EXTRACT(DAY FROM CURRENT_DATE)`, [sid]),
      ]);

    res.json({
      stats: {
        totalStudents: parseInt(students.rows[0].count),
        totalTeachers: parseInt(teachers.rows[0].count),
        totalStaff:    parseInt(staff.rows[0].count),
      },
      feeSummary:  feeStats.rows,
      attendance:  attendance.rows[0],
      holidays:    holidays.rows,
      notices:     notices.rows,
      birthdays:   birthdays.rows,
    });
  } catch (err) { next(err); }
});

module.exports = router;
