const router = require('express').Router();
const { uuidParam } = require('../middleware/validation');
const { authenticate, authorize } = require('../middleware/auth');
const db = require('../config/database');

router.get('/', authenticate, async (req, res, next) => {
  try {
    const { schoolId, month, year, sessionId } = req.query;
    const sid = schoolId || req.user.school_id;
    const { rows } = await db.query(
      `SELECT p.*, st.emp_no, st.first_name, st.last_name, st.designation, st.staff_type
       FROM payroll p JOIN staff st ON p.staff_id = st.id
       WHERE p.school_id=$1 AND p.month=$2 AND p.year=$3
       ORDER BY st.first_name`, [sid, month, year]
    );
    res.json(rows);
  } catch(e){ next(e); }
});

router.post('/process', authenticate, authorize('super_admin','org_admin','principal','accountant'), async (req, res, next) => {
  try {
    const { schoolId, sessionId, month, year } = req.body;
    const sid = schoolId || req.user.school_id;
    const { rows: staffList } = await db.query(
      `SELECT id, salary FROM staff WHERE school_id=$1 AND status='active'`, [sid]
    );
    let processed = 0;
    for (const s of staffList) {
      const gross = parseFloat(s.salary) || 0;
      const ded   = gross * 0.13; // 13% approx (PF+PT+TDS)
      await db.query(
        `INSERT INTO payroll (staff_id, school_id, session_id, month, year, gross_salary, deductions, days_worked, status)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,'processed')
         ON CONFLICT (staff_id, month, year) DO UPDATE SET gross_salary=$6, deductions=$7, status='processed'`,
        [s.id, sid, sessionId, month, year, gross, ded, 26]
      );
      processed++;
    }
    res.json({ message: `Payroll processed for ${processed} staff`, month, year });
  } catch(e){ next(e); }
});

router.put('/:id/mark-paid', authenticate, authorize('super_admin','org_admin','principal','accountant'), async (req, res, next) => {
  try {
    const { paymentMode = 'bank_transfer' } = req.body;
    const { rows } = await db.query(
      `UPDATE payroll SET status='paid', payment_date=CURRENT_DATE, payment_mode=$1 WHERE id=$2 RETURNING *`,
      [paymentMode, req.params.id]
    );
    res.json(rows[0]);
  } catch(e){ next(e); }
});

// ── SALARY HEADS ──────────────────────────────────────────────────────────────

// GET /payroll/salary-heads
router.get('/salary-heads', authenticate, async (req, res, next) => {
  try {
    const sid = req.query.schoolId || req.user.school_id;
    const { rows } = await db.query(
      `SELECT * FROM salary_heads WHERE school_id=$1 ORDER BY head_type, head_name`,
      [sid]
    );
    res.json(rows);
  } catch(e){ next(e); }
});

// POST /payroll/salary-heads
router.post('/salary-heads', authenticate, authorize('super_admin','org_admin','principal'), async (req, res, next) => {
  try {
    const { headName, headType = 'earning', isFixed = true } = req.body;
    const sid = req.body.schoolId || req.user.school_id;
    if (!headName) return res.status(400).json({ error: 'headName is required' });
    const { rows } = await db.query(
      `INSERT INTO salary_heads (school_id, head_name, head_type, is_fixed)
       VALUES ($1,$2,$3,$4)
       ON CONFLICT (school_id, head_name) DO UPDATE SET head_type=$3, is_fixed=$4
       RETURNING *`,
      [sid, headName, headType, isFixed]
    );
    res.status(201).json(rows[0]);
  } catch(e){ next(e); }
});

// DELETE /payroll/salary-heads/:id
router.delete('/salary-heads/:id', authenticate, authorize('super_admin','org_admin','principal'), async (req, res, next) => {
  try {
    await db.query(`DELETE FROM salary_heads WHERE id=$1`, [req.params.id]);
    res.json({ message: 'Salary head deleted' });
  } catch(e){ next(e); }
});

// GET /payroll/staff/:staffId/salary — all salary components for a staff member
router.get('/staff/:staffId/salary', authenticate, async (req, res, next) => {
  try {
    const { rows } = await db.query(
      `SELECT ss.*, sh.head_name, sh.head_type, sh.is_fixed
       FROM staff_salary ss
       JOIN salary_heads sh ON sh.id = ss.head_id
       WHERE ss.staff_id = $1
       ORDER BY sh.head_type DESC, sh.head_name`,
      [req.params.staffId]
    );
    res.json(rows);
  } catch(e){ next(e); }
});

// POST /payroll/staff/:staffId/salary — upsert a salary component
router.post('/staff/:staffId/salary', authenticate, authorize('super_admin','org_admin','principal','accountant'), async (req, res, next) => {
  try {
    const { headId, amount, effectiveFrom = new Date().toISOString().split('T')[0] } = req.body;
    if (!headId || amount === undefined) return res.status(400).json({ error: 'headId and amount required' });
    const { rows } = await db.query(
      `INSERT INTO staff_salary (staff_id, head_id, amount, effective_from)
       VALUES ($1,$2,$3,$4)
       ON CONFLICT (staff_id, head_id, effective_from) DO UPDATE SET amount=$3
       RETURNING *`,
      [req.params.staffId, headId, amount, effectiveFrom]
    );
    res.status(201).json(rows[0]);
  } catch(e){ next(e); }
});

module.exports = router;
