const router = require('express').Router();
const { uuidParam } = require('../middleware/validation');
const { authenticate, authorize } = require('../middleware/auth');
const { getExams, createExam, updateExam, getSchedule, setSchedule, getResults, enterMarks, generateHallTickets, getHallTickets } = require('../controllers/examsController');

router.get('/',                    authenticate, getExams);
router.post('/',                   authenticate, authorize('super_admin','org_admin','principal'), createExam);
router.put('/:id', uuidParam,                 authenticate, authorize('super_admin','org_admin','principal'), updateExam);
router.get('/:id/schedule',        authenticate, getSchedule);
router.post('/:id/schedule',       authenticate, authorize('super_admin','org_admin','principal'), setSchedule);
router.get('/results',             authenticate, getResults);
router.post('/results/enter',      authenticate, enterMarks);
router.post('/hall-tickets/generate', authenticate, authorize('super_admin','org_admin','principal'), generateHallTickets);
router.get('/hall-tickets',        authenticate, getHallTickets);

module.exports = router;
