const router = require('express').Router();
const { authenticate } = require('../middleware/auth');
const { getOverview, getAttendanceTrend, getFeeCollection, getClassStrength, getTopPerformers, getExpenditureReport } = require('../controllers/reportsController');

router.get('/overview',            authenticate, getOverview);
router.get('/attendance-trend',    authenticate, getAttendanceTrend);
router.get('/fee-collection',      authenticate, getFeeCollection);
router.get('/class-strength',      authenticate, getClassStrength);
router.get('/top-performers',      authenticate, getTopPerformers);
router.get('/expenditure',         authenticate, getExpenditureReport);

module.exports = router;
