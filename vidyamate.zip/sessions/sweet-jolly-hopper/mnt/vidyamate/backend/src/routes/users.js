const router = require('express').Router();
const { uuidParam } = require('../middleware/validation');
const { authenticate, authorize } = require('../middleware/auth');
const bcrypt = require('bcryptjs');
const db = require('../config/database');
const { v4: uuidv4 } = require('uuid');

router.get('/', authenticate, authorize('super_admin','org_admin','principal'), async (req, res, next) => {
  try {
    const { schoolId, orgId, role } = req.query;
    let where = ['1=1']; const params = [];
    if (schoolId) { where.push(`school_id = $${params.length+1}`); params.push(schoolId); }
    if (orgId)    { where.push(`organization_id = $${params.length+1}`); params.push(orgId); }
    if (role)     { where.push(`role = $${params.length+1}`); params.push(role); }
    const { rows } = await db.query(
      `SELECT id, username, email, role, school_id, organization_id, is_active, last_login, created_at
       FROM users WHERE ${where.join(' AND ')} ORDER BY role, username`,
      params
    );
    res.json(rows);
  } catch(e){ next(e); }
});

router.post('/', authenticate, authorize('super_admin','org_admin','principal'), async (req, res, next) => {
  try {
    const { schoolId, orgId, username, email, password, role, firstName, lastName } = req.body;
    const hash = await bcrypt.hash(password || 'School@123', 12);
    const { rows } = await db.query(
      `INSERT INTO users (id, school_id, organization_id, username, email, password_hash, first_name, last_name, role)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING id, username, email, role, is_active`,
      [uuidv4(), schoolId, orgId, username, email, hash, firstName, lastName, role]
    );
    res.status(201).json(rows[0]);
  } catch(e){ next(e); }
});

router.put('/:id', uuidParam, authenticate, async (req, res, next) => {
  try {
    const { username, email, role, isActive, firstName, lastName } = req.body;
    const { rows } = await db.query(
      `UPDATE users SET username=$1, email=$2, role=$3, is_active=$4, first_name=$5, last_name=$6
       WHERE id=$7 RETURNING id, username, email, role, is_active`,
      [username, email, role, isActive, firstName, lastName, req.params.id]
    );
    res.json(rows[0]);
  } catch(e){ next(e); }
});

router.post('/:id/reset-password', authenticate, authorize('super_admin','org_admin','principal'), async (req, res, next) => {
  try {
    const { newPassword = 'School@123' } = req.body;
    const hash = await bcrypt.hash(newPassword, 12);
    await db.query(`UPDATE users SET password_hash=$1 WHERE id=$2`, [hash, req.params.id]);
    res.json({ message: 'Password reset successfully' });
  } catch(e){ next(e); }
});

module.exports = router;
