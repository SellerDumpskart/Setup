const router = require('express').Router();
const { uuidParam } = require('../middleware/validation');
const { authenticate, authorize } = require('../middleware/auth');
const db = require('../config/database');

router.get('/', authenticate, async (req, res, next) => {
  try {
    const sid = req.query.schoolId || req.user.school_id;
    const { rows } = await db.query(
      `SELECT * FROM subjects WHERE school_id = $1 AND status = 'active' ORDER BY subject_name`, [sid]
    );
    res.json(rows);
  } catch(e){ next(e); }
});

router.post('/', authenticate, authorize('super_admin','org_admin','principal'), async (req, res, next) => {
  try {
    const { schoolId, subjectName, subjectCode, description, isLanguage } = req.body;
    const sid = schoolId || req.user.school_id;
    const { rows } = await db.query(
      `INSERT INTO subjects (school_id, subject_name, subject_code, description, is_language)
       VALUES ($1,$2,$3,$4,$5) RETURNING *`,
      [sid, subjectName, subjectCode, description, isLanguage || false]
    );
    res.status(201).json(rows[0]);
  } catch(e){ next(e); }
});

router.put('/:id', uuidParam, authenticate, authorize('super_admin','org_admin','principal'), async (req, res, next) => {
  try {
    const { subjectName, subjectCode, description, status } = req.body;
    const { rows } = await db.query(
      `UPDATE subjects SET subject_name=$1, subject_code=$2, description=$3, status=$4 WHERE id=$5 RETURNING *`,
      [subjectName, subjectCode, description, status, req.params.id]
    );
    res.json(rows[0]);
  } catch(e){ next(e); }
});

module.exports = router;
