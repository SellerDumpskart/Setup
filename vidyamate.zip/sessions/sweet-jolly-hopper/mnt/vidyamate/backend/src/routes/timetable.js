const router = require('express').Router();
const { uuidParam } = require('../middleware/validation');
const { authenticate, authorize } = require('../middleware/auth');
const {
  getPeriods, upsertPeriod, getTimetable, saveTimetableEntry, deleteTimetableEntry
} = require('../controllers/extendedController');

router.get('/periods',    authenticate, getPeriods);
router.post('/periods',   authenticate, authorize('super_admin','org_admin','principal'), upsertPeriod);
router.get('/',           authenticate, getTimetable);
router.post('/',          authenticate, authorize('super_admin','org_admin','principal'), saveTimetableEntry);
router.delete('/:id', uuidParam,     authenticate, authorize('super_admin','org_admin','principal'), deleteTimetableEntry);
module.exports = router;
