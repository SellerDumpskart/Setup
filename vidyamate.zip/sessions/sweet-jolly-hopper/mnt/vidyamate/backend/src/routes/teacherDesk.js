const router = require('express').Router();
const { authenticate } = require('../middleware/auth');
const {
  getHomework, createHomework, getDiary, writeDiary, enterMarksTeacher
} = require('../controllers/extendedController');

router.get('/homework',    authenticate, getHomework);
router.post('/homework',   authenticate, createHomework);
router.get('/diary',       authenticate, getDiary);
router.post('/diary',      authenticate, writeDiary);
router.post('/marks',      authenticate, enterMarksTeacher);
module.exports = router;
