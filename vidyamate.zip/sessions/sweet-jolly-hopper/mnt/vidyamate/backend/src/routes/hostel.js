const router = require('express').Router();
const { uuidParam } = require('../middleware/validation');
const { authenticate, authorize } = require('../middleware/auth');
const db = require('../config/database');

router.get('/', authenticate, async (req, res, next) => {
  try {
    const sid = req.query.schoolId || req.user.school_id;
    const { rows } = await db.query(
      `SELECT h.*,
              (SELECT COUNT(*) FROM hostel_rooms WHERE hostel_id=h.id) as total_rooms,
              (SELECT COALESCE(SUM(capacity),0) FROM hostel_rooms WHERE hostel_id=h.id) as total_beds,
              (SELECT COUNT(*) FROM hostel_allocations ha
               JOIN hostel_rooms hr ON ha.room_id=hr.id
               WHERE hr.hostel_id=h.id AND ha.status='active') as occupied
       FROM hostels h WHERE school_id=$1 ORDER BY hostel_name`, [sid]
    );
    res.json(rows);
  } catch(e){ next(e); }
});

router.get('/:id/rooms', authenticate, async (req, res, next) => {
  try {
    const { rows } = await db.query(
      `SELECT r.*, COUNT(a.id) as current_occupants
       FROM hostel_rooms r
       LEFT JOIN hostel_allocations a ON a.room_id=r.id AND a.status='active'
       WHERE r.hostel_id=$1 GROUP BY r.id ORDER BY r.floor_no, r.room_number`, [req.params.id]
    );
    res.json(rows);
  } catch(e){ next(e); }
});

router.post('/allocate', authenticate, authorize('super_admin','org_admin','principal'), async (req, res, next) => {
  try {
    const { studentId, roomId, sessionId, mealPlan } = req.body;
    const { rows } = await db.query(
      `INSERT INTO hostel_allocations (student_id, room_id, session_id, meal_plan)
       VALUES ($1,$2,$3,$4) RETURNING *`,
      [studentId, roomId, sessionId, mealPlan || 'full']
    );
    res.status(201).json(rows[0]);
  } catch(e){ next(e); }
});

module.exports = router;
