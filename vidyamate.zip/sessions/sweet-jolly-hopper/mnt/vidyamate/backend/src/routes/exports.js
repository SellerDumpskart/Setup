const router = require('express').Router();
const { authenticate } = require('../middleware/auth');
const { dispatchReport } = require('../jobs/workers');
const { exportStudents, exportFeeCollection, exportAttendance, exportResults, exportStaff } = require('../utils/excelService');
const { htmlToPdf, generateReceiptHtml } = require('../utils/pdfService');
const db = require('../config/database');

// All exports are async — queued or immediate depending on size

// GET /export/students
router.get('/students', authenticate, async (req, res, next) => {
  try {
    const { sessionId } = req.query;
    const schoolId = req.query.schoolId || req.user.school_id;
    const school   = (await db.query('SELECT name FROM schools WHERE id=$1', [schoolId])).rows[0];

    const { rows } = await db.query(
      `SELECT s.*, c.class_name, c.section, p.father_name, p.father_phone
       FROM students s
       LEFT JOIN classes c ON s.class_id = c.id
       LEFT JOIN parents p ON s.parent_id = p.id
       WHERE s.school_id=$1 AND s.status='active'
       ${sessionId ? 'AND s.session_id=$2' : ''}
       ORDER BY c.class_name, s.roll_number`,
      sessionId ? [schoolId, sessionId] : [schoolId]
    );

    const result = await exportStudents(rows, school?.name || 'School');
    res.json({ url: result.url, count: rows.length });
  } catch (e) { next(e); }
});

// GET /export/fee-collection
router.get('/fee-collection', authenticate, async (req, res, next) => {
  try {
    const schoolId = req.query.schoolId || req.user.school_id;
    const school   = (await db.query('SELECT name FROM schools WHERE id=$1', [schoolId])).rows[0];

    const { rows } = await db.query(
      `SELECT fp.*, s.first_name, s.last_name, s.student_code,
              fh.fee_name, c.class_name, c.section
       FROM fee_payments fp
       JOIN students s ON fp.student_id = s.id
       JOIN student_fees sf ON fp.student_fee_id = sf.id
       JOIN fee_heads fh ON sf.fee_head_id = fh.id
       LEFT JOIN classes c ON s.class_id = c.id
       WHERE s.school_id=$1 ORDER BY fp.payment_date DESC`, [schoolId]
    );

    const result = await exportFeeCollection(rows, school?.name);
    res.json({ url: result.url, count: rows.length });
  } catch (e) { next(e); }
});

// GET /export/attendance?classId=&month=&year=
router.get('/attendance', authenticate, async (req, res, next) => {
  try {
    const { classId, month, year } = req.query;
    const schoolId = req.query.schoolId || req.user.school_id;
    const school   = (await db.query('SELECT name FROM schools WHERE id=$1', [schoolId])).rows[0];
    const cls      = (await db.query('SELECT class_name, section FROM classes WHERE id=$1', [classId])).rows[0];

    const { rows } = await db.query(
      `SELECT s.id, s.first_name, s.last_name, s.roll_number,
              COUNT(a.id) FILTER (WHERE a.status='present') as present_days,
              COUNT(a.id) FILTER (WHERE a.status='absent')  as absent_days,
              COUNT(a.id) FILTER (WHERE a.status='leave')   as leave_days,
              COUNT(a.id) as total_marked,
              ROUND(COUNT(a.id) FILTER (WHERE a.status='present') * 100.0 / NULLIF(COUNT(a.id),0), 1) as percentage
       FROM students s
       LEFT JOIN student_attendance a ON a.student_id=s.id
         AND EXTRACT(MONTH FROM a.attendance_date)=$3
         AND EXTRACT(YEAR  FROM a.attendance_date)=$4
       WHERE s.school_id=$1 AND s.class_id=$2 AND s.status='active'
       GROUP BY s.id, s.first_name, s.last_name, s.roll_number
       ORDER BY s.roll_number`,
      [schoolId, classId, month, year]
    );

    const className = cls ? `${cls.class_name}-${cls.section}` : classId;
    const result = await exportAttendance(rows, className, month, year, school?.name);
    res.json({ url: result.url, count: rows.length });
  } catch (e) { next(e); }
});

// GET /export/staff
router.get('/staff', authenticate, async (req, res, next) => {
  try {
    const schoolId = req.query.schoolId || req.user.school_id;
    const school   = (await db.query('SELECT name FROM schools WHERE id=$1', [schoolId])).rows[0];
    const { rows } = await db.query(
      `SELECT * FROM staff WHERE school_id=$1 AND status='active' ORDER BY first_name`, [schoolId]
    );
    const result = await exportStaff(rows, school?.name);
    res.json({ url: result.url, count: rows.length });
  } catch (e) { next(e); }
});

// GET /export/receipt/:paymentId — PDF receipt
router.get('/receipt/:paymentId', authenticate, async (req, res, next) => {
  try {
    const schoolId = req.user.school_id;
    const { rows: pay } = await db.query(
      `SELECT fp.*, fh.fee_name FROM fee_payments fp
       JOIN student_fees sf ON fp.student_fee_id=sf.id
       JOIN fee_heads fh ON sf.fee_head_id=fh.id
       WHERE fp.id=$1`, [req.params.paymentId]
    );
    if (!pay.length) return res.status(404).json({ error: 'Payment not found' });

    const { rows: stu } = await db.query(
      `SELECT s.*, c.class_name, c.section FROM students s
       LEFT JOIN classes c ON s.class_id=c.id
       WHERE s.id=$1`, [pay[0].student_id]
    );
    const { rows: sch } = await db.query('SELECT name FROM schools WHERE id=$1', [schoolId]);

    const html     = generateReceiptHtml(pay[0], stu[0], sch[0]);
    const filename = `receipt_${pay[0].receipt_no}.pdf`;
    const url      = await htmlToPdf(html, filename);
    res.json({ url, receiptNo: pay[0].receipt_no });
  } catch (e) { next(e); }
});

module.exports = router;
