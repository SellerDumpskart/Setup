const router = require('express').Router();
const { uuidParam } = require('../middleware/validation');
const { authenticate } = require('../middleware/auth');
const db = require('../config/database');

router.get('/', authenticate, async (req, res, next) => {
  try {
    const { schoolId, sessionId, type, role } = req.query;
    const sid = schoolId || req.user.school_id;
    let where = ['school_id = $1', 'is_published = TRUE']; const params = [sid];
    if (type) { where.push(`notice_type = $${params.length+1}`); params.push(type); }
    if (role && role !== 'all') { where.push(`(target_role = $${params.length+1} OR target_role = 'all')`); params.push(role); }
    const { rows } = await db.query(
      `SELECT * FROM notices WHERE ${where.join(' AND ')} ORDER BY published_at DESC LIMIT 50`, params
    );
    res.json(rows);
  } catch(e){ next(e); }
});

router.post('/', authenticate, async (req, res, next) => {
  try {
    const { schoolId, sessionId, title, content, noticeType, targetRole, expiresAt } = req.body;
    const sid = schoolId || req.user.school_id;
    const { rows } = await db.query(
      `INSERT INTO notices (school_id, session_id, title, content, notice_type, target_role, expires_at, created_by)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
      [sid, sessionId, title, content, noticeType || 'general', targetRole || 'all', expiresAt, req.user.id]
    );
    res.status(201).json(rows[0]);
  } catch(e){ next(e); }
});

router.delete('/:id', uuidParam, authenticate, async (req, res, next) => {
  try {
    await db.query(`UPDATE notices SET is_published=FALSE WHERE id=$1`, [req.params.id]);
    res.json({ message: 'Notice removed' });
  } catch(e){ next(e); }
});

module.exports = router;
