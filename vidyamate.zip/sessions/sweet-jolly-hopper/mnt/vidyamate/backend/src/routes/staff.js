const router = require('express').Router();
const { uuidParam } = require('../middleware/validation');
const { authenticate, authorize } = require('../middleware/auth');
const { getStaff, getOneStaff, createStaff, updateStaff, deleteStaff, resetStaffPassword } = require('../controllers/staffController');

router.get('/',          authenticate, getStaff);
router.get('/:id', uuidParam,       authenticate, getOneStaff);
router.post('/',         authenticate, authorize('super_admin','org_admin','principal'), createStaff);
router.put('/:id', uuidParam,       authenticate, authorize('super_admin','org_admin','principal'), updateStaff);
router.delete('/:id', uuidParam,    authenticate, authorize('super_admin','org_admin','principal'), deleteStaff);
router.post('/:id/reset-password', authenticate, authorize('super_admin','org_admin','principal'), resetStaffPassword);

module.exports = router;

// Upload staff photo
router.post('/:id/upload-photo', authenticate, async (req, res, next) => {
  const { uploadPhoto, getFileUrl } = require('../services/uploadService');
  uploadPhoto(req, res, async (err) => {
    if (err) return res.status(400).json({ error: err.message });
    if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
    const url = getFileUrl(req.file.path);
    const db  = require('../config/database');
    await db.query('UPDATE staff SET photo_url=$1 WHERE id=$2', [url, req.params.id]);
    res.json({ url });
  });
});
