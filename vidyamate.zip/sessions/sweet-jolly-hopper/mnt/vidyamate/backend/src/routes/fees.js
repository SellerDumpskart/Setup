const router = require('express').Router();
const { authenticate, authorize } = require('../middleware/auth');
const { collectPaymentRules } = require('../middleware/validation');
const { getFeeHeads, createFeeHead, getStudentFees, assignFees, collectPayment, getPayments, applyDiscount, getDefaulters } = require('../controllers/feesController');

router.get('/heads',              authenticate, getFeeHeads);
router.post('/heads',             authenticate, authorize('super_admin','org_admin','principal','accountant'), createFeeHead);
router.get('/student/:studentId', authenticate, getStudentFees);
router.post('/assign',            authenticate, authorize('super_admin','org_admin','principal','accountant'), assignFees);
router.post('/collect',           authenticate, authorize('super_admin','org_admin','principal','accountant'), collectPaymentRules, collectPayment);
router.get('/payments',           authenticate, getPayments);
router.post('/discount',          authenticate, authorize('super_admin','org_admin','principal','accountant'), applyDiscount);
router.get('/defaulters',         authenticate, getDefaulters);

module.exports = router;
