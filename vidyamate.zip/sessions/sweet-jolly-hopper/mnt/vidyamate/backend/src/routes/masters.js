const router = require('express').Router();
const { uuidParam } = require('../middleware/validation');
const { authenticate, authorize } = require('../middleware/auth');
const db = require('../config/database');

router.get('/', authenticate, async (req, res, next) => {
  try {
    const { orgId, type } = req.query;
    const oid = orgId || req.user.organization_id;
    let where = ['organization_id = $1']; const params = [oid];
    if (type) { where.push(`master_type = $2`); params.push(type); }
    const { rows } = await db.query(
      `SELECT * FROM masters WHERE ${where.join(' AND ')} ORDER BY master_type, sort_order, value`, params
    );
    // Group by type
    const grouped = rows.reduce((acc, r) => {
      if (!acc[r.master_type]) acc[r.master_type] = [];
      acc[r.master_type].push(r);
      return acc;
    }, {});
    res.json(grouped);
  } catch(e){ next(e); }
});

router.post('/', authenticate, authorize('super_admin','org_admin'), async (req, res, next) => {
  try {
    const { orgId, masterType, value, code } = req.body;
    const oid = orgId || req.user.organization_id;
    const { rows } = await db.query(
      `INSERT INTO masters (organization_id, master_type, value, code)
       VALUES ($1,$2,$3,$4) RETURNING *`,
      [oid, masterType, value, code]
    );
    res.status(201).json(rows[0]);
  } catch(e){ next(e); }
});

router.put('/:id', uuidParam, authenticate, authorize('super_admin','org_admin'), async (req, res, next) => {
  try {
    const { value, code, status } = req.body;
    const { rows } = await db.query(
      `UPDATE masters SET value=$1, code=$2, status=$3 WHERE id=$4 RETURNING *`,
      [value, code, status, req.params.id]
    );
    res.json(rows[0]);
  } catch(e){ next(e); }
});

router.delete('/:id', uuidParam, authenticate, authorize('super_admin','org_admin'), async (req, res, next) => {
  try {
    await db.query(`UPDATE masters SET status='inactive' WHERE id=$1`, [req.params.id]);
    res.json({ message: 'Master value removed' });
  } catch(e){ next(e); }
});

module.exports = router;
