const router = require('express').Router();
const { uuidParam } = require('../middleware/validation');
const { authenticate, authorize } = require('../middleware/auth');
const db = require('../config/database');

// GET /transport — list all routes for school
router.get('/', authenticate, async (req, res, next) => {
  try {
    const sid = req.query.schoolId || req.user.school_id;
    const { rows } = await db.query(
      `SELECT tr.*,
              st.first_name || ' ' || COALESCE(st.last_name,'') as driver_name,
              (SELECT COUNT(*) FROM transport_stops WHERE route_id = tr.id) as stop_count,
              (SELECT COUNT(*) FROM student_transport WHERE route_id = tr.id AND status = 'active') as enrolled_students
       FROM transport_routes tr
       LEFT JOIN staff st ON tr.driver_id = st.id
       WHERE tr.school_id = $1 ORDER BY tr.route_no`, [sid]
    );
    res.json(rows);
  } catch (e) { next(e); }
});

// GET /transport/:id/stops
router.get('/:id/stops', authenticate, async (req, res, next) => {
  try {
    const { rows } = await db.query(
      `SELECT * FROM transport_stops WHERE route_id = $1 ORDER BY stop_order`,
      [req.params.id]
    );
    res.json(rows);
  } catch (e) { next(e); }
});

// GET /transport/:id/students
router.get('/:id/students', authenticate, async (req, res, next) => {
  try {
    const { rows } = await db.query(
      `SELECT st.*, s.first_name, s.last_name, s.student_code, s.roll_number,
              c.class_name, c.section
       FROM student_transport st
       JOIN students s ON st.student_id = s.id
       LEFT JOIN classes c ON s.class_id = c.id
       WHERE st.route_id = $1 AND st.status = 'active'
       ORDER BY c.class_name, s.roll_number`, [req.params.id]
    );
    res.json(rows);
  } catch (e) { next(e); }
});

// POST /transport — create route
router.post('/', authenticate, authorize('super_admin','org_admin','principal'), async (req, res, next) => {
  try {
    const { schoolId, routeNo, routeName, vehicleNo, capacity, monthlyFee, driverId } = req.body;
    const sid = schoolId || req.user.school_id;
    const { rows } = await db.query(
      `INSERT INTO transport_routes (school_id, route_no, route_name, vehicle_no, capacity, monthly_fee, driver_id)
       VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
      [sid, routeNo, routeName, vehicleNo, capacity || 40, monthlyFee || 0, driverId]
    );
    res.status(201).json(rows[0]);
  } catch (e) { next(e); }
});

// PUT /transport/:id
router.put('/:id', uuidParam, authenticate, authorize('super_admin','org_admin','principal'), async (req, res, next) => {
  try {
    const { routeNo, routeName, vehicleNo, capacity, monthlyFee, driverId, status } = req.body;
    const { rows } = await db.query(
      `UPDATE transport_routes SET route_no=$1, route_name=$2, vehicle_no=$3,
       capacity=$4, monthly_fee=$5, driver_id=$6, status=$7
       WHERE id=$8 RETURNING *`,
      [routeNo, routeName, vehicleNo, capacity, monthlyFee, driverId, status || 'active', req.params.id]
    );
    res.json(rows[0]);
  } catch (e) { next(e); }
});

// POST /transport/:id/stops — add stop to route
router.post('/:id/stops', authenticate, authorize('super_admin','org_admin','principal'), async (req, res, next) => {
  try {
    const { stopName, stopOrder, pickupTime, dropTime, latitude, longitude } = req.body;
    const { rows } = await db.query(
      `INSERT INTO transport_stops (route_id, stop_name, stop_order, pickup_time, drop_time, latitude, longitude)
       VALUES ($1,$2,$3,$4,$5,$6,$7)
       ON CONFLICT (route_id, stop_order)
       DO UPDATE SET stop_name=$2, pickup_time=$4, drop_time=$5
       RETURNING *`,
      [req.params.id, stopName, stopOrder, pickupTime, dropTime, latitude, longitude]
    );
    res.status(201).json(rows[0]);
  } catch (e) { next(e); }
});

// DELETE /transport/stops/:stopId
router.delete('/stops/:stopId', authenticate, authorize('super_admin','org_admin','principal'), async (req, res, next) => {
  try {
    await db.query(`DELETE FROM transport_stops WHERE id=$1`, [req.params.stopId]);
    res.json({ message: 'Stop removed' });
  } catch (e) { next(e); }
});

// POST /transport/allocate — allocate student to route
router.post('/allocate', authenticate, authorize('super_admin','org_admin','principal','accountant'), async (req, res, next) => {
  try {
    const { studentId, routeId, sessionId, stopName, pickupTime, dropTime } = req.body;
    const { rows } = await db.query(
      `INSERT INTO student_transport (student_id, route_id, session_id, stop_name, pickup_time, drop_time)
       VALUES ($1,$2,$3,$4,$5,$6)
       ON CONFLICT (student_id, session_id)
       DO UPDATE SET route_id=$2, stop_name=$4, pickup_time=$5, drop_time=$6, status='active'
       RETURNING *`,
      [studentId, routeId, sessionId, stopName, pickupTime, dropTime]
    );
    res.status(201).json(rows[0]);
  } catch (e) { next(e); }
});

// PUT /transport/allocate/:id/remove
router.put('/allocate/:id/remove', authenticate, async (req, res, next) => {
  try {
    await db.query(`UPDATE student_transport SET status='inactive' WHERE id=$1`, [req.params.id]);
    res.json({ message: 'Student removed from route' });
  } catch (e) { next(e); }
});

// GET /transport/vehicle-maintenance — maintenance records
router.get('/maintenance', authenticate, async (req, res, next) => {
  try {
    const sid = req.query.schoolId || req.user.school_id;
    const { rows } = await db.query(
      `SELECT * FROM vehicle_maintenance WHERE school_id=$1 ORDER BY service_date DESC`, [sid]
    );
    res.json(rows);
  } catch (e) { next(e); }
});

router.post('/maintenance', authenticate, authorize('super_admin','org_admin','principal'), async (req, res, next) => {
  try {
    const { schoolId, vehicleNo, serviceType, serviceDate, nextServiceDate, cost, remarks } = req.body;
    const sid = schoolId || req.user.school_id;
    const { rows } = await db.query(
      `INSERT INTO vehicle_maintenance (school_id, vehicle_no, service_type, service_date, next_service_date, cost, remarks)
       VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
      [sid, vehicleNo, serviceType, serviceDate, nextServiceDate, cost || 0, remarks]
    );
    res.status(201).json(rows[0]);
  } catch (e) { next(e); }
});

module.exports = router;
