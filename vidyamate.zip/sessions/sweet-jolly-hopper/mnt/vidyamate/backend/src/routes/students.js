const router = require('express').Router();
const { authenticate, authorize } = require('../middleware/auth');
const { createStudentRules, uuidParam } = require('../middleware/validation');
const { getStudents, getStudent, createStudent, updateStudent, deleteStudent } = require('../controllers/studentController');
const db = require('../config/database');

router.get('/',      authenticate, getStudents);
router.get('/:id',   authenticate, getStudent);
router.post('/',     authenticate, authorize('super_admin','org_admin','principal','accountant'), createStudentRules, createStudent);
router.put('/:id',   authenticate, authorize('super_admin','org_admin','principal'), updateStudent);
router.delete('/:id',authenticate, authorize('super_admin','org_admin','principal'), deleteStudent);

// ── Bulk import ───────────────────────────────────────────────────────────────
router.post('/bulk-import',
  authenticate,
  authorize('super_admin', 'org_admin', 'principal'),
  async (req, res, next) => {
    try {
      const { students: rows, schoolId, sessionId } = req.body;
      const sid = schoolId || req.user.school_id;
      if (!Array.isArray(rows) || rows.length === 0)
        return res.status(400).json({ error: 'No student data provided' });

      const { withTransaction } = require('../config/database');
      const { v4: uuidv4 } = require('uuid');

      // Build class lookup: "ClassName-Section" and "ClassName" → id
      const { rows: classes } = await db.query(
        `SELECT id, class_name, section FROM classes WHERE school_id = $1`, [sid]
      );
      const classMap = {};
      classes.forEach(c => {
        const withSec = `${c.class_name}-${(c.section || '').trim()}`.toUpperCase();
        const noSec   = c.class_name.trim().toUpperCase();
        classMap[withSec] = c.id;
        if (!classMap[noSec]) classMap[noSec] = c.id; // first match wins
      });

      // Validate all rows first (client-side-style, fast fail per row)
      const validRows  = [];
      const validationErrors = [];

      rows.forEach((row, idx) => {
        const rowNum = idx + 2; // +1 header, +1 for 1-based
        const errs = [];

        if (!String(row.firstName || '').trim())
          errs.push('First Name is required');
        if (!['male', 'female', 'other'].includes(String(row.gender || '').toLowerCase()))
          errs.push('Gender must be male / female / other');
        const phone = String(row.fatherPhone || '').replace(/\D/g, '');
        if (!phone || phone.length !== 10)
          errs.push('Father Phone must be 10 digits');
        if (row.aadhaarNo && !/^\d{12}$/.test(String(row.aadhaarNo).replace(/\s/g, '')))
          errs.push('Aadhaar must be 12 digits');

        const className = String(row.className || '').trim();
        if (!className) {
          errs.push('Class is required');
        } else {
          const key = row.section
            ? `${className}-${String(row.section).trim()}`.toUpperCase()
            : className.toUpperCase();
          const classId = classMap[key] || classMap[className.toUpperCase()];
          if (!classId) {
            errs.push(`Class "${className}${row.section ? '-' + row.section : ''}" not found in this school`);
          } else {
            row._classId = classId;
          }
        }

        if (errs.length) {
          validationErrors.push({ row: rowNum, reason: errs.join('; ') });
        } else {
          validRows.push({ ...row, _rowNum: rowNum });
        }
      });

      // Get current student count for sequential codes
      const { rows: cnt } = await db.query(
        'SELECT COUNT(*) FROM students WHERE school_id = $1', [sid]
      );
      let seq   = parseInt(cnt[0].count) + 1;
      const yr  = new Date().getFullYear();

      let importedCount = 0;
      const insertErrors = [];

      for (const s of validRows) {
        try {
          await withTransaction(async (client) => {
            // Insert parent
            const parentId = uuidv4();
            await client.query(
              `INSERT INTO parents
                 (id, school_id, father_name, father_phone, mother_name, mother_phone, address)
               VALUES ($1,$2,$3,$4,$5,$6,$7)`,
              [parentId, sid,
               s.fatherName || null,
               String(s.fatherPhone).replace(/\D/g, ''),
               s.motherName  || null,
               s.motherPhone ? String(s.motherPhone).replace(/\D/g, '') : null,
               s.address     || null]
            );

            // Insert student
            const studentCode = `STU-${yr}-${String(seq).padStart(4, '0')}`;
            await client.query(
              `INSERT INTO students
                 (id, school_id, session_id, class_id, parent_id,
                  student_code, first_name, last_name, date_of_birth, gender,
                  blood_group, category, religion, aadhaar_no,
                  admission_date, status)
               VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,CURRENT_DATE,'active')`,
              [uuidv4(), sid, sessionId, s._classId, parentId,
               studentCode,
               String(s.firstName).trim(),
               s.lastName ? String(s.lastName).trim() : null,
               s.dateOfBirth || null,
               String(s.gender).toLowerCase(),
               s.bloodGroup  || null,
               s.category    || null,
               s.religion    || null,
               s.aadhaarNo   ? String(s.aadhaarNo).replace(/\s/g, '') : null]
            );

            seq++;
            importedCount++;
          });
        } catch (e) {
          insertErrors.push({
            row: s._rowNum,
            reason: e.detail || e.constraint
              ? `DB error: ${e.detail || e.message}`
              : e.message,
          });
        }
      }

      const allErrors = [...validationErrors, ...insertErrors]
        .sort((a, b) => a.row - b.row);

      res.json({
        imported: importedCount,
        failed:   allErrors.length,
        total:    rows.length,
        errors:   allErrors,
      });
    } catch (e) { next(e); }
  }
);

// Roll number allotment
router.get('/:classId/roll-numbers', authenticate, async (req, res, next) => {
  try {
    const { sessionId } = req.query;
    const { rows } = await db.query(
      `SELECT s.id, s.first_name, s.last_name, s.student_code,
              COALESCE(rn.roll_no, s.roll_number) as roll_number
       FROM students s
       LEFT JOIN roll_numbers rn ON rn.student_id = s.id AND rn.session_id = $2
       WHERE s.class_id = $1 AND s.status = 'active'
       ORDER BY roll_number, s.first_name`,
      [req.params.classId, sessionId]
    );
    res.json(rows);
  } catch (e) { next(e); }
});

router.post('/:classId/roll-numbers', authenticate, authorize('super_admin','org_admin','principal'), async (req, res, next) => {
  try {
    const { assignments, sessionId } = req.body;
    // assignments: [{ studentId, rollNo }]
    const { withTransaction } = require('../config/database');
    await withTransaction(async (client) => {
      for (const a of assignments) {
        await client.query(
          `INSERT INTO roll_numbers (student_id, class_id, session_id, roll_no)
           VALUES ($1,$2,$3,$4)
           ON CONFLICT (class_id, session_id, roll_no) DO UPDATE SET roll_no = EXCLUDED.roll_no`,
          [a.studentId, req.params.classId, sessionId, a.rollNo]
        );
        // Also update denormalized roll_number on student
        await client.query(
          `UPDATE students SET roll_number = $1 WHERE id = $2`, [a.rollNo, a.studentId]
        );
      }
    });
    res.json({ message: `Roll numbers saved for ${assignments.length} students` });
  } catch (e) { next(e); }
});

module.exports = router;

// Upload student photo
router.post('/:id/upload-photo', authenticate, async (req, res, next) => {
  const { uploadPhoto, getFileUrl } = require('../services/uploadService');
  uploadPhoto(req, res, async (err) => {
    if (err) return res.status(400).json({ error: err.message });
    if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
    const url = getFileUrl(req.file.path);
    const db  = require('../config/database');
    const { rows } = await db.query('UPDATE students SET photo_url=$1 WHERE id=$2 RETURNING photo_url', [url, req.params.id]);
    res.json({ url: rows[0]?.photo_url });
  });
});

// Upload student document
router.post('/:id/upload-document', authenticate, async (req, res, next) => {
  const { uploadDocument, getFileUrl } = require('../services/uploadService');
  uploadDocument(req, res, async (err) => {
    if (err) return res.status(400).json({ error: err.message });
    if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
    const url      = getFileUrl(req.file.path);
    const docType  = req.body.docType || 'document';
    const colMap   = { birthCert:'birth_cert_url', tc:'tc_url', aadhaar:'aadhaar_url', casteCert:'caste_cert_url', incomeCert:'income_cert_url' };
    const col      = colMap[docType];
    const db       = require('../config/database');
    if (col) await db.query(`UPDATE students SET ${col}=$1 WHERE id=$2`, [url, req.params.id]);
    res.json({ url, docType });
  });
});
