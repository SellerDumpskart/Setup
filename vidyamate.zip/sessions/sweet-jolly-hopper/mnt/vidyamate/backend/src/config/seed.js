require('dotenv').config();
const { Pool } = require('pg');
const fs   = require('fs');
const path = require('path');

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

const SEEDS_DIR = path.join(__dirname, '../../../database/seeds');

async function runSeeds() {
  const client = await pool.connect();
  try {
    const files = fs.readdirSync(SEEDS_DIR).filter(f => f.endsWith('.sql')).sort();

    for (const file of files) {
      console.log(`▶  Running seed: ${file}`);
      const sql = fs.readFileSync(path.join(SEEDS_DIR, file), 'utf8');

      await client.query('BEGIN');
      try {
        await client.query(sql);
        await client.query('COMMIT');
        console.log(`✅  ${file} seeded`);
      } catch (err) {
        await client.query('ROLLBACK');
        // Seeds might fail on re-run due to unique constraints — that's OK
        console.warn(`⚠️  Seed ${file} warning:`, err.message);
      }
    }
    console.log('\n🌱  Seeding complete');
  } finally {
    client.release();
    await pool.end();
  }
}

runSeeds().catch(err => { console.error(err); process.exit(1); });
