require('dotenv').config();
const { Pool } = require('pg');
const fs   = require('fs');
const path = require('path');

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

// Resolve migrations dir — works in local dev (monorepo) AND Docker/Railway
// Local: __dirname = vidyamate/backend/src/config  →  ../../../ = vidyamate/
// Docker: WORKDIR=/app, migrations copied to /app/database/migrations
const _candidateDirs = [
  path.join(__dirname, '../../../database/migrations'),  // local monorepo
  path.join(process.cwd(), 'database/migrations'),       // Docker / Railway
  process.env.MIGRATIONS_DIR,                            // explicit override
].filter(Boolean);
const MIGRATIONS_DIR = _candidateDirs.find(p => fs.existsSync(p));
if (!MIGRATIONS_DIR) {
  console.error('❌  Cannot locate migrations directory. Tried:\n  ' + _candidateDirs.join('\n  '));
  process.exit(1);
}

async function runMigrations() {
  const client = await pool.connect();
  try {
    // Create migrations tracking table
    await client.query(`
      CREATE TABLE IF NOT EXISTS schema_migrations (
        id         SERIAL PRIMARY KEY,
        filename   VARCHAR(255) UNIQUE NOT NULL,
        applied_at TIMESTAMP DEFAULT NOW()
      )
    `);

    // Get already applied migrations
    const { rows } = await client.query('SELECT filename FROM schema_migrations');
    const applied = new Set(rows.map(r => r.filename));

    // Read and sort migration files
    const files = fs.readdirSync(MIGRATIONS_DIR)
      .filter(f => f.endsWith('.sql'))
      .sort();

    for (const file of files) {
      if (applied.has(file)) {
        console.log(`⏭  Skipping ${file} (already applied)`);
        continue;
      }

      console.log(`▶  Running migration: ${file}`);
      const sql = fs.readFileSync(path.join(MIGRATIONS_DIR, file), 'utf8');

      await client.query('BEGIN');
      try {
        await client.query(sql);
        await client.query('INSERT INTO schema_migrations (filename) VALUES ($1)', [file]);
        await client.query('COMMIT');
        console.log(`✅  ${file} applied successfully`);
      } catch (err) {
        await client.query('ROLLBACK');
        console.error(`❌  Migration ${file} failed:`, err.message);
        process.exit(1);
      }
    }

    console.log('\n🎉  All migrations applied successfully');
  } finally {
    client.release();
    await pool.end();
  }
}

runMigrations().catch(err => { console.error(err); process.exit(1); });
