#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════
# VidyaMate — Railway Deployment Script
# Run this from the vidyamate/ project root.
# ═══════════════════════════════════════════════════════════
set -e

BOLD='\033[1m'
GREEN='\033[0;32m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # no colour

step() { echo -e "\n${CYAN}${BOLD}▶ $1${NC}"; }
ok()   { echo -e "${GREEN}✅ $1${NC}"; }
warn() { echo -e "${YELLOW}⚠  $1${NC}"; }
die()  { echo -e "${RED}❌ $1${NC}"; exit 1; }

echo -e "${BOLD}"
echo "  ██╗   ██╗██╗██████╗ ██╗   ██╗ █████╗ ███╗   ███╗ █████╗ ████████╗███████╗"
echo "  ██║   ██║██║██╔══██╗╚██╗ ██╔╝██╔══██╗████╗ ████║██╔══██╗╚══██╔══╝██╔════╝"
echo "  ██║   ██║██║██║  ██║ ╚████╔╝ ███████║██╔████╔██║███████║   ██║   █████╗  "
echo "  ╚██╗ ██╔╝██║██║  ██║  ╚██╔╝  ██╔══██║██║╚██╔╝██║██╔══██║   ██║   ██╔══╝  "
echo "   ╚████╔╝ ██║██████╔╝   ██║   ██║  ██║██║ ╚═╝ ██║██║  ██║   ██║   ███████╗"
echo "    ╚═══╝  ╚═╝╚═════╝    ╚═╝   ╚═╝  ╚═╝╚═╝     ╚═╝╚═╝  ╚═╝   ╚═╝   ╚══════╝"
echo -e "${NC}"
echo -e "  ${BOLD}Railway Deployment Script${NC}"
echo "  ──────────────────────────────────────────────────────"

# ── 0. Prerequisites ─────────────────────────────────────────
step "Checking prerequisites"

command -v node >/dev/null 2>&1 || die "Node.js is required. Install from https://nodejs.org"
command -v git  >/dev/null 2>&1 || die "Git is required."

if ! command -v railway >/dev/null 2>&1; then
  step "Installing Railway CLI"
  npm install -g @railway/cli
  ok "Railway CLI installed"
fi

ok "All prerequisites met"

# ── 1. Git init ──────────────────────────────────────────────
step "Initialising Git repository"

if [ ! -d ".git" ]; then
  git init
  git add -A
  git commit -m "chore: initial VidyaMate commit for Railway deployment"
  ok "Git repository initialised"
else
  # Make sure everything is committed
  if ! git diff-index --quiet HEAD -- 2>/dev/null; then
    git add -A
    git commit -m "chore: pre-deploy snapshot"
    ok "Changes committed"
  else
    ok "Git repository already initialised — nothing to commit"
  fi
fi

# ── 2. Railway login ─────────────────────────────────────────
step "Logging in to Railway (browser will open)"
railway login
ok "Logged in"

# ── 3. Create Railway project ────────────────────────────────
step "Creating Railway project"
railway init --name vidyamate
ok "Project created"

# ── 4. Add PostgreSQL ────────────────────────────────────────
step "Adding PostgreSQL database plugin"
railway add --plugin postgresql
ok "PostgreSQL added — DATABASE_URL will be injected automatically"

# ── 5. Generate secrets ──────────────────────────────────────
step "Generating cryptographic secrets"

JWT_SECRET=$(node -e "process.stdout.write(require('crypto').randomBytes(64).toString('hex'))")
JWT_REFRESH_SECRET=$(node -e "process.stdout.write(require('crypto').randomBytes(64).toString('hex'))")
DEVICE_SECRET_KEY=$(node -e "process.stdout.write(require('crypto').randomBytes(32).toString('hex'))")

echo ""
echo -e "${YELLOW}  Save these somewhere safe — they won't be shown again:${NC}"
echo "  JWT_SECRET         = $JWT_SECRET"
echo "  JWT_REFRESH_SECRET = $JWT_REFRESH_SECRET"
echo "  DEVICE_SECRET_KEY  = $DEVICE_SECRET_KEY"
echo ""

# ── 6. Set environment variables ────────────────────────────
step "Configuring environment variables"

# We set FRONTEND_URL to a placeholder; update it after first deploy
railway variables set \
  NODE_ENV=production \
  PORT=4000 \
  JWT_SECRET="$JWT_SECRET" \
  JWT_REFRESH_SECRET="$JWT_REFRESH_SECRET" \
  JWT_EXPIRES_IN=15m \
  JWT_REFRESH_EXPIRES_IN=7d \
  STORAGE_TYPE=local \
  UPLOAD_DIR=/app/uploads \
  MAX_FILE_SIZE=10485760 \
  DEVICE_SECRET_KEY="$DEVICE_SECRET_KEY" \
  FROM_EMAIL=noreply@vidyamate.in \
  FROM_NAME=VidyaMate

ok "Environment variables set"

# ── 7. Deploy ────────────────────────────────────────────────
step "Deploying to Railway (Docker build — this takes ~3-5 minutes)"
railway up --detach
ok "Deployment triggered"

# ── 8. Get URL ───────────────────────────────────────────────
step "Fetching deployment URL"
sleep 5

DOMAIN=$(railway domain 2>/dev/null || echo "")

if [ -n "$DOMAIN" ]; then
  echo ""
  echo -e "${GREEN}${BOLD}  🎉  VidyaMate is deploying!${NC}"
  echo -e "  ${BOLD}URL:${NC} https://$DOMAIN"
  echo ""
  echo -e "  ${YELLOW}While it builds, update FRONTEND_URL:${NC}"
  echo "  railway variables set FRONTEND_URL=https://$DOMAIN"
  echo ""
else
  echo ""
  echo -e "${GREEN}${BOLD}  🎉  Deployment triggered!${NC}"
  echo ""
  echo -e "  ${BOLD}Next steps:${NC}"
  echo "  1. Run: railway open   (to see the Railway dashboard)"
  echo "  2. Once deployed, copy your Railway URL (e.g. vidyamate.up.railway.app)"
  echo "  3. Run: railway variables set FRONTEND_URL=https://<your-railway-url>"
  echo "  4. Redeploy: railway up --detach"
  echo ""
fi

echo -e "  ${BOLD}Monitor build logs:${NC}  railway logs"
echo -e "  ${BOLD}Open dashboard:${NC}     railway open"
echo ""
echo -e "${BOLD}  Default login: admin@vidyamate.in / Admin@123${NC}"
echo -e "${YELLOW}  ⚠  Change the admin password immediately after first login!${NC}"
echo ""
