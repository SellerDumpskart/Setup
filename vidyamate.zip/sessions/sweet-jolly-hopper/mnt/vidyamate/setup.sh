#!/bin/bash
# ============================================================
# VidyaMate — One-command Setup Script
# Run: chmod +x setup.sh && ./setup.sh
# ============================================================
set -e

GREEN='\033[0;32m'
TEAL='\033[0;36m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${TEAL}"
echo "╔══════════════════════════════════════════╗"
echo "║     VidyaMate — School ERP Setup         ║"
echo "╚══════════════════════════════════════════╝"
echo -e "${NC}"

# ── Check prerequisites ──────────────────────────────────
echo -e "${TEAL}Checking prerequisites...${NC}"

command -v node  >/dev/null 2>&1 || { echo -e "${RED}Node.js not found. Install Node.js 18+${NC}"; exit 1; }
command -v npm   >/dev/null 2>&1 || { echo -e "${RED}npm not found.${NC}"; exit 1; }
command -v psql  >/dev/null 2>&1 || { echo -e "${RED}PostgreSQL not found. Install PostgreSQL 14+${NC}"; exit 1; }

NODE_VER=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VER" -lt 18 ]; then
  echo -e "${RED}Node.js 18+ required. Found: $(node -v)${NC}"
  exit 1
fi

echo -e "${GREEN}✓ Node.js $(node -v)${NC}"
echo -e "${GREEN}✓ npm $(npm -v)${NC}"

# ── Backend setup ────────────────────────────────────────
echo ""
echo -e "${TEAL}Installing backend dependencies...${NC}"
cd backend
npm install --silent
echo -e "${GREEN}✓ Backend dependencies installed${NC}"

# ── Create .env from example ─────────────────────────────
if [ ! -f .env ]; then
  cp .env.example .env
  echo -e "${GREEN}✓ Created backend/.env from template${NC}"
  echo -e "  Edit ${TEAL}backend/.env${NC} to set your database credentials"
fi

# ── Frontend setup ───────────────────────────────────────
echo ""
echo -e "${TEAL}Installing frontend dependencies...${NC}"
cd ../frontend
npm install --silent
echo -e "${GREEN}✓ Frontend dependencies installed${NC}"

cd ..

# ── Database setup ───────────────────────────────────────
echo ""
echo -e "${TEAL}Setting up database...${NC}"

# Try to create database and user
psql -U postgres -c "CREATE DATABASE vidyamate;" 2>/dev/null && echo -e "${GREEN}✓ Database 'vidyamate' created${NC}" || echo "  Database already exists"
psql -U postgres -c "CREATE USER vidyamate_user WITH PASSWORD 'vidyamate_pass';" 2>/dev/null && echo -e "${GREEN}✓ User created${NC}" || echo "  User already exists"
psql -U postgres -c "GRANT ALL PRIVILEGES ON DATABASE vidyamate TO vidyamate_user;" 2>/dev/null
psql -U postgres -c "ALTER DATABASE vidyamate OWNER TO vidyamate_user;" 2>/dev/null

# ── Run migrations ───────────────────────────────────────
echo ""
echo -e "${TEAL}Running database migrations...${NC}"
cd backend
npm run migrate
echo -e "${GREEN}✓ Migrations complete${NC}"

# ── Run seeds ────────────────────────────────────────────
echo ""
echo -e "${TEAL}Seeding default data...${NC}"
npm run seed
echo -e "${GREEN}✓ Seed data inserted${NC}"

cd ..

# ── Create uploads folders ───────────────────────────────
mkdir -p backend/uploads/{students,staff,documents,bills,profiles,content,pdfs,exports}
mkdir -p backend/logs
touch backend/uploads/.gitkeep
echo -e "${GREEN}✓ Upload directories created${NC}"

# ── Done ─────────────────────────────────────────────────
echo ""
echo -e "${GREEN}╔══════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║         Setup Complete! 🎉               ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════╝${NC}"
echo ""
echo -e "To start VidyaMate:"
echo ""
echo -e "  ${TEAL}Terminal 1 (Backend):${NC}  cd backend && npm run dev"
echo -e "  ${TEAL}Terminal 2 (Frontend):${NC} cd frontend && npm start"
echo ""
echo -e "Then open: ${TEAL}http://localhost:3000${NC}"
echo ""
echo -e "Login with:"
echo -e "  Email:    ${TEAL}admin@vidyamate.in${NC}"
echo -e "  Password: ${TEAL}Admin@123${NC}"
echo ""
