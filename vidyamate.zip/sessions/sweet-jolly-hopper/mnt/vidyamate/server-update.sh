#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════
# VidyaMate — Update Script (run on server after git push)
# Usage: bash /var/www/vidyamate/server-update.sh
# ═══════════════════════════════════════════════════════════
set -euo pipefail
APP_DIR="/var/www/vidyamate"

BOLD='\033[1m'; GREEN='\033[0;32m'; CYAN='\033[0;36m'; NC='\033[0m'
step() { echo -e "\n${CYAN}${BOLD}▶  $1${NC}"; }
ok()   { echo -e "${GREEN}✅  $1${NC}"; }

step "Pulling latest code"
git -C "$APP_DIR" pull
ok "Code updated"

step "Installing backend deps"
cd "$APP_DIR/backend" && npm ci --only=production --silent
ok "Deps updated"

step "Building frontend"
cd "$APP_DIR/frontend"
npm ci --legacy-peer-deps --silent
CI=false npm run build

step "Copying build"
rm -rf "$APP_DIR/backend/public"/* && cp -r "$APP_DIR/frontend/build/." "$APP_DIR/backend/public/"
ok "Frontend updated"

step "Running migrations"
cd "$APP_DIR/backend" && node src/config/migrate.js
ok "Migrations done"

step "Reloading PM2"
pm2 reload "$APP_DIR/ecosystem.config.js" --update-env
ok "App reloaded (zero downtime)"

echo -e "\n${GREEN}${BOLD}✅  Update complete!${NC}\n"
